# THE BLOOM WARS — Player AI Difficulty Tiers Plan v1 (Easy / Moderate / Hard)

**Written 1 Sep 2026, at Maxime's direction. Status (updated 2 Sep 2026): BUILT — Phases A–D shipped and committed; see §12 at the end and the build record `claude/Bloom_Wars_Build_Log_Addendum_PlayerAiTiers_Telemetry_UI_01Sep2026.md`. Phase E (PvP wiring) remains post-EA. Sections 1–11 are the plan as written; where the build diverged, §12 says so.** His ask, verbatim: *"plan a update to playertest ai so it can play 3 way. easy, moderate, hard. hard being tactical genius. i know i havent made my bit able to use spell and ability yet. its part of your task to determine what will be needed and how. the new bot will ship with the pvp update. but i need a good bot at EA time to test the game. before the tester get their hand on it. i dont want to spend days adjusting difficulty. it will be another claude job to test the game and adjust mission difficulty off those bot."*

**Scope flag, up front, per this project's own rule.** Difficulty tiers are a new concept — nothing in the code or any prior doc has a notion of bot skill level, and the whole balance rule this project runs on (the ≤15% bot-win-rate ceiling) is calibrated to one specific bot. A stronger bot doesn't just change numbers, it changes what the rule means. §6 below proposes the replacement rule; that's Maxime's call, and it touches `Bloom_Wars_Consolidated_Build_Plan_Progress.md`'s own stated rule and the EA Launch Plan's Week 3 balance-triage slot. Everything else in this plan is additive engineering inside the existing `src/sim/playerAi/` engine, not a rewrite.

Companion docs written the same day: `claude/Bloom_Wars_Player_Telemetry_Plan_v1.md` (the statistics side — it shares one data shape with this plan on purpose, see §8) and `claude/Bloom_Wars_First_Game_Dev_Feature_Gap_Report_1Sep2026.md`.

---

## 0. Plain-language glossary (terms used below)

- **Bot / Player AI** — the code in `src/sim/playerAi/` that plays *your* side of a battle in headless tests. It never runs in the real game today; the enemy has its own separate brain (`src/engine/ai.ts`).
- **Heuristic** — a hand-written rule of thumb ("if HP under 30% and an enemy can see me, retreat"). The whole bot is a stack of these in a fixed priority order.
- **Profile** — a settings sheet the bot reads: which rules are switched on, what thresholds they use. Three profiles = three tiers.
- **Threat map** — for every tile on the board, "how much damage could enemies land here next turn if I stood here." Computed by asking each enemy where it can move and what it can hit.
- **One-ply lookahead** — before committing a move, simulate the enemy's next turn against the candidate board and see what happens. "Ply" = one side's turn.
- **Seeded RNG** — a random-number source started from a fixed number so the same run replays identically. Needed for reproducible test batches.
- **Harness** — the script that drives a headless mission (`npm run sim`, `npm run sim:batch`).

---

## 1. Where the bot actually stands today (read from the code, not the docs)

Verified against the staged source (`src/sim/playerAi/index.ts` 1062 lines, `combat.ts` 779, `support.ts` 83, `types.ts` 117; harness `src/sim/run.ts` and `runBatch.ts`):

**What it does:** a single pure function, `decidePlayerAiAction(map, unit, allUnits, turn, context)`, called per unit up to four times a turn, returning a move path and/or an attack/repair target or a named action. Priority chain in order: rescue-carry → rescue-pickup → guaranteed kill → critical ally repair → survival extraction → retreat when low and spotted → regroup → routine repair → Screen (narrow case) → Clear Bloom → focus-fire weakest in range → advance into range (ranged units hang back at max range) → objective moves (exit, hold zone, rescue) → seek fight → hold. Commander and Munti get a raised retreat threshold (0.5 vs 0.3) and are capped from advancing past the most-forward ally, except on extract missions. Class-triangle weighting exists but only when choosing among targets already in range.

**What it doesn't do — every one of these is a real, shipped verb the bot never calls:** Ambush, Interdict, Sensor Sweep, Overwatch, Taunt (a gated branch exists but is disabled after three failed attempts), Fire Support, Missiles. It never paths a Munti *toward* a hurt ally (heal-in-place only). It has no idea what the enemy will do next turn — every retreat is reactive, after the damage lands. That's the documented "alpha-strike ceiling": Mission 8 is 0/100 across seeds because packs concentrate 60+ damage on one target before a threshold-based retreat can ever fire.

**Three structural gaps that matter for this plan specifically:**

1. **No difficulty, profile, or personality concept anywhere.** Every knob is a module-level constant (`RETREAT_HP_FRACTION = 0.3`, `COMMANDER_RETREAT_HP_FRACTION = 0.5`, `CRITICAL_ALLY_HP_FRACTION = 0.4`, `ROUTINE_ALLY_HP_FRACTION = 0.85`, `MAX_LEAD_FROM_ALLIES = 5`, `VIP_THREAT_PRIORITY_DISCOUNT = 0.4`, `EMERGENT_BOSS_PRIORITY_DISCOUNT = 0.5`, plus half a dozen unnamed inline weights). The decision function takes no options object.
2. **No seeded RNG in the repo.** The mulberry32 harness that produced the Mission 36 "99/100" result was a throwaway, never committed. The only randomness in a battle is the Meeps dodge roll (`Math.random()` in `mission.ts`'s `rollMeepsDodge`), but that's enough to make every batch non-reproducible. `Mission` has no place to inject a random source.
3. **The harness loop is duplicated by hand** between `run.ts` and `runBatch.ts` ("kept in sync by eye, not by import" — the file's own comment). Any new action dispatch has to be added in both places or one silently drifts. Also: `runBatch.ts` only records WIN/LOSS/COMMANDER_DOWN/TIMEOUT — no turns, no damage, no per-pilot anything.

Test coverage for the bot: 3 files, 31 cases, none end-to-end.

---

## 2. What the three tiers mean

Anchored to human skill, since the whole point is standing in for testers before testers exist:

| Tier | Stands in for | One-line character |
|---|---|---|
| **Easy** | A first-time tactics player, or someone playing half-attention. | Moves toward the nearest thing and shoots the nearest thing. Retreats too late. Forgets the Munti exists until someone's already down. Never uses an ability. |
| **Moderate** | A competent player who's learned the systems — roughly the bar of "plays like Maxime does on a normal night." | Focus-fires, respects the class triangle, keeps the commander back, heals proactively, uses every ability when the obvious trigger is there. Still reacts to damage rather than predicting it. |
| **Hard** | A tactics veteran who reads enemy ranges before every move and plans the whole squad's turn as one thing. | Sees the threat map. Never ends a turn with the commander inside a lethal bubble. Baits with the Tank, screens with the Munti, breaks stealth for the 2× strike, drops Fire Support on clusters, uses Interdict at chokepoints. Plans unit order, not just each unit alone. |

Honest framing of "tactical genius": this is a hand-written expert, not a learning system. It gets its edge from three things — reading the enemy's reach exactly (the game's ranges are pure Chebyshev distance with no line-of-sight, so the math is clean), exploiting the fact that the enemy AI is deterministic and readable, and coordinating the squad as a unit. That is what a strong human does too. It will feel like a genius against this campaign. It will not be a genius in the machine-learning sense, and it shouldn't be — a black-box bot can't be batch-tested or explained, which the Gladiator doc already called out as the reason to keep rules hand-tuned.

**Where the current bot lands on this scale:** between Easy and Moderate. Maxime's own read ("the playerai suck a lot still," 31 Aug) is right in the sense that it has Moderate's discipline but Easy's toolset. So Moderate is mostly "finish what the 25 Aug ability plan already specified," and Easy is mostly "the current bot with some discipline switched *off*." Hard is the genuinely new build.

### 2.1 Behavior matrix

| Capability | Easy | Moderate | Hard |
|---|---|---|---|
| Target choice in range | nearest / most damage | weakest × triangle × VIP-threat (current) | + kill-order that maximizes enemies removed this turn across the squad |
| Chase target | nearest visible | weakest (current) | threat-weighted: whatever most endangers the commander/Munti next turn |
| Retreat | at 15% HP, only if actually hit last turn | 30% HP when spotted (current) | pre-emptive: leave any tile where predicted incoming ≥ 60% of current HP, before the damage lands |
| Commander/Munti protection | none | front-line cap + raised retreat (current) | squad-side: other units position to block/absorb; commander never ends inside a predicted-lethal bubble |
| Repair | only when adjacent by accident | range-aware, two thresholds (current) | + Munti paths toward the worst ally, and the squad holds so the Munti can reach |
| Focus fire | none | squad-shared weakest (current) | + prefers targets that die this turn (denies enemy actions) |
| Terrain / bloom_mat | ignored | nudged (current) | hard-avoid bloom_mat when standing still; cover-seeking when it changes the threat number |
| Abilities | none | obvious-trigger rules (§4) | contextual rules + combos (§4, §5) |
| Objective play | generic | branches (current) | objective-specific plans (§5.4) |
| Randomness | small: 20% chance to pick 2nd-best move/target | none | none |
| Lookahead | none | none | one-ply threat map; optional hostile-AI oracle (§5.2) |
| Unit order within a turn | roster order | roster order | planned: screeners → attackers → Munti → commander last |

The Easy tier's randomness is what makes it feel like a person rather than a broken bot. It needs the seeded RNG (§3.3) so an Easy batch is still reproducible.

---

## 3. Architecture: one engine, three profiles

### 3.1 `PlayerAiProfile`

A plain object passed into `decidePlayerAiAction` as a sixth argument (defaulting to `MODERATE` so nothing existing breaks). Every constant in §1 becomes a field; every heuristic that a tier can switch off becomes a boolean. Sketch:

```ts
export interface PlayerAiProfile {
  tier: "easy" | "moderate" | "hard";
  retreatHpFraction: number;             // 0.15 / 0.30 / dynamic
  commanderRetreatHpFraction: number;
  criticalAllyHpFraction: number;
  routineAllyHpFraction: number;
  useClassTriangle: boolean;
  focusFire: boolean;
  protectVips: boolean;                  // current front-line cap
  squadSideProtection: boolean;          // hard only
  repairPathing: boolean;
  useAbilities: Partial<Record<AbilityId, boolean>>;
  threatMap: boolean;                    // hard only
  hostileOracle: boolean;                // hard, test-only (see §5.2)
  planSquadOrder: boolean;               // hard only
  mistakeChance: number;                 // easy: 0.2, else 0
}
export const EASY: PlayerAiProfile = {...}; export const MODERATE = {...}; export const HARD = {...};
```

The existing module constants become `MODERATE`'s values, so the current behavior is byte-for-byte preserved under the default profile — which is what lets the existing 31 tests and every recorded batch number stay meaningful during the build.

### 3.2 One driver, not two

Pull the per-unit dispatch loop out of `run.ts`/`runBatch.ts` into `src/sim/driveMission.ts`: `driveMission(mission, profile, rng): MissionSummary`. Both scripts call it. This is where every new action (`ambush`, `interdict`, `sensor_sweep`, `overwatch`, `taunt`, `fire_support`, `missile`) gets dispatched exactly once. `PlayerAiDecision.action` grows from four literals to eleven, and `fire_support`/`missile` carry a `targetTile`.

The driver returns a `MissionSummary` — the same record the telemetry plan defines for human play (§8). That's deliberate: a bot run and a human run produce identical rows.

### 3.3 Seeded RNG in the engine

`Mission` gains an optional `rng: () => number` (constructor option, default `Math.random`), and `rollMeepsDodge` reads it. That's the entire engine change — grep-confirmed it's the only random call in a battle (`runBatch.ts`'s own header comment claims the on-hit-effects engine also rolls randomness; it doesn't — `turnManager.ts` has no `Math.random` — so fix that comment while in there). The social sim already uses this exact injectable-`rng` pattern (`engine/socialSim.ts`), so it's the house convention, not a new one. The harness gets `--seed=N` (mulberry32, ~20 lines, the same generator the throwaway Mission 36 harness used) and a batch of N runs uses seeds `seed+0 … seed+N-1`, so any single losing run is replayable by seed. The Easy profile's `mistakeChance` draws from the same `rng`.

Side benefit outside this plan: a seeded `Mission` is also what a future replay feature or a "share this battle" code would need.

### 3.4 Harness flags

`npm run sim:batch -- 500 mission_amaranth_8 --tier=hard --seed=1000`. Reports per tier: win / loss / commander_down / timeout, mean turns, mean turns-on-win, damage taken per pilot, abilities used, and a per-run seed list of losses. A `--all-tiers` flag runs the three profiles back to back and prints the **difficulty fingerprint** — the (easy%, moderate%, hard%) triplet §6 is built on.

### 3.5 Minimum sample size — Maxime's rule, 2 Sep 2026

**Never less than n=500 per tier on any batch run used to make or confirm a balance call.** Set explicitly during the Mission 22 ("Ash on the Water") tuning session, 2 Sep 2026, after Maxime asked for a 500-run pass on top of an already-run n=150 batch: *"in fact, we should add it to the build never less than 500 pass on a test run."* This raises the working floor from the n≥200 this plan originally specified in §9's Phase D and from the n=100 the actual 1–2 Sep re-baseline shipped at (§12) — both are now under the new minimum and due for a re-run at n=500 whenever that mission's numbers matter again, not just at the next full campaign-wide retune.

Why this is a real rule and not caution for its own sake: this exact mission's build history (see `claude/build_log/act2/mission22_ash_on_the_water.md` and this file's own §12 notes on Mission 8/12/36) has repeatedly shown non-monotonic, knife-edge responses to small composition changes — a single added unit has flipped a win rate by 60+ points before. A smaller batch can land inside a cliff's own noise band and read as "fine" when a wider sample would show it sitting right on the edge. n=500 was confirmed affordable in the same session that raised open question §10.4 (n=500 × 76 missions × 3 tiers ran in about 30 minutes in-sandbox post the `reachableTiles` speed-up) — cost is not the reason to skip it.

Applies going forward to any single-mission or small-batch balance pass (like the Mission 22 wave-composition changes this session made), not only Phase D's full-campaign retune. `npm run sim:batch`'s own examples throughout this doc are updated to n=500 to keep that the default anyone copies, rather than the smaller counts used before this rule existed.

---

## 4. Abilities: what the bot needs, and how (the part Maxime flagged as owed)

Good news first: **every engine API a bot needs already exists**, because `Battle.ts`'s action bar already calls it. Each verb has a `canX(unitId)` check and an area/targets query. Nothing in the engine has to be invented for Moderate; it's all bot-side trigger rules plus driver dispatch. The inventory, from `mission.ts`:

| Ability | Who | Engine API (exists) | Cost shape |
|---|---|---|---|
| Ambush (3-turn cloak, 2× decloak strike) | Meeps | `canAmbush`, `ambush(id)` | whole turn; refused if an enemy is adjacent |
| Interdict (brace: adjacent hostile that moves in loses its actions) | Tank | `canInterdict`, `getInterdictedTilesFrom`, `interdict(id)` | whole turn |
| Sensor Sweep (reveal burrowed/concealed in vision+2) | Reeps | `canSensorSweep`, `sensorSweepChargesRemaining`, `sensorSweep(id)` | 1 action, 2 charges/mission |
| Overwatch (reaction shot) | anyone | `canEnterOverwatch`, `enterOverwatch(id)` | whole turn |
| Screen (conceal Munti + adjacent for one enemy phase) | Munti | `canScreen`, `getScreenableFrom`, `screenAllies(id)` | 1 action, once/mission |
| Clear Bloom | Munti | `canClearBloom`, `clearBloom(id)` | 1 action |
| Taunt (all hostiles target the taunter and are rooted) | Meeps, Mission 8+ | `canTaunt`, `taunt(id)` | whole turn, reusable |
| Fire Support (60 flat, 3×3, no counter) | all, Mission 14+ | `canFireSupport`, `getFireSupportAreaFrom`, `fireSupport(id, tile)` | whole turn, 2 squad charges (+Weapons Bay) |
| Missiles (splash, hits friendlies) | Reeps w/ branch | `canMissileStrike`, `getMissileAreaFrom`, `missileStrike(id, tile)` | whole turn, 2 charges/unit — **note: not wired in Battle.ts's UI either**, so a human can't fire it today; flag for the feature report |
| Repair | Munti | `getRepairableFrom`, `repairUnit` | 1 action, repeatable |

One thing to say plainly: there is no "spell"/energy system in this engine. Every cost is action budget plus per-mission charges, with one new exception as of this evening — **Field Doctor** (shipped 1 Sep by a concurrent session, `claude/Bloom_Wars_Build_Log_Addendum_AegisWard_FieldDoctorScope_01Sep2026.md`) gives a Munti a free Repair at 0 actions, gated by a 3-turn cooldown in `abilityCooldowns`, and exposes `Mission.fieldDoctorReady(unitId)` (per that addendum — this session's staged source predates it, so re-stage before building on it). That matters for the driver in §3.2: today's harness loop stops asking a unit for decisions once `actionsRemaining` hits 0, so the free repair would be invisible to every tier unless the loop also continues while `fieldDoctorReady(id)` is true — the exact reachability bug that addendum found and fixed in `Battle.ts`, mirrored on the bot side. If a future Heirloom/ultimate layer adds a real resource, the profile gets one more knob; nothing here blocks it.

### 4.1 Trigger rules per tier

**Moderate — "obvious trigger" rules.** Each is a cheap check placed in the priority chain at the position noted:

- *Sensor Sweep*: mission has burrowing archetypes (Undertow) or concealed enemies **and** no revealed target is in anyone's range **and** charges remain → sweep. Sits right before "focus-fire." Under-use is the safe failure, so it fires at most once per two turns.
- *Interdict*: Tank has no in-range target after moving **and** ≥1 visible hostile can reach an adjacent tile next turn (reach = `moveRange + 1`, Chebyshev) → brace instead of seek-fight. Placed after advance-into-range fails.
- *Overwatch*: any unit with an attack left, no in-range target, and ≥1 hostile whose move can end inside its range → overwatch instead of holding. Same slot as Interdict; Interdict wins for Tanks.
- *Ambush*: Meeps not spotted, no in-range target, an enemy worth 2× damage exists within `moveRange×2` → cloak; while cloaked, prefer the target where the doubled hit is lethal. Never cloak when an ally is under 40% HP nearby (the Meeps is needed as damage now).
- *Screen*: Munti and ≥2 allies within radius **and** predicted incoming to any of them ≥ 40% of its HP → screen. Keeps the current clear-bloom trigger too.
- *Taunt* (the three-times-reverted one): only when (a) an enemy can reach the commander or Munti next turn, (b) the taunter's own predicted incoming from *everyone who would switch to it* is < 70% of its HP, and (c) it stands on ≥1 defence star. Condition (b) is exactly the "reason about its own survival odds" the previous attempts lacked — and it needs the threat map, so under Moderate, Taunt only uses the cheap reach-count proxy and stays conservative (max one taunt per two turns).
- *Fire Support*: ≥2 hostiles inside one 3×3 box within a caster's vision, **or** one boss/emergent-tier unit **or** a hostile that would otherwise reach the commander this turn → fire. Charges are squad-shared, so at most one per turn and never on turn 1 of a `survive_n_turns` mission (save it for the swarm).
- *Missiles*: same cluster rule, plus a hard "no friendly in the splash" filter.
- *Repair pathing*: if no ally is in range but the worst ally under `criticalAllyHpFraction` is reachable-into-range this turn with no hostile able to reach the destination → move then repair (the two-action budget allows it).

**Hard — contextual rules on top.** Every Moderate trigger swaps its "reach-count proxy" for the real threat-map number (§5.1). Plus combos: Interdict placed *on the chokepoint tile* the threat map says the swarm funnels through; Screen used the turn before a predicted alpha-strike rather than after; Ambush timed so the decloak strike lands on the pack's shared target-selector (the pack tier all chase one weakest target — a cloaked Meeps next to that target gets a free 2× hit on whoever closes); Taunt on a Tank-covered Meeps standing in cover with the Munti behind it, which is the bait pattern the 25 Aug plan explicitly deferred.

**Easy —** `useAbilities` all false. The one exception is Repair on an adjacent ally, because a bot that never heals doesn't stand in for any real player.

---

## 5. The Hard tier's brain

### 5.1 Threat map (the core new piece; ~250 lines, pure, unit-testable)

`threatMap(map, hostiles, units): Map<tileKey, {maxHit, sumHit, attackers}>`. For each living hostile: enumerate its reachable tiles (existing `reachableTiles` + `occupiedSet`), from each compute the attack footprint (Chebyshev `[attackRange[0], attackRange[1]]`), and for every tile in the footprint add `estimateDamage(hostile, hypotheticalDefenderAt)` (existing function in `engine/ai.ts`). The per-tile record holds the worst single hit, the sum of all hits, and how many attackers can reach. Cost: hostiles × reachable tiles × footprint — on a 20×20 map with 15 hostiles that's tens of thousands of cheap additions, well under a millisecond in Node.

Two refinements that matter against this campaign specifically: pack-tier hostiles share one target, so `sumHit` for the tile their shared weakest-target stands on is the real alpha-strike number; and burrowed/unseen hostiles still count (Hard "remembers" the last seen position and assumes it can move) — the same thing a careful human does.

This same map is exactly what a player-facing "enemy range overlay" would draw (see the feature-gap report). Build it once in `src/engine/threat.ts`, not under `sim/`, so the game UI can import it too.

### 5.2 Hostile oracle (test-only, flag-gated)

`decideHostileAction(map, unit, units)` in `engine/ai.ts` is a pure function. Hard can clone the unit list with candidate positions applied and *ask the enemy's own brain what it would do*. That gives exact one-ply prediction: "if I put Rourke here and Bosk here, the Choir attacks Bosk twice and Rourke once, for 86." It is a cheat in the sense that no human sees the enemy's code — but for **campaign difficulty testing** it's the right tool: it answers "can a player who has fully learned this enemy's tells beat this map," which is the ceiling question the ≤15% rule is really asking. Flag it off (`hostileOracle: false`) for any PvP use against a human, where only the generic threat map applies. One implementation trap, found while fact-checking: `ai.ts`'s `bestAttackTargetInRange` temporarily writes `unit.pos` and restores it, so the oracle must be called on *cloned* units, never on the live `Mission.units` array — otherwise a mid-plan crash leaves a unit teleported.

### 5.3 Squad turn planner

Today the harness walks units in roster order and each decides alone. Hard plans the turn: (1) sort units by role — screeners/Tanks first, damage dealers, Munti, commander last; (2) keep a `plannedPositions` overlay so each later unit's threat lookup accounts for allies already placed (a Tank standing in the funnel *reduces* the sum on tiles behind it, because pack targeting will now pick the Tank — modeled by re-running the oracle, or approximated by blocking); (3) a final pass: if the commander's planned tile has `sumHit ≥ currentHp`, re-plan the commander first and let others adapt. This is what "protect the commander from the squad's side" means concretely, the thing the 30 Aug/31 Aug rounds couldn't reach by changing the commander's own behavior.

### 5.4 Objective-specific plans (Hard)

- `survive_n_turns`: find the tile cluster with the lowest total threat that fits the squad (defence stars, corners, chokepoints), move there on turn 1, hold, Interdict/Overwatch the approach, spend Fire Support on the biggest predicted wave.
- `hold_zone`: same, constrained to the zone; rotate hurt units to the back of the zone for the Munti.
- `extract_unit` / civilians: escort formation — extraction target inside a ring, Tank on the threat-facing side, path chosen to minimize cumulative threat along the way rather than distance.
- `eliminate_all` with roaming fallback: don't chase into the swarm; pick a defensible line and let the roam bring them, then advance in a block.
- `protect_asset`: threat map centered on the asset; anything that can reach the asset next turn is the only target that matters.
- Bonus objectives: only pursue when the detour's cumulative threat stays under a budget.

### 5.5 Optional: real search (flagged, not recommended for EA)

With a seeded `Mission` and deterministic enemy, Hard *could* do shallow search: for the top-K candidate squad plans, actually run the enemy phase in a cloned mission and score the result (units lost, HP lost, enemies killed), pick the best. It's the same idea as a chess engine's lookahead, one move deep. It would be the strongest possible bot here. Cost: cloning `Mission` per candidate (it isn't cloneable today — it holds Phaser-free state, so a `snapshot()/restore()` pair is buildable, ~1 session) and roughly 10–50× slower batches. Given Maxime's own n=500-per-map retune pass across 36 (later 72) maps, that's the difference between an overnight run and a week. Recommendation: build Hard on §5.1–5.4 first, measure, and only reach for search if Hard still can't crack Mission 8's 0/100 — which the oracle-driven planner should, because the wall there is predictable.

---

## 6. What this does to the balance rule (needs Maxime's decision)

**Correction, 4 Sep 2026 — this section is retired as "the working rule."** Asked directly whether to formally sign off on the bands below, Maxime: *"Ai arent really suposed to win the mission btw. Ai test are to see if mission is cheesable."* That removes the premise this whole section stands on — the bands treat "the AI wins at roughly the rate its tier implies" as the balance signal, and that was never actually the intent. The AI sim's real job is catching cheese: a degenerate, unintended exploit that trivializes a mission, not hitting a win-rate target. A mission the AI loses 0% at every tier, including Hard, is not automatically a problem under this framing — it just means the hand-tuned heuristic bot didn't find a way through, fair or unfair, which isn't evidence of anything by itself. The older ≤15% ceiling (an upper bound on AI win rate, not a floor) sits closer to the real intent than this section's bands do, but whether that specific number is still the standing check post-tiers is genuinely open, not decided here. Full write-up: `Bloom_Wars_Build_Log_Addendum_BalancePhilosophyCorrection_04Sep2026.md`. Leaving the rest of this section below intact as a historical record of the proposal, not as adopted policy.

Today's rule, his words: *"if ai win more than 15% of the time, the map is too easy."* That number is calibrated to the current bot. Once Moderate uses abilities, most missions' rates rise; once Hard exists, some go to 90%+. Every recorded number is stale the day Phase B ships — the same duplicated-work risk he named on 29 Aug when he said tune the bot *before* building more missions.

**Replacement (updated 2 Sep 2026 after the build and the re-baseline — see §12 and the build addendum §4): per-mission target bands on the three-tier fingerprint, read together with Hard's two cost columns.** Maxime's framing for the bands, 1 Sep: *"xcom is the benchmark. mission should feel as hard as xcom missions"* and *"I want the mission to be hard and player have loss in them. Especially at hard."* So the win column alone is not the rule any more — a mission that is usually won but always paid for is the target.

| Intended difficulty | Easy bot | Moderate bot | Hard bot | Hard downed / run | Hard lost / run |
|---|---|---|---|---|---|
| Opener (first 3–4 of an act) | 40–70% | 80–95% | ≥95% | ≤0.5 | ~0 |
| Standard | 10–30% | 50–75% | 85–100% | 0.5–2 | ≤0.3 |
| Hard (act-climax) | ≤10% | 25–50% | 60–90% | 1–3 | ≤0.5 |
| Wall (finale, boss, deliberate) | ≤3% | 10–25% | 40–70% | 2–4 | ≤1 |

Reading it: Moderate's number is the one that should feel right to a competent human; Hard's number is the ceiling ("is this beatable by someone who has mastered it — if Hard can't win 50%, the map may be unfair rather than hard"); Easy's number is the onboarding check ("is Act I safe for a newcomer"); the cost columns are what make a mission *feel* hard even when it is won. A mission whose triplet is out of band in one column tells the tuning job *what kind* of wrong it is, which the single number never could — e.g. Easy 0% / Moderate 5% / Hard 85% says "punishes mistakes brutally, fine for a veteran, brutal for everyone else," while Easy 0% / Moderate 5% / Hard 10% says "this map is unfair, not hard," and Hard 100% with 0.0 downed says "too easy whatever Moderate says."

The bands above are a proposal to argue with, not sim-validated numbers. The "other Claude job" runs the fingerprint (`npm run sim:batch -- 500 --all-tiers --seed=N`, per §3.5's minimum) and tunes toward whichever bands Maxime signs off on. Docs that need updating once he decides: `Bloom_Wars_Consolidated_Build_Plan_Progress.md` (the ≤15% rule and its "redo all Warden missions to the 15% ceiling" note — a pointer note has been added there), `Bloom_Wars_EA_Launch_Plan_31Aug2026.md` Week 3, and `claude/build_log/engine_systems/player_ai_engine.md`.

---

## 7. EA scope vs PvP scope

**Needed by EA (26 Oct), for the test job:** Phases A–D below. The bot never ships in the EA build — it's tooling — so there's no player-facing risk in landing it during the EA window.

**PvP update (later):** the same Hard/Moderate profiles driving a second mech squad. Known engineering there, none of it started: every `canX` verb and `enterOverwatch` carries a `unit.side !== "player"` guard; `runHostileTurn` is hardwired to `decideHostileAction`; `decidePlayerAiAction` hardcodes `livingTargets(allUnits, "hostile")`. Parameterizing `side` through those three seams is mechanical, roughly one session, and the Gladiator doc's v1 (fair-by-construction mirrored roster) is exactly "Hard profile, oracle off, side = hostile." Do not build it before EA.

---

## 8. Shared data shape with telemetry

`driveMission()` returns a `MissionSummary` — mission id, tier, seed, outcome, turns, per-pilot damage dealt/taken/kills/downs, abilities used, charges spent, permanent losses, bonus outcome. The telemetry plan writes the *same* record when a human finishes a mission. That is the thing that lets a future pass answer the only question that really matters for tiers: *which bot do real players resemble?* If the tester cohort's win rates sit between Easy and Moderate on Act I, the bands in §6 move; if they sit above Moderate, the tiers are too timid. Without the shared shape, tiers stay a guess forever.

---

## 9. Sequencing and sizing

Estimates are in "Claude sessions" — one attended or unattended stretch with a full typecheck/lint/test/build pass and a device commit at the end, the way every other pass in this project has been sized.

| Phase | What | Size | Fits EA week |
|---|---|---|---|
| **A — plumbing** | `PlayerAiProfile` + three presets (MODERATE = today's constants, zero behavior change), `driveMission()` consolidation, seeded `Mission.rng` + `--seed`, `--tier` and `--all-tiers` flags, `MissionSummary` output, tests for profile defaults and seed reproducibility | 1 session | Week 1–2 |
| **B — Moderate** | §4.1 trigger rules for all nine abilities, repair pathing, class triangle on chase targets (the 400-run regression from 30 Aug says gate it behind the profile and re-measure), Easy profile's switch-offs and `mistakeChance` | 1–2 sessions | Week 2 |
| **C — Hard** | `engine/threat.ts` threat map + tests, hostile oracle behind a flag, squad planner, §5.4 objective plans, Hard's ability combos | 2–3 sessions | Week 2–3 |
| **D — re-baseline** | All 36 Warden missions × 3 tiers, n≥500 seeded (§3.5), produce the fingerprint table, flag out-of-band missions — this is the input the tuning job starts from | 1 unattended batch run + a write-up | Week 3 (the existing "balance triage" slot) |
| **E — PvP wiring** | §7 | 1 session | post-EA |

Total before EA: roughly 5–7 sessions, landing inside the existing Week 1–3 plan without displacing the Vault (Week 2) if it runs as unattended overnight work. Phase C is the one that could overrun; if it does, ship A+B+D with Moderate as the tuning bot and let Hard land in Week 5's second verification pass.

### What could go wrong, said plainly

- **Oscillation.** The 31 Aug gang-up retreat blew two missions past a 60s timeout by flip-flopping. Hard's pre-emptive retreat has the same failure shape. Mitigation: the planner commits a whole-turn plan once and doesn't re-decide mid-turn; plus a per-unit "moved away last turn, don't move away again unless the threat number doubled" damper.
- **Every old number goes stale at once.** Accepted; that's Phase D's job and Maxime's own n=500 pass was already scheduled.
- **Hard beats a mission by exploiting an enemy-AI quirk no human would find.** That's real, and it's what the oracle flag is for: run Phase D twice, oracle on and off, and treat a mission Hard only wins with the oracle as "solvable but not legible" — a mission-design note, not a balance pass.

---

## 10. Open questions, need Maxime's call

1. **The rule in §6** — replace the single ≤15% ceiling with the three-tier bands (numbers negotiable), or keep one number and pick which tier it applies to? *(2 Sep: he said "your call" — the bands in §6 are the working rule until he says otherwise. **4 Sep: superseded — see §6's own correction note. The bands are retired; the AI sim's job is cheese detection, not win-rate targets.**)*
2. **Oracle on for campaign testing?** Recommendation: yes for tuning, always off for PvP, and Phase D reports both. *(2 Sep: built with the oracle on; the oracle-off comparison run is still owed.)*
3. **Should Easy make deliberate mistakes** (the 20% second-best pick) or just lack skills? Recommendation: both — a bot with fewer skills but perfect execution doesn't look like a newcomer. *(2 Sep: both, as built.)*
4. **Compute budget for the retune pass** — n=500 × 36 × 3 tiers ≈ 54,000 runs; fine for A–D, but decides whether §5.5 search is ever affordable. *(2 Sep: after the `reachableTiles` speed-up, 76 missions × 3 tiers × 100 runs took about 30 minutes in the sandbox; n=500 is an overnight run, not a week. **Confirmed again the same day, single-mission scale:** a 500-run, 3-tier batch on one mission (Mission 22, during its own tuning pass) took under 2 minutes — this is what grounds §3.5's "never less than 500" rule; the floor was never compute, so there's no reason to test smaller.)*
5. **Does the PvP bot need to be *beatable* on purpose** (a Gladiator "Moderate" that leaves openings), or is fair-by-construction enough? Not needed now; recorded so the profile design leaves room for it.

## 11. What this plan deliberately doesn't touch

The enemy AI (`engine/ai.ts`) stays exactly as is — changing what the Bloom does is a balance change to the shipped game, out of scope here. No engine mechanic changes except the `rng` hook. No Battle.ts UI. No Heirloom/ultimate verbs (none exist as engine verbs yet). No learning-from-the-player layer — that's Gladiator v2, and the telemetry plan's per-action event log is the only groundwork it needs.

---

## 12. Built — 1–2 Sep 2026 (what shipped, where it diverged from the plan)

Full record: `claude/Bloom_Wars_Build_Log_Addendum_PlayerAiTiers_Telemetry_UI_01Sep2026.md`. Gates at commit: tsc / eslint / vitest 63 files, 1319 tests / vite build, all clean.

**Shipped as planned.** `PlayerAiProfile` with EASY / MODERATE / HARD plus a fourth preset, `LEGACY` (the pre-1-Sep bot byte-for-byte, kept so old batch numbers stay reproducible — the plan had MODERATE playing that role, but Moderate also gained honest vision, see below, so it is no longer byte-identical). `driveMission.ts` as the one driver; `Mission.rng` with mulberry32 and `--seed`; `--tier` / `--all-tiers` / `--json`; every ability trigger in §4.1; `engine/threat.ts` (threat map + oracle); `hard.ts` with the pre-emptive retreat, threat-aware positioning, role-ordered units and objective discipline; the re-baseline (76 missions — the old Warden slice, Warden Company 1–36, House Amaranth 1–36 — × 3 tiers × 100 seeded runs).

**Where the build diverged, and why.**
- *Honest vision for every tier but LEGACY.* Not in the plan. The old bot could target burrowed and concealed units no human can click; leaving that in would have made every fingerprint a lie. Consequence: Moderate is *not* the old constants byte-for-byte — that role went to LEGACY.
- *The squad planner (§5.3) is role ordering plus an assumption, not a two-pass plan.* Units decide Tanks → Reeps → Meeps → Munti → commander last; units deciding before a VIP assume the VIP will move out of reach (they usually do — their bar makes them). The "re-plan the commander first" final pass was not built; the commander deciding last with the finished picture did the same job in measurement.
- *The Hard danger bar is 60% of MAX HP for VIPs* (tightening to 60% of current once hurt), not "60% of current" — measured: 0.35 and 0.5 of max both collapsed Mission 12 from 70% to under 5% because a commander who never shoots is one gun short.
- *Objective plans (§5.4)* shipped for hold_zone (zone discipline: line units don't step out to reposition, the last unit never leaves, everyone walks in once the zone is about to be judged; the least-punished zone tile is chosen) and for extract_unit (the extraction target runs first and shoots second — a fix for every tier, not just Hard). survive_n_turns / protect_asset / eliminate_all got no dedicated plan; the threat-aware chain handles them.
- *Three behaviour fixes landed for every tier* because the bot was losing missions for reasons no human would: the extraction target racing the exit, the Munti walking to the bloom patch on clear_bloom maps (Mission 3 went from 0% at every tier to 21 / 29 / 84), and Interdict only when the Tank is the unit the hostile is closest to.
- *A semantics-preserving rewrite of `engine/grid.ts`'s `reachableTiles`* (half of every sim's CPU time under the oracle) with an equivalence test against the original on all 76 maps — same costs, predecessors and iteration order, so no mission's numbers moved.
- *§5.5 search* was not needed: Mission 8, the plan's own benchmark for it, went from 0/100 (LEGACY) to 100/100 (Hard) on the threat map alone.

**The numbers (n=100 per tier, seed base 1000, aggregate over 76 missions):** Easy 31% (2.68 downed / 1.07 lost per run), Moderate 48% (2.86 / 0.93), Hard 73% (2.09 / 0.42). The per-mission table and its reading are in the addendum §4.2–4.3. Three things the tuning job inherits from it: Warden Act I is inverted (Missions 1, 7, 12, 21 unwinnable or nearly so on every tier while 5, 6, 10, 11 are free); the extract missions read easy now because the bot stopped throwing them; House Amaranth Act III is very hard for every tier, sometimes by the clock rather than the enemy. **This aggregate itself predates the §3.5 minimum (it's n=100, not n≥500) — worth a re-run at the new floor before leaning on it for anything precise.**

**Still owed:** the oracle-off comparison run; Phase E; player-facing difficulty settings tied to these profiles.
