# THE BLOOM WARS — House Amaranth Hub: Build Plan v1 (the Greathouse)

**Status: plan + mockup, 6 Sep 2026 — for approval, zero code.** Maxime: *"we are building house amaranth hub. plan 1st gimme a mockup once ive aprouve ill allow you to built it."* This doc is the plan half; the mockup half is the artifact **The Greathouse Floor Plans** (four sheets: RC, 1SS, 2SS, YARD, plus the eight approval questions). Nothing below is built. Every design decision here sits on top of `Bloom_Wars_House_Amaranth_Hub_Facility_Plan_v1.md` (4 Sep) — that doc's locks are not reopened, its open items are answered as proposals and flagged as such.

---

## 0. What the mockup proposes, in one screen

| Floor | Rooms (functional id → proposed display name) | Notes |
|---|---|---|
| **RC** — ground floor, "The Greathouse" | berths ×3 → Barracks 1st/2nd/3rd Lance · heads → the Washhouse · engineering → the Boiler Room · recroom → the Longhouse · hangarDeck → the Motor Court · lowerHall → the Gallery | Warden's lower deck to the coordinate. Motor Court drawn as an outdoor courtyard (flagstones, Terrace Gate where the bay doors were). |
| **1SS** — first basement, "the Undercroft" | **cellars → the Cellars (new)** · workshop ×3 → Cultivar Works 1st/2nd/3rd Lance · ss1Hall → Undercroft Passage | Warden's three workshops moved down one floor, geometry untouched (MEK_SPOTS, the bench at (150, 600), the hoist). Cellars is a decor-only forward room so the floor isn't a corridor with one empty side. |
| **2SS** — second basement, "the Deep Floor" | vault → the Reliquary · cic → the War Room · forwardBays → the Signal Cellar · **controlRoom → the Control Room (Verinis's post, new)** · **records → Records (new)** · ss2Hall → Deep Passage | Warden's upper-deck forward row to the pixel (plinth at (310, 250)). The Control Room does the grotto's job with the opposite register. One stair only — the secure floor is a dead end by design. |
| **YARD** — separate outbuilding | sparRoom → the Yard | SPAR_BOX reused; ring, posts, kit racks, a well where the water station was. |

Floor chain: **Yard — RC — 1SS — 2SS**, stairs at the corridor ends where Warden's are (x 130 / x 1490), so `DECK_ORDER`'s generic step-walk works unchanged. The CO: **Brig. Verinis Amaranth** at `CO_POINT (560, 760)` in `controlRoom`, standing mid-room, command desk on the aft wall, the Seal-holder's chair behind it, empty (my addition — Q6).

What ports with zero change, because the coordinates were kept on purpose: `MUSTER_POINT`, `HANGAR_SHOP_POINT`, `CREW_RECORDS_POINT`, `RECROOM_TABLE_POINT`, `RECROOM_BOARD_POINT`, `RECROOM_SEATS`, `PLAYER_SPAWN`, `WORKSHOP_BENCH_POINT`, `VAULT_PLINTH_POINT`, `MEK_SPOTS`, both `BAY_MARKERS` columns, every door width and position, the spine corridor at 420–516. This isn't laziness — it's the reason the reachability test, the no-trap-gaps test and every walk-up radius pass on day one instead of being re-tuned.

## 1. The one architecture call that decides everything else (Q8)

`scenes/Hub.ts` is **10,283 lines** today. It is the most-verified file in the repo (five Playwright scripts walk it live, the 28-screen sweep screenshots it, and this evening's Vault scroll fix went in there too). There are two ways to give House Amaranth a hub.

**Option A — fork.** Copy `Hub.ts` → `HubHouseAmaranth.ts`, copy `hubLayout.ts` → `hubLayoutHouseAmaranth.ts`, edit the copies. Fast to start; the wrong answer. Every fix from then on is made twice or it isn't made — tonight's Vault scroll fix would already need porting. The two files drift within a week (this project's own doc-sync history this week is the evidence of how fast that happens with *one* copy). And the "same tech, different building" idea the 4 Sep plan locked becomes two techs.

**Option B — one Hub, two facilities (recommended).** Teach `Hub.ts` to read a *facility profile* instead of importing Warden's constants, then register the same scene class twice: `new Hub("Hub", WARDEN_FACILITY)` and `new Hub("HubHouseAmaranth", HOUSE_AMARANTH_FACILITY)`. House Amaranth's hub is then a **data file** (the floors, from the approved mockup) plus a **profile** (names, points, the CO) plus **content** (lines). Slower to start, one Hub forever.

*Plain-language aside, since "parameterize" is jargon:* right now `Hub.ts` reaches for Warden's numbers directly — `import { CO_POINT, MUSTER_POINT, ... } from "../engine/hubLayout"` — the way a recipe might say "use the oven in my kitchen." Option B changes it to "use the oven in *this* kitchen," where the kitchen is handed in when the scene is created. Same recipe, any kitchen.

**Measured, not guessed — what in `Hub.ts` is Warden-specific today** (grep counts against the live file, 6 Sep):

- 51 deck-id literals (`"lower"`, `"grotto"`, `"upper"`, `"sparRoom"`), mostly inside four module-level tables: `ROOM_DECK`, `DECK_TITLES`, `DECK_ORDER`, `DOORS` (the six stair definitions).
- Three more module-level tables keyed on Warden's room set: `ROOM_TITLES`, `ROOM_NOTES`, `ROAMABLE_ROOMS`, plus `LANCE_BERTHS` / `LANCE_WORKSHOP` and the `isBerths()` helper.
- 22 references to `WARDEN_PILOTS` / `SECOND_LANCE_PILOTS` / `THIRD_LANCE_PILOTS` (NPC building, lance-of-pilot lookups).
- 22 references to `NPC_SEED` (the three Rec Room regulars' seats and catalyst/social seeds).
- 16 `pilot_rourke` references and 9 `rourkeRank` references (the player character: header rank, greetings, the CO check-in).
- The CO is built by hand inside `buildNpcs()` — name, colour, species, catalyst, `CO_POINT`, room `"grotto"` — around line 6935. `CO_PILOT_ID = "npc_co"` is already module-level and can stay shared (both COs can be `npc_co`; only one hub is ever live).
- 14 imported landmark constants from `hubLayout.ts` (the list at the top of the file, lines ~306–328).
- `engine/hubNav.ts` and `hubLayout.ts`'s `resolveAgainstSolids` both look layouts up by `DeckId` in the global `DECK_LAYOUTS` — so the pathfinder is Warden-only by the same import.

**The profile, as a shape** (`engine/facility.ts`, new; Warden's instance is just today's constants moved, House Amaranth's is new):

```
FacilityProfile {
  sceneKey, displayName ("THE ANTFARM" / "THE GREATHOUSE"),
  deckOrder, deckTitles, layouts (DeckLayout per deck),
  roomTitles, roomNotes, roomDeck, roamableRooms,
  lanceBerths, lanceWorkshops, mekSpots,
  doors (the stair table), stairs,
  points: muster, hangarShop, crewRecords, recroomTable, recroomBoard, recroomSeats,
          workshopBench, vaultPlinth, co, playerSpawn, bayMarkers,
  co: { displayName, color, species, catalyst, socialSeed, room },
  mc: { pilotId ("pilot_rourke" / "pilot_marrow"), rankLabel(state) },
  roster: { pilots, lances[] }, npcSeed, bondSeed
}
```

`DeckId` and `RoomId` stay TypeScript unions, widened to cover both facilities (`"rc" | "ss1" | "ss2" | "yard"` join the four Warden ids; `"cellars" | "controlRoom" | "records" | "ss1Hall" | "ss2Hall"` join the room set). Shared mechanics keep shared ids on purpose: a Barracks *is* `berths`, so sleep-restore, `berthRoomFor`, the "empty until they come aboard" note and the roster panel's lance biasing all work without a rename. Deck ids are globally unique across facilities, so `DECK_LAYOUTS` and the pathfinder can simply hold both sets — no signature change in `hubNav.ts`.

**Cost, honestly:** the refactor is a full session on its own, and it touches the file the game can least afford to break. It is also a *pure* refactor — zero visible change for Warden — which is exactly what makes it safe to verify: the existing harness (`checkHubNpcs`, `checkHubDoorReachability` 6/6, `checkHubCameraScroll`, `checkHubInteractionAfterScroll`, `captureHubDecks`, `sweepUi` 28 screens) must come back **identical** before any estate data goes in. Two separate commits, on purpose, so a Warden regression can never hide behind new-content noise.

## 2. Build order

1. **Refactor (Option B), Warden only.** `engine/facility.ts` + `data/facilityWarden.ts`; `Hub.ts` reads `this.facility`; `main.ts` registers `new Hub("Hub", WARDEN_FACILITY)`. Gate: `tsc` / `eslint` / all tests / `vite build` clean, and the six Hub Playwright scripts + sweep identical to their 6 Sep baseline. Commit.
2. **The estate as data.** `engine/hubLayoutHouseAmaranth.ts` — the four floors from the approved mockup, using `hubLayout.ts`'s own builders (`assembleRooms`, `wallBand`, the furniture helpers — export them; they're module-private today). `hubLayout.test.ts` extended to walk the new floors: no trap gaps, every door reachable, every landmark inside its room, every `MEK_SPOT` on a walkable cell. This is the step the mockup exists to shortcut: approved numbers go in as written.
3. **The profile and the CO.** `data/facilityHouseAmaranth.ts`; Verinis seeded from the profile (not hand-built in `buildNpcs()` — that hand-build becomes the Warden profile's `co` block in step 1). `npcSeedHouseAmaranth.ts` gains the three regulars' seats and social seeds (its own header says it deliberately doesn't carry those "until a House Amaranth Hub scene actually exists" — it will now). `baseSceneKeyFor` returns `"HubHouseAmaranth"` instead of `"Hangar"` for a House Amaranth save; every `scene.start(baseSceneKeyFor(state))` call site already routes through it, so the entry path is one line. `Hangar.ts` stays as the shop scene it is.
4. **Content, the honest minimum.** `ROOM_NOTES` for every estate room in the same "not built yet" register Warden's use; deck/room display strings; the Debrief callouts that name "the Campaign Shop" for House Amaranth (from the Third Lance addendum) re-pointed at the Motor Court's console. Ambient lines at the Mission Plan's §3c v1 target (~180) rather than Warden's 700+ — flagged there, unchanged here. **Verinis's own lines are yours** (first batch by you, matching second batch after — the 4 Sep workflow); until they exist he speaks Arangement's CO lines, which is wrong in voice but not broken. Not a launch blocker for the hub — it is for the campaign.
5. **Verification for the estate.** `tools/verify/checkHubHouseAmaranth.mjs` — a live walk of all four floors (every door, every stair both ways, every walk-up point triggers its panel, NPCs roam without stranding, camera clamps per floor), plus `sweepUi` extended with the new screens. `genSave.ts` gains a House Amaranth fixture (it's Warden-only today, per the audit). And `npm run lint` on your machine — the naming lock check needs `.env.local`, and this build adds the biggest batch of new player-facing strings since Frame Systems (every estate room name, Verinis, the Seal's chair label).

Rough shape: step 1 one session; steps 2–3 one session; step 4 is mostly yours; step 5 rides with 2–3.

## 3. Things the refactor will surface — known now, not surprises later

- **Marrow has no rank field.** The header reads `rourkeRank` + name; `campaignState.ts` already flags that `rourkeRank` stays `"2nd_lt"` forever on a House Amaranth save. The profile's `mc.rankLabel` returns a fixed `"Col."` for her until a promotion schedule exists. Cosmetic, honest, flagged.
- **The CO check-in gate, brief/debrief, build-approval and advice paths are written for Arangement** (`pickCoAdviceLine`, the check-in nudge text, the build-request sentences). They key off `CO_PILOT_ID` and `CO_POINT`, so they *function* for Verinis on day one — in the wrong voice. Step 4.
- **Verinis is romanceable; Arangement is not.** Species-capped via `ROMANCE_CAPPED_SPECIES`, so human = open by default (the 4 Sep doc checked this). The refactor is the moment to grep for any "the CO is never a romance option" assumption in the Hub-CO wiring — the doc's own flag. None known; not yet proven absent.
- **The carrier-module economy is Warden-flavoured in its strings** ("carrier modules", the Workshop panel's "CARRIER UPGRADE MODULES" title). The Boiler Room's BAY markers reuse the same system as-is; a string pass ("estate works") is cosmetic and can wait. The stale "Runic Integration Line — Waiting on Heirlooms" lockout you photographed tonight is the same file (`carrierModules.ts`, already in the audit gap log) and would show up in both hubs until fixed.
- **`NPC_SEED` positions bleed.** `buildNpcs()` walks `NPC_SEED` for the three regulars' *positions* — the reason `npcSeedHouseAmaranth.ts` was kept separate. The profile owns the seed, which closes that.
- **Two new room ids with no mechanic** (`cellars`, `records`) need a `ROOM_NOTES` line each so an empty room reads as "not built yet," not "broken" — Warden's own rule.

## 4. Out of scope, said out loud

- The Antfarm placement economy ("build your ship"). The estate is a fixed floor plan exactly like the Antfarm is today.
- A Frame Systems / salvage walk-up in the Cellars, a records terminal in Records — both drawn as *natural future homes*, neither built.
- The Seal-holder as a character. The empty chair is a prop, not an NPC.
- Any change to House Amaranth's missions, roster, or economy numbers.
- Sharing one save between hubs. A save is one side; `baseSceneKeyFor` picks the hub.

## 5. Decisions needed on approval (mirrors the mockup's Q1–Q8)

1. Estate name — "The Greathouse" proposed.
2. Room display names as drawn, or plain functional names.
3. Reliquary on 2SS — recommend yes.
4. Three Cultivar Works (one per lance) — recommend yes.
5. Keep the Cellars and Records as decor-only rooms — recommend yes.
6. Verinis: Brigadier, name tag text, the Seal's empty chair — chair is optional.
7. Floor chain and stair ends as drawn.
8. **Option B (one Hub, two facilities) — recommend yes, and it goes first.**

---

*Also this session, unrelated to the hub but on the same machine:* the Vault overlay is now scrollable (`Hub.ts`, mouse-wheel + geometry mask, same idiom as `MapSelect.ts`'s mission list; title/close/memorial link stay fixed) — written to disk, **not** run or typechecked at Maxime's request ("just dont load it"). And a real gap confirmed against the live files: `PilotSocialState` tracks `stress` and `morale` per pilot, but `scenes/ui/RosterPanel.ts` renders only favorability, path/tier and points — Stress and Morale were in the 29 Aug plan for that panel and never made the 5 Sep build. Both belong in `Now_And_Next.md`'s "Needs verifying" / "On the table" lists.
