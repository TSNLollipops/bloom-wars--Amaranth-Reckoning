# Bloom Wars — The Mek Workshop, and Weapon/Module Progression, v1

*Started 26 Aug 2026. A plan, not a lock — real open questions flagged throughout, same discipline as every other design doc in this project. Nothing here is in the engine yet.*

## 0. What this is answering

Maxime, in one message: build out a room for the Meks to actually live in ("the mek living in thr workshops one per lance thats where they work. otherwise they can roam"), frame Meks as the pilots' real narrative partner, style the shop room like XCOM's Engineering bay, and — separately, but clearly meant to inform the same system — "expand the weapon and progression list, I think the options are slim... go ham on weapons and modules," using "weapon and progression" as the read on what he wants the per-pilot point system to actually be. He also flagged mid-thread that he's already added **Missiles as a Reeps weapon type** on his own end — the first real crack in what's currently a flat, weapon-free stat model.

Per his own steer, this checks the Qiraki book project first — it turns out to have a whole document on exactly this (`Qiraki_Weapons_And_Progression.md`), which is cited throughout below. **One naming-lock note, quick and not dwelt on:** that book doc uses its own in-universe word for a deployed pilot. That word doesn't appear anywhere below — this doc says "pilot" throughout, same as every other Bloom Wars doc, per the project's standing naming lock.

## 1. Meks are people — the Workshop room

**The game's own data already treats a Mek as one specific person's partner, not a generic gear slot.** `PilotRecord.mekId` is already a 1:1 pairing (`data/meks.ts`: "Nagori's Mek," "Barasj' Mek" — a named entity per pilot, not a shared pool), it's just never been exposed as a *character*. That's a real head start — this isn't a new data model, it's giving an already-1:1 relationship a face and a room.

**What the book project already has, checked before proposing anything:** every named pilot cadet in Qiraki has an individually matched Mek — Petra Lindqvist matched to Ilyen Pral, Doyle Marsh to Denic Voss, Fenn Okafor to Corw Adeyemi-Tal, each with a real personality distinct from their pilot's, described as genuine chosen-family texture that has to "visibly warm and develop... not just exist as a name on a roster," specifically because "a mek who barely gets screen time still needs to be missed if lost, which only works if the bond read as real." That's the emotional register Maxime's "partner" word is pointing at, and the book project has already thought through why it has to be earned rather than assumed.

The book's own workshop concept is paired at the individual level — one cadet, one mek, one shared workspace, "kept paired specifically so they keep working on the same machine together." Maxime's ask scales that up to **one workshop per lance** rather than one per pilot pair, which reads as the right call for a UI that has to represent up to 20 pilots by Act III rather than one protagonist's team — instead of twenty individual workshop scenes, a lance's five pilot-mek pairs share one room, the same way real machine shops have multiple benches under one roof. Each pilot's mek is still *their* mek — the 1:1 bond doesn't change — the room is just where that lance's set of them happen to work. Proposed, not locked; worth a direct confirm before it gets built.

**Resolved, 2 Sep 2026 — one workshop per lance, confirmed.** Raised again in chat (Maxime: "we gotta make workshop only work per lance so player gotta have 3 workshop in act 3 for their 3 lance"), and confirmed directly this time, settling the open question above for real: one Mek-pairing Workshop per lance, three by Act III, matching the game's existing 1/2/3-lance progression exactly. Scoped narrowly to this room specifically, not the Carrier Upgrade Modules bench that shipped into the same physical room on 2 Sep — that bench buys ship-wide upgrades and stays a single, ship-wide fixture; it does not get cloned per lance. Full build plan, including the physical-space dependency this creates (the ship needs to get bigger before two more Workshop-sized rooms fit) and the still-open cost/gating question for a new lance's Workshop: `Bloom_Wars_Carrier_Scale_And_Lance_Workshop_Plan_v1.md`. Not yet built — still a plan, same as everything else in this doc — and explicitly flagged in that plan as sitting outside the current Early Access critical path, per the 27 Aug Early Access Scope Triage's own call that Mek Workshop is post-launch, ongoing work.

**"Otherwise they can roam"** is the same mechanism the Hub's planned "talk to the crew" ambient-line system already needs (see the Spitball doc's Hub-layer entries) — a mek isn't confined to the Workshop any more than a pilot is confined to Berths. One line-pool system, doing double duty for both pilots and meks, not two systems.

**The real open question this raises, bigger than the room itself: can a Mek be lost?** The book's own material treats mek loss as a real, mournable event — the whole point of "must be missed if lost." Bloom Wars already has a locked, load-bearing permadeath system for pilots and a Stress/grief mechanic taking shape for the social layer. Giving meks a face and a name without deciding whether they can die leaves a real gap: either they're quietly plot-armored in a game that's proud of not doing that for anyone else, or losing one needs its own hook into Stress/grief, distinct from a pilot's own permadeath (a mek dying doesn't cost a roster slot the way a pilot does, so it'd need its own shape, not a reused one). Not answered here — flagged as the single biggest design question this idea opens.

**The XCOM look, concretely.** Picture the existing Hangar/`ShopPanel` screen (already live, already does tier upgrades, mek secondaries, spare parts, discretionary recruits, company-points readout) but scoped to one lance's Workshop: a named Mek "at the bench" for that lance, the same item-grid-with-cost-and-description shape Engineering already uses, and one genuinely open call — does a purchase resolve instantly, the way the shop does today, or does it cost real time on a build queue, the way XCOM's own Engineering does? The in-fiction calendar idea (already queued in the Spitball doc, waiting on the mission-building-done trigger, which has now actually fired) is the natural home for that if the answer's "it takes time" — worth deciding those two together rather than separately, since a build queue with no calendar to measure it against doesn't have anywhere to put its numbers.

**One more idea worth stealing directly, not just adjacent inspiration:** the book's fabrication economy splits the cost in two — the pilot spends points on the *schematic* (what gets built), the mek spends a separate, cheaper, per-unit *materiel* cost to actually print it, and batching several small jobs into one run saves materiel over doing them one at a time. That's a genuinely good fit for a per-lance Workshop specifically, since it gives the room a reason to reward planning (queue several pilots' upgrades together) rather than being a flat vending machine. Proposed as a real candidate for how weapon/module purchases work, not locked — see §2.

## 2. The points economy, extended for weapons and modules

**What's already locked (Data Pack §12), for reference, nothing here changes it:** gear tier costs 60 / 90 / 140 / 210 / 320 / 500 points per step, G through A; a mek secondary specialization costs 180, once, only for a mek with no secondary yet; a spare Fabricator part costs 40. Earning: 120–200 per mission base, +10 per turn under the limit, +40 for no pilot downed, +30 for no spare parts spent, +25 for clearing an objective without Severance (Mission 3 only). All of that stays exactly as-is — this section is only about where weapons and modules plug into it.

**Proposal: weapons and modules are a new purchase category in the same economy, tier-gated.** Not a second currency, not a separate minigame — the same points a player already earns and already spends on tier/mek/recruits, just with more things to spend them on. Tier-gating (a pilot's *own* gear tier has to be at least X before a given weapon tier is purchasable) keeps this from being "buy the best gun turn one" and keeps the existing tier ladder meaningful instead of being made redundant by a parallel weapon ladder.

**Every actual number below is a placeholder.** Per this project's own standing rule, a number only counts once it's run through `combat_sim.py`/the live sim harness and passed — nothing here should be read as tuned, only as "here's roughly the shape."

**A genuinely good later idea, not core to this pass:** the book's military-era point formula reshapes entirely at higher rank — survival and kills stop being the only inputs, and points start rewarding *teammates who come back alive*, explicitly because "a pilot thinks in terms of what he alone can survive, a commander has to think in terms of what an entire team can." Bloom Wars already has the exact rank ladder this would hook into (2nd Lt. → Capt. → Maj., already on record from the Gladiator-mode discussion). Worth a real look once the rank ladder itself is actually built and used for something — flagged here so it isn't lost, not proposed as part of this pass.

## 3. Weapon expansion — going ham, per class

Current baseline, worth stating plainly before expanding it: every unit today has one flat `baseAttack` number and a set of path-locked abilities (Overwatch, Ambush, Taunt, Screen, Interdict, Fire×2). There's no weapon-*choice* layer at all yet — Missiles-for-Reeps is the first crack in that, not an extension of an existing system. Everything below assumes a new `weapon` slot per pilot, separate from the Mek track, unlocked/upgraded through the Workshop.

For reference, the actual locked class triangle (Master Index, confirmed against the GDD's own §4.1 language before writing any of this): **Tank beats Meeps, Reeps beats Tank, Meeps beats Reeps.** Every weapon idea below is written to reinforce that shape, not soften it — especially Tank, which has an explicit, already-locked "do not soften the zero-reach weakness" rule.

**Meeps — mobile skirmisher, beats Reeps, loses to Tank.** The book's own Meeps track discovers a real fork between committed impact and cutting mobility (two different cadets on the same path never fully understanding why the other's choice works) — worth mirroring as real build-fork flavor, not just numeric variants:
- **Twinblades** (default) — dual-blade melee, the mobility/ambush-first option: best synergy with the existing dodge and Ambush kit.
- **Impact Lance** — a single, heavier committed strike: more damage per hit, no dodge-adjacent bonus, the "trust the hit, not the footwork" alternative to Twinblades.
- **Shock Claws** — melee, chance to briefly stun on hit. **Flag:** stun doesn't exist in the engine today — this is new status-effect work, not just a number (see §5).
- **Scattershot Pistols** — very short range (2, not Meeps' usual 1), small cleave to a second adjacent target. A tiny nudge toward range without actually breaking "Meeps has to get close" — worth watching that it doesn't quietly become a mini-Reeps.

**Tank — melee anchor, beats Meeps, loses to Reeps. No ranged option, ever — restating the existing GDD §4.1 lock explicitly so it doesn't get re-proposed by accident later.**
- **Slam Cannon** (default) — heavy single-target melee, today's baseline.
- **Riot Drum** — melee plus a knockback/pin on hit, echoing the existing Interdict ability's own flavor.
- **Grinder Claw** — melee plus self-heal on hit, a natural pull for anyone running Armorer as their track.
- **Maser Lance** — a big, committed cone AoE. The book is explicit that Tank's offense is supposed to arrive *late*, after the defensive/utility identity is already established, not from day one — propose gating this behind a real tier floor (D-tier or higher) on purpose, so Tank keeps reading as "the wall" before it reads as "also hits hard."

**Reeps — ranged kiter, beats Tank, loses to Meeps.**
- **Marksman Rifle** (default) — standard ranged, today's baseline.
- **Missiles** (Maxime's own addition) — heavier single hit, likely small splash. Worth a real tradeoff so it doesn't just strictly outclass the rifle — limited charges per mission, or a lower shot count, is the obvious lever.
- **Rail Lance** — armor-piercing, a real bonus specifically against Tank. Doubles down on the class triangle instead of blurring it, which is the right direction for a Reeps weapon to lean.
- **Suppression Autocannon** — lower per-hit damage, applies an attack-debuff to the target. **Flag:** the *precedent* for this already exists on the Bloom side (Sirenmaw's own AoE attack-debuff aura), just not on a player weapon yet — porting a concept that's already proven in the engine is cheaper than inventing one from scratch.

**Munti — support/healer, outside the triangle, range 2.** The book's own Munti design is worth taking almost directly rather than inventing three generic guns: one weapon, doing double duty. Its combat unit "fights via matter disintegrator, which is the repair beam run in reverse... one piece of tech, two functions, no separate weapon system needed." That's a better fit for Bloom Wars' own Munti than a gun would be — it's already got Repair and passive AoE regen defining its identity, and this gives its attack the *same* fiction instead of a bolted-on third thing.
- **Reclaimer Beam** (proposed name, placeholder) — same tech as Repair, aimed at a hostile instead of an ally. Possibly literally the same ability/action-point slot, retargeted, rather than a separate weapon system — worth checking against the existing two-action economy before assuming it needs new plumbing at all (see §6).
- Munti gets **modules**, not more weapons, since it already has a real identity — see §4.

One more piece of found connective tissue, offered rather than assumed: the book's Munti also carries a "cockpit evacuation system" that teleports a downed pilot's cockpit straight to the carrier the moment they're rescued. Bloom Wars' own restock rule ("if there's a Munti, there's restock") has never had an in-fiction *mechanism* — it's just abstractly "restock." This would give it one, for free, narratively. Not required, just sitting there if it's wanted.

## 4. Modules — a separate slot from weapons

Utility augments, one or two per pilot, in the same spirit as the existing Mek-track secondary specializations but not tied to a Mek track:

- **Combat Stims** — temporary attack boost, limited charges per mission.
- **Reinforced Plating** — temporary defense boost, same shape.
- **Grapple Line** — one extra burst of mobility, once per mission.
- **Smoke Charge** — a defensive AoE, reduces incoming accuracy in the cloud.
- **Signal Booster** — extends vision, or synergizes with Sensor Sweep's existing cooldown/charge system.
- **Emergency Foam** — a self-stabilize charge. **Flag, real overlap:** this reads extremely close to the Fabricator track's existing spare-parts fiction (redeploy a downed pilot at 50% HP). Worth deciding whether this is a genuinely separate module or just a second way to buy the same thing Fabricator already sells — probably shouldn't be both.

## 5. New status effects this would actually need — said plainly, not buried

None of these exist in the engine today: a stun (Shock Claws), an attack-debuff (Suppression Autocannon), a slow/root (if a Munti-side control module is ever built). Each is real engineering, not a data-only change like the rest of the archetype system currently is. Worth deciding up front whether a first pass ships numbers-only weapons (bigger/smaller attack, range, a defense-ignoring multiplier for Rail Lance, a heal-on-hit for Grinder Claw — none of which need new engine work) and holds the status-effect weapons for a second pass, rather than trying to build everything in §3 at once.

## 6. Open questions, collected in one place

- ~~**Workshop granularity** — one per lance (proposed above) or one per pilot-mek pair. Needs a direct confirm.~~ **Resolved 2 Sep 2026 — one per lance.** See the resolution note in §1 and the new `Bloom_Wars_Carrier_Scale_And_Lance_Workshop_Plan_v1.md` for the build plan this unlocked.
- **Can a Mek be lost, and if so, what does that cost?** The biggest open question in this whole doc.
- **Instant purchase (today's shop) or a real build queue over in-fiction time** — ties directly to the still-queued calendar idea.
- **The schematic/materiel cost split** — adopt the book's two-part spend, or keep one pool like today's shop?
- **Munti's Reclaimer Beam — same action as Repair, retargeted, or a genuinely separate weapon slot?** The two-action system may already have the shape this needs without new plumbing.
- **Which status effects (if any) get built for a first pass**, per §5.
- **Every weapon/module name above is a placeholder.** Naming is Maxime's own call throughout this project — none of it should be read as decided.

## 7. If this got greenlit, what I'd actually build first

Cheapest-to-most-expensive, not importance order: (1) the Munti Reclaimer Beam, since it likely reuses an existing ability rather than needing anything new; (2) the numeric-only weapons that need zero new status-effect work — Missiles, Rail Lance, Grinder Claw; (3) the per-lance Workshop room itself, reusing the existing `ShopPanel` pattern the Hangar and Debrief screens already share; (4) the status-effect-dependent weapons (Shock Claws, Suppression Autocannon) once there's an actual status-effect system to hang them on, rather than building that system for one weapon at a time.

---

Sources checked before writing this: `Qiraki_Weapons_And_Progression.md` (weapon philosophy per path, the Munti's dual-use disintegrator, the schematic/materiel cost split, the rank-based reward reshape), `Qiraki_Character_Sheets_v5.md` (the named mek-pilot pairs, the chosen-family framing), `data/meks.ts` and the Data Pack's §12 points economy (the live, current numbers this plan extends rather than replaces).
