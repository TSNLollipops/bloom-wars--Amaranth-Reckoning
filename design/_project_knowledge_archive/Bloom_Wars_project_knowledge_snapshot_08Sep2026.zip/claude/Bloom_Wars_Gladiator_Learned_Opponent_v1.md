# THE BLOOM WARS — Gladiator Mode: Player-Learned Opponent AI (v1)

*25 Aug 2026. Design only, zero code, not scheduled — same standing rule as
`Bloom_Wars_Player_AI_Ability_And_Objective_Plan_v1.md` and
`Bloom_Wars_NPC_Reaction_Engine_v1.md`. Captures a real decision Maxime made
about how Gladiator's AI opponent should work, and is honest about how big a
dependency chain sits underneath that decision. Companion to the Player AI
plan (shares its architecture) and to the Gladiator entry in
`Bloom_Wars_Spitball_Ideas.md`'s "Parked" section (not duplicated there —
this doc is the fuller reasoning it now points to).*

**Pointer, 4 Sep 2026 — a much bigger, separate Gladiator concept now exists too, deliberately not merged in here.** `Bloom_Wars_Gladiator_Fleet_Battle_Concept_v1.md` captures a persistent-fleet, ship-combat, boarding-and-capture version of Gladiator — same name, a different and far larger mode, sitting behind this one in the build queue rather than replacing it. This document's own small vs-AI v1/v2 split (§5/§6 below) is still the nearer-term version, if either ever gets picked up.

## 0. Where this came from

Maxime, extending the Player AI conversation: "do what you recomend, see if
we can make the ai learn from the player an actual feature of the game. so
that when the guy play gladiator after the story, (the multiplayer match)
hed have a fair enemy." Two follow-up decisions, made directly rather than
assumed:

- **Asked whether "fair" should mean rules-fair-now-smarter-later, or
  whether learning should gate the mode's release at all — Maxime picked the
  gate.** The AI has to have actually learned from real play before Gladiator
  counts as done. It doesn't ship as "vs. a heuristic bot we'll improve
  later."
- **Asked whose play it should learn from — one baked-in designer dataset,
  or each player's own — Maxime picked each player's own,** explicitly
  including his own play as the first real instance of that: "the player who
  play the game 'play' including in this specific case, my own."
- **Then, unprompted, on real (human-vs-human) multiplayer:** "a fair ai to
  fight against at least, i'm sure if we add actual multiplayer itl have to
  be doom style." Read as: the AI-opponent version of Gladiator is the
  actual near-term target, full stop — not a placeholder standing in for
  real PvP. If human-vs-human multiplayer ever gets built, Maxime's own
  instinct is that it would need a different, real-time architecture ("Doom
  style") rather than an extension of this turn-based one — matching the
  concern already on record in Spitball Ideas' own Gladiator entry ("turn
  gladiator into rts lol"). Not designed here, and per that same instinct,
  probably shouldn't be assumed to share much code with what follows.

**Superseded by §5 below, kept for the reasoning.** Everything from here
through §3 was the shape of the ask before Maxime weighed what it actually
committed to and scoped it back down — still worth keeping in full, since §5
is a deliberate scale-down of this, not a replacement for the thinking in
it.

## 1. What "learning gates the mode" actually commits to

Worth being direct about this rather than letting the size of the
commitment stay implicit: picking the gate over the rules-fair-first option
means Gladiator, as a shippable feature, now depends on a whole chain of
things that don't exist yet — most of them well beyond AI. Laying out the
chain plainly, in order, so nothing in it is a surprise later:

1. **A campaign worth learning from.** "After the story" implies most or
   all of the campaign has actually been played — right now only missions
   1-8 of 36 are built
   (`Bloom_Wars_Player_AI_Ability_And_Objective_Plan_v1.md` §0). A single
   player's data, mid-campaign, is a thin and skewed thing to learn a
   final-boss-adjacent opponent from. This realistically can't start
   producing something worth shipping until the campaign is substantially
   built out.
2. **The Player AI plan's own Phase 1** — giving `decidePlayerAiAction` a
   real `Mission` reference and a structured, named `action` output (that
   plan's §1). Shared foundation either way: the same interface that lets
   the kid-level test bot ask "can I Screen right now" is the interface a
   real player's actions need to be logged against, so the two efforts
   aren't separable.
3. **New: logging real play, not just the sim harness.** Nothing built or
   planned so far records a *human's* in-mission decisions in a structured
   way — `src/sim/playerAi/` is the test bot's own code, and a human playing
   through `scenes/Battle.ts` today produces no equivalent trail at all (the
   NPC Reaction Engine doc's §4a already flagged this exact gap from a
   different angle: "a human playing a real mission... never produces a
   `PlayerAiReason` at all"). This has to be built new, has to run for every
   player on their own save data, and has to start from a player's very
   first real mission — not retrofitted in later once "the learning system"
   is ready, or most of a playthrough's data is lost before it's ever
   collected.
4. **New: turning a played campaign's log into an opponent.** The honest
   data-scale problem: one full campaign generates something like a few
   thousand individual decisions, not the scale a trained-from-scratch model
   would want. The realistic shape for this, given that constraint: not a
   black-box model, but **fitting the numbers inside the rule structure the
   kid-level bot already has** — the same "retreat below X% HP,"
   "prioritize the objective over a kill by this much," "use this ability
   when this condition crosses a threshold" shape from the Player AI plan,
   except X and the thresholds come from that specific player's own logged
   choices instead of a hand-picked "kid-level" guess. Keeps the opponent's
   behavior explainable and testable, which matters a lot given how much
   this project's own stress-testing (n=20+ batches, watching for outliers)
   depends on knowing why a bot did something.
5. **New: what the opponent's own squad is.** Gladiator is company-vs-
   company — the AI needs a roster, not just in-mission unit control, and
   squad composition is explicitly called out as *out of scope* in the
   Player AI plan (§5). One idea worth putting on record here rather than
   defaulting to a generic enemy list once this gets designed for real:
   **mirror the player's own trained roster and mek loadouts as the
   opponent's company** — a literal reflection of what the player built,
   which both answers the composition question and fits "gladiator match"
   thematically better than an arbitrary enemy roster would. Not decided,
   just worth not losing. **Reopened, 4 Sep 2026 — see §7: this idea is now
   in real tension with a newer ask, not just an open question.**
6. **Still open, inherited, not solved by any of the above:** the
   turn-structure/scale problem flagged the day Gladiator was first floated
   — a full company on each side (up to ~20 pilots by Act III) risks
   tipping the whole mode into something closer to an RTS than this game's
   tactics loop. A smarter AI opponent doesn't touch that problem at all;
   it's a separate design question that still has to get solved for
   Gladiator to exist in any form.
7. **Real multiplayer, if it happens.** Per Maxime's own read above, a
   different (real-time) architecture, a separate future decision, not
   designed here.

## 2. What I'd actually build first, given that chain

Not a schedule — nothing here is being built now — but worth naming the
order that makes sense once it does get picked up, so the dependency chain
in §1 doesn't read as an argument for doing nothing:

- Phase 1 of the Player AI plan happens regardless of Gladiator — it's
  needed for the kid-level test bot either way, so it isn't new cost this
  decision adds.
- The campaign-side logging (§1.3) is worth building **early,
  deliberately** — even long before any learning layer exists — so data
  starts accumulating from the first real missions played rather than being
  missed retroactively. Waiting to build the logger until "we're ready to
  build the learning system" throws away exactly the data that system will
  need most.
- The parameter-fitting layer (§1.4) becomes its own scoped project once
  there's a campaign's worth of real log to fit against — not before, since
  there's nothing to tune against yet.
- Composition (§1.5) and the turn-scale question (§1.6) stay open
  questions, tracked here and in Spitball Ideas' own Gladiator entry, until
  Gladiator itself gets a real design pass.

## 3. Explicitly not decided here

- The exact statistical method for turning a player's log into fitted
  thresholds (nothing more specific than "fit the existing rule shape"
  above).
- Whether emergency-replacement/recruit pilots (Spitball Ideas' permadeath
  entry) show up in a mirrored opponent roster, or whether the opponent
  gets its own separate pool.
- Anything about real human-vs-human multiplayer — flagged as
  probably-different-architecture per Maxime's own instinct, nothing more.
- Whether "each player's own play" data ever needs to leave that player's
  own machine/save (a privacy/architecture question this doc doesn't
  touch).

## 4. Status (as first written)

Design only. Not scheduled. Depends on the campaign being substantially
built (only 1-8 of 36 missions exist today) and on the Player AI plan's own
Phase 1 landing first. This document exists so the decision — gate on
learning, learn per-player — and the chain it commits to don't drift or get
lost before any of that is actually true. **Superseded by §5 directly
below, same day.**

## 5. Update, 25 Aug 2026 (same day) — scoped down to a v1/v2 split, filed as wish-list-later

Maxime, after sitting with the dependency chain in §1: "lets fold it in the
wish list ill get to it when ther emor emission dones." Two things happened
here, not one:

- **The plan splits into a v1 and a v2, not a single learning-gated
  feature.** v1 drops the per-player learning pipeline entirely and gets
  "fair" from two things that are cheap because they're already committed
  or trivial: a fair-by-construction opponent (same points budget and rules
  the player has, no vision/stat cheats, plausibly a roster that mirrors
  the player's own trained company — §1.5's idea) controlled by the Player
  AI plan's own bot, with its heuristics hand-tuned from Maxime's actual
  play the same informal way every other balance number in this project
  already gets tuned (the Tank-dodge fix, the two-action Munti change — see
  `Bloom_Wars_Spitball_Ideas.md`'s "Already built" section for the
  pattern). No new logging system, no per-save data pipeline, nothing
  beyond Player AI plan Phases 1-4 plus whatever composition work Act II's
  own squad-picker already needs to do anyway. v2 is everything in §0-§3
  above, unchanged — the real per-player learning vision — kept on record
  as the actual "someday," not the near-term target anymore.
- **Neither version is being picked up now.** Maxime's own framing: this
  belongs in the wish list, revisited once more of the campaign is actually
  built — matching the "campaign has to substantially exist first"
  dependency that was already §1's first and hardest-to-shortcut item.
  Filed in `Bloom_Wars_Spitball_Ideas.md`'s Gladiator entry, not scheduled
  here or there.

## 6. Status

Design only, not scheduled, not started. v1 waits on more of the campaign
being built; v2 waits on v1 existing and a full campaign's worth of real
play data on top of that. This document exists so both versions, and the
reasoning behind the split, don't drift or get lost before either gate
clears.

## 7. Update, 4 Sep 2026 — recurring rivals across Gladiator matches, reusing the new friendliness gradient

Maxime, in the same conversation that just locked the -100/100 mirrored
friendliness gradient for the Hub roster (`Bloom_Wars_Antfarm_Carrier_Hub_v1.md`
§13.2, `Bloom_Wars_House_Amaranth_Hub_Facility_Plan_v1.md` §5): *"also we sre
going to reuse the system during gladiator. to allow player npc pilot and
mech to hsve rivals among the other company if they ever play against the
same guy again."* Read plainly: a player's own trained pilots can build a
real rivalry (or, symmetrically, a grudging respect — same mirrored axis,
same as everywhere else it's used) against a *specific* opposing pilot they
recognize from an earlier Gladiator match, not just "the AI is harder this
time."

**Good idea on its own merits, worth saying plainly rather than just
logging it.** This is exactly the kind of thing that turns a vs.-AI
minigame into something with real texture — "oh, it's her again" lands very
differently than a fresh anonymous roster every match, and it's genuinely
cheap in *content* terms because it reuses infrastructure that already
exists or was just designed, not a new system from scratch:

- **The pairing math already exists, just scoped to the wrong roster
  today.** `npcBonds.ts`'s `RIVAL_THRESHOLD` and `friction.ts`'s display
  layer (the ⚡ tag, `FRICTION_LINES`) already do "two pilots whose bond has
  gone negative enough to register as a real rivalry" — currently only
  between pilots who share the player's own crew. Extending that same
  mechanic to a cross-company pairing (a player pilot × a specific opposing
  pilot) is the same shape of problem, not a new one.
- **The tone axis is exactly what got designed this session.** The mirrored
  -100/100 gradient (Antfarm doc §13.2) is precisely the thing that should
  drive what a recurring Gladiator rival actually *says* when you face them
  again — hostile at the bottom, grudging respect climbing toward the top,
  same seven bands, same content already being planned. No separate
  "Gladiator rivalry" vocabulary needs inventing; this is the same system,
  a new pairing domain.

**The real prerequisite this creates, not smoothed over: opposing pilots
need to actually persist as individuals across separate matches.** This is
the part that isn't free, and it's worth being direct that it's a new
requirement, not just content reuse. "If they ever play against the same
guy again" only means something if there's a real "guy" to play against
twice — a named opposing pilot with a stable identity (an id, a face, a
catalyst, eventually gradient history) that can recur across separate
Gladiator sessions, not a random roster regenerated fresh every match.
Nothing on record today provides that.

**Direct tension with §1.5's own standing idea, worth flagging rather than
letting both sit on record as if they agree.** §1.5 (and §5's v1 scope)
currently only has one idea for where the opponent company comes from:
"mirror the player's own trained roster and mek loadouts as the opponent's
company." If the opponent is always a reflection of the player's *own*
roster, there is no persistent third party to recognize and hold a grudge
against — you'd be building rivalries with copies of your own pilots, which
doesn't match "rivals among the other company" at all. These two ideas
can't both be the answer to "where does the opponent roster come from."
Not resolving this here — flagging it as a real decision Gladiator's
eventual real design pass owes an answer to, one of, plausibly:

- A separate, persistent pool of named opposing pilots (hand-authored or
  procedurally generated once and then kept stable) that Gladiator draws
  from match to match, mirroring the player's roster only in *size/comp*,
  not literal identity — the version that actually supports this ask.
- The player-mirror idea stays, and "the same guy" instead means something
  narrower — recognizing a specific one of the player's *own* trained
  pilots reflected back, which is a stranger, more introspective feature
  than "a rival company" implies and probably isn't what was meant here.
- Some blend: a small fixed roster of named "circuit regulars" (rivals
  worth remembering) layered on top of an otherwise-mirrored or
  otherwise-generated opponent company each match.

**Status: recorded intent, not designed, not scheduled — same as every
other Gladiator decision in this document.** Everything here waits on the
same gate §5/§6 already established (more of the campaign built out before
Gladiator gets a real pass) plus, now, a real answer to the composition
question above before this specific piece is buildable at all. Worth
revisiting alongside whichever of §1.5's open composition question actually
gets picked when that day comes, not before.
