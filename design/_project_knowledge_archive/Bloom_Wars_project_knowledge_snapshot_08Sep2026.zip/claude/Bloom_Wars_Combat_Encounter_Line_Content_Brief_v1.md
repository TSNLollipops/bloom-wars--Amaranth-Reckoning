# THE BLOOM WARS — Combat Encounter Line Bank: Content Brief v1

**Purpose of this doc:** a planning brief, same tier as `Bloom_Wars_Ambient_Line_Content_Brief_v1.md` was before its bank got written — scope the job, flag what it touches, propose a shape, surface the one real decision, before anyone writes 200+ lines around a guess. Written 27 Aug 2026, in response to Maxime asking for combat-encounter dialogue between Warden Company and two counterpart forces: House Amaranth ("the other side") and a Coalition-flavored force ("COE force").

**Decision logged, same day:** Maxime picked the deep tie-in over the light-touch default for Bank 2 — real connective canon between Warden Company and the Coalition, not just flavor. §4 below is the worked-out shape of that, not the open question it started as.

---

## 0. The one hard rule, restated for whoever writes this

Same rule as every other content doc in this project: one reserved term from the book side must never appear in any line, filename, or comment written for the game, enforced by `tools/lint-spoiler.mjs`, not just a convention. Separately, **"Synker"** (the Qiraki-side in-universe term for a mech pilot) and **"The Synker Wars"** are both explicitly reserved as the book series' own military-arc name and must not surface as game-facing strings either — this bank sits closer to that trip-wire than any prior content pass has, since it's the first Bloom Wars content deliberately drawing on Qiraki's *military* material rather than its species/bestiary material, so it's flagged here at the top rather than assumed. The word **"Qiraki"** itself also never appears as an in-fiction name — that's a separate, book-internal spoiler lock (the enemy's true name, unrevealed) — Bloom Wars already handles this correctly everywhere by only ever saying "the Bloom," and this bank keeps doing that.

## 1. What this actually is

Two banks of combat-encounter dialogue for Warden Company (the Amaranth Reckoning's own cast, using the 9 already-established catalyst voices — Wolf/Dog/Cat/Crow/Raven/Bear/Fox/Rabbit/Shark) to exchange with two counterpart forces:

- **Bank 1 — "The Other Side."** House Amaranth's troops and Colonel Marrow, already Bloom Wars' own established antagonist. Lines both directions: what Warden says at/about them, and what they say back.
- **Bank 2 — "Coalition Force."** A Coalition-flavored allied/counterpart force, sourced from Qiraki's political and military material, invented where the source is silent (there's no existing "frontier relief fleet" character work in Qiraki to port — this is new texture built in Qiraki's voice, not a transcription of something already written). Now a real, connective piece of canon rather than one-way flavor — see §4.

This is a new content *type*, not a new bucket in the existing Hub ambient-line system — see §2 before Phase B starts.

## 2. Scope flag — read this before writing anything

Per the project's own standing rule ("if something meaningfully grows scope, say so before building it"), two things here are bigger than a normal content pass:

**a) New content type, likely new engine surface.** Everything written so far (Crew Banter, the Ambient Line Bank) fires in the Hub — `Hub.ts`, `socialSim.ts`, `pickAmbientLine`/`pickLineForMessage`. Nothing in the engine currently triggers a line *during a mission* off "this is the first turn you've seen a House Amaranth unit" or "a Coalition unit is on your side this battle." That's a real, unscoped hook — where in `Battle.ts`'s turn loop a line would fire, whether it's a toast/subtitle or a portrait+text box, whether it needs cooldown/dedup logic so it doesn't refire every turn. **Not blocking the writing** (same relationship Phase D had to Phases A–C in the ambient brief) but flagging now so nobody assumes this ships the moment the bank is written.

**b) New canon material for Bank 2, now decided rather than open.** House Amaranth needs no new canon — it's fully Bloom Wars' own, already built. "Coalition Force" did need a real decision: the Independent Campaign doc is explicit that this campaign "invents its own political texture from scratch" and "does not use the book series' reserved terminology anywhere" (§1) *specifically so it can't contradict book canon* — and the Master Index's 26 Aug policy update says deliberate Qiraki borrowing is the standing default for **"general lore, species, culture, and structural systems... not a repeal of the one actual lock."** A Coalition-flavored military force interacting with Warden Company sits right at the edge of that line: it's institutional/political texture, not just species or bestiary borrowing like everything reused so far. Maxime's call, logged at the top of this doc and worked out in §4: go deep, make it real connective canon.

## 3. Bank 1 — The Other Side (House Amaranth) — ready to write, no open questions

This one has real, already-locked material to draw from, and doesn't touch the naming lock, the cross-project dial, or anything unbuilt. Recommend starting here regardless of how Bank 2 gets decided.

**Voice arc across the campaign, already implied by existing docs, just needs to be written out as dialogue:**

- **Act I (Missions 1–12):** proud, territorial, a chartered House's own soldiers defending ground they believe is rightfully theirs. First real friction is Mission 6, House Colors — a checkpoint dispute turning violent, not yet personal.
- **Act II (Missions 13–24):** cracking. Mission 16, Collaborators, introduces conscripts fighting without conviction — the source doc already flags this mission as wanting a moral-complexity layer, and the parked "talk/fight/ambush" idea in Spitball Ideas is a real, live hook this bank could feed directly (a surrender/parley line-type, not just kill-or-be-killed barks). By Mission 23, the Bloom bargain is confirmed on-page — the ground under their own pride starts to give.
- **Act III (Missions 25–36):** shame and desperation. House Amaranth's name is quietly no longer said aloud by its own loyalists by this point (§5 of the Independent Campaign doc). Marrow turns on Halcyon Amaranth mid-battle at Mission 28. Rank-and-file lines here should read like people who know exactly what their own leadership traded away.

**Marrow herself** already has a full character voice on record (`Bloom_Wars_Amaranth_Reckoning_The_Other_Side_v1.md`) — common-born, proving herself to a family that'll never grant her rank by birth, executing the bargain out of debt not malice, "always better than the woman she served." She's referred to on Warden's comms as "the Major" before Mission 20 confirms who she is. Worth a small, separate higher-fidelity lane for her specifically (she shouldn't sound like a generic House Amaranth trooper), distinct from the generic-troop voice the rest of this bank covers.

**Before writing generic-troop lines, a 10-second check worth doing** (same discipline the Ambient brief's own §1 correction ran on): confirm whether `campaignAmaranth.ts` or the mission files already carry *any* House Amaranth unit flavor text today. Nothing in the docs read for this brief mentions any, so the working assumption is this bank starts from zero — but that assumption should get the same verify-against-the-file treatment every other claim in this project gets before Phase B locks in.

## 4. Bank 2 — Coalition Force — deep tie-in, decision made 27 Aug 2026

Maxime picked deep tie-in over light touch — real connective canon, not just flavor. Worked out a concrete shape rather than leaving "deep tie-in" as a label with nothing under it:

**The proposed origin, resolving the open Spitball Ideas flag.** Warden Company was never a House-chartered battlegroup. It started the way Qiraki's own political material already describes a specific category of unit: sport-named, corporately owned, exactly the kind of formation "no house would put its name on" — which by the Coalition's own logic (the Warrant-and-the-Hand structure, Qiraki_Political_Web.md) means whatever Warrant it nominally had was vacant or absentee from the start. Stationed in the Amaranth Reach — "a frontier cluster... answering to a core that's never in real danger" (Independent Campaign doc §4) — a Warrant posting here was never a prize, more likely a punishment or an afterthought.

So when the corporate chain of command that nominally owned Warden Company stopped paying attention — no dramatic severance, just the slow evaporation an under-resourced frontier asset gets when the people who technically own it have bigger things to watch — the professional officers (the Hand, in Coalition terms) kept running it, because the war didn't pause for an administrative gap. Nobody seceded. There was nothing left worth seceding from.

This is almost exactly the "corporation that owned the group outright, and the war turned that corporation into the group's government" idea already floated in Spitball Ideas — it just now has a real institution on the other end of it, and a real reason "nobody in it wants to change the name": no house ever performed loyalty to it, no Warrant ever cared what it was called, and by the time anyone from the Coalition core thinks to ask, it's been three years.

**A free mechanical payoff, not just lore.** Coalition doctrine (Auftragstaktik, per the Political Web doc) trains every officer to be given intent and left alone with it — missions running up to twelve hours to automatic recall, no arrangement under which a distant commander can direct a squad in real time. That's a clean, in-fiction reason the game already behaves the way it does: nobody radios Rourke new orders mid-mission. She's not improvising a local custom — she's flying a Coalition Staff-trained doctrine built around exactly this problem. Costs nothing to add, explains something the game already does.

**Vocabulary call.** Real Coalition institutional terms — Warrant, the Hand, on-Roll/off-Roll — come out of Coalition characters' own mouths naturally (this is genuinely how they'd talk about their own world; the source material's own usage note confirms these read as unexplained ambient vocabulary from early on, not held-back reveals). Warden Company itself doesn't reach for this language day to day — they're too many years removed from Coalition administrative culture, and a scrappy frontier company narrating its own history in that vocabulary would read like it's performing an identity it dropped a long time ago. Practical effect: Coalition-voiced lines get a genuinely distinct, foreign-sounding register on contact — a real culture clash, not just an accent — while House Amaranth keeps using Bloom Wars' own already-established "Seal and the Sword" phrasing rather than picking up Coalition terms. The two counterpart factions stay textured differently from each other and from Warden Company, which is good — they should.

**Staying backstage until it matters.** This origin doesn't need to surface anywhere before Act 3 — Warden Company doesn't explain itself to the player early, and the reveal lands harder if it's Coalition contact (Mission 36's relief fleet, still the anchor from the original draft) that surfaces it rather than any earlier narration. Matches the source material's own discipline (on-Roll/off-Roll, the Warrant system — none of it is ever explained on the page, a reader assembles it from context) — same restraint, applied here.

**Docs this actually touches, if this take is good — not edited yet, flagging first per the project's own rule about letting docs quietly drift:**
- `Bloom_Wars_Spitball_Ideas.md`'s "Company Commander" entry — this resolves the reconciliation it flagged as open.
- `Bloom_Wars_Independent_Campaign_The_Amaranth_Reckoning.md` §6 — Warden Company's roster intro could carry a line on origin.
- `claude/Bloom_Wars_Master_Index.md`'s cross-project references section — worth a note that this is now a second deliberate connective-canon decision, not just species-sharing.

Say the word and those get updated alongside the actual line bank, so nothing here just sits in a content brief while the docs it touches stay stale.

## 5. Situational taxonomy — answering "any other situation that might arise"

Proposed context tags, mirroring the Ctx column style the Ambient bank already uses:

| Tag | Situation |
| --- | --- |
| **FS** | First Sighting — initial contact/comms chatter before a fight starts |
| **MX** | Mid-combat exchange — taunts, warnings, banter traded while actively fighting |
| **KO** | Kill/down callout — a specific unit falls, either side |
| **AL** | Allied — fighting side by side (Bank 2 only, realistically — House Amaranth never fights *for* Warden in the current campaign outline) |
| **VC** | Victory — the fight's won |
| **DF** | Defeat/retreat — a forced withdrawal, either side |
| **PL** | Parley — surrender, ceasefire, the Mission 16 "talk/fight/ambush" moral-complexity moment |
| **PR** | Post-battle respect — a beaten or beaten-by opponent acknowledged as worth something, win or lose |
| **HB** | Hub reflection — an After-Action-context line for the *existing* ambient system, referencing "that fight against House Amaranth" or "the regulars who showed up" after the fact. This is the one bucket that plugs directly into infrastructure that already exists (`ambientLines.ts`'s AA context) rather than needing the new mission-time hook from §2a — worth prioritizing if a working demo before the engineering work is wanted.

## 6. Sample lines — proof of voice, not the delivery

A handful per bank, to show tone before committing to full volume. All written clean against §0.

**Bank 1 — The Other Side**

- *FS, Act I, Wolf:* "This isn't a fight either of us actually wants. Stand down and nobody else's name goes on a wall today."
- *FS, Act I, House Amaranth trooper:* "Warden Company. Mercs playing soldier. Get off our line."
- *MX, Act II, Bear, re: conscripts:* "Half of them aren't even trying to hit us. Somebody should ask why before we're the reason none of them go home."
- *PL, Act II, House Amaranth conscript:* "I didn't sign up to fight people — I signed up so my family keeps their terrace ration. Let us pull back. Please."
- *MX, Act III (post-Mission 23), Dog:* "You knew. Your whole House knew. Every grave on the Fallow Line has your name on it somewhere, even the ones that don't say it."
- *PR, Act III, House Amaranth trooper:* "Don't call it stewardship where I can hear it. Not anymore. Not after Meridian."
- *FS, pre-Mission 20, Raven, re: Marrow:* "Whoever's flying that mech reads a battlefield like she's done it her whole life. I almost want to buy her a drink instead of a burial."
- *DF, Marrow (comms, distant):* "Rourke. Yes — I know your name too. Pull your people back. I'd rather not add you to a very long list."

**Bank 2 — Coalition Force** *(revised for the deep tie-in — the "long-lost parent institution" register, not a first-contact-with-strangers one)*

- *FS, Coalition officer:* "Warden Company — you're still listed active on the Fleet manifest. Three years, and nobody flagged that as worth checking."
- *FS, Wolf, in reply:* "Nobody flagged us as worth remembering either. Good to know the paperwork agrees."
- *FS, Coalition officer:* "Records show your Warrant's been vacant since before any of us shipped out. Who's actually been running this company?" / *Dog, in reply:* "Same person who's been running it since it needed running. You're a little late to ask."
- *AL, Coalition officer, mid-fight:* "Hold formation, we'll take the flank. Whatever you've been doing out here without support, Staff is going to want it written up as doctrine."
- *AL, Shark, in reply:* "Try to keep up, regulars."
- *PR, Coalition officer, post-battle, quieter:* "Off-Roll, on-Roll — out here I'm not sure the difference ever meant anything. Wish someone back home could see this."

## 7. Phases

**Phase A — Lock the shape.** Situational taxonomy (§5) and Bank 2's depth (§4) are both settled now. Only remaining Phase A item: spot-check whether House Amaranth already has any unit flavor text in the repo (§3) before Phase B starts writing.

**Phase B — Write Bank 1 in full.** House Amaranth generic-troop voice across all three acts' arcs, plus Marrow's own higher-fidelity lane, across the §5 taxonomy.

**Phase C — Write Bank 2 in full.** Coalition Force generic-troop/officer voice, anchored on the Mission 36 relief fleet, using the vocabulary register from §4.

**Phase C.5 — Doc reconciliation.** Update Spitball Ideas, the Independent Campaign doc §6, and the Master Index per §4's list, so the origin decision doesn't just live in this brief.

**Phase D — NOT part of this job, flagged so nobody builds it by accident.** Wiring the actual mission-time trigger hook in `Battle.ts` (or wherever it ends up living), cooldown/dedup so a line doesn't refire every turn, and deciding the presentation (toast vs. portrait+textbox vs. something else). Real engineering work, separate from this content pass, the same relationship Phase D had to Phases A–C in the Ambient brief.

**Phase E — optional, stretch, cheap.** Fold the **HB** bucket into the *existing* Hub ambient system as new After-Action-context lines once a mission against House Amaranth (or, later, alongside Coalition forces) resolves. This is the one piece of this whole bank that could ship playable before any new engine hook gets built, since the hook it needs already exists.

## 8. Deliverable format

Same shape as the Ambient bank's own delivery: a table, columns **bank** (Other Side / Coalition), **tag** (§5), **act/stage** (where relevant), **speaker** (catalyst name, House Amaranth generic, Marrow, or Coalition generic), **line**, **source** (new, or cites what it's drawing from).

## 9. What this brief deliberately doesn't decide

- Exact lines-per-bucket volume — proportional to however deep the taxonomy in §5 ends up being used, not fixed here.
- Whether Marrow's higher-fidelity lane is a handful of lines or a real named-character pass on the scale of Crew Banter's own §10 named-pilot treatment.
- Whether the Mission 36 relief fleet gets a named commander (a Coalition-side counterpart to Marrow) or stays a generic-voiced formation throughout.
- The Phase D engineering work — hook design, presentation, and whether it's worth building before or after a first playable slice of Bank 1/Bank 2 content exists.
- The exact timing/wording of the Phase C.5 doc edits — drafted above as a proposal, not yet applied to Spitball Ideas, the Independent Campaign doc, or the Master Index.
