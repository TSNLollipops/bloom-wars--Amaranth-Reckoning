# THE BLOOM WARS — Grief Catalyst live port, shipped 28 Aug 2026

**Delivery note, same standalone-now/fold-in-later convention as the Weapons Bay + Fabricator and Needs Counter deliveries: not yet folded into `Bloom_Wars_Antfarm_Carrier_Hub_v1.md` §13.2 or `claude_Bloom_Wars_Master_Index.md` themselves.**

## What shipped

Source: your `claude_Bloom_Wars_Grief_Catalyst_Port_Spec_v1.pdf` — item 2 of the Antfarm Réalisation plan's Phase 1 gate, item #21d of `Bloom_Wars_Social_Sim_Roadmap_v1.md`. The mechanic itself was already built and proven out in the design sandbox (`claude/pilot_creator.html`, §13.2) — this is a straight port into the live TypeScript engine, not a redesign. Nothing about `ECHO_BOND_LEAN`'s values or the ×4 scale changed (§4's own constraint) — verified with a dedicated test asserting the exact literal numbers.

**On a true loss, the deployed squad mourns, visibly.** `Debrief.ts`'s existing permanent-losses loop (step 1b, unchanged) still flips a lost pilot's status. A new second pass right after it (`runGriefCatalyst`, `engine/griefCatalyst.ts`) runs once per loss: every surviving deployed pilot gets a real dialogue line (via the existing `pickAmbientLine`/catalyst/echo system, unchanged), and every bonded PAIR among those mourners gets their real `npcSocial.bonds` value shifted by `ECHO_BOND_LEAN` (love +2 / sadness +1 / fear −1 / anger −2, summed per pair, ×4 scale). New panel on the Debrief screen, "GRIEF — HOW THEY'RE TAKING IT," between the earnings panel and the Munti/bonus callouts — a mourner's line, then an understated "A and B: Bond ±N" note when a pair actually shifted. This was your own call, not left ambiguous: "yes, it says something," not a silent number change.

## Where this diverges from the spec — worth your read

**Mourner population was widened, on purpose, by your own explicit answer.** The PDF's literal wording was "the survivor + every pilot with an existing bond to the lost pilot." When I asked you point-blank, you picked "whole squad that was deployed" instead. That's what's live: every deployed pilot who's still active mourns, not just the ones who happened to already have a bond on file. The bond-SHIFT half stayed exactly as specced — only a pair of mourners with an existing bond moves, lazy-init respected (no bond invented from nothing just because two people were on the same mission). Worth a line in the Carrier Hub doc's §13.2 whenever that section next gets touched, since it's a real departure from what's written there.

**A real, previously-unflagged gap got closed along the way: catalyst coverage.** `pickSoloEcho` needs every pilot to have a catalyst, and until this pass, exactly three did (`NPC_SEED`: Bosk/raven, Anand/wolf, Iyari/crow) plus the CO's hardcoded "bear." Everyone else — Rourke, Lask, every Second/Third Lance pilot, every generated recruit — had none. Since "whole squad mourns" means anyone on the roster might need to speak, this would have silently failed for most of a real mission's squad. Not re-asked about — this read as a small, mechanical extension of an existing lookup (`catalystForPilot`, `data/npcSeed.ts`), not a new system or a content call worth blocking on: named pilots keep their hand-picked catalyst exactly where they already lived; anyone else gets a stable, deterministic pick derived from their own pilot id (same catalyst every time, no re-roll on reload), not a hand-authored row for every recruit that will ever exist. Flagging it here since it's still a placeholder assignment for the ~90% of the roster it covers — worth a real pass whenever catalysts for the wider cast get decided for real, same caveat `NPC_SEED`'s own three picks already carry.

**Multiple true losses in one mission each get their own grief round.** Not addressed explicitly in the spec, so I made a call rather than leaving it undefined: `Debrief.ts` runs `runGriefCatalyst` once per entry in `Mission.permanentLosses`, after ALL of that mission's status flips have already happened — so a second loss's mourner list correctly excludes the first loss's pilot too (they're gone, not grieving), rather than briefly mourning someone who's themselves already dead. Tested explicitly.

## Verification

Full pipeline, same as every other pass this session: `tsc --noEmit`, `eslint .` + the naming-lock spoiler check (skipped in this sandbox, no `BW_RESERVED_TERM` set — expected, flagged the same way every prior pass here has), `npx vitest run` (51 files / 1046 tests, up from 1033 — 13 new: mourner-population correctness including the multiple-losses case, lazy-init bond respect, the exact `ECHO_BOND_LEAN`/scale values, a three-mourner/two-of-three-pairs scenario with hand-checked math, unclamped-bond confirmation, and `catalystForPilot` coverage/determinism), `npm run build`, `npm run sim`, `npm run sim:social` — all clean. On top of the automated suite, I ran one more manual end-to-end check that isn't part of either sim harness (neither one reaches `Debrief.ts`'s scene code): built a real `Mission` off `AMARANTH_MISSION_14` (a real 10-pilot Act II squad), forced a loss, and called `runGriefCatalyst` with the mission's actual `deployedPilotIds` against a real `CampaignState` — confirmed real dialogue lines, correct bond math, and clean fail-open behavior for deployed pilots with no `CampaignPilotEntry` in that particular test state (expected there, since I didn't run the Second Lance integration first — not a bug, just an artifact of the quick check).

Committed to your device, zero conflicts: `engine/griefCatalyst.ts` (new), `engine/__tests__/griefCatalyst.test.ts` (new), `data/npcSeed.ts`, `scenes/Debrief.ts` — 4 files.

## Where this belongs once the Carrier Hub / Master Index docs get their next full-rewrite pass

- **`Bloom_Wars_Antfarm_Carrier_Hub_v1.md` §13.2:** a "shipped" note, plus the mourner-population widening (whole squad vs. the spec's literal "survivor + bonded") written in directly.
- **`claude_Bloom_Wars_Master_Index.md`:** one more clause in the running top paragraph, new section near wherever the Weapons Bay/Fabricator and Needs Counter addenda land.
- **Catalyst content:** worth a real entry in the priority queue — right now most of the roster's catalyst is a hash, not a decision.

## Open, for you

1. Catalyst assignment for the wider roster (Rourke, Lask, Second/Third Lance, generated recruits) — worth a real content pass at some point, or fine to leave the deterministic-hash fallback in place indefinitely?
2. The Debrief panel's exact wording/color is my own first pass (a muted plum panel, small print, no fanfare) — want it louder, quieter, or is understated the right read?
3. Groups 3–5 from the sandbox (Anger Blowup, Toxic Pairs, Breakdown) are still sitting there unported. Grief Catalyst is the first of the sandbox's "visible consequence" systems to actually ship live — worth lining one of those up next?
