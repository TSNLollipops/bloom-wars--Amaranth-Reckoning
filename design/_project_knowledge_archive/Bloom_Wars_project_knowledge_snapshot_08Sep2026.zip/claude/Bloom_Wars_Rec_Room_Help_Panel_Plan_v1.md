# THE BLOOM WARS — Rec Room Help Panel Plan v1

**Written 28 Aug 2026**, from a chat conversation. **Built and shipped later the same day (unattended overnight pass)** — see "Build status" at the end of this doc. Answers a real gap flagged mid-conversation: the three shipped Rec Room minigames (the peg board, Poker, Fletchers/Darts) have no in-game rules explanation anywhere. `HOW_TO_PLAY.html` (the Field Manual) covers combat only and doesn't mention any of them. A player who doesn't already know Texas Hold'em, and nobody knows the peg board (it's invented for this game), currently has to learn by trial and error.

## Decision made in chat

Two shapes were on the table: add a "Rules" section to the existing Field Manual (cheap, reuses trusted infrastructure, but it's a separate page a player has to go find), or a small in-modal help affordance inside each minigame's own overlay. Maxime picked the in-modal version, and specifically **always available** — not a first-time-only tooltip that dismisses itself and never comes back (the pattern the Mission 1 combat tutorial hints already use), a persistent "?" button or corner control the player can open any time, every session.

This also scales cleanly to Tetris/Asteroids whenever that "one day" wave (§15/§16 of `Bloom_Wars_Walkable_Hub_Build_Plan_v1.md`) gets built — each new minigame just gets its own panel, nothing about the pattern needs to change.

## What this needs, roughly

Per minigame overlay (peg board, Poker, Fletchers): a small "?" button, probably a fixed corner of the modal so it doesn't compete with the actual play area, opening/toggling a text panel with that game's rules. No new engine logic — this is UI plus static text. Real work, not zero-cost, but small relative to everything else these three modals already carry (all three already shipped and Playwright-verified, so this only touches presentation, not the rules engines themselves).

## Draft rules text, one per minigame

Written player-facing (short, scannable, no engine jargon) and checked against the actual shipped mechanics per `Bloom_Wars_Walkable_Hub_Build_Plan_v1.md` §12/§13/§14 — not guessed. **This is the exact copy that shipped** (see "Build status" below) — unchanged from the draft.

### The peg board

Nine dots in a 3×3 grid. You and your opponent each draw one line per turn, connecting two dots that don't already have a line between them.

Your first line is fixed — you don't get to choose it. After that, every line you draw has to start from wherever your last line ended. Your lines have to form one continuous path.

Lines can never cross an existing line — yours or your opponent's.

**Reach:** if your last two lines form a bend through three dots, you're threatening to win. Your opponent gets exactly one move — closing the triangle — to stop it. If they can't (the closing line would cross something already down), you win on the spot.

**Knot:** land three of your own lines on a single dot and it locks — nobody can draw through it again, for either side, for the rest of the game.

If the board fills up and nobody's completed a Reach, whoever has more Knots wins. Equal Knots, it's a draw.

### Poker

Texas Hold'em. You and your opponent are each dealt two hole cards face down; five community cards come out face up in stages (flop, turn, river), shared by both of you. Best five-card hand out of your two plus the five shared wins.

Betting happens after each stage — fold, check, call, or raise. Folding ends the hand immediately and hands the pot to whoever didn't fold; your cards stay hidden either way.

### Fletchers (darts)

Three rounds, three darts each, you and your opponent alternating whole rounds. Highest total after all darts are thrown wins; a tie is a draw.

Each throw: a marker sweeps back and forth across a bar. Time your click (or press E) to lock it — the closer to center, the better your aim. Landing dead center doesn't perfectly guarantee a bullseye (your hand isn't that steady), but it gets you close, and a bad lock reliably misses.

Scoring: bullseye (50), inner ring (30), mid ring (20), outer ring (10), miss (0).

## Still open, as of the original plan (28 Aug 2026, before build)

Exact copy above is a draft, not locked — worth a pass once it's actually in a panel and readable at the modal's real size. Whether the "?" is a button, a small always-visible label, or something else visually is a UI call for whoever builds it. No decision yet on whether Tetris/Asteroids' eventual panels get written now or wait until those games themselves get designed (leaning wait, since there's no ruleset to document yet).

---

## Build status (28 Aug 2026, unattended overnight pass)

**Shipped, all three minigames, same shape for each.** Built directly into `src/scenes/Hub.ts` — no new engine logic, exactly as scoped above; only the three existing minigame overlays (`buildPegBoardOverlay`/`buildPokerOverlay`/`buildDartsOverlay`) gained a persistent `[ ? ]` button and a shared help-panel builder.

**The "still open" UI calls, resolved during build:**
- **The "?" control is a text button**, `[ ? ]`, mirroring the existing `[ leave — Esc ]` control's own style but in the opposite corner (top-left vs. top-right) — consistent with the rest of the file's plain monospace-button convention rather than introducing a new control style.
- **One shared panel builder (`buildRulesHelpPanel`), not three separate ones** — takes the rules text and a dismiss callback, used identically by all three minigames. A future Tetris/Asteroids panel is a one-line call once those games have a ruleset to document, exactly as this doc originally hoped.
- **Always available, confirmed, not just claimed:** the panel is a normal toggle (click `[ ? ]`, click again or click anywhere on the panel or press Esc to dismiss) — no first-open-only gating, no dismiss-forever flag, reopens identically every time, matching Maxime's own "every session" requirement rather than the Mission 1 tutorial-hint pattern this doc explicitly said not to copy.
- **Copy fit the panel at its real size, checked, not assumed** — the peg board's rules (the longest of the three, Reach + Knot both needing real explanation) initially ran close enough to the panel's own "back to the game" hint line to look cramped in a live screenshot; fixed by tightening the panel's font/line-spacing slightly (11px/6 → 10px/4), re-screenshotted, confirmed clear on all three panels. Draft copy itself needed no trimming.

**Guards against the one real interaction risk this kind of overlay-on-an-overlay invites:** the help panel is a child of its parent minigame's own container, so closing the minigame always closes an open help panel too (no stale "help was left open" state carried into the next visit to that table). The panel's own background is interactive specifically so a click doesn't fall through to whatever's underneath it (the peg board's dot zones, Poker's action buttons, the close/leave button) — confirmed this was a real risk, not a hypothetical one, since Phaser only routes a click to the topmost interactive object at that point, and a non-interactive backdrop would have let clicks pass straight through to the game board it was covering. Esc while help is open closes only the help panel (back to the game), a second Esc closes the minigame itself — "one level at a time," checked against a live click/keypress test, not just read from the code.

**Verification:** `tsc --noEmit`, `eslint` (whole repo), and the full `vitest` suite (996/996) all clean; `npm run build` clean. Beyond static checks, a live Playwright pass against a running dev server exercised all three panels for real: opened each via the actual `[ ? ]` button with a real mouse click (not a direct method call), confirmed dismiss-by-clicking-the-panel and dismiss-by-`[ ? ]`-again both work, confirmed the two-stage Esc behavior (help closes first, minigame closes second) via real keypresses, and screenshotted all three panels to confirm the copy renders fully on-screen with no clipping or overlap. Zero console/page errors throughout. Committed to the real repo (`src/scenes/Hub.ts`), byte-identical baseline confirmed before write (nothing changed on the device copy since it was last staged, so this was a clean apply, not a merge).
