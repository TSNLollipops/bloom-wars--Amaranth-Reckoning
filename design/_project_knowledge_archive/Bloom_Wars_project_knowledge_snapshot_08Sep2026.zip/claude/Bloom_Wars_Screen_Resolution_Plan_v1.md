# The Bloom Wars — Screen Resolution Plan v1

**Written and shipped same day, 2 September 2026.** Maxime: "check the ui, it gotten too big, in fact. make a screen resolution plan, and make [the] screen resolution adjustment to the game so people with different resolution can play." This doc is both the plan and the build record — same pattern as the CO Check-In Gate doc — because the fix turned out to be small enough to design, build, and verify in one pass rather than needing a separate go-ahead.

## The actual bug, diagnosed against the real files, not assumed

The "too big" report lands the day after `Bloom_Wars_Build_Log_Addendum_PlayerAiTiers_Telemetry_UI_01Sep2026.md` shipped window scaling (feature-gap report A5, 1 Sep 2026): `main.ts` went from a fixed 1074×640 canvas — "a small box in the middle of any larger monitor" — to `Phaser.Scale.FIT` with `CENTER_BOTH`, and `index.html`'s `#app` was set to `width: 100vw; height: 100vh` so FIT has the whole viewport to fit into.

That fixed the small-box problem and created the opposite one: FIT had no upper bound. It scales the fixed 1074×640 logical canvas to fill whatever parent element it's given, preserving aspect ratio — and on a big or high-resolution monitor, "whatever it's given" is the entire screen. Measured directly (not estimated) on a real build, before any fix:

| Monitor | Canvas rendered at | Scale vs. authored 1074×640 |
|---|---|---|
| 1280×720 laptop | 1208×720 | 1.13x |
| 1920×1080 desktop | 1920×1080 (effectively, close to full) | ~1.79x |
| 2560×1440 desktop | 2560×1440-bound | ~2.25x |
| 3840×2160 (4K) | 3625×2160 | 3.38x |

Every scene in this codebase places its UI in absolute pixel coordinates (Hub.ts and Battle.ts especially — 383KB and 122KB of hand-placed positions). FIT scales the whole canvas as one image, so all of that blows up together: buttons, text, the HUD, everything gets 2-3x larger on a common 1440p or 4K monitor than it was ever drawn to look. That's the "gotten too big" — not a bug in any one scene's layout, a missing ceiling on how far the 1 Sep window-scaling fix was allowed to stretch.

## What this plan does NOT try to fix, and why

Worth being direct about scope, per this project's own "flag it before building" rule — the request could be read as "make every screen genuinely responsive," which is a different and much bigger job:

- **A true per-resolution relayout** (Phaser's `RESIZE` scale mode, where the logical coordinate space itself changes with the window and every scene repositions its own elements) would touch essentially every scene file — Hub.ts and Battle.ts most of all, both already flagged in this project's own history as too large for any one pass to safely rewrite in absolute-position terms. That's a structural rework, not a fix, and it's not started here.
- **DPI/`devicePixelRatio`-aware canvas rendering** (so the game's internal render resolution scales with a high-DPI display instead of a browser CSS upscale of a lower-resolution canvas) is a real, separate improvement for sharpness on Retina/4K-native displays specifically. Not touched — the fix below caps how big the canvas gets, it doesn't change how many actual pixels it's rendered at.
- **Ultrawide (21:9) support** — the game's own 1074:640 aspect ratio always letterboxes on a 21:9 display regardless of any cap; nothing here changes that letterboxing behavior, only how big the letterboxed box is allowed to get.
- **An Electron windowed-mode size picker / remembered window size** — relevant once the EA Launch Plan's Electron packaging step actually starts (still not begun as of the Forgotten Plans Audit); out of scope for a browser-only build today.

All four are real, legitimate follow-ups if this becomes a bigger priority later — flagged here so they're on record, not built.

## The fix that shipped

A ceiling, not a redesign. Two pieces:

**1. A capped `#app` parent, so FIT can't stretch past a chosen multiple of the authored 1074×640 canvas.** `index.html`'s `#app` keeps its existing `width: 100vw; height: 100vh` (so it still shrinks to fit a small window exactly as before) but gains `max-width`/`max-height`, read from two CSS custom properties (`--bw-max-w`/`--bw-max-h`). `body` gained flex centering so a capped (smaller-than-viewport) `#app` sits in the middle of the screen instead of pinned to the top-left. Below the cap, nothing changes — a small laptop window still shrinks the game exactly as FIT always did; the cap only ever stops *growth*.

**2. A player-facing "DISPLAY SIZE" control, not a hardcoded number.** Different people want different things here — someone on a 4K monitor might still want the game to fill more of the screen, someone else wants it small and crisp. `src/engine/displayScale.ts` (new, deliberately Phaser-free and DOM-guarded, same reasoning as `hubGeometry.ts`) defines five options — **100% / 125% / 150% (default) / 175% / Fill screen (no cap, the old 1 Sep behavior)** — each a multiplier on the base canvas size, stored in `localStorage` (`bloomwars_display_scale_v1`) and applied by writing the two CSS custom properties above. `main.ts` applies the saved choice before the game boots. `Options.ts` gained a DISPLAY SIZE row (five buttons, the active one shown bracketed — `[150%]` — the same "state shown via the label" idiom `ShopPanel.ts` already uses for things like "AT MAX," rather than a new highlight color) — clicking one saves the choice and takes effect immediately, live, no reload.

**150% was picked as the default, not 100%.** A hard 100% cap would just re-create the original "small box in the middle of the screen" complaint that the 1 Sep fix was built to solve — it would let the game render at a fixed, small size regardless of how big the player's monitor actually is. 150% was chosen by checking the actual numbers: on a normal 1920×1080 monitor it renders at 1611×960, comfortably filling most of the screen without edge-to-edge stretching; on anything bigger (1440p, 4K, ultrawide) it holds at that same 1611×960 rather than growing further. A player who wants it bigger has FILL one click away; a player who wants it sharp and small has 100%.

## One real implementation snag, caught by actually testing it rather than trusting the code

The first pass called `this.scale.refresh()` after changing the CSS cap, expecting Phaser's Scale Manager to immediately re-measure `#app` and resize the canvas. Live-clicked in Playwright, this consistently lagged one click behind — clicking FILL appeared to do nothing, and the *next* click appeared to jump to FILL's size regardless of which button was actually clicked.

Read the actual installed Phaser 3.90 source (`node_modules/phaser/src/scale/ScaleManager.js`) rather than guessing: `refresh()` calls `updateScale()`, which reads `this.parentSize` — a **cached** value, only refreshed by a separate method, `getParentBounds()` (a real `getBoundingClientRect()` call). Phaser normally calls `getParentBounds()` itself once per frame from the game's own step loop, which is why ordinary window resizing already works with no extra code — but that means a *manual* `.refresh()` call, fired synchronously right after a CSS change, uses whatever `parentSize` was cached before the CSS change took effect. One frame later, the automatic per-frame check catches up — which is exactly the "one click behind" symptom that showed up in testing.

Fixed by calling `this.scale.getParentBounds()` (forces a fresh, synchronous DOM read) immediately before `this.scale.refresh()`. Re-verified: every option now takes visible effect on the exact click that set it, confirmed via Playwright `boundingBox()` measurements matching the expected size exactly (1074×640 for 100%, 1611×960 for 150%, etc.) with zero lag.

## Verified, not assumed

This session has a linked device but no shell on Maxime's own machine — the verification below ran in a disposable cloud sandbox, mirroring the real repo (staged from the live device files, not written from memory), so it's a genuine build-and-run check, not just a code read:

- `tsc --noEmit`, `eslint .`: clean, before and after.
- `vitest run`: **1330/1330 passing** (1319 pre-existing + 11 new, `engine/__tests__/displayScale.test.ts` — the pure `capFor`/`getDisplayScaleOption` logic, plus three tests confirming the module's DOM guards are real and not just decorative: vitest's own environment here has no `document`/`localStorage` at all, so a missing guard would have failed the suite outright, not just in theory).
- `npm run build`: clean production build (same one pre-existing chunk-size warning as before, unrelated).
- **A real Playwright pass**, not a static check: launched the built game in headless Chromium (`/opt/pw-browsers/chromium-1194`, the pinned local build) and measured the actual rendered `<canvas>` size —
  - Across six real monitor sizes (1280×720, 1366×768, 1920×1080, 2560×1440, 3840×2160, 3440×1440 ultrawide) at the 150% default: every 1080p-or-bigger monitor capped identically at 1611×960; both laptop sizes still shrank correctly below the cap (1208×720, 1289×768) — confirming small screens are unaffected.
  - Each of the five Display Size options forced via `localStorage` on a 4K viewport: 100%→1074×640, 125%→1343×800, 150%→1611×960, 175%→1880×1120, Fill→3625×2160 (the old uncapped number, confirming Fill genuinely reproduces the pre-fix behavior for anyone who wants it back).
  - **A real click-through**, mouse clicks translated through the actual canvas-to-screen transform, not synthetic events: MainMenu → OPTIONS → clicked FILL (canvas grew live, no reload) → clicked 100% (canvas shrank live to exactly 1074×640) → clicked 150% (back to default) — each click's `localStorage` value and rendered canvas size both confirmed correct.
  - Confirmed persistence: set 100% via `localStorage`, reloaded the page cold, canvas rendered at 1074×640 immediately with no flash of the old uncapped size.
  - Screenshots of the Options screen (both mid-scroll states) confirmed the new DISPLAY SIZE row doesn't collide with the existing STATISTICS section above it or the BACK button below it, and reads cleanly at both 150% and after a live FILL click.

**Committed to the real device repo**, with a fresh mtime-drift check on every pre-existing file immediately beforehand (all clean, no concurrent edits) and a fresh post-commit device listing confirming genuinely new sizes and mtimes: `src/main.ts`, `index.html`, `src/scenes/Options.ts` (all modified), `src/engine/displayScale.ts`, `src/engine/__tests__/displayScale.test.ts` (both new).

## Honestly still open

- The four deferred items in "What this plan does NOT try to fix" above — a true responsive relayout, DPI-aware rendering, ultrawide-specific layout, and Electron window-size persistence — are all real, undecided follow-ups, not forgotten scope.
- 150% as the default is a reasonable-looking number backed by the 1080p math above, not something Maxime has explicitly signed off on — worth a quick "does this look right on your actual monitor" check the next time the game is run for real. If 150% still reads too big (or too small) on his own screen, it's a one-line change (`DEFAULT_DISPLAY_SCALE` in `src/engine/displayScale.ts`).
- No human has looked at the DISPLAY SIZE row in the actual Electron/browser window yet — the Playwright screenshots above are the strongest evidence available from this session, but they're not the same as Maxime's own eyes on his own monitor.
