# Bloom Wars — The Codex, v1 (Design Proposal)

*Started 26 Aug 2026, on request ("I think we might need an in-game codex, can you start on it, and flag me what's weak"). Nothing here is built — this is a design proposal plus a real first pass at content, same status as every other `_v1` doc in this project until you weigh in. Checked against the Master Index, GDD v0.2, Data Pack v0.1, Build Brief v0.1, Canon Pass v1, the Independent Campaign doc, Rank and Command v1, Mek Workshop v1, and Spitball Ideas before writing a word of this, plus a scan of the actual repo (`src/data`, `src/scenes`) — nothing called codex/glossary/bestiary/compendium exists in the codebase today. This is genuinely new territory.*

**Scope flag, per the project's own standing rule.** A codex is a new content type (a whole category of player-facing text that doesn't exist yet) and a new screen (nothing in `src/scenes` is close to it — closest analog is `Hub.ts`, already 140KB, which is itself an argument for *not* stuffing this into that file). I have not written any code or repo files for this — everything below is design only, for you to react to before anything gets built.

**Timing note, not asked but worth saying because it changes the calculus.** The Master Index's own "hard loop before the social layer" sequencing rule has actually cleared — all 36 missions are built, sim-tuned, and delivered, and your own words in the Spitball doc were "we gonna add the full calendar when we are done with the mission building... after that I want to work on the ui for non combat interaction." A codex is squarely non-combat UI. This isn't jumping the queue — it's arriving right when the queue says it should.

**Status, 27 Aug 2026: you picked up this doc's own §11 sequencing** ("fold into a bigger Codex push") — the Wellroot stat-block gap this section's own §9 flagged as blocking is now resolved (see §6's entry below, no longer flagged), so that specific blocker to moving forward is cleared. The rest of §11's order (Systems + Glossary content, then World's act-by-act pass together, then `Codex.ts` itself) is still ahead, not started this pass.

**Status update, 2 Sep 2026 — sequencing continued, scope confirmed.** `src/scenes/Codex.ts` was built 1 Sep 2026 (see `Bloom_Wars_Build_Log_Addendum_Codex_ForgottenPlansPass1_01Sep2026.md`) — but as a first tab only: it recreates `HOW_TO_PLAY.html`'s 9 manual sections (Controls, Terrain, Class Triangle, etc.), not this doc's six-category lore vision. `src/data/codex.ts` still doesn't exist. Maxime confirmed the same day that the manual tab was never meant to be the whole Codex — the original vision here (Systems, Personnel, The Bloom bestiary, Ranks & Command, World, Glossary) stands as the actual destination, RPG-style bestiary included. §11's own order still applies: content backlog first, then extend `Codex.ts` with the remaining tabs and stand up `src/data/codex.ts` for real. First content pass underway now is a `World` entry on the wider Coalition the Amaranth Reach sits inside — see `Bloom_Wars_Coalition_Lore_Codex_Entry_Plan_v1.md`.

---

## 0. What a "codex" actually is, in plain terms

You'll have seen this feature under different names: XCOM's UFOpaedia, Mass Effect's Codex, Fire Emblem's or Final Fantasy Tactics' bestiary, Hollow Knight's Hunter's Journal. Mechanically it's always the same thing: a reference screen, reachable from a menu, that explains the game's own systems and world back to the player in plain language — what a unit type does, what an enemy's weaknesses are, who the named characters are, what the factions want. It's not a tutorial (tutorials interrupt play to teach one thing right when you need it) and it's not a wiki someone else wrote (a wiki can be wrong; a codex ships with the game and is the developer's own claim about what's true). It's the game explaining itself to itself, browsable at your own pace.

The one design choice every good codex makes, and the one I'd steer you toward: **entries unlock through play, they aren't all sitting there on day one.** XCOM doesn't tell you what a Sectoid's autopsy reveals until you've captured or killed one; Final Fantasy Tactics' bestiary fills in as you actually fight each monster type. This does two things for you specifically: it rewards playing (opening the codex after a mission and seeing a new entry light up is a small, free dopamine hit — the "gorgeous and gory" tone work you've already locked for Stage 1 gets an extra showcase for free), and — this is the one that actually matters mechanically for this project — **it's your built-in spoiler gate.** More on that in §3, because it's the single biggest risk a naive version of this feature has.

---

## 1. Design goals — the non-negotiables

Written in the same spirit as the Build Brief's own §2 ("cheap to honour now, expensive to retrofit"):

**a. Data-first, like everything else in this engine.** Codex entries are data (`src/data/codex.ts` or similar), not strings hardcoded into a scene file. This isn't a new discipline — it's the same rule the GDD and Build Brief already enforce everywhere else (`§2.3`, `§13.3`), just applied to a new data type.

**b. Unlock-gated, not all-visible.** Every entry has an unlock condition (first encounter, first kill, mission-complete, act-complete). Nothing in the codex is readable before the game itself would have shown it to you in play.

**c. The naming lock applies here at full strength, maybe more than anywhere else in the game.** A codex is pure prose — paragraphs of world-explaining text, written in long sessions, exactly the format where a reserved term or "The Synker Wars" is most likely to slip in unnoticed (a design doc leak already happened once, caught and redacted, in the Gladiator rank-ladder discussion — see Spitball Ideas). I'd recommend extending `tools/lint-spoiler.mjs` to scan `src/data/codex.ts` the same as everything else under `src/` — it already would, actually, since the lint walks all of `src/`, but it's worth stating explicitly here since codex content is the highest-volume prose in the entire game and deserves a deliberate double-check pass before ship, not just reliance on the automated net.

**d. The quiet-critique discipline extends to codex content — this is the one I'd flag hardest.** The Build Brief is explicit that Mission 1a's ambush mechs are never explained anywhere in game text, ever, on purpose (§2.4). If a codex entry gets written by summarizing the design docs directly, it will leak exactly the things the design docs discuss openly but the game itself is built to withhold — Halcyon Amaranth's bargain with the Bloom, the reason House Amaranth's name quietly disappears by Act 3, what Marrow actually is doing versus what she appears to do across Missions 6/20/28. **A codex entry and a design doc section are not the same document even when they're about the same subject** — the codex has to know less than we do, on purpose, gated to what the player has actually been told in-fiction by that point in the campaign. I've tried to model this discipline in the sample entries below rather than just asserting it.

---

## 2. Proposed categories

Six sections, each independently unlockable, each with its own gating logic:

| Category | What it covers | Gate |
| --- | --- | --- |
| **Systems** | Class triangle, chassis/species, mek tracks, gear tiers, the Collapse rule, the Heirloom | Unlocks progressively as each system is introduced in Act I (mirrors the GDD's own mission-by-mission teaching order — see GDD §5.4's "teaches / answered by" table, which is honestly already 80% of a codex outline) |
| **Personnel** | Warden Company roster, bios, mek partners | Always visible for currently-living roster members; see §4 for the dynamic-status problem this raises |
| **The Bloom** | Bestiary entries, base archetypes and named threats | Unlocks on first encounter (not first kill — a player should be able to look up what they're facing mid-fight, same instinct XCOM's own "alien data" panel serves) |
| **Ranks & Command** | The enlisted/officer ladder | Flavor-only for now — see §5, this is describing a system that isn't mechanically live yet |
| **World** | The Amaranth Reach, House Amaranth, Meridian | Act-gated — see §3, this is the section with the real spoiler risk |
| **Glossary** | Short-form lookups for jargon used elsewhere in the UI (Restock, Collapse, Severance, Munti) | Available from Mission 1, since these are terms the HUD itself uses immediately |

---

## 3. The spoiler-gating problem, worked through concretely

This is worth walking through with an actual example rather than just asserting the principle, because it's the part most likely to get built wrong by accident.

**House Amaranth.** The design docs (Independent Campaign §5) tell *us* the full truth up front: Halcyon Amaranth's mother started a ward-crop program to study and redirect the Bloom, it worked long enough to look like wisdom, it's the reason the Wellroot exists, and by Act 3 loyalists have quietly stopped saying "the Amaranth Reach" out loud. A player at Mission 6 (House Colors — first distant sighting of Marrow) knows none of this. If the World codex entry for "House Amaranth" is unlocked at Mission 6 and contains the full §5 writeup, the game has just told the player the Act 2 and Act 3 twists six missions early, for free, in a menu, with zero narrative cost. That's a real bug, not a nitpick — it's the exact failure mode Build Brief §2.4 exists to prevent, just in a screen nobody thought to apply that rule to yet.

**The fix, proposed:** World entries are versioned by act, same entry id, escalating content, gated on mission-complete:

- Unlocks at Mission 6: *"House Amaranth. A charter house, generations-old, holding the Reach's richest agricultural terraces. Fields its own chartered battlegroup — Colonel Ysolde Marrow commands it, though a House officer holds its seal. Currently allied with Warden Company; the alliance has been tense since the checkpoint dispute at [Mission 6's location]."* — states only what a soldier on the ground would know at that point.
- Rewrites/extends at Mission 17 (The Wellroot Uncovered) once that reveal actually lands in-mission.
- Rewrites/extends again after Mission 23 (The Amaranth Accord confirms the bargain) and Mission 28 (Marrow's turn).

This is the same pattern the campaign doc already uses for the pilots themselves (§6a's "write flexibly for whoever's actually left standing," not a fixed script) — I'm not inventing a new discipline, just applying an existing one to a new screen.

**Practical implication for the data schema (§6):** a World entry isn't one string, it's an ordered list of `{unlockedAfterMissionId, text}` revisions, and the codex always shows the latest one the player has actually reached. Slightly more data-modeling work than a flat lookup table, and worth it — the alternative is a menu that spoils your own campaign.

---

## 4. Personnel entries and the dynamic-death problem

Same category of issue, sharper here because it's mechanical, not just narrative. Under §6a's real permadeath rule, "M.Sgt. Halvard Bosk" might be alive right now, restocked-and-fine, dead since Mission 4 to a bad Splitfang pack, or dead-as-scripted at Mission 12 — and which one is true is different for every player, every save. A codex bio can't be static prose written once at build time; it has to read live campaign state.

**Proposed shape for a Personnel entry:**

```
{
  id: "codex_pilot_bosk",
  displayName: "Halvard Bosk",
  callsign: "Anvil",
  path: "tank",
  bioStatic: "Master Sergeant. The mentor. Came up through House Amaranth's
    own regulars before Warden Company folded him in — old enough to have
    outlived two younger officers before Rourke.",
  statusText: (campaignState) => {
    const record = campaignState.getPilotStatus("pilot_bosk");
    if (record.status === "active") return "Currently serving with Warden Company.";
    if (record.status === "kia") return `Killed in action, ${record.missionDisplayName}.`;
    // no other cases — no "scripted to die at Mission 12" branch anywhere,
    // because the game doesn't know that until it happens, and neither
    // should the codex.
  },
}
```

The load-bearing detail: `statusText` has no branch for "is this the scripted Mission 12 death." It just reports whatever actually happened, whenever it happened, because §6a already established that the scripted beat is *intent*, not a guarantee, and the mission text itself has to be written to route around whoever's actually still standing. The codex just needs to follow the same discipline the missions already do — this isn't new design, it's making sure a new screen doesn't accidentally reintroduce a bug the campaign doc already solved everywhere else.

**One more wrinkle worth flagging, not solving here:** Rourke's own status text needs to never imply she *could* die, since mechanically she can't (§6a's mission-fail-and-retry framing, not a death exemption) — but it also shouldn't read as "obviously invincible" in a way that undercuts the fiction. Probably solvable with careful wording ("Still leading from the front" rather than anything that reads as a fourth-wall wink), but it's a real writing task, not a data problem, and I haven't attempted it below.

---

## 5. Sample entries — Systems

These are the ones I'd trust to ship close to as-written, since they're explaining already-locked mechanics rather than touching anything spoiler-sensitive. Written for a player who, per your own standing instruction to me, shouldn't be assumed to know genre conventions either — so these lean slightly more explanatory than a veteran-tactics-game codex would, on purpose.

> **codex_system_class_triangle**
> **The Three Paths**
> Every pilot flies one of three combat paths, and the three beat each other in a loop: **Meeps beats Reeps, Reeps beats Tank, Tank beats Meeps.** No path is strongest overall — which one wins a fight depends entirely on who's fighting whom.
>
> A **Meeps** is fast and fragile — six tiles of movement, one-tile reach, built to close distance before anything can react. It doesn't out-fight a Tank; it goes *around* one, because a Tank's whole threat is standing next to you, and a Meeps' whole plan is never giving it the chance.
>
> A **Tank** stands its ground — short movement, high defense, an overshield that protects everyone standing near it. It punishes anything that comes adjacent. It has no answer to anything that doesn't.
>
> A **Reeps** fights from range — two to four tiles out, never in melee, never countered for it. It chips away at a Tank's raised defense from a distance the Tank can't close, and it dies in two hits if a Meeps ever actually reaches it.
>
> A fourth path, **Munti**, sits outside the triangle entirely. It doesn't win fights — it keeps everyone else alive. Every mission is quietly a mission to protect it.

> **codex_system_chassis**
> **Chassis and Species**
> Every pilot's body shapes how they move and fight, independent of which of the three paths they've chosen — a Hiopi Meeps and a human Meeps are both Meeps, they just get there differently.
>
> **Human** pilots use the standard bipedal frame — no terrain penalties, no special tricks, a slightly higher baseline toughness to make up for it.
>
> **Hiopi** pilots use a centauroid frame — full speed across open ground, slower through rubble and tight structures, and a real reward for committing to it: charging three tiles or more in a straight line before striking hits harder.
>
> **Osnian** pilots use a modified bipedal frame with a longer sensor suite — wider vision, and the ability to see burrowed threats other pilots can only find by walking into them.

> **codex_system_collapse**
> **How the Bloom Dies: the Collapse Rule**
> A Bloom creature's health isn't one bar — it's two: **Endurance**, the shell, and **Vitality**, the thing living underneath it. Damage empties Endurance first, and a hit that overflows past zero Endurance does *not* carry into Vitality — the shell simply breaks. Once Endurance hits zero, the creature enters **Collapse**: any hit at least as hard as its remaining Vitality kills it outright, and — this is the part worth watching for — a creature in Collapse hits back at full strength, not weaker. The moment it looks like it's dying is the moment it's most dangerous. That's not a bug in how it reads. That's the whole point.

*(Mek tracks, gear tiers, and the Heirloom/Severance entry follow the same shape — not written out here to keep this doc a reasonable length, but the class-triangle entry above is the template: plain language first, the mechanical hook stated once, clearly, near the end.)*

---

## 6. Sample entries — The Bloom (bestiary)

Three written safe, one flagged as flavor-accurate but mechanically ahead of the current engine.

> **codex_bloom_crawlmass** *(unlocks on first encounter — Mission 1)*
> **Crawlmass**
> The first thing most soldiers ever see of the Bloom, and the least dangerous — alone. A Crawlmass folds almost the instant it's hit. The danger was never any single one of them; it's that they never show up alone, and every one you're fighting is a turn you're not spending on something worse.

> **codex_bloom_undertow** *(unlocks on first encounter — Mission 4)*
> **Undertow**
> You will not see this thing until it wants you to, or until something with a sharper sensor does. It waits under the ground, motionless, right up until it surfaces to strike — and the strike lands harder for the wait. After that, it's just a target like anything else. The wait is the entire fight.

> **codex_bloom_wellroot** *(unlocks on first encounter — Mission 21)* — **written 27 Aug 2026, no longer flagged.**
> **The Wellroot**
> Solheim found the root structure two weeks before anyone found what's actually growing out of it — "too regular to be natural," she called it, and she wasn't wrong. It doesn't move, doesn't have to: it's already dug in past anywhere you'd want to reach it, and it calls up burrowers of its own the longer the fight runs. The wound it leaves isn't the kind that closes clean. Whatever's feeding it, it isn't hungry — it's patient.
>
> *(Stays soldier-level on purpose — it alludes to something deliberate behind the growth without naming House Amaranth or the bargain, matching what a pilot at Mission 21 has actually been told in-fiction by that point. The full truth is Mission 23's reveal, not this entry's.)*

**Was flagged, now resolved:** `bloom_wellroot` is a real, distinct archetype as of 27 Aug 2026 (`data/bloom.ts`) — acid lineage (Gallcyst's family), endurance 480 / vitality 65, sim-validated against the campaign's own 35% target for this fight. See the Independent Campaign doc's §8 and `data/bloom.ts`'s own comment for the full derivation. The entry above is written against real data now, not a placeholder.

**One thing this surfaced, worth flagging here too even though it's not a codex problem:** none of the Bloom's on-hit effects (acid DoT, attack debuffs, knockback — `BLOOM_ON_HIT_EFFECTS` in `data/bloom.ts`) are actually wired into the engine anywhere. A codex entry that describes a Bloom archetype's on-hit effect mechanically (rather than staying in the same "how it feels to fight" register the entries above use) would currently be describing something that doesn't happen in play. The entries above avoid this by design — Undertow's "the strike lands harder for the wait" describes the ×1.5 surface-damage rule, which *is* real and implemented, not the on-hit-effects system. Worth keeping that same discipline for every future Bloom entry until the on-hit-effects gap closes (see the build log's own "still open" list).

---

## 7. Sample entry — Personnel

> **codex_pilot_rourke** *(always visible — protagonist)*
> **2nd Lt. Dessa Rourke — "Lark"**
> Meeps. Human. Green when this started, and it showed — quick, aggressive, not yet a commander. Still leading from the front. The unit under her now carries the opposite of her own callsign.
> *Status: {live campaign state — current rank, current lance}*

> **codex_pilot_bosk** *(unlocks once recruited/introduced — Mission 1)*
> **M.Sgt. Halvard Bosk — "Anvil"**
> Tank. Human. Came up through House Amaranth's own regulars before Warden Company folded him in. The mentor — the one the newer pilots orient around without being told to.
> *Status: {live campaign state — see §4}*

---

## 8. Data schema sketch

Matching the project's own conventions (Build Brief §5.1's id patterns, §5.2's folder discipline — `src/data` holds pure data, no Phaser import, same rule as everything else):

```ts
// src/data/codex.ts — PROPOSED, not built

export type CodexCategory = "system" | "personnel" | "bloom" | "rank" | "world" | "glossary";

export type UnlockCondition =
  | { type: "always" }
  | { type: "first_encounter"; archetypeId: string }
  | { type: "mission_complete"; missionId: string }
  | { type: "roster_join"; pilotId: string };

export interface CodexEntry {
  id: string;              // codex_{category}_{name}, per existing id convention
  category: CodexCategory;
  displayName: string;
  unlock: UnlockCondition;
  // Static text for anything that doesn't change (Systems, Bloom, Glossary).
  body?: string;
  // Live text for anything that reads campaign state (Personnel status,
  // World entries that escalate by act — see §3 and §4).
  liveBody?: (state: CampaignStateReadOnly) => string;
}
```

A `World` entry, per §3's escalation model, is really a small ordered list rather than one `CodexEntry` — proposing a thin wrapper (`WorldCodexEntry` with a `revisions: {afterMissionId: string; text: string}[]` field) rather than overloading `liveBody` to do both jobs. Not fully worked out here — flagging the shape, not the final interface.

**Where it'd live, if this moves forward:** `src/data/codex.ts` (data), a new `src/scenes/Codex.ts` (the screen itself, reached from the Hub — not folded into `Hub.ts`, which is already the single largest file in the repo at 140KB and doesn't need a second job). No engine changes required — this is presentation over data that's mostly-already-real (pilot records, Bloom archetypes) plus new prose data for everything else.

---

## 9. What's weak — the consolidated list

In rough order of how much it matters:

1. **Spoiler leakage is the real risk, not a hypothetical one.** §3's House Amaranth example isn't a contrived worst case — the World category is where this bites hardest, and it's the category I'd trust myself least to get right on a first pass without a dedicated read-through checking every entry against "what would a player at this exact mission actually know."

2. ~~The Wellroot has no real stat block yet~~ **Resolved, 27 Aug 2026.** See §6 above — a real archetype exists now, sim-validated, and the sample entry is written against it.

3. ~~Colour palettes for the three new Amaranth threats (Choir, Wellroot, Unnamed) aren't confirmed~~ **Resolved.** All three have locked `colorPalette` values in the live `data/bloom.ts` as of this pass (Choir and the Unnamed already did before this pass; Wellroot's own was set alongside its new stat block). Not yet reflected in Canon Pass §E's own formal palette table — that's still a real, separate fast-follow, same status as the gear-tier-names item below was until it quietly got resolved in code too.

4. **Gear tier names are still just letters — checked fresh, 27 Aug 2026: this one's also resolved, just never marked as such here.** `crewBanterSlots.ts` has the full per-path naming table (Stocklance → Stormblade, Blockshield → Bastion, and the rest) and it's already live in banter resolution. A Systems entry for gear can use the real names now, not "Tier G through Tier A."

5. **Ranks describe a system that isn't mechanically live.** Rank and Command v1 is explicit: "paper only, nothing here is built." A Ranks codex section can absolutely ship as flavor (it's genuinely nice, low-cost texture), but it shouldn't be written in a way that implies rank does anything mechanically yet, since right now it doesn't.

6. **The dynamic-personnel-status problem (§4) needs a real writing pass, not just the data plumbing.** Getting the mechanism right (live status lookup, no hardcoded death branches) is the easy half. Writing status lines that read naturally whether a pilot died on schedule, died early, or is still alive three acts later than planned — without any of those readings sounding like a template with blanks filled in — is real prose work.

7. **This is a new screen with no current home.** Confirmed by checking the actual repo: no existing scene is a natural fit, `Hub.ts` is already oversized, and this needs its own place in the Hub's navigation (a new button/room, not a stretch of an existing one).

8. **New, 27 Aug 2026: the Bloom's on-hit effects (acid DoT, attack debuffs, knockback) are pure data, wired into nothing.** Doesn't block writing bestiary entries — the entries above already avoid describing mechanics that aren't real — but worth knowing before anyone writes a bestiary entry that leans harder on an archetype's specific on-hit effect than the ones here do. See the build log's own "still open" list for the full finding.

---

## 10. A few things I'd suggest, unprompted

Since you've said you want the back-and-forth, not just execution — three ideas I think are worth considering, none of them decided:

**Frame it as Rourke's own field log, not an omniscient menu.** Instead of a neutral "Codex" header, consider it being *her* notes — a soldier's own reference material, updated as she personally learns things. This costs nothing extra to build (same data, same unlock gating) but gives you a diegetic reason for the unlock-on-encounter rule (of course she doesn't have notes on a threat she hasn't fought yet) and a consistent voice to write all of it in, rather than a generic reference-book tone. It also sidesteps part of the Rourke-status-text problem in §4 — her own log naturally wouldn't narrate her own death either way.

**This is a genuinely good Stage 1 target, maybe your best one.** Your own tone roadmap (Spitball Ideas, 25 Aug) puts "writing and atmosphere" first, before any UI or art work, and specifically calls out mission prose and combat description as the obvious place to start testing the "gorgeous, gory, realistic" bar. Codex entries are pure text, need zero engine work, and touch nearly everything else in the game (bestiary, personnel, world) — it might be a better testing ground for that voice than mission briefings, precisely because there's more of it and it's lower-stakes to iterate on.

**Consider a small "field notes" flourish per Bloom entry** — not just stats-in-prose, but one line that's Rourke's own reaction rather than clinical description (XCOM's autopsy reports do a version of this — dry science with one line of a scientist's own dread showing through). Given the Zerg/Cthulhu/Tyranid horror lineage you've already locked for the Bloom, that's a natural showcase, and it's cheap — one extra sentence per entry, not a new system.

---

## 11. If you want to move forward

**Status, 27 Aug 2026: step (1) below is now largely done** — the Wellroot stat-block gap is resolved (§6), the gear-tier-naming question turned out to already be resolved in code (§9), and the color-palette question is resolved too. What's still open from the original (1): nothing blocking. Remaining order, unchanged from the original plan: (2) draft the full Systems + Glossary sections (lowest spoiler risk, highest immediate value, no missing data blocking it — this is the natural next session); (3) work through the World category's act-by-act revisions together, since that's the one where "does this line spoil something" needs your read on the story, not just mine on the mechanics; (4) only once content exists does building `Codex.ts` and the Hub entry point actually make sense — no reason to build the screen before there's real data to put in it.

**Status, 2 Sep 2026: (4) partially happened out of order — see the top-of-document status update.** `Codex.ts` and its Hub/menu entry points got built 1 Sep, but as a manual tab, not as the World/Personnel/Bloom/Glossary screen this section describes. That doesn't invalidate the plan — it just means the eventual `Codex.ts` extension is adding tabs to an existing scene rather than building one from nothing, and (2)/(3) (the actual content) are still the real next work, picking back up now via the Coalition World entry.
