# The Bloom Wars — Systems Codex Entries v1

*Written 2 Sep 2026, continuing the Codex content backlog per `Bloom_Wars_Codex_Design_v1.md` §11's own order — Systems was already flagged there as "lowest spoiler risk, highest immediate value, no missing data blocking it," and three sample entries (class triangle, chassis, Collapse) were already drafted in that doc's §5 as the template. This doc finishes the category: the three already-shipped entries carried forward unchanged, plus the three the design doc explicitly deferred — Mek tracks, gear tiers, the Heirloom. Checked against `Bloom_Wars_GDD_v0.2.docx` §4.4/§6/§8, `Bloom_Wars_Data_Pack_v0.1.docx` §5/§11.5/§12.1, and `Bloom_Wars_Canon_Pass_v1.md` §D before writing a word of new prose. Same `_v1` status as everything else — a full pass for reaction.*

## 0. One correction caught while researching this, worth flagging on its own

`Bloom_Wars_Docx_Pending_Edits_Status_28Aug2026.md` already flagged and fixed this at the design-doc level, but it's directly relevant to writing a Heirloom entry, so it's worth restating here rather than risk quietly reintroducing it: the GDD's own §8.2 originally justified Severance's design by quoting Reqa's personal Heirloom sword from the Qiraki books directly. Maxime corrected that specifically, and in terms stronger than the ordinary naming-lock reasoning: **"we shouldnt be using reqa severance in this, its hers"** — a specific character's personally identity-defining item, off-limits even as inspiration, not a branding or spoiler question. This is a separate boundary from the naming lock that "full crossover" (2 Sep 2026) touched — that policy update was about the book's own branding-level military-arc name and the true-name spoiler term specifically, not about borrowing a named character's personal signature item, and nothing in Maxime's "old rule is stale" message asked for this one to move. The Heirloom entry below is written entirely Bloom-Wars-native, no citation to any Qiraki character or object, matching the replacement rationale that doc already recommended.

## 1. The entries

> **codex_system_class_triangle** — *already shipped, `Codex_Design_v1.md` §5*
> **The Three Paths**
> Every pilot flies one of three combat paths, and the three beat each other in a loop: **Meeps beats Reeps, Reeps beats Tank, Tank beats Meeps.** No path is strongest overall — which one wins a fight depends entirely on who's fighting whom.
>
> A **Meeps** is fast and fragile — six tiles of movement, one-tile reach, built to close distance before anything can react. It doesn't out-fight a Tank; it goes *around* one, because a Tank's whole threat is standing next to you, and a Meeps' whole plan is never giving it the chance.
>
> A **Tank** stands its ground — short movement, high defense, an overshield that protects everyone standing near it. It punishes anything that comes adjacent. It has no answer to anything that doesn't.
>
> A **Reeps** fights from range — two to four tiles out, never in melee, never countered for it. It chips away at a Tank's raised defense from a distance the Tank can't close, and it dies in two hits if a Meeps ever actually reaches it.
>
> A fourth path, **Munti**, sits outside the triangle entirely. It doesn't win fights — it keeps everyone else alive. Every mission is quietly a mission to protect it.

> **codex_system_chassis** — *already shipped, `Codex_Design_v1.md` §5*
> **Chassis and Species**
> Every pilot's body shapes how they move and fight, independent of which of the three paths they've chosen — a Hiopi Meeps and a human Meeps are both Meeps, they just get there differently.
>
> **Human** pilots use the standard bipedal frame — no terrain penalties, no special tricks, a slightly higher baseline toughness to make up for it.
>
> **Hiopi** pilots use a centauroid frame — full speed across open ground, slower through rubble and tight structures, and a real reward for committing to it: charging three tiles or more in a straight line before striking hits harder.
>
> **Osnian** pilots use a modified bipedal frame with a longer sensor suite — wider vision, and the ability to see burrowed threats other pilots can only find by walking into them.

> **codex_system_mek** *(unlocks — proposed: Mission 1, first mek assignment)*
> **Meks**
> Every pilot has exactly one Mek — never on the board, never a target, never lost to anything that happens in a fight. A Mek doesn't fight. It's the reason the pilot fights a little better, all the time, without anyone having to think about it mid-mission.
>
> Four real specialties, and a Mek carries one, sometimes two. A **Fabricator** keeps spare parts in reserve, and can put a downed pilot back in the fight the very next turn, at half strength — instead of that pilot being lost for the rest of the mission outright. An **Armorer** simply makes the whole unit hit harder and shrug off more. A **Runemaster** sharpens awareness and reaction across the board — sees further, reacts first, and makes whatever the pilot's own weapon does on a hit last longer and bite harder. A **Fieldwright** rewards holding position: heals the pilot who stays put, and if that pilot is a Munti, makes their own healing hit harder too.
>
> One specialty exists only as a Mek's second skill, never its first — a Mek that's purely good at stretching the company's points further, cheaper gear for the rest of the campaign, nothing sharper in a fight. Not every pilot wants that trade. Some do, and it adds up.

*(Deliberately never uses "spareParts," "×1.5 potency," or any of the actual numbers — same discipline the Systems entries above already use. "Half strength" and "stretching the company's points further" describe the Fabricator redeploy and Quartermaster discount in plain language rather than mechanically.)*

> **codex_system_gear** *(unlocks — proposed: Mission 1, first shop visit)*
> **Gear Tiers**
> Every pilot starts on standard issue and earns better with points spent, not levels grinded — a straight climb from G up to A, seven rungs, each one a real but modest step rather than a leap that makes everything below it obsolete. The company doesn't hand out gear that turns a fight into a stat check. It hands out gear that turns a close fight into a winnable one.
>
> What it's actually called changes with what a pilot flies. A Meeps climbs from a **Stocklance** through **Heavylance**, **Twinlance**, and **Pairblade**, on to an **Arcblade**, a **Flareblade**, and — for the very few who get there — a **Stormblade**. A Tank goes **Blockshield** to **Wallpanel** to **Skinshield** to **Groupshield**, then **Maserline**, **Tachlance**, **Bastion**. A Reeps runs a **Popgun** up through **Burstrifle**, **Twinburst**, **Longeye**, **Farmark**, **Twinmark**, to a **Skyline**. A Munti's kit goes from a **Quickfix kit** to a **Longarm**, a **Farfix**, a **Lifebox**, a **Quickbox**, a **Widefix**, and at the very top, an **Overcharge**.
>
> D-tier is the first rung that earns a real ability. B-tier earns a second. A-tier is as far as the standard ladder goes — and past it, there's nothing left to buy. What's past it isn't for sale at all.

*(Names sourced from Canon Pass §D's own already-locked table — real crossover, already in live use in banter resolution, not new. Numbers stay out of the prose entirely on purpose; the entry states the shape of the curve, not the table.)*

> **codex_system_collapse** — *already shipped, `Codex_Design_v1.md` §5*
> **How the Bloom Dies: the Collapse Rule**
> A Bloom creature's health isn't one bar — it's two: **Endurance**, the shell, and **Vitality**, the thing living underneath it. Damage empties Endurance first, and a hit that overflows past zero Endurance does *not* carry into Vitality — the shell simply breaks. Once Endurance hits zero, the creature enters **Collapse**: any hit at least as hard as its remaining Vitality kills it outright, and — this is the part worth watching for — a creature in Collapse hits back at full strength, not weaker. The moment it looks like it's dying is the moment it's most dangerous. That's not a bug in how it reads. That's the whole point.

> **codex_system_heirloom** *(unlocks — proposed: Mission 2, first sighting of the meter, per GDD §8.3's own campaign gating table)*
> **The Heirloom**
> One per company, not one per pilot — charged by every hit landed and every hit taken, by anyone, and spent all at once by whoever's holding it when it's full. Aim it in a straight line, eight tiles long, and it fires.
>
> It doesn't ask what's standing in that line. Ally, enemy, doesn't matter — it hits everything the same, at the same fixed, ugly number, no gear bonus, no defense stat softening it, nothing. Every other hit in this war respects one limit: nothing can drop a mech from full health in a single shot. The Heirloom doesn't know that rule exists. And against anything the Bloom fields with a shell worth grinding down — the kind of thing that just shrugs off everything smaller — it doesn't grind. It goes straight through the shell to whatever's actually alive underneath, and if that's not much, that's the whole fight, over, in one line drawn across the map.
>
> Charging it is free. Firing it never is.

*(No citation to any Qiraki character or item — see §0 above. "Straight through the shell to whatever's actually alive underneath" describes the vsBloom Collapse-check bypass in the same register the Gallcyst/Wellroot bestiary entries already use for the same rule from the other side. Campaign gating — locked in the earliest missions, visible-but-halved once introduced, fully live later — exists per GDD §8.3 but isn't restated here; that's pacing data for the unlock condition, not something the entry's own text needs to explain.)*

## 2. Naming-lock safety check

Gear-tier names are Canon Pass §D's own already-locked, already-live crossover — no new risk. Nothing here touches either of the two actually-reserved terms, and the Heirloom entry specifically avoids the one separate, non-naming-lock boundary flagged in §0.

## 3. Status

Systems category is now complete — six entries, matching the design doc's own six-topic list exactly. Next up, per Maxime's own priority order from the Coalition/bestiary rounds: Personnel bios, or the Glossary (short-form lookups — Restock, Collapse, Severance, Munti — available from Mission 1 per the original category table, and probably the fastest of everything left to draft since most of it is one or two sentences per term). Your call which.
