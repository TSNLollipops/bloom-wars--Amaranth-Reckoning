# THE BLOOM WARS — What You Might Be Missing: a feature-gap report for a first-time game dev

**Written 1 Sep 2026, at Maxime's request:** *"take a look at current state and current plans and write me a rapport of thing I should add to the game that would be useful. good. or loved by the player. this is my 1st game dev. im used to making good story people see and hear. not a coder at all. so I may have miss some things that might be cool or useful."*

**How this was put together.** Every claim of "present" or "absent" below was checked against the staged source code (`src/scenes/Battle.ts`, `main.ts`, `Debrief.ts`, `Options.ts`, the engine) or a doc that says it shipped — not guessed from memory of what a tactics game usually has. Where I couldn't verify, it says so. The ranking is by *love-per-effort*: how much players will notice, divided by how much work it is. Effort sizes: **S** = an evening, **M** = one Claude session, **L** = several sessions. Companion plans written the same day cover the two items Maxime already asked for (bot tiers, telemetry); they're referenced, not repeated.

One framing thought before the list. The game already has more *systems* than most first games ever ship — a 36-mission campaign, permadeath with a real rule behind it, weapon branches, a walkable ship with a social sim that has its own roadmap. What it's short on isn't systems. It's the layer of small things that sit between the player and those systems: information before a decision, feedback after one, and the ways a game says "I know you're here." That layer is cheap, mostly, and it's where the reviews get written.

---

## A. Table stakes for the genre — players will notice these missing on day one

These are things Advance Wars, Fire Emblem, XCOM and Into the Breach all have, and a player who's touched any of them will reach for reflexively.

### A1. Combat forecast before you commit an attack — **absent, S/M, highest priority**
What it is: hover or first-click on a target shows "you deal 34, they counter for 12, they'll be at 20% HP" *before* the attack resolves. Verified absent: `Battle.ts` never calls `estimateDamage` and draws no damage text; the Build Brief's step 10 specified a forecast popup that was never built. Why it matters this much here specifically: this game has **permadeath and Ironman on by default**. A player who can't see the number is gambling with a pilot's life on every click, and losing a pilot to a mis-estimate feels unfair instead of tragic. The engine already has the function (`engine/ai.ts estimateDamage`, and `combat.ts` resolves both hit and counter) — this is a UI box, not new math. Show it for the Meeps dodge too ("40% chance to dodge").

### A2. Enemy threat range overlay — **absent, M**
Fire Emblem's "press a button, see every tile an enemy can reach and hit next turn." Verified absent. It's the single biggest reason players die to the alpha-strike Missions 8 and 12 are built around: they can't see the pack's reach. The difficulty-tier plan builds exactly this computation for the Hard bot (`engine/threat.ts`); putting it in the game UI as a toggle key is the same map drawn in red. Build once, use twice.

### A3. "Units still have actions — end turn anyway?" — **absent, S**
Verified: `doEndTurn` in `Battle.ts` ends the turn with no check. Space is bound to it. Under permadeath, an accidental Space with the Munti un-moved is a run-ender. One confirmation prompt when any player unit still has `actionsRemaining > 0`. XCOM has it; everyone who's ever fat-fingered it is grateful.

### A4. Enemy phase you can actually watch — **absent, M**
Right now `endPlayerTurn()` resolves the whole hostile phase instantly, then the board re-renders. The player sees the aftermath and a text log, not the events. No tween, no flash, no camera pan on hostile moves (the walking animation shipped for the player side only). Every tactics game plays the enemy turn back — move by move, with the attacked unit flashing — because that's how the player learns what killed them. Add a queued playback of the hostile phase (the engine's `log` already records each action in order; the UI just needs to animate through it), with a "fast-forward" key. This also makes A2 teachable: the player watches the swarm cover distance and learns to respect it.

### A5. The window scales to the screen — **absent, S, do it before Electron week**
`main.ts` creates a fixed 1074×640 canvas with no Phaser `scale` config. In the browser demo it sits as a small box; in the Electron build it will sit as a small box in the middle of a 1440p monitor, which is the first thing a paying player will complain about. Phaser's Scale Manager (`scale: { mode: FIT, autoCenter: CENTER_BOTH }`) is a five-line change — but every scene that hard-codes pixel positions needs a look for anything that assumed the old size (the Tier 6 canvas-widening hotfix already did this once for full-screen overlays, so the pattern is known). Worth doing in Week 3, not Week 4, so Electron week isn't also layout week.

### A6. Sound — **nothing exists, L for real, M for "enough"**
Verified: zero audio code anywhere, `Options.ts`'s own comment says "no audio/graphics." No music, no hit sound, no UI click. This is the biggest *feel* gap in the game and it's easy to underweight if you play muted yourself. "Enough for EA" is: one ambient loop for the Hub, one for battle, a hit/miss/kill sound, a UI click, a mission-win sting, a pilot-lost sting — eight files from a CC0 pack (Kenney's, freesound), a 60-line audio manager, and two volume sliders in Options. The permadeath moment in particular needs a sound; silence there reads as a bug, not a beat. Real music is a post-EA, find-a-composer item.

### A7. Version number on the main menu + a "Report a bug" button — **absent, S**
`package.json` says `0.0.1`; nothing displays it. For an EA with outside testers, "which build were you on" is the first question on every bug and today there's no answer. Show `v0.x (build hash)` in the corner of MainMenu. The bug button copies a diagnostic blob (version, last mission's log, current save summary, the stats export from the telemetry plan) to the clipboard and opens the itch thread. This is the item that most directly protects Maxime's evenings during EA.

### A8. Missiles have no UI — **shipped in the engine, unreachable by a human, S**
Found while auditing abilities for the bot plan: `Mission.canMissileStrike/missileStrike` exist and are tested, the Reeps weapon branch grants `abil_missile`, but `Battle.ts`'s action bar never offers it. A player who buys the Missiles branch gets nothing. Either wire it (same arm-then-click-tile pattern Fire Support already uses) or hide the branch until it's wired.

---

## B. Cheap and loved — small work, outsized emotional payoff

These are the things people post screenshots of. Most fall out of the telemetry plan's mission records almost for free.

### B1. A real end-of-mission stat screen — **partial, S once telemetry Phase 1 exists**
Debrief today shows the points breakdown (completion, turns-under-limit bonus, no-downed bonus…) and nothing else. Players want the story of the fight: MVP by damage, kills per pilot, who took the most punishment, who got saved by the Munti, turns vs par, and a badge line ("Clean sweep — nobody downed"). Every number is already in `Mission.unitPerformance` except damage taken.

### B2. Pilot service records — **absent, S/M after telemetry**
Fire Emblem players memorize their units' kill counts. Missions flown, kills, times downed, times restocked, favorite ability — on the roster card in the Hangar and on the Hub's Berths. This is the combat half of the attachment the social sim is building on the Hub side; right now a pilot's history is only social. Ties the two halves of the game together.

### B3. A memorial — **absent, S after telemetry, very high love**
Every permanently lost pilot, name, mission, turn, cause. XCOM's memorial wall is one of the most-cited features of that game and it's a list. The Vault is the natural home (it's Week 2's build anyway); the Grief Catalyst system already gives the *crew* a reaction to a loss — this gives the *player* one.

### B4. Use the portraits you already have — **assets exist, unwired, M**
The EA plan says all 15 named pilot portraits and 4 splash images are generated and in the repo. Verified: every scene still draws the placeholder circle-with-initials (`TransporterPad.ts` header says as much). Wiring the real portraits into the Transporter Pad, the roster, Debrief, and the Hub name labels is the single biggest visual upgrade available for the least work, and it's already paid for.

### B5. A briefing room — **the storyteller's item, M**
Mission briefings exist as text on the mission-select card, and in-mission dialogue events exist as one-line log entries (`action: {type: "dialogue", text: "Anand: ..."}`). Neither is a *scene*. You write stories people see and hear — the game currently delivers yours as a paragraph on a button. A briefing screen before deploy (CO portrait, two or three lines, the map thumbnail, the objective in plain words) and a two-line portrait exchange at the mission's turning point would be the first time the campaign's writing is actually *staged*. The dialogue-event hook is already in the mission data; this is the presentation layer for it. Post-mission, the same screen can carry the Debrief's story beat before the numbers.

### B6. Name your company / your ship — **absent, S**
One text field at New Campaign. Players name things they intend to lose. Feeds the Hub's ambient lines (`{COMPANY}` slot) and the memorial header.

### B7. Save the battle report — **absent, S**
"Copy mission log" on Debrief. The engine's `log` is already a readable turn-by-turn narrative; players share those, and testers will paste them into bug reports without being asked.

### B8. "Last words" — **absent, S, content not code**
When a pilot is permanently lost, one line in their catalyst's voice on the COMMAND/loss overlay. Nine catalysts × two lines each is an afternoon of writing, and it's the moment players will remember.

---

## C. Worth doing soon after EA (or in EA if a week frees up)

### C1. Player-facing difficulty settings — **absent, M, and the bot tiers hand you the calibration**
Today the only choice is Ironman on/off. Once the Easy/Moderate/Hard bots exist and every mission has a win-rate fingerprint, a player difficulty setting stops being a guess: "Story" = enemy damage ×0.8 and one extra Fire Support charge, tuned so the Easy bot wins the band; "Veteran" = tuned so only Hard clears the climaxes. Two multipliers in `combatTables.ts` and a selector on CampaignSetup. Don't ship this before the bots exist — you'd be guessing the numbers, which is the thing you said you don't want to spend days on.

### C2. French — **never mentioned in any doc, groundwork is S, translation is M**
You're Québécois, the game will be on itch.io where French-speaking players are a real slice, and every UI string is hardcoded English today. Full translation isn't an EA item. But the *groundwork* — a single string table the scenes read from instead of inline literals — gets exponentially more expensive every week it waits, because every new feature adds more strings in the wrong place. The dialogue banks (hundreds of lines) are the hard part and can stay English for years; the ~200 UI strings are the cheap part. Do the string table during a quiet week; translate later, or let the community.

### C3. Undo the last move — **absent, M, design call**
Into the Breach lets you undo a move as long as nothing new was revealed. Under Ironman it's a real design question (does undo cheapen permadeath?), so a conservative version: undo is allowed only for a move that revealed no new enemy and triggered no reaction fire. Reduces the misclick tax without touching the stakes.

### C4. Hover to inspect — **absent, S/M**
Hover an enemy: archetype name, HP, attack range, what its on-hit effect does (the acid DoT is invisible until it lands). Hover a tile: terrain name and defence stars. Verified no `pointerover` handlers in Battle. The Codex now has the field manual; this is the in-context version.

### C5. Cancel with Esc / right-click — **absent, S**
Selection and targeting are cancelled by clicking elsewhere only. Esc to deselect and right-click to cancel a targeting mode are reflexes; their absence reads as "it's stuck."

### C6. Colorblind consideration — **partial, S**
The Bloom silhouette doctrine already made enemy *types* readable by shape, which is the hard part. The remaining risk is the green/red highlight pair (reachable vs attackable) — the standard trap. A single alternate palette toggle in Options (blue/orange) covers ~8% of male players. Also verify the hold-zone teal reads against the scrub-green tiles.

### C7. Enemy-phase speed, animation speed — **S, once A4 exists**
"Fast enemy turn" toggle. Paired with A4.

### C8. A campaign progress view — **partial**
MapSelect with Act tabs already does the job functionally. What it lacks is *momentum*: a visible thread (12 nodes, 24, 36; where you are; what's next; your losses so far along it). A vertical strip with mission nodes and the memorial's names under the ones where someone fell. Presentation, not system.

### C9. Controller / key rebinding — **absent, defer**
Not for a browser/itch EA. Note it in the Steam plan.

---

## D. Things to protect the launch *from* — don't add these before 26 Oct

Said as a partner, not a scold: every one of these is a good idea, and every one is the kind of thing that turns an eight-week plan into a twelve-week one.

- **PvP / Gladiator** — the bot plan gets the *bot* ready; wiring it as an opponent is the PvP update, as already decided.
- **The calendar / day-cost economy** — locked design, deferred by the EA plan; re-deferring it here.
- **More social-sim systems** (Worries, Praise/Insult, Pilot Discharge) — the Hub is already the deepest part of the game; nobody will review EA saying "not enough social verbs."
- **The Character Editor** — a whole product on its own.
- **Real art / sprites** — the placeholder decision is the right one; the portraits (B4) are the exception because they're already made.
- **A second campaign in the build** — House Amaranth is built and deferred; keep it deferred.

What *should* eat spare weeks instead: section A top to bottom, then B in order.

---

## E. The two things that will save you the most time, said directly

1. **A7 + the telemetry export.** Testers who can press one button and paste a blob into a thread will report ten bugs for every one they'd report by describing it from memory. It turns "spend days adjusting difficulty" into "read the numbers on Sunday."
2. **A1 + A2 + A4 before the outside playtest round (Week 6).** The 26 Aug playtest's own notes are dominated by "I couldn't tell what was happening" (which unit to extract, why the mission failed on turn 16, misreading a highlight). Every one of those is an information gap, not a balance gap. A tester cohort that can see damage numbers, enemy reach, and the enemy phase will give you *balance* feedback; one that can't will give you the same legibility complaints the first playtest did, and the difficulty numbers underneath will stay invisible.

---

## F. Suggested order, fitted to the existing EA weeks

| Week | Already planned | Add from this report |
|---|---|---|
| 1–2 | Verification pass; Vault | A3, A5, A7, A8, B6 (all S) |
| 3 | Docs, balance triage | A1, A2 (shares the bot's threat map), telemetry Phase 1, B1 |
| 4 | Electron | A4, A6 "enough" audio |
| 5 | itch page, second verification | B3 memorial (in the Vault), B4 portraits, B7, B8 |
| 6 | Outside playtest | ship with A1/A2/A4/A7 in testers' hands |
| 7–8 | Feedback, freeze, launch | C5, C6 if trivial; everything else post-EA |

None of the S items above needs a design decision from Maxime; the M items in A each need a "yes" and one session. The only items here that change the docs are C1 (a new Options/difficulty section for the GDD, later) and C2 (a Build Brief convention: strings live in a table). Neither is urgent.
