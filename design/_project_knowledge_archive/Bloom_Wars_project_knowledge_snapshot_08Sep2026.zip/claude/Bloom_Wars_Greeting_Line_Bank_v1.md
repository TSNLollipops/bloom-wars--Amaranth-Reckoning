# Bloom Wars — Greeting Line Bank, v1

*Written 27 Aug 2026, in response to Maxime: "we forgot to add greetings line to the game oops." He's right, and the gap is narrower and more specific than "greetings were never done" — see §1. Content only; nothing here is wired, and it can't be until the repo is reachable (see §5).*

## 1. What was actually forgotten — three different "greetings," only one of them missing

Worth separating these before writing anything, because two of the three are already shipped and re-doing them would be waste:

| Thing | Status |
|---|---|
| **Rank-deference greeting** ("Hello, Sir" — an NPC defers the first time you talk to them after Rourke's promotion to Capt./Maj.) | **Built**, 27 Aug. One-time reveal, catalyst-specific, 18 buckets × 2 lines. Uses her rank title, not "sir." |
| **Stage graduation reveal** (an NPC acknowledges their own Green→Blooded→Command promotion) | **Built**, 27 Aug. Same shape. |
| **A plain greeting — you type "hey" and the crew says hello back** | **Not built.** This is the one. |

The third has a paper trail and it stops halfway:

- `Bloom_Wars_Build_Log_Addendum_HubPolish_26Aug2026.md` recorded the original symptom in play — a typed greeting "doesn't land in any recognized bucket... so it falls all the way through to the generic shrug." You say hi, the crew shrugs at you.
- `Bloom_Wars_Chat_Keyword_Categories_Plan_v1.md` made Greeting category #1 and said *"Recommend building first."*
- `Bloom_Wars_Chat_Keyword_Categories_Delivery_v1.md` drafted the recognizer for categories 1–5 the same day — and its own header says **"content + spec drafted, NOT verified against the live repo."**

So it was designed twice and never shipped once. That's the oops.

## 2. The real hole in the delivery doc — it has no greeting *lines* in it

This is the part worth catching before anything gets wired, because it would have shipped feeling wrong.

The Delivery doc routes a recognized greeting straight to `pickAmbientLine(npc.ambient)` — the exact same call the E-key Talk already makes — and explicitly calls this "recognizer only, no new content." That's true, cheap, and it's what the plan doc recommended.

**But it means typing "hey" and pressing E produce literally identical output.** The NPC never says hello. They answer a greeting with whatever mood line they'd have volunteered unprompted. Mechanically it's a response; conversationally it's still a shrug with extra steps, which is the exact complaint that started this.

A greeting needs the crew to *greet back*. That's the content below — and it's genuinely small, because a greeting is the one line in the game that should be short.

## 3. The bank — 9 catalysts × 4 states × 2 lines = 72 lines

State axis is the engine's real `AmbientPilotState`, not a new one: `idle` (default), `worried` (mission worry active), `drunk` (after Share a Drink), `low_morale` (after a loss). Same states `pickSoloEcho` already reads, so this needs no new plumbing — only a new bank and a routing branch.

**Written short on purpose.** The chat side panel renders at 9px with 6 visible lines in the ~110px right-hand gutter. A greeting is a doorway, not a speech. Most of these are under 50 characters. (See §4 — this is also a problem for the *other* categories in the Delivery doc.)

```ts
const GREETING_LINES: Record<Catalyst, Record<AmbientState, string[]>> = {
  wolf: {
    idle:       ["You're up. Good — that's everyone accounted for.",
                 "There you are. Was about to start a headcount."],
    worried:    ["Come sit. Easier when there's two of us waiting.",
                 "Hey. Still no word. Stay a minute."],
    drunk:      ["Hey! Hey. Sit. You're pack, you get a seat.",
                 "There's my— there you are. Good."],
    low_morale: ["Hey.",
                 "You're here. That's the part that counts today."],
  },
  dog: {
    idle:       ["Hey! Been hoping you'd come round.",
                 "There you are. Told you I'd be here."],
    worried:    ["You heard anything? No? Okay. Okay.",
                 "Hey. Sit with me till they're back?"],
    drunk:      ["HEY. You. My favourite. Don't argue.",
                 "Hey — hey, I was just talking about you."],
    low_morale: ["Hey. Glad it's you.",
                 "...Hey. Sorry. Slow start today."],
  },
  cat: {
    idle:       ["Mm. You.",
                 "Oh good, company. I'd nearly relaxed."],
    worried:    ["Still nothing. I'm not pacing. You're pacing.",
                 "Don't ask. I'll tell you when there's news."],
    drunk:      ["Ahh. You. I've decided I like you today.",
                 "Sit down, you're making the room lopsided."],
    low_morale: ["Not today. But sit if you want.",
                 "Hm. Hello."],
  },
  crow: {
    idle:       ["Oh — good, you're here, I had a thought.",
                 "Hey! Okay so. Unrelated question."],
    worried:    ["I keep running the numbers. They don't help.",
                 "Hey. Distract me. Please."],
    drunk:      ["OH. Okay. Okay listen. Listen.",
                 "You! I have theories. Several."],
    low_morale: ["Hey. Not much in the tank today.",
                 "Oh. Hey."],
  },
  raven: {
    idle:       ["Good, you're up. Sit, if you've got a minute.",
                 "Hello. How's the head?"],
    worried:    ["No news yet. Waiting's the hardest drill there is.",
                 "Hey. Sit. Nothing to do but wait it out."],
    drunk:      ["Ha — there you are. Pull up something.",
                 "Hello. Ask me anything, I'm feeling generous."],
    low_morale: ["Hello. Rough one.",
                 "Hey. Take the chair. Don't talk if you don't want."],
  },
  bear: {
    idle:       ["Hm. Hello.",
                 "You're here. Good."],
    worried:    ["Still waiting. I'll hold the corner.",
                 "Hm. Nothing yet."],
    drunk:      ["Hah. Hello.",
                 "Sit. Plenty of room."],
    low_morale: ["Hello.",
                 "I'm here. That's all I've got."],
  },
  fox: {
    idle:       ["Well look who remembered where we live.",
                 "Hey, trouble."],
    worried:    ["No news. I've made up three versions. All bad.",
                 "Hey. Talk to me, it's too quiet."],
    drunk:      ["HEY. Don't— don't judge me, sit down.",
                 "Ohhh, perfect timing. Terrible timing. Both."],
    low_morale: ["Hey. Not feeling clever today.",
                 "Hey, you."],
  },
  rabbit: {
    idle:       ["Oh — hi! Sorry, hi.",
                 "Hi. Sorry, you startled me. Good startle."],
    worried:    ["Hi. Have you— no. Okay. Sorry.",
                 "Hi. I'm fine. I'm not fine. Hi."],
    drunk:      ["Hi! Hi. I'm having a nice time, is that okay?",
                 "Oh — hello! Sit, sit."],
    low_morale: ["Hi. Sorry. Not great today.",
                 "...Hi."],
  },
  shark: {
    idle:       ["You're up. Good.",
                 "Hey. Tell me there's something happening."],
    worried:    ["Nothing yet. I hate this part.",
                 "Hey. Sitting still is the worst thing we do."],
    drunk:      ["Hah! There you are. Sit, I'm winning.",
                 "Hey. You're just in time for my best story."],
    low_morale: ["Hey.",
                 "Not my day. Say something anyway."],
  },
};
```

**Routing, amending the Delivery doc's §1:**

```
greeting matched
  → pickGreetingLine(npc.catalyst, ambientStateOf(npc))
  → NOT pickAmbientLine()
```

One deliberate follow-on worth considering rather than assuming: a greeting could show the greeting line **and then** the ordinary ambient line, one after the other — the NPC says hello, then tells you what's on their mind. That reads far more like a conversation than either half alone, and the staged-second-bubble mechanism already exists (`NPC_REPLY_DELAY_MS`, built for NPC-to-NPC exchanges). Cheap, and probably the version worth playing. Flagged, not decided.

## 4. A real problem with the *other* categories, caught while sizing these

The Delivery doc's Farewell / Advice / Banter lines are long. Several run past 90 characters; crow's advice line is 108, raven's banter line is 88. The chat panel's 9px font and 6-line display cap were tuned by rendering **real `LINE_BANK`-length content** and checking it didn't overflow — and `LINE_BANK` lines are ambient barks, which are short.

Nobody has checked whether a 108-character line fits in that gutter. It may wrap to three lines and eat half the visible log, or it may clip. **Worth measuring before categories 3–5 ship**, not after. That's a five-minute check against the running scene, and it's exactly the kind of thing that ships broken because the content and the panel were written by different passes.

## 5. What's blocking the wiring

This session can see the device `lorian-pc` but **no folder is connected**, so `chatIntent.ts` and `Hub.ts` can't be read. Per the Delivery doc's own access note and this project's standing rule, nothing here should be pasted in blind — the recognizer's real function name, the existing match order, and whether a greeting keyword collides with an existing emotion keyword all need a look at the actual file first.

**To unblock: connect the repo folder in the Claude desktop app ("Add folder"), or say the path and I'll request access.**

Once it's reachable, the build is small and should go in one pass:

1. Read `chatIntent.ts` — confirm the real recognizer signature and current match order.
2. Add `GREETING_LINES` + `pickGreetingLine()` to the ambient-line module (pure, `src/data/**`, same purity rule the other banks follow).
3. Add the greeting and worry-checkin recognizers, **ordered ahead of the emotion buckets** — "how are you" and "any word" are plausible false-matches against loosely-matched emotion keywords, which is the one real risk in the Delivery doc's spec.
4. Route `greeting` to `pickGreetingLine`, not `pickAmbientLine`.
5. Unit tests: every catalyst × state bucket returns real content; greeting outranks emotion on a colliding phrase; no bucket is empty.
6. Live check in a real browser — type "hey" at three NPCs in different states and read what comes back.
7. Measure the §4 line-length question before deciding whether 3–5 go in the same pass.

## 6. Docs that need updating once this ships

- `Bloom_Wars_Chat_Keyword_Categories_Delivery_v1.md` — §1's "recognizer only, no new content" is superseded by §3 above; its status header stops being "drafted, not verified."
- `Bloom_Wars_Chat_Keyword_Categories_Plan_v1.md` — category 1's "zero new content required" line needs the same correction, and it's the source the delivery doc inherited the assumption from.
- `Bloom_Wars_Social_Sim_Roadmap_v1.md` — worth an entry, since this is the roadmap's own territory.
- `Bloom_Wars_Master_Index.md` — a pointer, once it's actually built rather than drafted.
