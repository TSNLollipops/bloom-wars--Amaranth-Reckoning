# Weapon Branch Point System vs. campaign mission balance — check v1

*28 Aug 2026. Maxime asked, plainly: does the campaign still hold up against the current-gen mech roster now that pilots have a specialty (the 27 Aug Weapon Branch Point System) to equip? This doc records an actual run of the real mission harness with branches equipped — not a stats-table guess — against five of the campaign's toughest/most sensitive missions, plus two things found along the way that aren't about weapon branches at all.*

## Why this was worth checking for real

All 36 Amaranth missions were sim-tuned and win-rate-validated **before** weapon branches existed. `data/weaponBranches.ts`'s own header says so directly: costs/effects are "placeholders pending a real economy sim harness... nothing here has been through combat_sim.py or an equivalent." Nobody had re-run the actual mission harness (`npm run sim`) with a branch-equipped squad against the already-tuned campaign. Given how tight several missions already are on record — Mission 21 at a documented ~35%, Mission 32 sitting on what its own comment calls "a sensitive margin," Mission 36 flagged in its own file as having "knife-edge tuning sensitivity" — and given Impact Lance alone is a flat +15 ATK stacked permanently on top of gear tier (roughly a tier-and-a-half of progression, for 150 points, forever), this was a real risk, not a hypothetical one, and exactly the kind of silent drift this project has caught before (the Wellroot on-hit-effects gap, the 26 Aug deploy-cap retuning pass).

## Method

Reached the actual repo on Maxime's machine, pulled the current source needed to run the mission harness (`data/`, `engine/`, `sim/`, minus the Hub/social-sim-only files, which the combat path doesn't touch), and ran it in a sandbox with a fresh `npm install` — same `Mission`/`decidePlayerAiAction` code that's live in the repo right now, nothing reimplemented. Weapon branches were equipped by setting `equippedWeaponBranch` directly on the roster's `PilotRecord`s (Impact Lance for every Meeps, Grinder Claw for every Tank, Missiles for every Reeps, Rapid Response for every Munti — Rail Lance was left out of this pass since every mission tested is a pure-Bloom fight and Rail Lance only ever triggers against a Tank-*path* defender, which no Bloom archetype is; see "still open" below).

**A real bug in this check's own first draft, caught before trusting any of it:** the first version called `new Mission(missionDef)` against the same shared mission object every trial, exactly the in-process state leak `claude/build_log/engine_systems/squad_and_deploy_structure.md` already documents catching once before ("an earlier, non-cloned test run gave misleadingly extreme numbers"). It happened again here — win rates drifted and were inconsistent run to run until every trial deep-cloned its own mission object. Fixed the same way that doc fixed it. Worth restating as a standing rule: never sim-test off a shared mission object across trials.

## What actually moved

Baselines below use each mission's real current shipped state — current squad, current enemy counts, no branches — which is exactly what `npm run sim` produces today. N=100 trials per cell unless noted.

| Mission | Documented target | Baseline (no branches) | With branches equipped |
| --- | --- | --- | --- |
| M14 Steel Rain | ~5-15% (already a known, un-retuned outlier) | 13% | 13% — no change |
| M21 Cut the Root (Wellroot) | ~35% | 30% (matches) | **48%** — a real jump |
| M32 Hold at the Spire | ~35-40% | 26% | 28% — no meaningful change |
| M35 The Last Ring (Cradle) | 55% (11/20) | 72% | 72% — no change *(see the doc-drift note below — the 55% itself looks stale)* |
| M36 Until Relief | 80% (16/20) | ranged 40-73% across repeated N=40/100 batches | no separable signal — see below |

**Mission 21 is the one real, repeatable finding.** Every configuration tested — the full N=100 pass, an earlier N=40 pass, a per-branch isolation pass — landed in the same direction: branches make this fight noticeably easier, roughly a 30-40% baseline creeping into the high 40s/high 50s%. Isolating each branch alone against just this mission (N=60 each) pointed at Impact Lance and Grinder Claw as the two doing most of the work (each alone pushed the baseline from ~37% to ~47-48%), with Missiles and Rapid Response showing no reliable individual effect — though at N=60 that per-branch attribution has real noise on it and shouldn't be read as precise. The mechanical story fits: this is a single durable boss (Wellroot, 480/65) plus repeated Undertow reinforcements, i.e. exactly the attrition shape where a flat, unconditional +15 ATK and a 20%-of-damage self-heal both compound hardest.

**M14/M32/M35 show no reliable branch-driven movement** — whatever else is going on with them (see below), equipping branches didn't shift their numbers outside noise in this test.

## Two things found that have nothing to do with weapon branches

**Mission 35's build-log doc looks stale.** `mission35_the_last_ring.md` still reads "Result: 11/20 (55%)." Testing the current 15-pilot Act III squad against the old, pre-26-Aug 12-pilot squad on this exact mission (branches off both times) gave 88% vs 38% — a swing entirely explained by the 26 Aug deploy-cap change, which `squad_and_deploy_structure.md` already says happened to this mission ("Mission 34 and 35 went from near-unwinnable to healthy... as a side effect") but that mission's own file was never updated to say what the new number actually is. Same shape as the roadmap #6/#7/#8 and #14 doc-drift bugs already caught elsewhere this project — the fix belongs in `mission35_the_last_ring.md` itself, independent of anything about weapon branches.

**Mission 36 won't hold still.** Four independent large-sample batches of the identical current-code, current-squad, no-branches configuration returned 29%, 40%, 51%, and 73% win rate. That's more spread than sampling noise alone should produce at N=40-100, and it lines up with the mission's own file already calling this a "knife-edge" — a first draft went 0/20, a small trim overshot to 20/20, and the shipped counts were the narrow middle that "landed correctly" at the time. Something (plausibly the same 26 Aug/27 Aug engine changes elsewhere) may have nudged this mission back onto that same knife-edge. This needs its own dedicated look before anyone can say whether branches touch it at all — folding it into this check would have been guessing.

## The actual decision this leaves open

Mission 21 is the only place this check found a clear, attributable problem: a fight tuned to ~35% is heading toward ~50% once a player has bought and equipped weapon branches. Three honest ways to close that, none of them started without your call:

1. **Leave it.** A boss from Act II reading easier once a player has spent real currency on a specialty upgrade is a completely normal, even satisfying, power curve for a tactics game — Mission 21 isn't the campaign's hardest fight (that's Mission 35), and nothing says every mission has to stay pinned to its original number forever.
2. **Nudge Mission 21 itself** (Wellroot's endurance, or the Undertow reinforcement cadence) back toward ~35% assuming branches are equipped — the same kind of content-level fix already used on this exact mission once before (removing the opening Crawlmass wave, 25 Aug).
3. **Nudge the branch numbers themselves** — Impact Lance's +15 or Grinder Claw's 20% — which ripples protectively across every mission at once rather than one, and fits since those numbers are explicitly still-placeholder in the code's own comments.

Whichever way this goes, the fix only counts once it's re-run through this same harness and lands back near target — the sandbox rig built for this check is still standing by to verify any of the three in a couple of minutes.

## Still open / honestly not covered by this pass

- Only 5 of 36 missions were checked (the ones with the tightest documented margins, on the theory that a systemic problem would show up there first). A clean result on these five is evidence the campaign broadly holds up, not proof all 36 do.
- Rail Lance was never exercised — every mission tested is Bloom-only, and Rail Lance's defense-ignore only ever fires against a Tank-*path* defender, which no Bloom archetype is. It would need a mission with hostile Amaranth mechs to test at all, and on this evidence it's the lowest-risk of the five branches by construction, not because it was checked and passed.
- Per-branch attribution on Mission 21 (Impact Lance/Grinder Claw vs. Missiles/Rapid Response) is a real signal but wasn't run at a large enough N to be precise — good enough to guide a fix, not good enough to cite as an exact split.
- Mission 36's instability and Mission 35's stale doc are both logged here as findings, not fixed — neither has had anything about it changed yet.
