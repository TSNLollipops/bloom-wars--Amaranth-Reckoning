# THE BLOOM WARS — Hangar Deck Roster & Stats Panel: Plan Only, Zero Code

**Design pass only, per Maxime's own explicit instruction (29 Aug 2026): "just plsn it out. dont build anything yet. no more building for a few day."** Nothing in this doc is built. Written to be read fast and reacted to, not re-derived from scratch, once building starts again.

*Ask, verbatim: "dont let the player see the fsvorability incrase decrase. they just see the number in the hangsr room panel that give them acess to a menu with their pilot stats on it. divided per lanced. each with their own sub page."*

## 0. Restating the ask, so a misread gets caught now

Two changes, one dependent on the other existing:

1. **Stop showing Favorability moving in real time while walking the Hub.** Today, standing near an NPC shows their live number and it visibly ticks up/down as things happen around you. That goes away.
2. **The only place the number lives is a new panel, opened from the Hangar Deck room** — a menu of pilots, grouped by lance, each lance getting its own subpage, each pilot's subpage showing their stats (Favorability included) as a static readout you check on purpose, not something ambient.

Flag if this isn't the read: the doc below treats "hide the delta" and "hide it everywhere except one deliberate menu" as the same instruction, not two — read as spending doesn't want the number gone, just wants it demoted from ambient to on-demand.

## 1. Current state, checked against the actual files, not memory

**The live ambient readout this is replacing.** `Hub.ts`'s `favorabilityLabel()` renders `"<Name>  [Stage]  +35 (demo)  ♥ with X  ⚡ Y"` and shows it the instant you're within `APPROACH_RADIUS` (78px) of an NPC — the file's own comment reads "Favorability becomes visible once you're this close." It updates live, every tick, off the same `npc.favorability` number every interaction writes to. That's the thing to remove: not a popup or toast (there isn't one — no code path flashes "+5 Favorability!" anywhere), just this always-on proximity readout.

**Two different things are both named "Hangar" — worth being precise about which one this touches.** `scenes/Hangar.ts` is the live Campaign Shop (gear purchases, live since 25 Aug) — unrelated, not touched by this. The **Hangar Deck room** inside `Hub.ts`'s walkable ship is a different thing: one of the seven rooms, currently a stub. Its own room-note string, verbatim, is: *"Roster & deploy management still lives in the Campaign Shop for now."* Its planned mechanical job, per `Bloom_Wars_Antfarm_Carrier_Hub_v1.md` §2's original room table, was always "Roster and deploy management, mission select, the Munti deploy gate" — **this ask isn't a new idea for that room, it's the first real request to actually build the job that room was always supposed to have.** Worth knowing going in: this doesn't compete with anything else planned for that space.

**"Lance" doesn't mean the same thing in the live game as it does in the sandbox — this is the one real landmine in the ask.** In `pilot_creator.html` (the disconnected prototype), a lance is a real, player-assignable grouping — "a lance is 5 man squad, 4 random and a Munti minimum," and a pilot can be clicked to cycle A → B → C → unassigned at will. **None of that is wired into the live game.** `PilotRecord` has no `lance` field. `CampaignState.pilots` is one flat dictionary, no grouping. What the live game does have is three *static* pilot batches that arrive at fixed campaign beats — `WARDEN_PILOTS` (the starting five), `SECOND_LANCE_PILOTS` (added at Mission 12, Rourke promoted to Captain), `THIRD_LANCE_PILOTS` (added at Mission 24, Rourke promoted to Major) — and nothing ever reassigns a pilot between these after the fact. Both readings produce three even groups today, since nobody's built a reason for them to diverge yet, but they're not the same feature, and only one of them is free.

**Reusable pattern already in the codebase, so a subpage-per-lance UI isn't a new kind of thing to build.** `ShopPanel` already runs a `shopPage` index plus a category selector (`recruitClass`, cycling Meeps/Tank/Reeps/Munti) to drive its own tabbed layout. Whatever the roster panel ends up being, it's the same shape of problem this file already solved once.

## 2. Proposed shape

**2a. Ambient view — small, contained.** `favorabilityLabel()` stops interpolating the raw signed number into the string. What's left of the label (name, Stage badge, the ♥/⚡ relationship-status tags) is a judgment call — see open question below — but the number itself no longer renders anywhere in the walk-around Hub view, full stop.

**2b. The Hangar Deck panel — the actual new piece.** Walking into Hangar Deck and interacting (same "E — enter" convention every other room already uses) opens a panel, laid out the same register as `ShopPanel`/`Hangar.ts`'s existing Campaign Shop screens rather than inventing new chrome:

- **Top level: a lance tab strip** — Lance A / Lance B / Lance C (names a placeholder; "1st/2nd/3rd Lance" or something in-fiction is Maxime's call), each tab a subpage.
- **Each subpage: a card per living pilot in that lance.** Stats available today, per pilot, without inventing anything new: display name/callsign, path (Meeps/Tank/Reeps/Munti), chassis/species, gear Stage (Green/Blooded/Command) and tier, catalyst personality, Stress and Morale (already have label functions — "steady/strained/panicking" style, matching the sandbox's own wording), Favorability (now living here instead of ambient), relationship status (♥ partner / ⚡ rival tags), equipped weapon branch if any, personal points balance.
- **A pilot who's permanently lost** — shown as a memorial/KIA entry on their lance's page, or dropped entirely once lost? Not decided (see below).

## 3. Open questions — my own recommended pick on each, so this is a fast yes/no pass rather than a blank page

- **Lance grouping: derive from the three static arrival batches (Lance A/B/C = which of `WARDEN_PILOTS`/`SECOND_LANCE_PILOTS`/`THIRD_LANCE_PILOTS` a pilot's static id came from), or build the sandbox's real player-reassignable lance system for real?** *Recommend the static-batch reading.* It's free — no new persisted field, no reassignment UI, just a lookup — and it's exactly what "divided per lance" needs for a stats-viewing menu. The reassignable version is a real, separate feature (and was never actually ported from the sandbox into the live game) — worth its own future ask if you want players actually reorganizing squads, not something to fold into "let me see my roster's stats."
- **Whose Favorability shows on a pilot's card?** A pilot can have bonds with several other pilots at once. *Recommend: the bond with Rourke (the player character) as the headline number, since that's what the ambient readout showed today, plus the existing ♥/⚡ tags for anyone else they're tied to* — not a full matrix of every pair.
- **Does the ambient label keep the ♥/⚡ relationship tags, or does "don't let the player see it" mean the whole label goes dark until you're in the panel?** *Recommend keeping name + Stage + relationship tags ambient (they're status, not a moving number), dropping only the numeric Favorability value itself* — but this is a real either/or, not a small detail, and worth confirming since it changes how much of today's Hub polish work gets rolled back.
- **A permanently-lost pilot — memorial entry on their lance's page, or gone?** *Recommend a memorial entry* — this project's own discipline elsewhere (Legend status, the Vault's dedication scene) treats a lost pilot as still-present in the record, not erased, and a lance page that just quietly shrinks reads worse than one that shows who was lost.
- **Anything on the "stats available" list above that shouldn't be shown, or anything missing you actually want?** The list above is everything the engine already tracks per pilot — not a proposal to add new stats, just an inventory of what a card could show without new engineering.

## 4. What this doesn't touch

No code this pass, per the instruction. Both "Hangar" namings stay exactly as they are — that collision is already flagged in both files' own headers and isn't this doc's problem to fix. Nothing about mission-fielding changes — lance grouping here is a Hub-viewing category only, not a constraint on which pilots can deploy together (that's the parked Transfer-Orders/lance-cohesion idea, a separate thing).

## 5. Doc-touch flag, once this is confirmed and built

`Bloom_Wars_Antfarm_Carrier_Hub_v1.md` §2's Hangar Deck row goes from "roster & deploy management" as an aspirational label to an actual description of what's there. Worth a line in the Master Index too, same as every other shipped Hub piece.
