# The Bloom Wars — UI Improvement Plan v1

**Written 4 September 2026, by Claude Code, working directly against the live repo** (`F:\The Bloom wars. Code project\bloom-wars\bloom-wars`), not against docs or memory of them — every claim below was checked against the actual source file it names. **This is a plan, not a build.** Nothing in here ships until Maxime picks what to build.

**Why this exists.** Maxime asked for a UI improvement plan. That turned out to be four different things once the actual project state got pulled up, so this document is four independent tracks rather than one list, ordered by how urgent each is against the 26 October EA date:

1. **Harden the UI safety net** — the sweep tooling that caught six shipped bugs 3–4 Sep has known gaps in itself.
2. **Close the table-stakes polish gaps** — re-sequenced from the 1 Sep feature-gap report against what's actually shipped since.
3. **Flag the Hub.ts overlay architecture** — the real root cause behind two of this week's bugs. Flagged per Foundation's own rule, not being built.
4. **The Battle HUD relayout, mission chat, and player notes** — Maxime's own already-written plan doc, handed to this session to unblock. Its three blocking facts got answered directly against the code below.

Each track stands on its own — read the one you care about.

---

## Track 1 — Harden the UI safety net

**What exists today.** `sweepUi.mjs` walks 28 screens checking for squashed/buried/offscreen text; `auditUiText.mjs` is its underlying text-geometry auditor; `checkUiAuditSelfTest.mjs` tests the auditor itself; and roughly 15 feature-specific Playwright scripts (`checkHangarShopFitsDock.mjs`, `checkActionBarPaging.mjs`, `checkHubCameraScroll.mjs`, `checkCodex.mjs`, and so on) each pin one specific bug class. This caught real, shipped bugs this week: six invisible Hub HUD readouts, `6LAST RITES` rendering as `BAST RITES`, the Hangar Shop clipped by the chat dock, the Transporter Pad's deploy list crushing itself, a doubled "House House" prefix. That's a genuinely good week for a UI test harness on a solo project.

**The gaps, in the tooling's own words, from this week's build logs:**

- **The sweep is not deterministic.** Hub NPCs roam, and a label's screen position can decide which button it pairs with — one run found a finding, the next found none, no code changed in between (`Bloom_Wars_Now_And_Next.md`, "Needs verifying"). A green run today proves nothing about tomorrow's run.
- **The viewport-vs-canvas blind spot is fixed as a rule, not proven as a catch.** The Hangar Shop clip happened because the sweep compared text position against the full 1074×640 canvas instead of a scene's own (narrower) camera viewport. That's fixed now — but the original bug could not be reproduced from the sweep's own save even with the fix (`fitWidth`) removed. So it's real that the sweep *now measures the right box*; it is not proven that it *would have caught this exact bug*.
- **It's a geometry lint, nothing else.** Its own build log says this plainly: "it only proves no text is squashed, buried, or off the edge" — nothing about colour, contrast, wording, or whether a screen is actually good.
- **Real screens nobody has looked at.** Two specific ones are named in Now & Next: the Workshop with all 5 Meks seated (positions came from real layout constants, never visually confirmed since 29 Aug — "two of them may read as crowded or too near a door in practice"), and the CO check-in gate's block message (verified by code inspection and a non-regression argument, never actually seen rendered).

**A new finding from this session, not previously flagged anywhere.** `Battle.ts` (line 664) sizes every mission's board dynamically: `tileSize = max(16, min(floor(700/mapWidth), floor(560/mapHeight)))`. Running that formula against the real width/height of all 72 live-campaign maps (`mapsAmaranth.ts`, `mapsHouseAmaranth.ts`) turns up six maps already rendering at 19–21px tiles today, on the shipped build, with no relayout involved at all:

| Map | Campaign | Size (tiles) | Current tile size |
|---|---|---|---|
| Falling Back to Meridian | Warden, Act III | 36×14 | 19px |
| The Reckoning | Warden, Act III | 34×16 | 20px |
| The Long Walk Back | Warden, Act II | 34×13 | 20px |
| Draven's Cut | Warden, Act II | 32×14 | 21px |
| The Last Convoy | Warden, Act III | 32×13 | 21px |
| The Last Ring | Warden, Act III | 32×17 | 21px |

None of these are archived Team One maps — all six are live Warden Company missions a player will actually reach. Nobody has screenshotted any of them; the sweep tool doesn't check tile legibility, only text geometry. Worth a direct look before EA on its own merits, independent of whatever happens with Track 4's relayout (which, worked out below, barely moves these numbers either way).

**Proposed actions, effort-labelled to match the feature-gap report's own convention:**

- **Screenshot the six maps above at real gameplay zoom, plus the Workshop (5 Meks) and the CO check-in block message** — **S**, an evening, no code changes, just look. Highest love-per-effort item in this whole document: it's free and it's the only way to know if any of this is actually a problem.
- **Fix the sweep's non-determinism** — pin NPC positions with a seeded save, or require N consecutive clean runs before trusting one — **M**.
- **Write a real regression test for the Hangar-Shop-clip *class* of bug** (a panel sized for one camera hosted inside a narrower one) — the project's own build log already names this as not done. **S**.

Nothing here is a design decision — it's "go look," then decide. Flagging it as a track rather than just doing it because six new screenshots plus whatever they turn up is Maxime's evening to spend, not mine to spend for him.

---

## Track 2 — Close the table-stakes polish gaps

The 1 Sep feature-gap report (`Bloom_Wars_First_Game_Dev_Feature_Gap_Report_1Sep2026.md`) is still the right document for this — it's specific, verified against the code at the time, and effort-labelled. It doesn't need replacing, it needs re-running against what's shipped in the four days since.

**Already shipped since 1 Sep (confirmed via `Bloom_Wars_History.md` and this session's own reads — no further action):** A1 combat forecast, A3 "end turn anyway?" prompt, A5 window scaling (plus the 2 Sep follow-up Display Size cap that fixed FIT's own overscale-on-4K problem), A8 Missiles wired into the action bar, C5 Esc/right-click cancel. **B5, the briefing room, also shipped** — 4 Sep, `MissionBriefingPanel.ts` — real mission name, real briefing text, a plain-English objective, and a composition-only passive scan, opened the moment you accept a brief from the CO. It's thinner than the report's original B5 ask (no CO portrait, no map thumbnail) but functionally live; it and B4 (portrait wiring, still unbuilt) are now the same job half-finished from two directions.

**Confirm, don't assume — one item genuinely unclear:** A7 asked for a version stamp *and* a one-click "Report a bug" button that copies a diagnostic blob. The version stamp shipped 1 Sep; nothing in the build logs since confirms the bug-report button specifically. Worth a two-minute check before crediting it done.

**Still open, in the report's own priority order, with what's changed:**

- **A4 — enemy-phase playback (M).** Still absent. Gets more valuable, not less, now that Track 4's mission chat plan exists — a player who can chat mid-mission and then watch the enemy respond wants to actually *see* that phase.
- **A6 — audio, "enough for EA" scope (M).** Still nothing. Unchanged ask: one ambient loop per zone, hit/miss/kill/click/win/loss stings, two volume sliders.
- **B2 — pilot service records (S/M).** Still absent from the roster card / Berths. The store queries the report cites already exist (`engine/statsStore.ts`).
- **B3 — the memorial (S).** Still absent. Natural home is the Vault, which is already built.
- **B4 — portrait wiring (M).** Still absent — all 15 portraits generated and sitting unused, per the report's own finding. Biggest visual upgrade for the least work, unchanged assessment.
- **B6 — name your company (S).** Still absent.
- **B7 — copy the mission log on Debrief (S).** Still absent.
- **B8 — "last words" on permanent loss (S, mostly content).** Still absent.
- **C1 — player-facing difficulty settings (M).** The report said explicitly not to build this until the Easy/Moderate/Hard bot tiers exist — **they now do**, seeded and replayable per Now & Next. This item just became buildable without guessing at numbers.
- **C2 — French string table, groundwork only (S).** Still absent; every week of new features makes it more expensive, unchanged from the report's own warning.

**Sequencing.** `Bloom_Wars_EA_Launch_Plan_31Aug2026.md` is the actual authority on the week grid, and it's already been detoured around more than once — I'm not asserting specific week numbers here without re-reading it fresh against today's date. What I'll say plainly: A4 and A6 are the two biggest remaining gaps in *feel* (a silent, instant enemy turn is the single most "unfinished" thing about the current build), and B2/B3/B4/B6/B7/B8 are all S/M items that could be batched into one or two sessions for a lot of "reviewers will screenshot this" payoff per the report's own B-section framing.

---

## Track 3 — Flag: the Hub.ts overlay architecture

**Not being built. This is the flag Foundation's own working rule asks for: "a structural rework — say so, name the tradeoff, let Maxime decide."**

**The evidence.** `Hub.ts` is 527KB, and grepping it turns up nine overlays — Workshop, Vault, History, Highlights, Hangar Shop, Peg Board, Poker, Darts, plus the newer Standings and Mission Briefing panels — each built with its own `this.add.container(0,0).setDepth(60)`, its own background rectangle sized off `ROOM_BOUNDS`, its own `[close — Esc]` button drawn by hand. Six of the nine still do all of that inline, as private methods on `Hub.ts` itself.

**This is the actual root cause behind two of this week's shipped bugs, not a stylistic complaint:**
- The Hangar Shop clip happened because that one overlay used `ShopPanel`'s native 900px card layout instead of the shared `ROOM_BOUNDS` box every *other* overlay already used — there was no single source of truth forcing consistency, so it silently drifted.
- The invisible-HUD bug (six readouts drawn at depth 0, buried by the deck floors drawn after them) was the same category of problem one layer up: no shared convention for "HUD elements live at this depth," so it had to be independently discovered and fixed with a new `HUB_HUD_DEPTH` constant.

**The project is already organically moving away from this pattern on its own** — the two newest UI pieces, `StandingsPanel.ts` and `MissionBriefingPanel.ts`, were both built as standalone classes outside `Hub.ts`, explicitly following `ShopPanel.ts`'s precedent rather than adding "a ninth overlay method to a file that is already 8,000 lines and 500 KB" (the Rec Room build log's own words). That's the direction to keep going, not a new idea.

**If Maxime ever says go, the shape I'd propose:** a small shared helper — `buildStandardOverlay(bounds)` or a light `HubOverlayBase` class — living in `engine/hubLayout.ts` (which already exists and holds other Hub geometry, so this isn't a new module, it's a new export from one that's already there). The six remaining inline overlays could migrate to it one at a time, each migration independently testable and shippable on its own, exactly like `fitWidth()` was added to `ShopPanel` this week without touching its other two callers.

**Why not now.** This is real scope against working code, seven and a half weeks from a launch date, with no player-facing symptom beyond the two bugs already fixed this week. The honest case for doing it is "the next overlay bug costs less to prevent than to fix" — that's a real argument, but it's Maxime's tradeoff to weigh, not mine to decide by just doing it.

---

## Track 4 — Battle HUD relayout, mission chat, and player notes

This is Maxime's own plan doc, `Bloom_Wars_Mission_Chat_Player_Notes_Battle_HUD_Relayout_Plan_v1.md` (now saved to the project, with this session's findings added inline). It splits into four workstreams — colon-command notes, a pure `battleLayout.ts` module, the actual HUD relayout, and mission chat wired through the existing social-verb system — each shippable on its own. Full detail lives there; this is the pointer plus what changed.

**The three blocking facts it asked "Claude Code" to confirm before any coordinate got written — answered directly against the live repo this session:**

- **1a, tile size and viewport.** The plan assumed a fixed ~45px tile. That's wrong for the shipped game: `Battle.ts` computes it per-mission, `tileSize = max(16, min(floor(700/mapWidth), floor(560/mapHeight)))`, board origin at `(16, 60)`. **No real map in the game renders at 45px** — see Track 1's table above; the biggest maps already sit at 19–21px today.
- **1b, the largest map, both campaigns.** Checked all 72 live maps directly: **max width is 36 tiles** (`map_amaranth_falling_back_to_meridian`), **max height is 19 tiles** (`map_amaranth_tunnel_rats`) — different maps, so `battleLayout.ts`'s own test suite (§3c of the plan) is right to loop over every real map rather than hand-picking a worst case.
- **1c, a data-layer flag distinguishing human-crewed hostiles from Bloom.** Turns out this doesn't need adding — it already exists structurally. `data/types.ts` defines `BloomArchetype` and `HostileMechArchetype` as two entirely separate interfaces (different fields: perception/intelligence/movementType vs. path/tier), not one hostile type with a flag. A mission-chat router can gate on which archetype pool a hostile resolves against rather than hardcoding an id list — which is exactly what the plan's own §1c asked for, just already true rather than needing to be built. One thing still worth a direct check when this workstream actually starts: confirming the *live* `Unit` instance on the board (not just the static archetype table) carries something that lets the router tell which pool it came from at runtime.

**The one real correction to the plan itself, worth flagging clearly since it changes the risk picture:** §4a's illustrative math ("684px for the board... roughly 34px tiles, down from 45") was built on the wrong current-tile assumption. Recomputing every map at the proposed 684px-wide viewport (both columns open) against the real 700px-wide one it replaces: **the numbers barely move.** Falling Back to Meridian stays at 19px either way; nothing in the game crosses the 16px floor under the proposed layout. That's good news for the relayout's feasibility — but it also means the six maps in Track 1's table are *already* this small today, so "the relayout makes the board smaller" undersells the real, pre-existing question, which is whether 19–21px was ever fine to begin with. Track 1's screenshot pass answers that; this workstream shouldn't get blamed for a problem it mostly didn't create.

**Scale, said plainly.** This is the single largest scope item across all four tracks in this document — a new persisted player-notes feature, a new mid-mission social system, and a genuine structural extraction of `Battle.ts`'s layout math (the same "pull shared geometry out of the scene file" move Track 3 recommends for `Hub.ts`, applied to a different scene — worth building both with the same lessons in mind, not necessarily in the same session). Workstream 1 (the colon-command namespace and `:notes`) is small, isolated, and could land anytime without touching Battle at all. Workstreams 2 through 4 are real weeks against a launch seven and a half weeks out — that call is explicitly left open in the plan's own §9, and stays open here.

---

## Where this leaves things

| Track | Status | Size | Blocking on |
|---|---|---|---|
| 1 — Harden the safety net | Ready to start | S/M | Nothing — screenshots first, everything else follows from what they show |
| 2 — Table-stakes polish | Ready to start | Mostly S, two M (A4, A6) | Nothing new; A4/A6 are the two biggest remaining feel gaps |
| 3 — Hub.ts overlay refactor | Flagged only | L | Maxime's go/no-go — real scope, no urgent player-facing case yet |
| 4 — Battle relayout / mission chat / notes | Unblocked (facts answered) | L, Workstream 1 is S | Maxime's go/no-go on Workstreams 2–4; Workstream 1 can start free-standing |

**Docs this plan touches:** `Bloom_Wars_Now_And_Next.md` gets a one-line pointer added under "On the table to build." `Bloom_Wars_Mission_Chat_Player_Notes_Battle_HUD_Relayout_Plan_v1.md` gets this session's findings added inline (marked as this session's own verification, not Maxime's decision, per Foundation's attribution rule). Nothing here touches the GDD, Data Pack, or Build Brief directly — Track 4's own plan already correctly flags that its eventual build will (§8 of that doc).
