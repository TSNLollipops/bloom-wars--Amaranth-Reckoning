# NPC Conversation Lock — Fix Proposal, 5 Sep 2026

**Status: proposal, NOT built.** Written by a different session than the one currently building the game — for that session to pick up, verify against the live file, and implement. Nothing in this doc has touched `Hub.ts`.

Maxime, verbatim: *"right now, when ant talk to each other they keep roaming replying but not staying to have a convo, so if one talk ahvve the guy stopp and converse with the pilot who talked."*

## 1. Root cause — verified against the actual file, not memory

Read the live `Hub.ts` directly off Maxime's machine (537,800 bytes, mtime 5 Sep 2026 18:15 UTC) rather than trusting the build-log summaries, per this project's own standing discipline. Confirmed:

- `updateNpcEncounters()` (`Hub.ts` ~L8789) only lets two ants strike up an encounter when **both** are already idle (`targetX === undefined`) and within `ENCOUNTER_RADIUS` (90px, L539) of each other.
- For the `"talk"` kind, `runNpcEncounter()` (~L8987) shows npcA's line immediately, then npcB's reply `NPC_REPLY_DELAY_MS` (1800ms, L626) later via `this.time.delayedCall`. `runAngerBlowup()` (~L8871) stages the same shape for Anger Blowup. The other encounter kinds (pegBoard/poker/fletchers/Ask Out) still show a single narrated bubble on npcA only — no second line, no reply.
- `showBubble()` (~L9949) sets `npc.bubbleUntil = now + Math.min(6000, 2600 + line.length * 30)` — each bubble stays up roughly 2.6–6s depending on line length.
- **The gap:** neither `runNpcEncounter` nor `runAngerBlowup` marks either NPC as "busy" for the duration of the exchange. `updateNpcRoaming()` (~L8510) runs every frame; its only early-exit checks are `targetX !== undefined`, `nextRoamAt` cooldown, `mustered`, `travelTargetRoom`, `homeRoom` — nothing about being mid-conversation. Because an encounter can only fire once an NPC has already been idle long enough to be encounter-eligible, `nextRoamAt` is often already close to elapsing (or already has), so `updateNpcRoaming` can hand that NPC a fresh walk target on the very next tick — before npcB's reply bubble even appears, in the worst case. Two systems (ambient chatter, ambient wandering) that never learned about each other.

**`tryBoredomSpar()` was not read in this pass** — it's the third "settled pair, something happens" branch in `updateNpcEncounters` (checked before `runNpcEncounter`, same shape as `tryAngerBlowup`). Confirm whether it stages its own bubble sequence before assuming it needs the same fix — don't assume from this doc alone.

## 2. Fix A — stop roaming mid-conversation (the actual bug report)

Small, additive, same pattern as the existing guards already in `updateNpcRoaming` — not a rework.

1. Add an optional field to the `HubNpc` type, alongside `nextRoamAt`/`nextEncounterAt`/`bubbleUntil`: `engagedUntil?: number`.
2. In `runNpcEncounter()`, right after the bubble-staging block (~L9096–9108), set `npcA.engagedUntil = npcB.engagedUntil = now + NPC_REPLY_DELAY_MS + 6000` for both participants. Using the flat `6000` (the hard cap on any single bubble's duration) instead of threading the real line length back out of the `delayedCall` closure is a deliberate simplification — worst case an ant stands still up to ~1-2s longer than strictly necessary after a short line, which is harmless (arguably reads as "lingered a beat after talking," not a bug). Apply the same two-line set in `runAngerBlowup()` (~L8894–8899) at its own bubble-staging point. Decide the equivalent for `tryBoredomSpar()` once its bubble shape is confirmed per §1.
3. In `updateNpcRoaming()`, add one more early-continue near the top, alongside the existing `targetX`/`nextRoamAt` checks (~L8511–8513): `if (npc.engagedUntil !== undefined && now < npc.engagedUntil) continue;`
4. In `updateNpcEncounters()`, add the same check to both the outer loop's npcA guard (~L8806) and the inner loop's npcB guard (~L8819) — otherwise a third ant could walk up and start a *second* encounter with npcA while npcA is still mid-exchange with npcB.

That's the whole fix for "not staying to have a convo." No new state machine, no rework of roaming or encounters — one field, one write site (two, once Boredom Spar is confirmed), two read sites.

## 3. Fix B — face each other (the visual nicety on top)

Separate and smaller in spirit, but **not yet scoped for real** — this pass didn't check whether NPC sprites track a facing direction at all. Before treating this as "just flip a sprite":

- Grep `Hub.ts` for `flipX` / `facing` / anything driving sprite orientation off movement direction in `updateNpcMovement`. Ordinary walk animation almost certainly already flips the sprite based on horizontal travel direction — if so, this fix is just: at the moment an encounter fires, explicitly set each NPC's facing toward the other's `x` position (override whatever direction they last walked in), rather than leaving them facing wherever they happened to stop.
- If no facing/flip concept exists on these sprites at all (fully symmetric art, nothing to flip), this is a bigger ask than it looks — flag it back to Maxime rather than building it silently, per the project's own scope-flagging rule.

Recommend building Fix A first and shipping it standalone — it's the actual bug report and it's low-risk. Fix B is worth a quick feasibility check before committing to it as "small."

## 4. Verification, once built

Standard gate per `Bloom_Wars_Foundation.md`: `tsc --noEmit`, `eslint .`, `lint-cast-collision`, full `vitest` suite, `vite build`. No existing test covers `updateNpcRoaming`/`updateNpcEncounters`'s interaction with a busy/engaged NPC — worth a real unit test for the new `engagedUntil` guard specifically (inject a fake elapsed `now`, confirm a roaming ant with `engagedUntil` in the future doesn't get a new `targetX`), same rigor the Greeting/Farewell Broadcast fix got. Live-verify by watching two ants actually hold still through a full staged exchange in a real Hub session — this has never been watched on screen, only reasoned about from the code.
