# Bloom Wars — the whole map, one page to start from (v1)

*26 August 2026. You asked for an overall plan up to completion, because even working one thing at a time you're feeling scattered. This is that — one document that shows the whole shape, so any single task you're doing has a visible place to sit. It doesn't replace the detailed docs; it points at them. Read this when you've lost the thread, not instead of the docs themselves.*

## Where things stand, in one look

| Stage | Status | What it is |
|---|---|---|
| 0. Foundation | **DONE** | Engine, class triangle, permadeath, the full 36-mission campaign. Shipped and sim-tuned. |
| 1. The Hub / social layer | **IN PROGRESS — you're on this now** | The walkable ship, NPCs, typed chat, Favorability. Partly built, partly sandboxed, partly still design. |
| 2. Mek Workshop + weapons | **DESIGNED, not built** | This session's new plan — a room for Meks, an expanded weapon/module list. |
| 3. Onboarding & polish | **NOT STARTED** | Tutorial, small UI fixes. Cheapest lever for a cold audience, per the playtest review. |
| 4. Real art | **GATED** | Needs an artist. No timeline, and that's fine — it's not blocking anything above it. |
| 5. Post-completion / stretch | **PARKED ON PURPOSE** | Gladiator mode, mod kit, TTRPG mode, monetization. Big, real, deliberately later. |

Everything below expands one row at a time.

## Stage 0 — Foundation. Done.

The core tactics engine, the class triangle (Tank beats Meeps, Meeps beats Reeps, Reeps beats Tank — closes clean), real permadeath, the chassis/movement layer, Collapse for the Bloom, Severance. On top of that, all 36 missions of The Amaranth Reckoning — Act I through the finale — built, sim-tuned, and playtested clean (I played eleven of them myself last week; zero console errors across the whole run). This is the part of the project that's actually finished. Nothing here is waiting on a decision from you.

One small thing sitting in the Master Index's own priority queue, not urgent: `commanderDown.test.ts` is flaky — passes clean most runs, fails 1–2 of 7 others — and it's already root-caused (the test's rigged attack doesn't stub the Meeps dodge roll, so Rourke occasionally dodges a hit that was supposed to kill her, and the test fails). Your own call on record is to leave it queued until you're back in the battle code. Nothing to do here unless you want to.

## Stage 1 — The Hub. In progress. This is where you actually are.

This is the biggest, most active thing in the project right now, and it's happening on your machine, not mine — I'm staying hands-off it per what we agreed. Current state, cross-checked against the Walkable Hub Build Plan and the Antfarm Carrier Hub design doc:

**Built:** the Rec Room with a few NPCs and a sound-range Talk verb (Phase 1). Six more rooms and twelve connecting doors — Hangar Deck, Workshop, Vault, Berths, CIC/Bridge, a grotto (Phase 2, piece 1). Minimal NPC movement, muster-only (piece 2). Real typed chat, with `chatIntent.ts` reading what you type and `detectUnbuiltVerbLine` catching verbs you've named but haven't built yet — poker, peg, drink, spar (piece 3).

**Not built yet:** wiring the Hub into actual mission launch (piece 4) — right now Boot still routes to MapSelect first, so the Hub isn't the front door yet. And the full version of Phase 3, NPCs roaming and forming cliques on their own rather than just mustering.

**Built, but only in the sandbox (`pilot_creator.html`), not the live game yet:** this is the big one. The Favorability system — a DAO-style rep bar per NPC — plus three Rec Room minigames (Poker, Fletchers, the peg game), a real drunk debuff, toxic pairs, gossip, save/assist/rescue tallies with roster badges, Legend status, Command Vacuum when a Lance Lead is lost, lance assignment, and a fast-forwarded sim tool that steps through all 36 missions. That's a genuinely large amount of finished design and working logic sitting in a sandbox file, waiting to be ported into the real game. Worth naming plainly: **this sandbox work already *is* most of what the old Spitball roadmap called "Phase 1 — the social layer."** The two plans converged without either of us planning it that way — good news, not a conflict.

One real bug flagged and not yet fixed, also sandbox-side: Rourke's permadeath exemption currently redirects her death to her partner. Per your own correction, it should be a true no-op — mission fails, back to briefing, nothing resolved, no redirect. Lives in `triggerLoss()` and `ensTriggerLoss()`.

Nothing for me to do here unless you ask — this section exists so you can see it laid out, not so I go touch it.

## Stage 2 — Mek Workshop and weapons. Designed this session, not built.

The new plan from this week: a per-lance Workshop room (XCOM Engineering-style) where each lance's Meks live and work, framed as real partners to their pilots rather than a gear slot — and a much larger weapon/module list per class, including the Missiles-for-Reeps you already added. Full detail, including the open questions (can a Mek be lost, one Workshop per lance or per pair, instant purchase vs. a build queue) is in `Bloom_Wars_Mek_Workshop_And_Weapon_Progression_v1.md`. Not started in code. Its one real dependency on Stage 1: if Workshop purchases end up costing in-fiction time rather than resolving instantly, that needs the calendar system that's also queued in Stage 1's roadmap — worth deciding those two together when you get here, not separately.

## Stage 3 — Onboarding and polish. Not started.

The cheapest, highest-leverage thing left, per the playthrough I did last week: there is no tutorial at all right now, and the systems underneath are already good enough to hold a genre-savvy player with zero hand-holding — a minimal three-turn hint layer is most of the gap between "prototype" and "something you can hand a stranger." Alongside it: the mission-title clip bug on every battle screen (trivial, one line), and a soft nudge for a stalled `eliminate_all` mission that can currently run forever with no signal. None of this is scheduled — it's next in line after Stage 1 and 2, not before them.

## Stage 4 — Real art. Gated, not scheduled.

Placeholder geometric shapes stay until there's an artist. This is the single highest-impact lever in the whole project — half of what holds the prototype back from reading as a finished product is presentation, not systems — but it's also the most gated thing here, and there's no artist on this yet. Nothing to plan until that changes.

## Stage 5 — Post-completion, parked on purpose

The big swings, kept out of the way so they don't compete with what's actually next: Gladiator mode / company-scale battles, a character mod kit and map editor, a lightweight TTRPG mode reusing the map/grid renderer, and skins-as-monetization once there's a real storefront. All of these are real, designed-in-some-detail ideas, not throwaway lines — they're just deliberately sequenced last.

One of them is worth a direct flag, because it's a live decision now, not a someday: **Gladiator mode's own stated gate — "I'll get to it when there are more missions done" — is now technically met. All 36 missions are done.** That doesn't mean it's ready to build; there's real unresolved design underneath it (a full ~20-pilot company on each side risks turning into an RTS rather than this game's tactics loop, the Carrier CO/Legion CO/Company CO rank idea conflicts with the existing personal rank ladder, and the ship-layer combat itself hasn't been designed past "Sword of the Stars-style, order-based"). But the condition you set for yourself has actually fired, so it felt dishonest not to say so. Your call entirely on whether that means anything right now.

## Two small honest corrections, while I had the full picture in front of me

First: the campaign review I gave you last week states the class triangle backwards — it says "Meeps beat Tank, Tank beats Reeps, Reeps beat Meeps," and the actual locked direction (confirmed against the Master Index, the GDD, and the combat sim's own counterattack rule) is the reverse: **Tank beats Meeps, Meeps beats Reeps, Reeps beats Tank.** I caught this while cross-checking sources for this doc and fixed the line directly in the review rather than leaving it wrong and just telling you — it was an unambiguous transcription error, not a judgment call.

Second, smaller: the project's standing instructions point at `combat_sim.py` and `maps.py` as the source of truth for balance and maps. That was true for the original 4-mission slice; the Master Index itself already documents that the live Amaranth campaign moved to `npm run sim` (`src/sim/run.ts`) and its own map generators instead. The Master Index has this right — it's only the project instructions text (outside my reach to edit) that's now stale on this one point. Worth a quick update whenever you're touching project settings, so a future session doesn't get pointed at the wrong tool.

## What I didn't try to do here

I didn't re-sequence Stage 1 for you — you're mid-build on it and know your own state better than a doc I wrote can. I didn't touch anything on your machine to make this. And I didn't fold the old Spitball roadmap's exact phase-by-phase content back in verbatim — it's real and still points to the right things, but as this doc shows, some of it has already been overtaken by what you've since built. If you want, I can go through that roadmap doc specifically and mark up which of its seventeen ideas are now done, in progress, or superseded, since two failed file deliveries mean you likely never actually saw it in the first place.
