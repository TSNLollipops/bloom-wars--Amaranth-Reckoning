# THE BLOOM WARS — Selling & Launch Plan v1

*Drafted 27 Aug 2026, at Maxime's direct request: "will I even be able to sell the game?" followed by "I have a paypal, youll walk me tru the sell part? can you start making a plan." Written after checking current platform facts live rather than from memory or assumption — see Sources at the end. Maxime is new to game dev and explicitly asked for a plan built from what he actually needs, not from his own first idea (PayPal + itch.io as a direct browser sale) — that idea turned out to have a real technical wrinkle, corrected below rather than quietly worked around. Same day, a business-philosophy note added — see below, after Recommended order.*

## The one correction worth stating plainly up front

The working assumption two turns ago in this same conversation was that itch.io could sell the *browser-playable* build directly, with PayPal handling payment. That's not accurate, checked live against itch.io's own docs and forum: **itch.io cannot put a hard paywall in front of a game that's played embedded in the browser (an "HTML5" project).** Browser-embedded games on itch.io are free-to-play by design; the only monetization option for that format is optional donations/tips, not a required purchase. Paid access on itch.io requires the "Downloadable" project kind — an actual file the buyer downloads and owns.

That one fact reshapes the whole plan: the real blocker to selling Bloom Wars isn't legal, and it isn't PayPal — it's that **the game currently has no form that isn't "open a browser tab."** There's no installable file to sell. Fixing that is Phase 1 below, and it's the same fix every path in this plan depends on.

## Phase 0 — the actual shape of the problem

Selling anything needs three separate things: a way to take money, something to hand over in exchange, and a place people find it and buy it. Maxime already has the first one (PayPal). The third one is easy (itch.io, and later Steam). **The second one is the real gap today** — the project has a fully playable 36-mission campaign, but it only exists as a live web page, not as a thing a customer can purchase and own a copy of.

## Phase 1 — Package the game as a real downloadable build (the unavoidable step)

**What this means in plain terms:** right now Bloom Wars runs by opening a browser and pointing it at the built web files (Vite + Phaser). To sell it as a file, it needs to be wrapped into a real Windows app — something with an icon a customer double-clicks, no browser required. **Electron** is the standard tool for this: it takes an existing web build (exactly what Vite already produces) and packages it into a real desktop executable, using the same web code underneath. This is already the tool this project's own docs named for "Steam port later" — nothing new is being invented, this plan is just moving that step earlier because it turns out to be needed for *any* real sale, not just Steam specifically.

**Flagging this as real scope, not a small tweak, per the project's own rule:** this is a new build pipeline — a second way the game gets produced, alongside the existing `npm run build` web output — not a gameplay or content change. It needs someone to actually wire up Electron (or its packaging tool, `electron-builder`), test that the wrapped game launches and plays identically to the browser version, and produce an installer file. Bounded work, but real work, and worth scoping as its own build task before assuming it's a five-minute step.

**One honest wrinkle worth knowing about now, not after the fact:** an Electron `.exe` that isn't code-signed will show Windows' "Unknown publisher" warning screen on first launch. It doesn't stop the game from running — the customer clicks through it — but it looks unpolished for a paid product. A code-signing certificate (roughly $100–400/year from a certificate authority) removes that warning. Not required to start selling; worth doing once there's real revenue to justify it. (Discussed live with Maxime same day — the honest takeaway: unsigned is completely fine to launch with, it's a "one extra click for early buyers" cost, and it matters far less on Steam specifically than on a direct itch.io download, since Steam's own client doesn't trigger the same warning.)

## Phase 2 — First real sale: itch.io, using PayPal directly

This is the fast, cheap, real path — live within days of having a packaged build, not weeks.

- **No listing fee.** Free to create a project page.
- **PayPal works directly.** itch.io's "Direct to you" payment setup connects Maxime's existing PayPal (and/or Stripe) account — money goes straight there, itch.io never holds it. (The alternative, itch.io's own "Payouts" system, also supports PayPal, but adds a tax-ID verification step, a $3 verification fee, a $5 minimum before withdrawal, and a 7-day fraud-prevention hold on new revenue. "Direct to you" skips all of that.)
- **He sets his own price and his own cut.** itch.io's revenue-share is a slider Maxime controls, 0–100% of each sale going to itch.io — the default is 10%, and it's entirely his call.
- **Keep the free browser build as the public demo.** It already exists, costs nothing extra, and matches the audience the project's own Campaign Playtest Review already identified (people who judge tactics games by systems before art, exactly the itch.io prototype crowd). Sell the packaged Electron build as "the full campaign," with the browser version doing the job a Steam demo or trailer would do.
- **Housekeeping before the first sale, not after:** upgrade the personal PayPal account to a **PayPal Business account** — it's free and takes a few minutes, and personal PayPal accounts aren't really built for merchant transactions; suddenly receiving a string of "goods and services" payments on a personal account can get it flagged or limited. Also worth starting a simple running log of what sells and for how much — Canadian tax rules require reporting income regardless of platform or amount, and that's much easier to do as sales happen than reconstructed later. (Not tax or legal advice — worth an actual accountant conversation once real sales start, not before.)

## Phase 3 — Steam, once there's something worth putting on a store page

Steam is the bigger, slower, more "real distribution" move — worth doing, but later, and it has one hard requirement that changes the plan: **Steam does not pay via PayPal at all.** Valve pays developers only by direct bank transfer (ACH within the US, SWIFT wire outside it), to an account in the developer's own name. That's a real, separate thing to set up — a personal bank account that can receive an incoming wire transfer is normally fine (most banks support this), but it's worth confirming with his bank rather than assuming, since PayPal being ready doesn't mean Steam payouts are.

The rest of the checklist: a one-time **$100 Steam Direct fee** (Valve automatically refunds it once the game earns $1,000 in revenue — it's a filter against spam listings, not a real cost for a game expected to sell at all), tax paperwork similar to any other freelance income, a free **IARC questionnaire** (an automated age-rating form every Steam game fills out — no cost, no review board), an actual store page (trailer, screenshots, description — the point where the project's current placeholder-geometric-shape art genuinely becomes a liability, since Steam shoppers judge a page at a glance in a way the itch.io audience doesn't), and uploading the same Electron build through Valve's own tool, **SteamPipe**. Realistic timeline from starting the process to launch day is **4–6 weeks**, mostly waiting periods (a mandatory "Coming Soon" visibility window, a review pass measured in business days) rather than active work.

**The honest sequencing call: do this after the art pass, not before.** The game itself — 36 missions, tutorial, permadeath — is genuinely ready. The store page isn't, yet, and Steam is the platform where that gap actually costs sales. itch.io doesn't have that problem the same way.

## What's deliberately not on this plan: a custom payment system

The project's own earlier notes (Spitball Ideas, 26 Aug) already looked at building direct in-house payments — accounts, a backend, a server-side check for who owns what — and correctly set it aside: it's a large side-project that duplicates what itch.io and Steam already give away for free or near-free, for a game that currently stores its whole save state as an unencrypted JSON blob in the browser. Nothing about this plan changes that call. Both real paths (itch.io, Steam) let Maxime skip building any of that.

## Recommended order

1. Package the build in Electron (Phase 1) — the one thing every other step depends on.
2. Set up PayPal Business + a sales log (5 minutes, do it before, not after, the first sale).
3. Launch the paid downloadable on itch.io, keeping the browser build as the free demo (Phase 2) — first real money, fastest path, lowest stakes.
4. Keep building/polishing in parallel (the art pass already on the After-Early-Access list).
5. Once the store page would actually stop a stranger scrolling past it, start the Steam process (Phase 3).

## Business philosophy — stated 27 Aug 2026

Maxime, right after this plan first went up, unprompted: **"I wont ever charge more than 5buck. or 20. if it go big, cool. but I want more a comunity as I explore the qiraki universe. and make mech battle games."** Three real decisions in that pair of lines, both his own words, neither hedged:

**Price ceiling: $5–$20, whatever it ends up being.** Not a placeholder — an intentional cap. This fits itch.io's own culture well: "pay what you want with a minimum" is the norm there, not a fixed premium price, and itch.io's own numbers back this up — roughly 30% of all money spent on the platform is voluntary payment above the stated minimum. A ~$5 minimum with a suggested price somewhere in the $10–15 range and "pay what you want" enabled above that fits both the stated cap and actual buyer behavior on that platform. Exact number still his call when Phase 2 gets built.

**The real goal is community, not revenue — "if it go big, cool" is the ceiling on ambition here, not the target.** That reframes Phase 2 slightly: itch.io's real value for Maxime isn't just "a place that can take PayPal," it's also where the audience already identified in the Campaign Playtest Review actually lives, and itch.io ships free tools built for exactly this — public devlogs (a followable update feed on a game's own page) and community posts. This project already produces exactly the kind of detailed build narration a devlog wants, just not public-facing yet. Worth treating the itch.io page as a community seed, not only a checkout page, once it's built — and worth considering posting devlogs even before the paid launch, since the free browser demo could start building a following now rather than waiting for Phase 2 to be fully ready.

**The explicit tie to Qiraki is worth taking at face value, not just filed as flavor.** "As I explore the Qiraki universe" lines up directly with the Bloom Wars Master Index's own 26 Aug cross-project policy — both properties are meant to connect as canon eventually and are both going to be shared publicly, deliberately, per Maxime's own words there too ("im afterall really gonna share the book. and the game. for my own sense of completeness"). That makes the game a real on-ramp into the book, not just a separate product that happens to share a universe. Nothing to build from this today — it's a marketing/community angle, not a code or design change, and it stays fully outside both master indexes' actual content per the naming lock — but worth keeping in view whenever devlogs, store copy, or community posts get written, since "come for the tactics game, stay for the universe" is a real, low-cost advantage most solo devs don't have.

**"and make mech battle games" — read as Bloom Wars being the first of a genre, not a one-off.** Said in the same breath as the community goal, not as a separate thought. Bloom Wars already has a real mech identity (the Meks system, chassis/pilot progression) even though the game reads as a tactics game first. Worth treating as a possible community/branding angle later — an indie dev known for mech tactics games set in one shared universe is a sharper, more followable identity than "one guy, one itch.io page" — but this is a positioning idea, not a scoped decision, and nothing about Bloom Wars' own build changes because of it.

## Open questions for Maxime

- Exact price within the stated $5–$20 range, and whether to use itch.io's "pay what you want" (minimum + suggested price) or a flat price — his call when Phase 2 gets built.
- Whether the itch.io release should be the full 36-mission campaign or an Early-Access-flavored slice — ties into the existing Early Access Scope Triage doc, not re-litigated here.
- Timing: start Phase 1 (Electron packaging) now, or hold until after a specific milestone (e.g. the art pass)?
- Whether a dedicated community space (Discord or similar) gets built alongside the itch.io launch or after — not raised by Maxime yet, flagged here since "community" was his own stated priority.
- Whether "mech battle games" (plural) means Bloom Wars is meant to be the first of a series/genre identity, or just a passing aside — worth a direct check whenever the branding/community question actually comes up for real.

## Sources (checked live, 27 Aug 2026 — not from memory)

- [Accepting Payments and Getting Paid — itch.io](https://itch.io/docs/creators/payments)
- [Pricing — itch.io](https://itch.io/docs/creators/pricing)
- [Uploading HTML5 games — itch.io](https://itch.io/docs/creators/html5)
- [Controlling who can access your project — itch.io](https://itch.io/docs/creators/access-control)
- [How buying works — itch.io](https://itch.io/docs/creators/how-buying-works)
- [Introducing open revenue sharing — itch.io](https://itch.io/updates/introducing-open-revenue-sharing)
- ["Can I Lock Browser-Based HTML Game Behind Paywall?" — itch.io forum](https://itch.io/t/6277781/can-i-lock-browser-based-html-game-behind-paywall)
- [Steam Direct 2026: Complete Publishing Walkthrough — egmatic](https://egmatic.com/blog/steam-direct-2026-publishing-walkthrough)
- [Reporting and Payments FAQ — Steamworks Documentation](https://partner.steamgames.com/doc/finance/payments_salesreporting/faq)
