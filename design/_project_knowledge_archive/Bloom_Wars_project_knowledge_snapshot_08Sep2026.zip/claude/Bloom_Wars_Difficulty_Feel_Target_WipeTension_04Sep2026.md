# Design Note — The Actual Difficulty Target: Constant Wipe Tension, 4 Sep 2026

**Maxime, verbatim, unprompted, right after this session's balance-philosophy correction:** *"im prolly going to have you add many more spawn to all mission by the time ea happen. because if I dont lose more than 5 unit late game its too easy. early, i should have restock happen at least once per mission."* Followed immediately by the line that actually pins down what this means: *"i should genuinely feel like im about to wipe at any moment or im not hitting the same itch as xcom."*

**Not a build task yet — "by the time ea happen," his own words.** Recorded here so it isn't lost before then, and so a future session reads the actual target (the felt tension) rather than just the numbers, which are a proxy for it.

## The target, as stated

- **The feeling, first:** playing should carry a constant sense that a full-squad wipe is one bad turn away — the specific XCOM itch. This is the real target; the numbers below are how to check for it, not the thing itself.
- **Late game:** if the player isn't losing more than 5 units, the mission (or the campaign's late stretch generally) is too easy.
- **Early game:** the player should be forced into at least one restock event per mission — not cruise through clean.
- **The lever he's already named:** more spawns, campaign-wide, added deliberately once EA's other work is further along. Not a rebalance of existing waves — added enemy volume.

## What "lose" and "restock" need pinning down before this becomes buildable

Neither term is fully unambiguous yet, and it's worth resolving before spawn counts actually get touched rather than guessing:

- **"Lose 5 units"** — this campaign already tracks two different things per run: **downed** (temporarily out, recoverable by a Munti mid-mission or by Debrief) and **permanently lost** (real permadeath). Losing 5 permanently in a single mission would gut most rosters outright (Act II's own default squad size is 10) — that reads as more likely to mean 5 *downed* in a mission, the XCOM "wounded and scared" feeling, not 5 permanent deaths in one sitting. Worth a one-line confirm whenever this becomes an actual build task, not assumed either way here.
- **"Restock"** — the term is used two ways in the project's own docs: loosely, for whatever brings a downed pilot back into a fight; and specifically, for **Beacon Control** (`Bloom_Wars_Beacon_Restock_Economy_v1.md`, 2 Sep) — a fully-designed but **entirely unbuilt** mid-mission revive mechanic (place beacons, spend a Fabricator crate + a Restock Room charge to pull back someone downed earlier that same mission). If "restock happening once per mission early" means Beacon Control specifically, that mechanic needs to actually ship first — it's still design-only. If it means something already live (a Munti reaching a downed ally in time), that's a spawn/timing tuning question only, no new system required. Worth knowing which one this is before scoping the spawn-count work.

## Why this isn't starting from zero

Already have real data that speaks to the "late game = near-wipe" bar, from today's own eliminate_all re-check (`Bloom_Wars_Build_Log_Addendum_EAPlanBalanceReality_ActIInversion_04Sep2026.md`), even though that pass was reading the numbers under a different (now-retired) framing. On Hard tier, n=100 spot-checks on three Act III missions already sit at or near a 5-downed-per-run bar without anyone deliberately tuning toward it:

- Mission 25, "The Reckoning": 5.46 downed/run
- Mission 28, "Marrow's Reckoning": 5.89 downed/run
- Mission 30, "Ashes of the Second Ring": 3.25 downed/run

Late Act III is already trending toward the feeling being described, at least on Hard, at least on downed-count. Early Act I (Missions 1-13ish) reads much safer by comparison (most sub-1 downed/run on Hard) — which lines up with wanting Act I to still force at least one restock, not already be there. Not treating this as proof of anything precise (n=100, not the n≥500 floor, and downed-per-run isn't the same axis as "genuinely feels like a wipe is coming") — just recorded so the eventual spawn-adding pass starts from "Act III's shape is roughly right, Act I needs the real work" rather than a blank slate.

## What this changes, connected to today's earlier correction

This is the human-facing half of what `Bloom_Wars_Build_Log_Addendum_BalancePhilosophyCorrection_04Sep2026.md` established for the AI-sim half. That doc retired "AI win rate should hit target bands" in favor of "AI sim exists to catch cheese." This note gives the actual replacement difficulty target, in Maxime's own words: not a win/loss percentage at all, downed/lost pilot counts and the felt tension of an imminent wipe. Worth reading together, and worth using this note's language (not the retired target-band table) if `Bloom_Wars_Player_AI_Difficulty_Tiers_Plan_v1.md` or the EA plan's balance sections get touched again before this actually gets built.
