# The Bloom Wars — Naming Lock Policy Update, 2 Sep 2026

*Written the same day Maxime said, in this conversation, right after the Coalition lore codex entry work closed out: **"we are going full crossover. old rule is stale."** This is the record of what that actually changes, what it doesn't, and why — superseding the "Naming lock" and "Cross-project references" sections of `claude/Bloom_Wars_Master_Index.md` as they stood before today. That doc's own Naming Lock/Cross-Project References sections should be replaced with the text at the bottom of this doc the next time that index gets a routine sync pass — not done in this same pass, since editing that doc requires reproducing its entire ~30,000-word body, and this addendum is the safer, immediately-durable record in the meantime, matching this project's own standing convention of dated addenda that the index later syncs against.*

## What Maxime actually said, and what it's answering

Right after locking "the Coalition of Enlightened" as the wider civilization's formal name for the new World-category codex entry (see `Bloom_Wars_Coalition_Lore_Codex_Entry_Plan_v1.md`), and after that entry's own careful, deliberately-hedged escalation structure (formal name surfaces exactly once, at Mission 36 contact, otherwise "the Coalition") — Maxime's next message was blunt: **"we are going full crossover. old rule is stale."**

Read plainly: the caution built into that entry, and into this project's whole naming-lock discipline going back to the start, is no longer the policy he wants. He's the author of both properties; this is his call to make, not a boundary this session should defend on his behalf.

## What the "old rule" actually was — two different things, not one

The naming lock was never a single rule. It was two, and they were never equivalent in kind:

1. **The book's own military-arc name — "The Synker Wars" / "Synker."** This was pure IP-identity separation. Nothing about it protects a reader from anything; it's a branding line, kept apart so the two properties didn't read as one thing before Maxime chose otherwise.
2. **The novel's true-name reveal — the enemy's real name.** Defined in the Build Brief, deliberately never written in any doc this session has ever been shown, enforced by a build-failing lint rule (`tools/lint-spoiler.mjs`) reading from a gitignored local env var. This one isn't branding. It's a genuine plot twist in the book itself — the reveal exists to land on the book's own readers at the right moment, in the book. Handing it to a game player, in a menu, on Mission 1, is spoiling Maxime's own novel through a cheaper, faster medium than the one he wrote it for.

## What changes, and what doesn't

**Changes, effective today:** term (1) above — the branding separation — is repealed. "The Synker Wars"/"Synker" is now fair game in Bloom Wars code, docs, filenames, and UI strings, the same standing every other Qiraki term already has in this project (Coalition of Enlightened, the five factions, Warrant/the Hand, Hiopi/Osnian/Carabil). "Full crossover, old rule is stale" is Maxime's own call as sole author of both properties, and this project's whole 26 Aug policy direction (deliberate shared-universe borrowing as the standing default) was already heading exactly here — this is that trajectory reaching its natural endpoint, not a surprise reversal.

**Doesn't change, at least not by implication, and this is worth stating plainly rather than assumed away:** term (2), the true-name reveal, stays a live default. Two separate, non-negotiable-by-policy facts, not one cautious habit:

- This session has never been shown the literal word. That's true regardless of what the naming-lock policy says — "full crossover" doesn't make the word appear in any doc I can read. Nothing changes here until Maxime tells me the word directly, in his own message.
- Even once I know it, using it as game-facing content is a decision to spoil the book's own climactic reveal through the game, ahead of (or instead of) the book itself. That's not the same kind of choice as reusing "Coalition of Enlightened" or "Synker" — those are setting/branding texture; this is the actual twist. It deserves its own explicit, deliberate yes from Maxime — not an inference from "old rule is stale," which was said in the context of a lore/branding entry, not this specific reveal.
- `tools/lint-spoiler.mjs` — a real, build-failing CI gate in the actual repo — stays untouched. Disabling or modifying it is a separate, real repo action, not a doc policy update, and needs its own explicit go-ahead if and when Maxime decides he wants that specific term in the game.

If Maxime does want the true-name reveal itself in full crossover scope — not just the branding and setting texture — that's a clean, one-line thing to confirm directly, and this doc/the Master Index gets updated again the moment he does.

## Practical effect right now

- The Coalition codex entry work (already locked, see the plan doc) doesn't change — it never used either locked term, and its own light-touch escalation was a narrative-pacing choice about *when* a reveal lands in-fiction, not a naming-lock workaround. Full crossover widens what's fair game elsewhere; it doesn't ask that entry to be rewritten.
- Every future Bloom Wars doc, code comment, or player-facing string is now free to use "The Synker Wars"/"Synker" the same way "Coalition of Enlightened" already is — no more redacting or working around it.
- The one thing still worth a naming-lock read-through pass before anything ships to a player: codex content specifically, since it's the highest-volume prose in the game and the easiest place a reference to the still-locked true-name term could slip in by accident, not because it's forbidden vocabulary anymore in the branding sense, but because nobody's actually said that specific word to me yet, so any appearance of it would be a hallucination, not a crossover.

## Master Index — replacement text for next sync pass

The two sections below should replace `claude/Bloom_Wars_Master_Index.md`'s current "## Naming lock (shared with the book project — the only real coupling)" and "## Cross-project references" sections verbatim, and the "Scope note" near the top should have its "except two reserved names... and a handful of one-way lore borrows" clause updated to reflect this. Kept here as ready-to-paste text rather than applied directly to that doc this pass — see this doc's own header note for why.

---

### Naming lock — repealed for branding, kept as a safety default for the one real spoiler (updated 2 Sep 2026)

Maxime, 2 Sep 2026, direct: **"we are going full crossover. old rule is stale."** This supersedes the section as it stood since this project began — full reasoning: `claude/Bloom_Wars_Naming_Lock_Policy_Update_2Sep2026.md`.

The book's own military-arc name ("The Synker Wars"/"Synker") was pure IP-identity separation, not a spoiler — that's the "old rule" this cancels. It's now fair game in Bloom Wars code, docs, filenames, and UI strings, same standing as every other Qiraki term already active here.

The Build Brief's other locked term is a different kind of thing — the novel's own true-name reveal, a real plot twist for the book's own readers, never written in any doc Claude has been shown (defined only in a gitignored local env var `tools/lint-spoiler.mjs` reads from). It stays a live default: this session doesn't know the word regardless of policy, and using it in the game once known would mean spoiling the book's own reveal through a different medium — Maxime's own explicit call to make, not something "old rule is stale" resolves by implication. The lint gate stays live until he says otherwise.

### Cross-project references (updated 2 Sep 2026)

The GDD and Data Pack pull inspiration/verification from Qiraki documents (see `Qiraki_Master_Index.md`); the Amaranth campaign reuses the same Bestiary/Bioterror Bank systems rather than re-deriving them.

**Policy history:** 26 Aug 2026 established deliberate shared-universe borrowing (species, structural systems) as the standing default rather than a per-case exception, condition being Maxime's own "I want both clearly not conflicting." **2 Sep 2026 — extended to full crossover**, Maxime's own words: "we are going full crossover. old rule is stale." The branding-separation half of the naming lock is repealed under this; the true-name spoiler term is a separate matter, held to its own safety default — see "Naming lock" above.

**How to apply it going forward, unchanged:** verify any specific Qiraki fact against the actual file before using it, not memory. Keep consistency in view both ways — a fact pulled from Qiraki into Bloom Wars should still read true if a reader ever holds both properties side by side, per Maxime's "not conflicting" condition, which full crossover doesn't relax.

---
