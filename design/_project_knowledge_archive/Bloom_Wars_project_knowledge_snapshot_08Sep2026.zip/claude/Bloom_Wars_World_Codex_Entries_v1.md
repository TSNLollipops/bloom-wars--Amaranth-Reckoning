# The Bloom Wars — World Codex Entries v1

*Written 2 Sep 2026, the category `Bloom_Wars_Codex_Design_v1.md` itself flagged as carrying "the real spoiler risk" — worked through concretely in that doc's own §3 before any entry existed. This document is that worked-through fix, actually written: three entries — the Amaranth Reach, House Amaranth, Meridian — each an ordered list of revisions gated on mission-complete, matching the `WorldCodexEntry` schema that design doc's §3/§8 sketched but never built out. The Coalition entry (`Bloom_Wars_Coalition_Lore_Codex_Entry_Plan_v1.md`, already shipped) is this category's fourth member, covering the wider civilization beyond the Reach — not duplicated here. Checked against `Bloom_Wars_Independent_Campaign_The_Amaranth_Reckoning.md` §§4/5/6a/7 and the full 36-mission table in full before writing a single revision, specifically to get real mission numbers rather than reuse the design doc's own illustrative Mission 6/17/23/28 example verbatim without checking whether the actual built campaign matches it. (It mostly does — see §0.)*

## 0. What checking against the real mission list changed, and one thing it confirmed should stay unsaid

The design doc's original worked example (§3) used Mission 6/17/23/28 as an illustration of how House Amaranth's entry *should* escalate, written before the campaign was fully built. Checked against the actual shipped 36-mission table, that illustration turns out to line up with real, built missions almost exactly — Mission 6 is genuinely "House Colors" (first distant sighting), Mission 23 genuinely is "The Amaranth Accord" (bargain confirmed), Mission 28 genuinely is "Marrow's Reckoning" (her turn). The one place it needed refining rather than just confirming: Mission 17 ("The Wellroot Uncovered") is a *hint* that the Bloom's growth on House Amaranth's terraces looks deliberate, not yet the full confirmation — that's Mission 23's job. The House Amaranth entry below has five revisions, not four, to hold that distinction rather than collapse it.

**One thing worth flagging rather than fixing, because it isn't broken:** the Independent Campaign doc's own §4 describes "the Seal and the Sword" — a charter house's battlegroup nominally commanded by a House officer holding its seal while a professional soldier (Marrow) actually runs it — as a worldbuilding device "kept implicit in play," the same discipline the Build Brief already applies to Mission 1a's ambush mechs. None of the revisions below ever explain that mechanism directly, on purpose, the same way none of them ever use the phrase "ward-crop program" before Mission 23 actually confirms one exists. A codex entry that spelled either of those out ahead of the game's own reveal would be the exact failure mode this whole category exists to prevent.

## 1. The Amaranth Reach

> **codex_world_amaranth_reach**
>
> **Revision 1** *(unlocked from Mission 1 — pure orientation, no reveal risk)*
> A frontier cluster on the edge of core-administered space, held nominally by a sector governor-general who's never once had to actually worry about it. Its wealth and its name both come from the same source — House Amaranth, the founding charter dynasty, generations deep in the sector's richest agricultural terraces. Warden Company holds a stretch of border line here, the Fallow Line, alongside House Amaranth's own chartered battlegroup. Meridian, the Reach's capital, gets its own entry.
>
> **Revision 2** *(unlocked after Mission 36 — matches the epilogue's own line)*
> After the siege, the name doesn't get used much anymore. Nobody's issued an order about it. It just isn't, the way people stop calling a street by a landlord's name once everyone remembers what that landlord actually did.

## 2. House Amaranth

> **codex_world_house_amaranth**
>
> **Revision 1** *(unlocked after Mission 6, "House Colors" — first distant sighting of Marrow)*
> A charter house, generations old, holding the Reach's richest terraces. Fields its own chartered battlegroup alongside the Reach's loyalist regulars — Colonel Ysolde Marrow runs it day to day. Officially allied with Warden Company. That alliance has been tense since a checkpoint dispute neither side has fully let go of.
>
> **Revision 2** *(unlocked after Mission 10, "The Amaranth Betrayal")*
> Whatever's actually kept this alliance strained, it broke outright once. House Amaranth pulled off a position everyone was supposed to be holding together — no warning given, no explanation offered since.
>
> **Revision 3** *(unlocked after Mission 17, "The Wellroot Uncovered")*
> Something about how the Bloom grows on House Amaranth's own terraces doesn't read as accident anymore. Too regular, too directed, too calm about it on House Amaranth's side for something that's supposed to be everyone's shared enemy. Nobody's said the word "deliberate" out loud yet. It's getting harder not to.
>
> **Revision 4** *(unlocked after Mission 23, "The Amaranth Accord")*
> It was deliberate the whole time. House Amaranth's own research — decades of it, reaching back to the war's earliest years — got turned into a bargain: divert the Bloom's growth away from House lands, and call the redirected mess stewardship instead of what it actually is. It worked long enough to look like wisdom. Nobody who signed off on it thought it would still be paying out this way.
>
> **Revision 5** *(unlocked after Mission 28, "Marrow's Reckoning")*
> Whatever debt put Colonel Marrow in that seat, she's stopped paying it. She turned on Halcyon Amaranth herself, mid-battle, at real cost — the kind of choice that doesn't undo anything already done, and isn't made to undo anything either. Warden Company doesn't know yet whether it changes the war they're actually fighting. It's not clear it does.

## 3. Meridian

> **codex_world_meridian**
>
> **Revision 1** *(unlocked from Mission 1 — pure orientation, no reveal risk)*
> The Amaranth Reach's capital world. Shipyards, an orbital elevator, more people than the rest of the sector combined. Everyone out on the Fallow Line has family there, or knows someone who does. It's the place this whole war is nominally protecting, whether or not it ever feels like it from a trench on the border.
>
> **Revision 2** *(unlocked after Mission 25, "The Reckoning" — first Meridian's Oath call-in)*
> Whatever's been quietly accelerating out on the terraces has found a new gear entirely, and it's coming this way faster than anyone accounted for. Meridian's own orbital defense grid — Meridian's Oath — just went from a name on a briefing slide to something Warden Company is actually calling in mid-fight.
>
> **Revision 3** *(unlocked after Mission 29, "The Outer Ring Falls")*
> Falling back ring by ring around a capital that isn't supposed to fall changes what a fight even means. The outer ring went by design, not by failure — buying time, not holding ground. What's left gets smaller every time Warden Company checks, and closer to the people the whole war was supposed to be keeping safe.
>
> **Revision 4** *(unlocked after Mission 36 — matches the epilogue's own line)*
> It held. Changed for good — the name that used to belong to the whole reach around it doesn't get said much anymore, and Meridian itself remembers exactly how close that margin actually was, even if the official histories round it up to a clean victory.

## 4. Data-shape note

Each entry above is a `WorldCodexEntry` per the original design doc's own §3/§8 sketch — an ordered `revisions` list, each tagged `unlockedAfterMissionId`, always rendering the latest revision the player's actual save has reached rather than a flat static string. No new schema decision made here; this is that sketch filled in with real content for the first time.

## 5. Naming-lock safety check

Nothing above touches either reserved book term — this is entirely Bloom Wars' own native political/geographic material, same as the Coalition entry it sits alongside. The Seal-and-Sword mechanism and the exact phrase "ward-crop program" are both withheld until the game's own reveal point, per §0 above — not a naming-lock issue, the other, separate spoiler discipline this whole category exists to protect.

## 6. Status

World category now has four entries total: the Coalition (already shipped), plus these three. That's every topic the original design doc's own category table named for World. Only Ranks & Command and Glossary remain from the original six-category list — see the companion docs shipped alongside this one, same session, if you want all three read together.
