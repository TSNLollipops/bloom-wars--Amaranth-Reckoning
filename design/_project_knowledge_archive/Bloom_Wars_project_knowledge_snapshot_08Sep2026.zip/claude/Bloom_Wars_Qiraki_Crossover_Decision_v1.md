# THE BLOOM WARS × QIRAKI — Crossover Decision, Locked

**7 Sep 2026, decided live in a Bloom Wars chat.** This supersedes the looser stance in the Master Index's own "Cross-project references" section ("deliberate shared-universe borrowing is the standing default, condition being 'I want both clearly not conflicting'"). That was permission to borrow flavor. This is a real, tracked canon fact: **Bloom Wars and Qiraki are the same universe.** Not two things that happen to resemble each other — one continuity.

## The placement

**Bloom Wars is set 30 years before Canon** — Maxime's own words, "Canon" meaning the main 7-book series' own story start (Era I, Trav's enrollment). The Bloom war is already locked at "roughly sixty years by story start" (`Qiraki_Bible_Skeleton.md` §2). Thirty years before that lands inside that same war, not before it — the Bloom has already been hitting Coalition space for about thirty years by the time Warden Company and House Amaranth are fighting it. Not first contact. A real, earlier chapter of the war the books show you the end of.

Checked against `Bloom_Wars_Qiraki_Era_Crossref_Ideas_v1.md` (27 Aug 2026, still on file, never scoped past a brainstorm): the 7 mapped eras (I–VII) all run forward from Era I. Thirty years *before* Era I sits in front of all of them — it isn't secretly Era III or a reskin of Era VI, it's genuinely unclaimed ground. Nothing already plotted to contradict, nothing to accidentally step on.

## The boundary — same one the project already uses, just made explicit

This isn't a new rule. It's the same line `Bloom_Wars_Carabil_Playable_Species_Proposal_v1.md` already drew for reusing Carabil (species mechanics: yes, already live — Arangement of Content's name follows Carabil naming convention today. COE political history and Coherence of Process's personal arc with Trav: explicitly left out, book-only material). This decision just says that boundary now covers the whole universe, not one species:

**Crosses freely:** species (Carabil, Hiopi, etc. and their real mechanics), tech and hardware (Holoband, Linktier, Sovereign/Heirloom-grade gear), general setting texture, the Bloom itself as a threat.

**Stays locked, unchanged, no exceptions:** the reserved term defined in the Build Brief (spoiler-locked, still enforced by the `BW_RESERVED_TERM` lint check); **"The Synker Wars"** (Era II's own title — still can't surface anywhere in Bloom Wars material, by name or by disguised reskin, exactly as `Bloom_Wars_Qiraki_Era_Crossref_Ideas_v1.md` already flagged); the true nature of the Bloom, its origin, and anything else the books are holding for their own reveal; any of Qiraki's specific plot beats or named cast's personal arcs.

## What this resolves, right now

- **Holoband is clear to use.** It's hardware/vocabulary, not reveal-adjacent — a wrist-worn personal comm predates or coexists fine with the cadet-issue version Qiraki locks decades later. Verinis's Brief line (b) can go back to naming it.
- **The Sovereign/Heirloom longevity idea, previously parked as an undecided cross-reference in `Bloom_Wars_Now_And_Next.md`,** is no longer undecided. House Amaranth being rich enough for S-grade tech and the "sober for a century" joke both hold as written.
- **Carabil's existing precedent stops being a standalone exception and becomes the template** for how every other piece of Qiraki texture gets pulled in going forward.

## Still open, not decided here

- How much of the actual COE political machinery (Hearth Bloc, Cradle Circle, Frontier Compact, Osnian Honor Guard) Warden Company/House Amaranth ever touches directly, versus just existing in the same galaxy near it. Nothing forces this to be answered now — Bloom Wars can stay a self-contained regional war without ever naming COE politics on the page.
- Whether Warden Company / House Amaranth are explicitly COE-affiliated forces on the record, or a frontier-adjacent power that COE politics barely reaches at the 30-years-earlier mark. Real worldbuilding call, not urgent.
- `claude_Bloom_Wars_Master_Index.md`'s own "Naming lock" / "Cross-project references" sections need a real pass to reflect this — not done here, per the project's standing practice of not touching the Master Index outside a deliberate pass.
- `Qiraki_Master_Index.md` should get a pointer to this doc too, since the relationship is no longer one-way inspiration. That's a book-side edit — flagged here, not made from a Bloom Wars conversation.
