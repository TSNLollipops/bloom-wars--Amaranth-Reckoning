*28 Aug 2026. Plan only, nothing built yet — answering Maxime's "plan, ship weapon use in the missions," narrowed via clarifying questions to: fix the Mission 21 branch-balance regression first, then build out the remaining weapon branches. This doc is the plan for both, in order. Sources: `Bloom_Wars_Weapon_Branch_Point_System_v1.md` (the original design), `Bloom_Wars_Weapon_Branch_Point_System_Delivery_v1.md` (what actually shipped 27 Aug), `Bloom_Wars_Weapon_Branch_Mission_Balance_Check_v1.md` (28 Aug finding), `Bloom_Wars_Mek_Workshop_And_Weapon_Progression_v1.md` (26 Aug, where every weapon name below actually comes from).*

**Status update, 1 Sep 2026 — §4 step 2 fully shipped.** Both Aegis Ward and Field Doctor (Munti) are now built, tested, and committed — see `claude/Bloom_Wars_Build_Log_Addendum_AegisWard_FieldDoctorScope_01Sep2026.md` for the full account. Aegis Ward shipped exactly as this doc originally described it. Field Doctor did not: checked against the live `repairUnit()` before building anything, and its own doc comment confirms Repair has no cost and no per-mission charge cap today (unlike Missiles/Fire Support, which this plan's "same shape as Weapons Bay's bonus Fire Support charge" line assumes) — so "cheaper Repair, or an extra Repair charge" never mapped onto the actual engine. Raised to Maxime directly; his call was a cooldown-gated free Repair every 3 turns, built on the existing (until now unused) `BattleUnit.abilityCooldowns` scaffolding, mirroring the Weapons Bay's own bonus-charge cooldown shape. The addendum also documents a second real bug this pass caught and fixed: the engine logic alone would have been unreachable through the actual game UI (Battle.ts's unit-selection guards excluded any unit at 0 actions), fixed alongside the feature itself. The table and remaining-branch list below are left as originally written for the historical record; read them alongside the addendum for current status.

## 0. Where this sits relative to everything else weapon-shaped

Two other docs touch "weapons" and are deliberately **not** part of this plan:

- **The Frame Systems Layer** (`Bloom_Wars_Frame_Systems_Layer_v1.md`) — a much bigger Lancer-inspired mounts/Draw/systems/refit layer. Maxime already decided its own economy sim harness gets built *before* any of it, and nothing here should be read as sneaking a piece of that in. If any branch below starts to feel like it wants Draw-budget logic or a mount count, that's a sign it belongs in that doc's queue, not this one.
- **Rourke's Reclaimer Beam** (Munti's actual attack weapon, repair-beam-reversed) — a real, named idea in the Mek Workshop doc, but still a fully open question (same action as Repair retargeted, or a separate slot?) with zero design decided. Not touched here.

This plan is scoped to exactly one thing: the existing Weapon Branch Point System (5 branches shipped 27 Aug, personal-pool economy, already live in real missions) — closing its one known balance gap, then filling in the branches that were deliberately left unbuilt because the engine couldn't support them yet.

## 1. Part one — the Mission 21 branch-balance regression

### The finding, restated plainly
Mission 21 (the Wellroot boss fight) is tuned to land around 35% win rate. With no weapon branches equipped, it does — the 28 Aug balance check measured 30%, in line. **With a full branch-equipped squad (Impact Lance on every Meeps, Grinder Claw on every Tank), the same mission jumps to ~48%.** The other four tightly-tuned missions checked in the same pass (14, 32, 35, 36) didn't move outside noise. This is a real, repeatable, single-mission finding — not a campaign-wide one, at least not provably.

### Why it's Mission 21 specifically
Wellroot is one durable boss (480 Endurance) plus recurring Undertow ambush bursts — an attrition fight. Impact Lance's flat, unconditional +15 ATK and Grinder Claw's 20%-of-damage-dealt self-heal both compound hardest in exactly that shape: more damage per hit across a long fight, more free healing to outlast the ambush bursts. Nothing about the other four missions tested has that same durable-single-target-plus-attrition shape, which is the likely reason they didn't move.

### The three options on the table (from the balance-check doc), and my read on them

1. **Leave it.** Argument for: a boss reading easier once a player has spent real currency on a specialty is a normal, even satisfying power curve — this isn't the campaign's hardest fight (Mission 35 is), and nothing says every number has to stay pinned forever.
2. **Retune Mission 21 itself** (Wellroot's Endurance, or the Undertow reinforcement cadence) back toward ~35% assuming branches are equipped.
3. **Trim the branch numbers themselves** (Impact Lance's +15, Grinder Claw's 20%) — ripples protectively across all 36 missions at once, not just this one.

**My recommendation: option 2, not option 3 — with a caveat.** Only 5 of 36 missions were actually checked, and the theory behind picking those five was "a systemic problem would show up on the tightest margins first." Four of five showed nothing. That's a real signal the branches aren't quietly breaking the whole campaign — it's a signal they're breaking *this specific fight shape*. Trimming the branch numbers to fix one attrition boss risks making Impact Lance and Grinder Claw feel worse on the other 31+ missions nobody's tested yet, purely to correct a problem that's shown up exactly once. Mission 21 has also already been hand-retuned once before (the opening Crawlmass wave got cut on 25 Aug) — there's precedent for treating this as "this mission's own dial," not "the branch's dial."

**The caveat:** option 2 alone doesn't rule out a similar surprise showing up on some other attrition-shaped boss fight nobody's checked yet (candidates worth a look eventually: any mission built around one durable named threat plus reinforcement waves, the same shape as Wellroot). Not proposing a full 36-mission re-run as part of *this* plan — that's real work in its own right and can happen on its own timeline — but flagging it as the honest gap this fix doesn't close.

### What actually gets tuned, concretely
Wellroot's own comment block in `data/bloom.ts` already carries a full history of every attackPower sweep run on this fight — this would be the same kind of pass, on a different knob (Endurance, or reinforcement cadence), specifically re-run *with* branches equipped this time, which nothing so far has done. Two real levers, not committing to either without a run:
- **Bump Wellroot's Endurance** up from 480 — has to be re-checked against the existing hits-to-kill ladder (Heartwood 7 hits < Wellroot 8 < the Unnamed 9, `combat_sim.py`'s own gate) so it doesn't quietly break that ordering.
- **Bump Undertow ambush frequency or damage** slightly — the fight's own build log already identifies Undertow burst damage as the actual killer more than the boss itself, so this lever touches the thing already doing most of the work.

### Verification
The balance-check doc's own sandbox rig is already built and "standing by to verify any of the three in a couple of minutes" — re-run N=100 with the branch-equipped squad after whichever change, confirm it lands back near 35%, confirm hits-to-kill ordering still holds via `combat_sim.py`. Cheap to re-check, which is part of why option 2 over option 3 isn't a big bet either way.

**This stays your call, same as every other Wellroot number so far** — I'm not shipping a specific value without a real run to back it, and the campaign-feel question (should this fight get a little easier once players have specialized?) is a taste call, not a math one.

## 2. Part two — the remaining weapon branches

### Where the branch system actually stands today
The design called for 4 purchasable branches per class (16 total) — Munti got a 4th support option specifically so "every class has 4, no special case." What's actually named and speced anywhere in this project's docs:

| Class | Default (free, not a branch) | Branches named | Shipped 27 Aug | Remaining, named | Not yet named |
| --- | --- | --- | --- | --- | --- |
| Meeps | Twinblades | Impact Lance, Shock Claws, Scattershot Pistols | Impact Lance | Shock Claws, Scattershot Pistols | 1 slot — no 4th concept exists anywhere |
| Tank | Slam Cannon | Grinder Claw, Riot Drum, Maser Lance | Grinder Claw | Riot Drum, Maser Lance | 1 slot — no 4th concept exists anywhere |
| Reeps | Marksman Rifle | Missiles, Rail Lance, Suppression Autocannon | Missiles, Rail Lance | Suppression Autocannon | none — Reeps is fully named at 3 |
| Munti | — | Rapid Response, Combat Medic, Field Doctor, Aegis Ward | Rapid Response, **Aegis Ward (1 Sep 2026)**, **Field Doctor (1 Sep 2026)** | Combat Medic | none — fully named at 4 |

**Flagging plainly, not glossing over it: Meeps and Tank are each one branch short of the "4 per class" symmetry the design doc states as its own goal.** Nobody has actually invented a 4th weapon concept for either class anywhere in this project's docs. Reeps sits at 3 named total (Missiles/Rail Lance/Suppression Autocannon) and nothing says it needs a 4th — Munti explicitly got bumped to 4 to match everyone else, but Reeps was never flagged the same way. This might just mean 3-3-3-4 is fine and the "4 per class" line was aspirational rather than a hard rule — genuinely your call, not something to guess at by inventing a weapon. Flagged as an open question below rather than assumed either way.

### What each remaining branch actually needs to build

**Cheap — numbers/economy only, same shape as Rapid Response:**
- ~~**Field Doctor** (Munti) — cheaper Repair, or an extra Repair charge per mission. Same shape as Weapons Bay's bonus Fire Support charge, already-proven pattern.~~ **Shipped 1 Sep 2026 as a cooldown-gated free Repair every 3 turns (Maxime's own pick, after the original framing above didn't map onto the live engine) — see the addendum.**
- ~~**Aegis Ward** (Munti) — passive AoE regen aura radius increase. Munti already has this aura; this just scales an existing number.~~ **Shipped 1 Sep 2026 exactly as described here — see the addendum.**

**Moderate — reuses on-hit-effects machinery that already exists, but needs it wired the other direction (see §3):**
- **Suppression Autocannon** (Reeps) — attack-debuff on hit. The exact mechanism (`debuff_attack`) already exists and already works — it's currently only wired for Bloom-hits-mech, not mech-hits-Bloom.
- **Riot Drum** (Tank) — knockback plus a "pin." Knockback geometry already exists (`knockbackDestination`); "pin" isn't defined anywhere yet — needs a decision (see open questions).
- **Combat Medic** (Munti) — Repair applies a short heal-over-time tick. The tick *system* exists (`tickStatusEffects`) but has only ever ticked damage, never healing — same infrastructure, opposite sign.

**New engine surface — real work, not data:**
- **Shock Claws** (Meeps) — chance to stun on hit. Stun doesn't exist in any form yet.
- **Scattershot Pistols** (Meeps) — short range (2), cleaves to a second adjacent target. Every attack in the engine today resolves against exactly one target.
- **Maser Lance** (Tank, D-tier minimum per its own original design note) — a committed cone AoE. No AoE targeting shape exists for a player weapon today (Fire Support's splash is the closest analog, and even that's a fixed-shape ability, not a weapon).

### Rail Lance, a loose end worth naming
Already shipped, but genuinely never fired in a real mission — every Amaranth mission is Bloom-only, and Rail Lance's defense-ignore only triggers against a Tank-*path* defender, which no Bloom archetype is. Not broken, just untested by construction. Nothing to do about it now (no Tank-path hostiles exist to test against), just worth remembering it's an unverified branch, not a verified-safe one.

## 3. The one foundational piece everything above leans on

`engine/turnManager.ts` (shipped 27-28 Aug) is real, tested, and live — but it only fires in one direction: **Bloom attacking a mech.** Every remaining branch above that needs a status effect (Suppression Autocannon's debuff, Riot Drum's knockback/pin, Combat Medic's heal tick, eventually Shock Claws' stun) needs the *other* direction — a mech's own weapon applying an effect to a Bloom it just hit. That wiring doesn't exist yet in any form.

This is exactly the situation the Frame Systems Layer doc already named as a standing rule worth following here too: **build the status-effect framework once, generalized both directions, rather than bolting one bespoke effect onto one weapon at a time.** Concretely, this means before any of the "moderate" or "new engine surface" branches above, one real piece of infrastructure work: generalizing `applyBloomOnHitEffect`-style application so it can run off a mech's attack against a Bloom target, not just the reverse — plus, while that's open, adding the two effect *types* nothing has today (stun, and a positive/healing tick) alongside the three that already exist (acid_dot, debuff_attack, knockback).

Do this once, and Suppression Autocannon and Riot Drum's knockback half both become close to data-only afterward — same as how Rapid Response, Aegis Ward and Field Doctor already are without touching anything new.

## 4. Proposed build order

Cheapest-to-most-defensible first, matching this project's own "if only one thing gets built, build the cheap wide thing" instinct rather than importance order:

1. **Mission 21 fix** (§1) — small, isolated, already has a rig to verify against. Do this before building on top of a system just shown to compound unpredictably on at least one fight.
2. **Field Doctor + Aegis Ward** (Munti) — zero new engine work, ships the moment someone's free to do it. **Both shipped 1 Sep 2026 — see the status update at the top of this doc.**
3. **The reverse-direction on-hit-effects wiring + stun/heal-tick types** (§3) — the one piece of infrastructure that unlocks everything else. Real work, worth doing as its own dedicated pass rather than half-building it for one branch.
4. **Suppression Autocannon, Riot Drum's knockback half, Combat Medic** — once step 3 lands, these are close to data changes.
5. **Riot Drum's "pin" half, Shock Claws, Scattershot Pistols, Maser Lance** — each needs its own real new mechanic (pin definition, stun, cleave targeting, cone AoE) on top of the step-3 foundation. Worth sequencing by which mechanic is cheapest once you've seen how step 3 actually shakes out in code — hard to rank precisely from the design side alone.

## 5. Open questions — genuinely yours, not guessed at

- **Meeps and Tank's missing 4th branch.** Invent a new weapon concept for each (and if so, any starting ideas — e.g. a Meeps option that leans further into mobility than Impact Lance does, or a Tank option that isn't offense-flavored at all), or accept 3-3-3-4 as the real, final shape and stop treating "4 per class" as a hard rule?
- **What "pin" actually means for Riot Drum.** Skip the target's next action entirely (a real stun-adjacent effect, arguably redundant with Shock Claws), reduce their move range for a turn, or something else? Needs a real definition before it's buildable, not just "knockback plus something."
- **Sequencing:** build the Mission 21 fix and the reverse-direction engine piece back-to-back in one pass, or treat them as two separate check-ins so you can look at Mission 21's fix before more gets built on the same system?
- **Doc debt:** GDD §6.4 and Data Pack §12 already have two edits waiting on your own hand from the original 5-branch delivery. Every branch this plan adds grows that same waiting list — now including Aegis Ward's and Field Doctor's own rows (both now locked, real numbers — 220 points / tier C, and a 3-turn cooldown / tier B respectively — so these two rows can actually be written for real). Worth batching all of it into one pass once you're at a machine that can touch the real `.docx` files, rather than nothing happening until then — flagging so the pile doesn't get bigger without you knowing it exists.

## 6. What this plan deliberately does not include

No numbers are proposed as final anywhere above — every stat in this doc is "here's the shape," same discipline the source docs already hold themselves to. Nothing here starts building without your go-ahead, same as every other plan doc in this project. The Frame Systems Layer and Reclaimer Beam stay exactly where they were — not touched, not folded in.
