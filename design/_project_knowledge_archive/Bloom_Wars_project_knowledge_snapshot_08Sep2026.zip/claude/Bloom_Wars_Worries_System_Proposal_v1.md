# THE BLOOM WARS — Worries System Proposal v1

*Design pass only, zero code, not a locked decision. Same framing as `Bloom_Wars_Stress_Morale_Trigger_Proposal_v1.md` and `Bloom_Wars_NPC_Reaction_Engine_v1.md` — a real proposal to build against, not something already shipped. Originates from a chat conversation with Maxime, 28 Aug 2026, not from a code session — nothing below had been checked against the actual current repo state until the verification pass appended at the end.*

**Filed into the project, 28 Aug 2026.** Maxime wrote/drafted this outside a code session and delivered it as a PDF (`claude_Bloom_Wars_Worries_System_Proposal_v1.pdf`) after telling this session to pause the sandbox-porting readiness pass (`Social_Sim_Roadmap_v1.md` §21) until "worries plan" was done and in the game. Text below is a faithful transcription of that PDF, unedited except for formatting. See the verification section at the bottom for what got checked against the actual current repo since.

**Scope flag, per the project's own standing rule.** This is a new system, not a tuning pass. It's the practical, buildable entry point into the Reaction Engine formula (`Bloom_Wars_NPC_Reaction_Engine_v1.md`) — a cheap stand-in for **c**, the catalyst ("what the pilot is visibly doing/carrying right now"), without needing the full `(A+B)+(a+b4(c))=D+E` machinery built first. The Reaction Engine doc's own status line still reads "not scheduled, behind the hard-tactical-loop gate" — that gate's own condition (36-mission campaign shipped first) is met, and the project is already deep in Hub/social work past it, so the gate reads cleared. Worth confirming that explicitly with Maxime before treating this as authorized to build, not assuming it from this doc alone.

## What this is

A general-purpose, short-window "what's currently on this NPC's mind" list, per pilot. Contrasted deliberately against the project's existing long-term numbers (`favorability`/`stress`/`morale` on `HubPilotSocialState`) — persisted, slow-moving, accumulate over the whole campaign. Worries is the opposite: unpersisted, fast-moving, holds only recent entries (Maxime's own framing: "less than 1 day in game"), and is meant to answer "what is this pilot preoccupied by right now" in both Hub and Battle contexts.

**Absorbs `missionWorry.ts`, doesn't run alongside it.** Confirmed by Maxime, 28 Aug 2026. The existing Mission Worry feature (shipped 27 Aug, Social Sim Roadmap #8 — a pilot worrying about a squadmate still out on a mission attempt left open too long) becomes one entry source on the general Worries list, not a parallel system. Its ramp math is the best intensity/decay model this project has and should carry over wholesale rather than being reinvented:

- Onset gate before any ramping starts (`WORRY_ONSET_MS`, currently a 60 real-second placeholder).
- Linear ramp from 0 to full intensity over `WORRY_RAMP_MS` (4 real minutes).
- A closeness multiplier with a floor of 0.3 — even a distant pilot worries some, never zero.

**Docs that need updating once this is picked up** (not done as part of this proposal, flagged so it doesn't get missed):

- `Social_Sim_Roadmap_v1.md` #8 needs a note that Mission Worry is superseded/absorbed, not left standing as its own independent shipped feature.
- `NPC_Reaction_Engine_v1.md` §4a should point at Worries as the actual landing spot for the combat bridge it already describes, instead of staying purely theoretical.

## The open problem this doc does NOT resolve: two clocks

Mission Worry's existing ramp runs on **real-world time** (an attempt sitting open 4 real minutes). The general Worries framing is **in-game time** (entries expire after less than 1 in-game day). If a real-time entry (missing pilot) and an in-game-time entry (a combat event, a domestic worry) sit on the same list, "which one is loudest right now" needs a consistent way to compare them, or the resolution rule below doesn't mean anything. Genuinely unresolved — raised with Maxime, not yet answered. Whoever builds this should get an explicit answer before writing the comparison logic, not silently pick one. Options on the table, none chosen:

1. Every entry normalizes to the same clock at write time (probably in-game, since that's the framing Worries as a whole uses) — Mission Worry's real-time ramp gets converted at the point it's pushed onto the list.
2. Entries keep their native clock and intensity is compared directly (0-1 scale) regardless of what produced it — simpler, but conflates "how urgent" with "how the timer works," which may not be the same thing.

## What already exists that this reuses

- **The animal list** (`Wolf/Dog/Cat/Crow/Raven/Bear/Fox/Rabbit/Shark`, `NPC_Reaction_Engine_v1.md` §2) — the vocabulary a Worry entry's catalyst tag should draw from. Don't invent a new taxonomy.
- **Gate 3's resolution rule** ("which one is loudest right now, not a walk through all four looking for where it discharges," §4b) — the same principle should govern how the Worries list picks which entry actually surfaces, rather than a hand-tuned priority stack.
- **The combat bridge already identified in §4a** — `engine/mission.ts` logs a structured outcome for every action already (kill, repair and how much it healed, a downing, a permadeath check, an overwatch trigger, a dodge), and `src/sim/playerAi/`'s own decision-reason vocabulary (`kill`, `repair_critical_ally`, `retreat_low_hp`, `hold_cornered`, `regroup_low_hp`, ...) already maps onto the same animal-list read a human-played mission would need. The reusable piece is a classifier sitting one level down from the sim bot's own reasons — reading catalyst off the engine's action outcomes directly, since those exist identically whether a human or the test bot triggered them.
- `pickSoloEcho`'s existing priority chain in `ambientLines.ts` (drunk → stress-panic → worried → low-morale, per the Hub Polish addendum, 26 Aug) — the slot a generalized Worries system should plug into for dialogue content, same as Mission Worry already does today.
- **The open gap in `Stress_Morale_Trigger_Proposal_v1.md`** — that doc's own open question #2 ("is a mission outcome in scope... the most obvious why-would-this-number-ever-go-up trigger") is exactly the gap a Worries system could close: a worry that lingers or repeats bleeding into the persisted Stress number is the concrete instant → long-term pipeline. Not proposed as Phase 1 (see Build order below) — flagged because it's the clearest long-term payoff for this whole system, and worth keeping the door open for rather than accidentally closing it with an incompatible data shape now.

## Proposed entry shape (not locked, a starting point)

```
WorryEntry {
  source: string         // e.g. "mission_pilot_missing", "combat_ally_critical",
                          // "domestic_oven", "domestic_door"
  catalyst: AnimalTag     // one of the 9 animal-list entries
  intensity: number        // 0-1, ramped per-source the way Mission Worry already does
  bornAt: timestamp
  expiresAt: timestamp     // <1 in-game day for Hub-context entries;
                           // mission-scoped (cleared on mission end) for Battle-context entries
  context: "hub" | "battle"
}
```

**Resolved, 28 Aug 2026 — both.** Cap: a fixed small stack (top few entries by intensity, e.g. 3-5 — a new entry bumps the weakest off a full list), not unbounded. Matches Gate 3's own resolution rule (read the loudest thing, don't walk a growing list looking for it) and keeps "what's loudest right now" cheap to compute regardless of how many sources fire close together.

Decay curve: per-source, not a single shared curve — against this doc's own earlier "start there, don't invent new curves without a reason" instinct. Maxime's call, explicitly against that default: "Per source is whst my instinc are telling me to go for. Its closer to the dream." Read plainly: expressive per-source ramps (combat worry spiking fast off a witnessed downing, domestic worry sitting low and slow) are closer to what this system's actually for than one shared shape borrowed from Mission Worry alone. Mission Worry's own proven ramp (onset gate, linear ramp, closeness floor) stays the starting template for whichever source needs it, including itself — "per source" means each source *can* diverge from that template, not that each one has to reinvent it from zero. Worth remembering this is now three-plus unproven curves to tune instead of one, with no playtesting yet on any of them — same "don't invent tuning numbers with no playtesting" discipline the rest of this project holds, just applied per curve instead of once.

## Content buckets

Three distinct sources, each with its own bar for what's needed before writing content:

1. **Combat/mission-side** — driven by the `mission.ts` classifier above. No new writing needed; reuses catalyst-to-line mappings that already exist for the animal list.
2. **Hub/social-side** — Mission Worry (absorbed) plus whatever else already writes into `pickSoloEcho`'s chain. No new writing needed either.
3. **Domestic/mundane** (new — "is the oven off," "did I lock the door") — genuinely new content, humanizing texture unrelated to the war narrative. Per the project's standing convention, this needs its own content brief before any lines get written, not drafted ad hoc. Flavor-only at first (no mechanical weight) until there's a real reason to let it push Stress.

## Build order

1. Data shape + resolution rule (the two sections above), locked with Maxime's sign-off — including the clock question. **Done, 28 Aug 2026** — clock (native per-source, see the addendum below), cap (fixed small stack), decay curve (per-source), and Gate 0 inheritance (see "Open questions" below) are all resolved. What's still genuinely open before this ships: the Lance-assignment fork this doc doesn't cover (resolved separately, `Social_Sim_Roadmap_v1.md` §21c), and the Voicebox/parallel-arc idea sitting on Spitball Ideas as a real but not-yet-scoped consumer of a future combat-source Worry entry. Otherwise this step is closed.
2. Read-side only: wire into `pickSoloEcho`'s existing chain, ambient dialogue content, nothing else. Absorb Mission Worry as the first live source here — this is the smallest slice that proves the general system without touching combat or Stress/Morale yet.
3. Combat bridge: build the `mission.ts` outcome classifier, mission-scoped entries only, cleared on mission end (not the 1-day window).
4. Domestic bucket: content brief first, then lines, flavor-only.
5. Stress/Morale bridge (Phase 2, not part of this pass): decide real deltas only after the read-side has been observed in actual play — same "don't invent tuning numbers with no playtesting" discipline already held everywhere else in this project.

## Open questions for whoever builds this

- The clock problem above — unresolved, needs Maxime's direct answer.
- ~~Cap size / decay curve per source, or one shared curve.~~ **Resolved, 28 Aug 2026 — see the entry-shape section above:** fixed small stack, per-source curves.
- ~~Should a generalized Worries system feed Gate 0's engagement chance the way Mission Worry deliberately does NOT today~~ — superseded, see the verification pass below: Mission Worry already does. **Resolved, 28 Aug 2026 — it inherits.** Maxime, on whether all Worries sources share Mission Worry's existing `GATE0_WORRY_BONUS = 0.1` rather than each getting its own tuning: "it will inherit it. i think. yeah." Low-confidence but real — one number for all Worries sources, not per-source tuning. Worth a gut-check once this is actually live in play, same discipline as every other placeholder number in this project, but not a blocker for building forward.
- Does the domestic bucket ever get mechanical weight, or stay permanently flavor-only?

---

## Verification pass against current repo state, 28 Aug 2026 (Claude, this session)

The proposal above explicitly asks for this ("nothing below has been checked against the actual current repo state by whoever picks this up"). Checked the two open questions against actual project docs before Maxime signs off on anything, since one of them turned out to be resting on a stale premise.

**1. The Gate 0 question is stale — Mission Worry already DOES feed Gate 0.** The proposal's closing bullet asks "should a generalized Worries system feed Gate 0's engagement chance the way Mission Worry deliberately does NOT today," citing the Hub Polish Addendum, 26 Aug. That's true of §30 of that doc, but §31 — same day, immediately following, direct response to §30's own flagged gap — built exactly that: `GATE0_WORRY_BONUS = 0.1`, live in `reactionGate.ts`, verified with 5 unit tests plus a 1,500-trial statistical check (73.7% observed vs. 75% predicted at full worry intensity, both within normal sampling variance). So the real open question isn't "should we start," it's already live for Mission Worry specifically — the actual question for a generalized system is whether other Worry sources (combat, domestic) inherit that same bonus, get their own tuned bonus, or stay silent on Gate 0 entirely. Worth putting that sharper version to Maxime rather than the version in this doc.

**2. There is no in-game calendar in this codebase — Option 1 of the clock problem isn't just harder, it has nothing to normalize to.** `Bloom_Wars_Spitball_Ideas.md` audited this directly and found "no locked start date, no day-count, nothing in the GDD, Data Pack, or Canon Pass." The only day-simulation anywhere is `pilot_creator.html`'s sandbox "Simulate a Day/Week" buttons, which the sandbox's own comment calls "a design/tuning tool, not a claim about real pacing" — explicitly not a real clock. The only clock that's actually live and built in the game is the mission's own 12-hour real-world wall clock (`engine/campaignState.ts`'s `activeMissionAttempt`/`MISSION_REAL_TIME_LIMIT_MS`) — itself real-world time, same axis as Mission Worry's ramp, not in-game time. So Option 1 (normalize everything to an in-game clock) isn't a harder version of the same task — it requires inventing and locking a whole in-fiction calendar system first, which is exactly the still-open, never-answered idea sitting unresolved in Spitball Ideas (what advances the calendar, what it costs, per-mission or per-choice). That's new scope stacked on top of new scope, not a detail of this one.

Given that, this session's recommendation is Option 2 (native clock per source, compare only the resulting 0-1 intensity) — not only because it's simpler as the original doc already noted, but because it's the only one buildable today without first shipping a separate, unscoped calendar system. Separately, and regardless of which option wins: the entry shape's `expiresAt: <1 in-game day for Hub-context entries` needs its own fix either way, since "in-game day" isn't a concrete unit anywhere in the engine yet. Recommend expiring Hub-context entries on real elapsed time instead, matching Mission Worry's own existing convention and needing zero new infrastructure — unless Maxime wants an actual in-fiction calendar built as its own deliberate, separately-scoped project, in which case that's a real conversation on its own.

Neither finding changes the proposal's own Build order or its call that step 1 (data shape + resolution rule) needs Maxime's sign-off before anything gets built. It sharpens what that sign-off is actually deciding.

## Addendum, 28 Aug 2026 (same day) — the calendar got built, and it confirms option 2 rather than reopening it

Maxime's call, in direct response to the finding above: **"we should probably do the calendar noe. its needed fkr furter game expention."** Full spec in the new `claude/Bloom_Wars_Calendar_System_v1.md` — short version: fixed cost per mission, itemized per-activity pricing, cosmetic-only for now.

Worth being explicit that this doesn't reopen the two-clocks question in the calendar's favor. The calendar advances per-mission, not continuously — it never ticks *inside* a still-open mission attempt, which is exactly where Mission Worry's ramp needs to resolve (between BEAM DOWN and Debrief, in real time). There's no calendar-day value that can represent "4 minutes into a still-open attempt." On top of that, worry specifically was already locked to real wall-clock time on 25 Aug 2026, before either this proposal or the calendar existed — Maxime, on the general worry concept: "the worry goes paralel to mission time. it run until the player exit, what isnt saved is lost." So option 2 (native clock per source, compare on the resulting 0-1 intensity) isn't just still the simpler answer, it's the only one consistent with both the calendar's actual shape and worry's own already-locked design. Treat this as settled unless Maxime says otherwise.
