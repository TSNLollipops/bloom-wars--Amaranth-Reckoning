# Hub Floor-Pin Portrait Revert — Proposal, 5 Sep 2026

**Status: proposal, NOT built.** Written by a different session than the one currently building — for that session to verify against the live file and implement. Nothing in this doc has touched any file.

Maxime, verbatim: *"notes, to remove portrait on the pin of the ant and player. its kinda a waste if we dont have enough for everyone."*

**Reading "the pin" as:** the small circular avatar token that follows each roaming ant and the player around the Hub floor — not the Transporter Pad's squad-row portraits, not Roster/Memorial/Debrief's list portraits. Stated plainly here so it's easy to correct if that's not what "pin" meant.

## 1. What's live today

B4 (`Bloom_Wars_Build_Log_Addendum_B4Portraits_05Sep2026.md`, shipped same day) added `drawPilotAvatar()` (`TransporterPad.ts` ~L216) as the one function every portrait-bearing scene now calls. It checks `scene.textures.exists(asset.key)` (~L227) and draws a real square portrait if the texture loaded, otherwise falls back to the original filled-circle-plus-initials placeholder. Five call sites use it: the Transporter Pad's 5 squad rows, RosterPanel's and MemorialPanel's new left-gutter portrait columns, Debrief's earnings panel, and **`Hub.ts`'s three floor avatars** — the roaming NPC loop (~L6734), the CO (~L6845), and the player's own avatar in `buildPlayer()` (~L7457).

Coverage today is real but partial: per `Bloom_Wars_October_Art_Plan_v1.md`, only Lance A's five named pilots have actual portrait art finished ("Five portraits, Lance A complete... a real finish line"). Everyone else drawn on the Hub floor — other lances, generated recruits, the CO (who's explicitly confirmed at Hub.ts ~L6840-6844 to have no portrait at all) — has no matching texture in cache and falls back to the placeholder already. So the Hub floor right now is a mix: a handful of ants with real faces standing next to a majority still showing plain circle+initials. That's the "waste" — the floor is the one place multiple pilots are ever on screen and visually compared at once, so partial coverage reads as inconsistent there in a way it doesn't in the other four scenes (which either show one pilot's portrait in isolation, or a short curated list).

## 2. The ask

Stop the Hub's three floor-avatar call sites from ever drawing a real portrait — always render the placeholder circle+initials there, regardless of whether art exists for that pilot — while leaving the Transporter Pad, RosterPanel, MemorialPanel, and Debrief exactly as B4 shipped them. This is a scope-narrowing revert on one scene's floor rendering, not a rollback of the B4 work or the art pipeline: `portraits.ts`, `Preloader.ts`, and every asset already made stay fully intact and fully used by the other four scenes.

## 3. Suggested fix shape

Smallest-diff version: add one more optional parameter to `drawPilotAvatar()` (`TransporterPad.ts` ~L216-224), e.g. `forcePlaceholder = false` after the existing `stroke` param, and gate the existing check at ~L227:

`const hasPortrait = !forcePlaceholder && !!asset && scene.textures.exists(asset.key);`

Default `false` means every existing call site (Transporter Pad, RosterPanel, MemorialPanel, Debrief) is byte-for-byte unaffected. `Hub.ts`'s three call sites each pass `true` for the new param:

- NPC loop, ~L6734: `drawPilotAvatar(this, 0, 0, NPC_R, pilotId, displayName, color, undefined, true)`
- CO, ~L6845: same shape with `CO_PILOT_ID`/`coDisplayName`/`CO_COLOR` (redundant with the CO's existing no-portrait-exists case, but worth setting explicitly so this doesn't silently start showing a portrait if one's ever added for him later without someone remembering this revert)
- Player, `buildPlayer()` ~L7457: the call already passes an explicit `stroke` object as the 8th arg, so `forcePlaceholder` becomes the 9th

(`undefined` in the middle position is valid JS/TS — it falls through to the parameter's own default. If whoever builds this would rather not read a call with a trailing `undefined`, folding `stroke` and `forcePlaceholder` into one `opts` object is the cleaner alternative — slightly bigger diff since it touches the one existing call site that already passes `stroke` today, but tidier long-term. Either is fine; not deciding that here.)

## 4. Explicitly NOT changed by this

- The art pipeline, `portraits.ts`'s id-resolution, and the 12-portrait generic-recruit mapping — all untouched, still fully wired for the four other scenes.
- Transporter Pad, RosterPanel, MemorialPanel, Debrief — all keep showing real portraits exactly as B4 shipped.
- No new filenames, no naming-lock exposure.

## 5. Verification, once built

Standard gate (`tsc`/`eslint`/`lint-cast-collision`/`vitest`/`vite build`). Worth a quick visual check specifically that the Hub floor now looks identical to how it did *before* B4 shipped — same placeholder path, so it should be a pure no-op regression check, not a new look to design.
