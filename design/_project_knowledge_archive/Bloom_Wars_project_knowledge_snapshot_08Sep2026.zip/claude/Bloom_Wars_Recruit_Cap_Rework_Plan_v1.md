# The Bloom Wars — Recruit Cap Rework: 20 Pilots From Act I — Plan v1

**Written 8 Sep 2026 (night), from Maxime's ask right before signing off:** *"allow player to recruit up to 20 pair of [pilot] and mek. even as early as act 1. making his lance full if he did before act 2 / 3."* Plan only — nothing built. Per this project's own process (plan → questions → "go"), and doubly so tonight since Maxime's heading to sleep and won't be around to answer a live popup.

## Where the roster cap actually lives today, verified against the real code/docs (not memory)

- `MAX_LANCE_SIZE = 5`, `MAX_LANCES = 5` — the lance scaffold is already sized for Gladiator (5 carriers × 6 lances of 5 mechs, per the Fleet Battle concept), but Warden Company only ever gets **3 lances granted**, one per Act (1st exists from the start, 2nd on Mission 12's win, 3rd on Mission 24's win). That's a **hard ceiling of 15 pilots** on this campaign today.
- 2nd and 3rd Lance arrive **empty** — you recruit into them from the ten previously-authored candidates first (Okafor, Solheim, Tarrant, Vashti, Reyes, Kova, Ness, Onwuka, Delgado, Yeun), then generated recruits once that pool runs dry. Recruiting itself is an ordinary points purchase (`DISCRETIONARY_RECRUIT_COST`) at ROSTER & GEAR.
- **The real blocker isn't points, it's the lance gate.** `assignPilotToLance` refuses assigning into a lance that hasn't been granted yet. So even with unlimited points, nothing stops a player from recruiting past 5 pilots until Mission 12 is won — that's the mechanism "even as early as Act 1" would have to open up.
- Deploy caps are a **separate** lever, also Act-tied: `ACT1_DEPLOY_CAP = 5`, `ACT2 = 10`, `ACT3 = 15`. These say how many of the roster can actually fight one mission — independent of how big the roster itself is.
- Rourke's promotion (Mission 12 → Capt., Mission 24 → Maj.) is keyed to **lance count**, not lance membership — she's promoted for commanding a 2nd/3rd lance, whether or not anyone's actually recruited into it yet.

## What "20, from Act I" actually asks for

Two changes bundled together:

1. **Raise the ceiling 15 → 20.** Cheap, structurally — the game already has a 4th (and 5th) lance slot sitting unused in the scaffold, sized for Gladiator. Turning on a 4th lance for this campaign is well inside existing plumbing, not new plumbing.
2. **Let recruiting happen before the lance that houses it is "granted."** This is the real ask, and it's a structural change, not a numbers tweak — it means recruiting is no longer gated by Mission 12/24's win, only by whether you can afford it. That's what makes "if he did before Act 2/3, his lance is already full" possible: right now a lance can't even *hold* anyone until its story beat fires.

## What this touches, and what I'd do by default if you say go

- **Rourke's rank stays exactly as it is** — tied to the Mission 12/24 beat, not to roster size. A fully-staffed 4-lance company before she's actually promoted just reads as "her people were ready before the bars were," which I think is a fine, even good, beat — but it's your call, not an arithmetic one, so flagging rather than assuming.
- **Deploy caps stay exactly as they are** (5/10/15 by Act) — a 20-pilot roster in Act I still only fields 5 in any one mission. The other 15 sit on the bench. I think this is actually the *point*, not a bug: it turns "recruit early" into building a deep reserve against permadeath (closer to your original "natural balance / rotating cast" reasoning from the early spitball days) rather than an early power spike. Worth you confirming that's the reading you want, since if you actually want early deploy caps raised too, that's a real difficulty-pacing change on top of this one.
- **The "[Second/Third] Lance granted — five berths, empty, go recruit" Debrief callout** currently assumes an empty lance. If a lance can already be full by the time that story beat fires, that line is just wrong in that case and needs a second branch ("already staffed") — small, but real, and it's a line, so it may be worth your own pass rather than a guessed rewrite.
- **Cost is the natural pacing lever**, and I'd lean on leaving it that way rather than adding a second, harder per-Act recruit limit on top of the lance gate. Discretionary recruiting already competes with gear-tier upgrades for the same points pool, and the personal-points earn rate was already tuned so a favorite pilot can max out well inside one campaign — an early recruiting binge already has a real opportunity cost against gearing up your existing five. But if you want a hard "no more than N before Mission 12" backstop regardless of points, that's a one-line addition, just tell me the number.

## Open questions, in order of how much they change

1. Does Rourke's rank stay on the beat (my assumption), or should it track roster size instead?
2. Do deploy caps stay Act-gated at 5/10/15 even with a bigger early bench (my assumption), or did you want early deploys bigger too?
3. Is 4 lances × 5 = 20 the right shape, or were you picturing something else (e.g. a lance that holds more than 5)?

## Docs this makes stale, once decided

- `claude/build_log/engine_systems/squad_and_deploy_structure.md` — the authoritative lance/deploy-cap doc, needs its "3 lances ever granted, 15 ceiling" section corrected to 4/20.
- `Bloom_Wars_Now_And_Next.md` — "Needs Maxime's call" already carries a related, still-open item (#5: should `MAX_LANCE_SIZE` scale with the Act II/III deploy caps?) that's adjacent to but distinct from this ask; worth resolving both at once rather than in two passes. Deliberately not touched tonight — that file is large enough that a previous session flagged it needs a dedicated, careful pass, not a drive-by edit at the end of a session.
- `Bloom_Wars_Independent_Campaign_The_Amaranth_Reckoning.md` §6/§9/§10 — already corrected once (25 Aug) for the lance-count math when it assumed 4 lances instead of 3; would need a second correction if this ships (back to 4, this time for real).

**Status: waiting on your go, and on the three questions above.** No code touched.
