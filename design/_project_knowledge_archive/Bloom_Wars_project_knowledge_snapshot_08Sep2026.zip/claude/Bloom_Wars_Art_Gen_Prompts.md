# Bloom Wars — Gemini Art-Gen Prompt Kit

For Maxime, generating reference/decor/environment art in Gemini (Nano Banana) on the Pro plan.
Built from the locked values in the GDD (§12), Data Pack, and the actual `TILE_COLORS` in `Battle.ts`.

## Read this first: what to generate here vs. what to leave alone

The unit icons (the triangle/square/diamond/circle-bar shapes) are **code-drawn on purpose** — that's
the reversible placeholder system locked in GDD §12, and it's what actually encodes gameplay info
(path, faction, tier, HP) at a glance. AI-generated art is bad at holding a strict symbolic language
consistent across 12+ separate generations — the shapes will drift, and you'll lose the "read it in
under a minute, no legend" property the whole system is built around.

Where Gemini is genuinely useful right now: terrain texture/mood art, mission-briefing backgrounds,
propaganda/flavor art, and portraits — anything that's *atmosphere*, not a stat encoding. Use this kit
for that. Leave the unit shapes alone until the game's fun is actually proven.

## Style anchor — paste this before every prompt below, or as a first "establish the look" generation

```
Top-down 2D tactics game environment art, in the visual register of Advance Wars: Days of Ruin —
clean, chunky, readable shapes, but muted and desaturated, not cheerful. Flat/cel-shaded coloring,
minimal texture noise, strong value contrast so shapes stay legible at very small size (32x32px
in final use). Grim, casualty-heavy military tone in the background details — rubble, damage,
overgrowth — while the color language itself stays clear and non-muddy. No painterly brushwork,
no photorealism. Think: a strategy-game tileset, not a painting.
```

## Terrain tiles

Target: 32×32 final size (generate larger, e.g. 512×512, then downscale). One tile type per generation,
top-down orthographic, edge-to-edge (no border/vignette), tileable/seamless where the type repeats
across a map (plain, scrub, rubble, ridge especially).

| Tile | Anchor hex | Prompt fragment |
|---|---|---|
| Plain / ferrocrete | `#3A4636` | cracked ferrocrete pavement, dark olive-grey, faint weathering |
| Road / rail spine | `#5A5A5A` | flat asphalt/rail-bed grey, subtle lane wear marks |
| Open scrub | `#455233` | dry low scrub vegetation, dark muted green, sparse |
| Rubble | `#8A7A5F` | collapsed masonry rubble, tan-brown broken concrete chunks |
| Structure / habblock | `#55606B` | blue-grey prefab habitation block rooftop, top-down |
| Bloom mat | `#4A2E3A` | organic biological growth mat, dark maroon-purple, faintly wet/pulsing texture |
| Ridge / elevated | `#6A5A4A` | rocky elevated brown terrain, sharp shadow edge denoting height |
| Water / sump | `#2A4A5A` | dark stagnant teal water, industrial runoff sheen |
| Deploy pad | `#2E5C7A` | steel-blue military deploy pad, painted markings, top-down |
| Bloom spawn seam | `#7A2430` | dark red fissure in the ground, faint organic glow at the seam |
| Extraction tile | `#3D8A4A` | green marked extraction zone, stenciled ground markings |
| Hold-zone tile | `#8A7A2A` | olive-gold hazard-striped hold zone, top-down |
| Blockhouse wall | `#151515` | near-black reinforced wall segment, top-down, heavy shadow |

## Mission briefing / mood backgrounds

```
[style anchor] + a wide establishing shot of [location from the mission briefing — e.g. "a
half-collapsed urban habblock district under grey overcast sky, bloom-mat growth creeping up
the walls"], no characters in frame, muted color grade, used as a briefing-screen backdrop.
```

Pull the actual location description straight from the relevant mission's briefing text in
`campaign.ts` / the Data Pack so the art matches what's written, not a generic guess.

## Consistency trick

Gemini/Nano Banana supports image + text conditioning. Once you get one tile or background you
like, re-upload *that image* alongside the next prompt ("match the exact color grade and rendering
style of the attached image, but depicting [next thing]") instead of relying on the text prompt
alone each time. This matters more than any wording — it's the difference between a coherent set
and 13 tiles that all look like they're from different games.

## If you do want to experiment with unit/portrait art later

Species physical descriptions already exist in the Qiraki bible docs (`Qiraki_Physical_Description_Bank.md`)
— worth pulling those in verbatim for portrait prompts rather than re-describing Human/Hiopi/Osnius
from scratch, so game portraits stay consistent with the book continuity. Ask and I'll pull the
relevant passages when you're ready for that.
