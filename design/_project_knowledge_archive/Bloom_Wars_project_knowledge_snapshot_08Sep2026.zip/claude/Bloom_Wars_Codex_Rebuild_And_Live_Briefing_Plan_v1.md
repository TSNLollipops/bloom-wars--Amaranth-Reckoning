# The Bloom Wars — Codex Rebuild & Live Mission Briefing: Plan v1

*Written 2 Sep 2026, in response to Maxime: "plan adjust codex. its not my vision how it went down and there are many things missing from it... my problem with whats shipped is warden roster and mission briefing." Status: **shipped 4 Sep 2026** — see §8.*

## 0. The honest headline, before anything else

Nothing you're unhappy with is a build mistake sitting there broken. It's a sequencing gap: on 1 Sep, "Codex" got claimed by a fast, cheap win (typing up the existing player manual into an in-game screen) instead of the real thing the design doc always meant. That shipped screen is still just the manual — Controls, Terrain, the Class Triangle, and so on — wearing a nicer coat of paint. The actual lore/roster/bestiary codex you're picturing was *never built*, not even the part you'd assume is basic. Separately, and this is worth knowing before you feel behind: **the Coalition/universe lore content mostly already exists.** It's written, it's good, it's sitting in docs. It was just never wired into the game. More on that in §5 — it's genuinely better news than "we have to invent it."

The two specific things you flagged — Roster and Mission Briefing — turn out to be two different flavors of the same underlying problem, and neither is a quick patch. Below is the diagnosis for both, then a real plan.

## 1. What "the Codex" actually is right now — verified against the real files, not memory

**`src/scenes/Codex.ts`, built 1 Sep 2026.** Nine sections: Controls, Reading the Board, Terrain, Health/Shield/Collapse, the Class Triangle, Abilities & House Rules, Objectives, **Roster**, **Mission Briefings**. Every one of those nine is hand-typed static text, transcribed by a person (well, by me) from the standalone `HOW_TO_PLAY.html` reference page — not read from that file at runtime, not read from anything live. It's reachable from the Main Menu (no save required) and from the in-play pause menu. `src/data/codex.ts` — the actual data file the original design doc (`Bloom_Wars_Codex_Design_v1.md`) always meant to hold real, unlock-gated lore entries — **does not exist.**

Two plain-language things worth being clear on, since "codex" gets used loosely:

- **"Static" means baked into the code at build time — the same for every player, every save, forever.** It can't say "here's your actual squad" because it has no way to look at your save file. It's a rulebook page, not a readout.
- **"Data-driven, unlock-gated" (the original design) means a real list of entries, each with a condition for when it's allowed to show ("after Mission 6," "once you've met this enemy," "always"), that the game checks against *your specific save* every time you open the screen.** That's the difference between a manual and a codex. Right now you have the manual.

So when you opened the Codex and it didn't feel like "your vision," that's accurate — it's genuinely not that vision yet. It's a different, smaller thing that happened to get the same name.

## 2. "Warden Roster" — diagnosed

The Codex's "Roster" section is the manual's explanation of *how rosters work as a game concept* (lances, chassis, path assignments) — not a list of your actual pilots. It can't be, today: `Codex.ts` has zero connection to `CampaignState` (the object that holds your actual save — pilot names, who's alive, ranks, gear). It doesn't import it, doesn't read it, has no code path that could.

**What you actually want exists, mechanically, just not here.** `Hangar.ts` and `TransporterPad.ts` (the pre-mission squad-review screen) already render your real, live roster off `CampaignState` every time you open them — that machinery is proven, not hypothetical. Separately, `Bloom_Wars_Personnel_Codex_Entries_v1.md` (written 2 Sep) already has real prose bios for all five Act I pilots, their five Meks, and the CO, each with a `statusText` function that's supposed to read live campaign state ("alive and serving," "restocked after Mission 4," "lost at Mission 12" — whatever's actually true for *that save*) instead of a fixed line. That content is done. It was written specifically to be wired into a real Personnel tab and never was.

**Your actual ask — "should be only accessible via the in-save codex" — is a real, sensible design call, and it falls out of the mechanics almost for free.** A live roster needs a save to read. The Main Menu's Codex button gets pressed before any save is loaded (that's the whole point of a main menu). So:

- **Reached from the Main Menu (no save loaded):** Personnel — and, for the same reason, World and the Bloom Bestiary, since those unlock off mission-complete and first-encounter state that also only exists inside a save — either don't appear as tabs at all, or appear greyed out with something honest like "start or load a campaign to see this." Systems, Ranks & Command (flavor-only, not tied to any save), and Glossary can stay fully browsable with no save, the same way a new player might want to check Controls before ever hitting Continue.
- **Reached from the in-play pause menu (a save is live):** every category is real, live, and gated by *that save's* actual progress — a fresh Warden Company save and one 30 missions deep would show visibly different Personnel/World content, correctly.

This is the same discipline the Main Menu already uses for CONTINUE/LOAD GAME (both grey out with no save) — not a new pattern, just applying an existing one to a screen nobody had applied it to yet.

**What this costs, plainly, so you're deciding with real numbers, not a vibe:** building a real Personnel tab means (a) writing the actual unlock/status-lookup code against `CampaignState` — the "read live state" half of the Personnel doc's own design was never built, only planned — and (b) building the save-aware/no-save-aware split above. Not enormous, but it's real engineering, not a copy-paste of existing text.

## 3. "Mission Briefing" — diagnosed, and this is the one with two different things wearing one name

**Thing one: the Codex's "Mission Briefings" manual section.** Same as Roster — static, explains the *concept* of a briefing, not an actual mission's content. Harmless, and not what you're actually unhappy about.

**Thing two, the real one: asking the CO for a briefing, in the Hub, by typing "brief" (or "aoc, brief" from anywhere on his deck).** This is a real, live, already-wired chat command — built 2 Sep, the same day "brief" and "debrief" got correctly split apart so they don't say the same thing anymore. Right now, **every single time, regardless of save state or which mission is next, the CO says the exact same line:**

> "No formal briefing drawn up yet — check the mission board for what's on offer."

That's a deliberate, flagged placeholder — not a bug, the build log for it says so directly, and names the two real options that were left on the table: (b) at least name-drop the next available mission, or (c) build a genuine per-mission objective briefing. **What you're describing — updates as you advance, includes a passive scan so you're not walking in blind — is option (c), for real this time, plus a new piece nobody had proposed yet: pre-mission recon.**

Read plainly, this needs two things layered together:

**3a. Make the briefing text itself real and live.** Instead of one hardcoded string, the CO's response reads "whichever mission is next in the player's campaign" (the same lookup `MapSelect`/`TransporterPad` already do) and says something real about it — objective type, a flavor line matching the mission's own briefing register (the GDD is explicit that briefings state the task and nothing else, no editorializing — worth keeping that same discipline here). This is genuinely "updates itself as you advance" for free, the moment it reads from the campaign instead of a fixed string, because "next mission" is always a live question, never a fixed answer.

**3b. The passive scan — this is the new part, and I want to be direct that it's new scope, not a tweak.** Nothing like this exists in the engine today. Right now a player's actual first look at enemy composition and placement is when the mission literally loads and fog-of-war starts revealing it in real time. What you're describing is intel *before* that — the CO (or a scan mechanic) telling you something about what you're walking into, before you commit to deploying. That's a real system: it needs a decision about what it reveals (see §4), where it surfaces, and it touches tactical planning and difficulty, not just UI. This is exactly the kind of thing the project's own rule says to flag before building rather than just doing it — so I'm flagging it, not building it.

One thing worth knowing in plain terms: every mission's enemy composition and starting positions already exist as real data (`data/campaignAmaranth.ts`, per-mission enemy waves) — this isn't inventing new mission content, it's exposing data that already exists to the player, on purpose, before the mission starts. That's a much smaller lift than it might sound like; the actual design work is deciding how much of it to show and where.

## 4. Real open questions — your call, not guessed at

Three genuine forks here, not busywork questions — each one changes what actually gets built:

1. **Sequencing.** This plan is really two separate workstreams — (A) wiring the six already-drafted lore categories into a real Codex, with the save-aware split from §2, and (B) building the live briefing + passive scan from §3. Do you want A first, B first, or one pass covering both? My honest read: B is the smaller, more self-contained build and directly fixes the sharper of your two complaints (walking in blind); A is bigger (new data module, new UI tabs, the unlock-evaluation logic) but is what actually delivers "the lore dump you pictured." Neither blocks the other technically.

   **Resolved 4 Sep 2026 — both, one pass.** ("both of them. you got time")

2. **How much the passive scan actually reveals.** This is a real difficulty/tone call, not an engineering one. Enemy composition and count only (a text readout — "scans show roughly a dozen hostiles, mixed Crawlmass and Splitfang") keeps positioning and pacing a real surprise. Composition plus rough positions (a partial map reveal — a few tiles or zones flagged, not full vision) gives real tactical planning info, closer to what "scan" implies literally. A full readout (composition, positions, terrain hazards, objective specifics) is the most XCOM-like but arguably removes most of the "walking in blind" tension the game currently has by design in a few missions (the Build Brief is explicit that some things — like the Mission 1a ambush mechs — are deliberately never explained; a scan mechanic needs to know it isn't allowed to spoil those).

   **Resolved 4 Sep 2026 — composition & count only.** No positions, no stat readout.

3. **Where the briefing + scan actually lives.** Extending the CO's existing "brief" chat command (cheapest, matches how brief/debrief already work, stays in his voice) versus a dedicated pre-deployment screen (more visual, more build, but a more natural home for something you're meant to check every time rather than something you have to remember to ask for) versus both — a quick chat heads-up plus a full panel on the squad-review screen before BEAM DOWN.

   **Resolved 4 Sep 2026 — Freespace-style full panel, opened the moment the brief is accepted from the CO.** Not an inline chat reply.

I've got recommendations on all three below, in the questions — happy to just build my own read if you'd rather I make the call, but these genuinely change the shape of what ships, so I wanted your eyes on them first.

## 5. The good news, restated plainly: the "lore dump" already exists

Worth separating from the two build problems above, since it's not actually a gap the same way. As of 2 Sep, this project already has real, finished-draft content for:

- **World / Coalition lore** — `Bloom_Wars_Coalition_Lore_Codex_Entry_Plan_v1.md`. Three revisions, gated by real story beats (Mission 1, Mission 20 after the Marrow duel, Mission 36 relief-fleet contact), naming locked ("the Coalition," full formal name held back until it's actually earned in-story), checked against the naming lock.
- **Bloom Bestiary** — `Bloom_Wars_Bloom_Bestiary_Codex_Entries_v1.md`. Nine live archetype entries, in encounter order, written in-character.
- **Personnel** — `Bloom_Wars_Personnel_Codex_Entries_v1.md`. Five pilots, five Meks, the CO — bios plus the dynamic-status design from §2.
- **Systems, Ranks & Command, Glossary** — each has its own `_v1` entries doc too.

None of this is missing or needs inventing from scratch. It needs *wiring* — the mechanical work in §2/§4 of getting a real `src/data/codex.ts` built, `Codex.ts` extended with real tabs, and the unlock-condition checks actually evaluated against `CampaignState`. That's real work, but it's a known, bounded shape, not a design problem.

## 6. Docs this touches, once decisions land

`Bloom_Wars_Codex_Design_v1.md`'s own status section (§11) still frames "extend `Codex.ts`" as the next open step — now that this plan is built and shipped (§8), that doc's status line needs a pointer here so it doesn't go stale the way a few other docs in this project already have.

## 7. Naming-lock check

Nothing above introduces a new proper noun — "the Coalition," "Coalition of Enlightened," and every other term referenced is already-locked, already-approved vocabulary from the docs cited. No code, filenames, or UI strings proposed here. Confirmed clean at build time too (`tools/lint-spoiler.mjs` passed on every commit in this pass).

## 8. Status

**Shipped 4 Sep 2026.** Both workstreams built, tested, and committed to the real repo in one pass, per the resolution in §4.1. Full build-out, interpretive calls, verification results, and open follow-ups are in `claude/Bloom_Wars_Build_Log_Addendum_CodexRebuildAndLiveBriefing_04Sep2026.md`.

Short version: Part B (live briefing, §3) reads the real next mission and shows real composition-and-count-only intel, replacing the old hardcoded placeholder line — reached the same way as before, by asking the CO for a brief, now opening a real Freespace-style full panel instead of a chat reply. Part A (lore Codex, §2/§5) wires all six drafted lore categories into real, save-aware Codex tabs, split exactly along the Main-Menu-vs-in-play line this doc proposed in §2.

Not built in this pass, and not blocking: House Amaranth's own Personnel/Bestiary/World content (Warden-only scope for now), the CO's real display name (still a placeholder string), and Rourke's "empty bio" flavor idea from her own source doc. All three are named explicitly in the build-log addendum so they don't get lost.
