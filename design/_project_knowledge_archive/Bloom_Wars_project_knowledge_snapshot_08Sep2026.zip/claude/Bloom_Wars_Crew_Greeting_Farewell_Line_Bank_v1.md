# THE BLOOM WARS — Crew Greeting & Farewell Line Bank v1

**Content pass only — zero code, when written.** Written 1 September 2026, at Maxime's direct request, right after the CO's own bespoke bank (`Bloom_Wars_CO_Bespoke_Dialogue_Bank_v1.md`) — "can you do a greeting goodbye pass for the other npc?" This is the crew-wide version: not one fixed voice like the CO, but the shared nine-catalyst axis every other NPC in the Hub already draws from (`ALL_CATALYSTS` — wolf/dog/cat/crow/raven/bear/fox/rabbit/shark).

**Update, 1 Sep 2026 (later the same day): wired into the real code and live-verified.** See §11 below — this bank is no longer content-only.

Picks up two items already sitting on record, not invented fresh here: `Bloom_Wars_Chat_Keyword_Categories_Plan_v1.md`'s own **#1 Greeting** and **#3 Farewell**, both named in that doc's recommended build order as cheap, near-zero-new-content, high-value additions — the two categories most directly answering what a live playtest actually surfaced (a player walking up to and away from crew with nothing catalyst-flavored bracketing the conversation).

## 0. Scope call, stated plainly

Catalyst-only, not crossed against Echo or Stage the way the main `LINE_BANK` is. That's a deliberate sizing choice, not an oversight: the Keyword Categories doc itself sizes Farewell/Advice as "a modest, well-scoped content bank," and a full catalyst×echo×stage cross here would be 81+ cells before a single line gets written — the wrong size for a quick pass. If greeting/farewell content later turns out to want an Echo or Stage read (a Command-stage pilot getting a sharper farewell than a Green one, say), that's a real follow-on, not done here. Four lines per catalyst per category — enough that two visits in a row don't obviously repeat, not so many this turns into a marathon.

## 1. Wolf (teamwork)

**Greeting:**
1. "There you are — we were about to start without you."
2. "Good, the whole crew's closer to together now."
3. "Hey. Who else is around today?"
4. "Perfect timing, actually — needed another set of hands."

**Farewell:**
1. "Go on, we've got this covered."
2. "Catch up with the others, yeah? Don't disappear on us."
3. "See you back with the group."
4. "Don't be a stranger — we're better with you in it."

## 2. Dog (loyalty)

**Greeting:**
1. "Hey. Good to see you, for real."
2. "Was hoping you'd swing by."
3. "There you are. I mean that."
4. "Good — was starting to wonder where you'd gotten to."

**Farewell:**
1. "I'll be right here if you need anything."
2. "Take care of yourself out there."
3. "Same time tomorrow, yeah?"
4. "You know where to find me."

## 3. Cat (selfishness)

**Greeting:**
1. "Oh. It's you."
2. "You want something, or is this just a social call?"
3. "Fine, you can stay. Doesn't cost me anything."
4. "Make it quick, I was in the middle of something."

**Farewell:**
1. "Yeah, yeah. Go."
2. "Don't take it personal if I don't walk you out."
3. "That's my cue to get back to my own business."
4. "See you whenever. I'll survive either way."

## 4. Crow (indulgence)

**Greeting:**
1. "Finally, someone worth talking to shows up."
2. "Tell me something fun happened today."
3. "Perfect timing — I was bored out of my skull."
4. "Oh good, an excuse to stop what I'm doing."

**Farewell:**
1. "Don't have too much fun without me."
2. "Go on — I'll find something to entertain myself."
3. "Come back when there's actually something interesting to talk about."
4. "Later. Try not to be boring in the meantime."

## 5. Raven (instruction)

**Greeting:**
1. "Good timing — I've got something worth telling you."
2. "You look like you could use a pointer or two."
3. "Come here, let me set you straight on something."
4. "Ah — someone willing to actually listen for once."

**Farewell:**
1. "Remember what I told you."
2. "Go put that into practice."
3. "Think about what we covered."
4. "You'll do better next time, now that you know."

## 6. Bear (isolation)

**Greeting:**
1. "...Didn't expect company."
2. "You can sit. I won't talk much."
3. "Hm. You again."
4. "Not much to say, but go ahead."

**Farewell:**
1. "Alright. I'll be here. Alone, probably."
2. "Go on. I've got quiet to get back to."
3. "See you around, I suppose."
4. "That's enough talking for one day."

## 7. Fox (trickery)

**Greeting:**
1. "Well, well. Look who wandered over."
2. "Careful, I might talk you into something."
3. "You've got that look — like you already know I'm trouble."
4. "Come closer. I don't bite. Much."

**Farewell:**
1. "Watch your back — mine too, probably."
2. "Go on, before I talk you into something dumb."
3. "See you. Try to keep up."
4. "Later. Don't trust everything I just told you."

## 8. Rabbit (nurturing)

**Greeting:**
1. "Oh, hi — how are you holding up, really?"
2. "There you are. Have you eaten anything today?"
3. "Come sit, you look like you need a minute."
4. "Hey — I've been meaning to check on you."

**Farewell:**
1. "Take care of yourself, okay?"
2. "Come find me if you need anything at all."
3. "Get some rest if you can."
4. "I'll be thinking of you — go on now."

## 9. Shark (ambition)

**Greeting:**
1. "You. Good. I've got a minute for you."
2. "Talk fast, I've got places to be."
3. "What do you need — let's make this count."
4. "Good, you're here. Let's not waste the time."

**Farewell:**
1. "Go get something done."
2. "Don't stand around — momentum matters."
3. "See you at the top of whatever's next."
4. "Make the most of the rest of your day."

## 10. Naming-lock safety check

No proper nouns invented anywhere in this bank — no places, no factions, no new characters. Nothing here echoes or abbreviates "The Synker Wars," and there's no new vocabulary to check against the absolute reserved term in the first place.

## 11. What this doesn't do — updated 1 Sep 2026, now wired and live-verified

**This bank is no longer content-only.** The same day it was written, `src/data/chatIntent.ts` gained a real `detectSmallTalk()` recognizer and `src/data/smallTalk.ts` (new) transcribed all 72 lines here verbatim, wired into `src/scenes/Hub.ts`'s `submitChat()` — a player typing "hey"/"bye" (or any of the other trigger phrases from `Bloom_Wars_Chat_Keyword_Categories_Plan_v1.md`'s #1/#3) to a nearby crew NPC now gets a real line from this bank, picked at random from that NPC's own catalyst's Greeting or Farewell list.

**Live-verified, not just type-checked, in Maxime's own running game:** typing "hey" to Cpl. Priya Anand (catalyst wolf) produced "Perfect timing, actually — needed another set of hands." (Wolf Greeting #4, verbatim); typing "bye" produced "See you back with the group." (Wolf Farewell #3, verbatim). Both exact matches confirm the transcription and the picker function both work correctly. Full account, including the routing logic and the CO's own separate bespoke treatment: `claude/Bloom_Wars_Master_Index.md`'s "Chat small-talk wiring" section.

Not crossed against Echo or Stage — see §0, unchanged. Doesn't touch the CO's own bank (`Bloom_Wars_CO_Bespoke_Dialogue_Bank_v1.md`) — he stays on his own bespoke content, not this catalyst pool, matching the reasoning that doc already lays out for why he needed something separate in the first place; the wiring confirms this in code too, via a `pilotId === CO_PILOT_ID` check that routes him to his own bank instead.
