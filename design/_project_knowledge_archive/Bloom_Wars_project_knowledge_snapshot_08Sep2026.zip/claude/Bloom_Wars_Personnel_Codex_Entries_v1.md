# The Bloom Wars — Personnel Codex Entries v1

*Written 2 Sep 2026, per Maxime's own direct instruction: "make sure personal bios point to background info chosen for the A in the formula. to give player info on their pilot and meks and co." This is the third content pass in the current Codex push (Coalition World entry → Bloom bestiary → Systems → this), and the first one where the sourcing rule bites hardest: every background-derived line below is checked against `Bloom_Wars_NPC_Catalyst_Formula_Closing_And_Roster_Assignments_v1.md` §4's own locked table, not invented fresh or pulled from memory. Also checked against `Bloom_Wars_Rank_And_Command_v1.md` (titles), `Bloom_Wars_Independent_Campaign_The_Amaranth_Reckoning.md` (roster, callsigns, chassis), and `Bloom_Wars_Codex_Design_v1.md` §4/§7 (the dynamic-status problem and the two already-shipped sample entries this doc carries forward). Same `_v1` status as Bloom Bestiary and Systems — a full pass for reaction, not locked.*

## 0. Scope, and three things handled with care rather than glossed over

**What's covered: the five named Act I pilots, their five paired Meks, and the CO.** Rourke, Bosk, Iyari, Anand, Lask — the roster that's actually in front of the player from Mission 1 — plus `mek_rourke`, `mek_bosk`, `mek_iyari`, `mek_anand`, `mek_lask`, plus the ship's Commanding Officer. That's the "pilot, meks, and CO" the instruction named.

**What isn't covered, on purpose, not an oversight:** generated Second Lance and Third Lance recruits (they form at Mission 13 and Mission 25 — no fixed identity to write a bio against yet, since the character editor generates them per-save), House Amaranth's own five fresh pilots and ten Meks (a real next pass, once you want it), and Marrow (excluded from the background formula by the same explicit design decision that excludes Rourke — see below). If you want any of these next, say so; none of it is blocked on anything.

**One: Rourke has no background, and that's not a gap in this document, it's the formula working as designed.** The Catalyst Formula doc excludes exactly two people from getting a background at all — Rourke and Marrow, the two player-controlled protagonists — by Maxime's own explicit instruction to that pass. Her entry below carries her existing bio (already shipped, `Codex_Design_v1.md` §7) unchanged, with no background section, because there genuinely isn't one to point to. Her Mek, `mek_rourke`, is a different matter — Meks aren't excluded, so it has a real background like every other Mek below.

**Two: the CO's placeholder display name never appears below, and shouldn't appear in the actual codex UI either.** His in-code `displayName` is currently the literal leftover string `"Arangement of Content"` — not a real name, flagged as a typo/placeholder in the Catalyst Formula doc itself. The entry below refers to him only as "the CO" / "the ship's Commanding Officer," the same way every other doc in this project already does. **Practical implication for whoever builds this into `Codex.ts`:** if the Personnel screen renders `displayName` directly the way a pilot entry would, the CO's card needs a special case — render his rank/role instead, not that field — until Maxime picks a real name. Worth flagging in code as a one-line TODO comment when this gets built, so it doesn't ship a typo string to players by accident.

**Three: the dynamic-status rule, restated concretely because it applies to every single entry below.** Per `Codex_Design_v1.md` §4: nobody's status text gets a mission-specific or campaign-specific branch. No entry below says "safe until Mission 12" or "scripted to survive Act I" — because the game itself doesn't know that until it happens, and a codex that knew it ahead of time would be spoiling the game's own permadeath system to the player reading it. Every status line is a live read of whatever `campaignState.getPilotStatus()` (or equivalent) actually returns for that save, full stop. The "Status" line under each entry below is an *example* of what that might render as right now for a save where nothing's gone wrong yet — not the only possible text, and not a promise about what happens in any specific save.

**Rourke gets one extra layer of the same care, restated from §4's own open flag:** her status text can never imply she's at risk of dying, because mechanically she isn't (a failed mission with her down is a retry, not a loss) — but it also can't read as an obvious invincibility wink that breaks the fiction. The line below ("still in the field") is a first pass at that balance, not a final answer.

## 1. The entries, roster order

> **codex_pilot_rourke** *(always visible — protagonist)* — *bio already shipped, `Codex_Design_v1.md` §7, carried forward unchanged*
> **2nd Lt. Dessa Rourke — "Lark"**
> Meeps. Human. Green when this started, and it showed — quick, aggressive, not yet a commander. Still leading from the front. The unit under her now carries the opposite of her own callsign.
>
> By Mission 12 she's carrying Capt.'s bars, and Maj.'s by Mission 24 — Company Commander over the whole force, both times. Neither promotion pulls her out of Lance A. She's still its Lead in person, still the same lance she's run since Mission 1, just with more of Warden Company answering to her on top of it.
>
> *Paired Mek — `mek_rourke`, catalyst Raven.* Grew up on a working dock on Glasswater itself, close enough to the sector capital's real labor to know exactly what keeps a comfortable world running underneath it. That's the same instinct that makes a good Mek: quietly making sure Rourke's own rig is right before she ever has to ask.
>
> *Status (example): still in the field. Warden Company's line has never reported her down for good — if it ever does, that's a fight still being fought, not one that's over.*

> **codex_pilot_bosk** *(unlocks — Mission 1, roster join)*
> **M.Sgt. Halvard Bosk — "Anvil"**
> Tank. Human. Came up through House Amaranth's own regulars before Warden Company folded him in. Raised in a garrison quarter on Glasswater itself — comfortable enough by any Reach standard, but a garrison childhood shows you exactly what that comfort actually costs to keep, and Bosk came out the other side of it not cynical, just exact. He explains a thing once, correctly, and expects you to have heard him. That's the instinct every newer pilot in the company leans on without being told to.
>
> *Paired Mek — `mek_bosk`, catalyst Bear.* A different upbringing entirely from his own pilot's — Tallowmere's smoky industrial anchor world, hit hard and early, learned to keep its own counsel and just work. The steady, self-contained presence at Bosk's back that never needs him to check on it.
>
> *Status (example): active, serving with Warden Company.*

> **codex_pilot_iyari** *(unlocks — Mission 1, roster join)*
> **Pvt. Tegan Iyari — "Foxfire"**
> Meeps. Hiopi — centauroid frame. Grew up on Emberfall, a refinery world the Bloom had already reached, close enough to an unmarked preserve boundary nobody in her family ever fully explained. Real frontier hardship the whole way through, and she met it by finding something to laugh about anyway, every time — not a habit she picked up later, the same thing that makes her the one already cracking a joke before anyone else has finished processing what just happened.
>
> *Paired Mek — `mek_iyari`, catalyst Fox.* Raised on money that never quite matched the plateau world around it, tested into a prestige Core academy despite frontier roots — still finding its own footing, quick and adaptable because nothing's forced it to be anything else yet. A fast, improvising presence that suits a Meeps pilot who moves the same way.
>
> *Status (example): active, serving with Warden Company.*

> **codex_pilot_anand** *(unlocks — Mission 1, roster join)*
> **Cpl. Priya Anand — "Farsight"**
> Reeps. Osnian — the first of her kind Warden Company's ever fielded. Raised in Skeinreach's weave-mill housing, one remove from anything that could honestly be called danger, trained locally alongside people she'd go on to actually serve beside. Nothing about her read is a standout, and that's the point — steady, exactly where the formation needs her, holding a Reeps line rather than chasing a kill count.
>
> *Paired Mek — `mek_anand`, catalyst Dog.* A comfortable, home-centered upbringing on Glasswater itself — the kind of loyalty that never had to be tested to become real. Distinct from Anand's own busier read: the Mek's job is simple devotion, not vigilance.
>
> *Status (example): active, serving with Warden Company.*

> **codex_pilot_lask** *(unlocks — Mission 1, roster join)*
> **Spec. Corin Lask — "Patch"**
> Munti. Human. Grew up on a fiber farm in Skeinreach, where a blight or a scrape isn't an emergency, it's Tuesday — quiet, unglamorous upkeep that just has to happen, every day, so everything else keeps working. That's the job now too, just with a squad instead of a field. He's not who anyone talks about after a mission goes well. He's the reason there's a squad left to talk about it.
>
> *Paired Mek — `mek_lask`, catalyst Rabbit.* Raised transient, ferried between Glasswater Reach's own barge routes rather than settled anywhere solid, and lost something real despite all that institutional shelter. Came out of it protective, specifically — the exact temperament for a Mek partnered with the one person in the company whose entire job is protecting everyone else.
>
> *Status (example): active, serving with Warden Company.*

> **the CO** *(always visible — command staff)*
> **[rank/name pending] — the ship's Commanding Officer**
> Raised inside the Understrand's own orderly, procedural culture from the start — an Academy Ward childhood on a dense arcology world, groomed for institutional service rather than combat. Steady, duty-bound, unremarkable in exactly the way that eventually puts someone in charge of an entire complement's worth of people, not despite it.
>
> *Catalyst: Wolf — team-first, formation-minded, the same read that makes him command staff rather than a line officer.*
>
> *No paired Mek — he isn't a deployed pilot.*
>
> *Status: does not use the live pilot-status mechanic — he's Hub-side command staff, not a deployed roster slot, so there's no mission-outcome branch to speak of here at all, live or hardcoded. Flag if that assumption's wrong and he's meant to be at any real risk.*

*A small, cheap connective note, worth having rather than losing: Lask and Anand land on the exact same catalyst, Wolf, from two completely different backgrounds — a farm kid and a mill-town Reeps. Nothing to fix; it's the formula working correctly (steady/team-first is a real, common read, not a rare one), and it's a nice bit of texture if either of their bios ever gets expanded scene-side — two very different people arriving at the same quiet loyalty.*

## 2. Naming-lock safety check

Every Sector, Planet, Birthplace Texture, and Academy name used above is copied verbatim from the Catalyst Formula doc's own already-locked table, which itself draws only from Background Zones v1's already-cleared vocabulary — no new proper noun anywhere in this document. Nothing here touches, echoes, or requires checking against either reserved term.

## 3. Status, and one unprompted idea worth floating rather than building

Personnel category now covers the whole Act I roster and the CO — pilot bios, Mek bios, dynamic-status handling all in one place. Next natural extensions, your call which: Second/Third Lance recruits once you want generated-roster bios (a genuinely different problem — no fixed identity to write against, more of a template-with-real-variance question than a bio), or House Amaranth's own five pilots and ten Meks, which already have full background data sitting in the Catalyst Formula doc's §4.2/§4.6 ready to write against the same way this pass did.

One idea, floated rather than decided, since you've said you want these when they come up: Rourke's entry above has no background section, which reads a little bare next to five pilots who all get one. There's a real, cheap connective tissue sitting right next to it — the Coalition codex entry's own Mission 20 beat has Marrow taunting Warden Company that "nobody's actually held Warden Company's own paperwork in years." Rourke's own file being the one genuinely empty one in the roster could be played as the same joke landing on her specifically, rather than just an absence. Not written into her entry above — flagging it as an option, not committing to it, since it'd be a real characterization choice about her, not just a formatting fix.
