# Stress & Morale — First-Pass Trigger Proposal, 26 Aug 2026

**Design pass only, zero code, not a locked decision.** Same framing as `Bloom_Wars_Character_Editor_v1.md` and `Bloom_Wars_Crew_Banter_Phrase_Bank_v1.md` — a real proposal to react to, not something being quietly built. Writing this now, while the tactical file is off-limits to me for a different reason (see the NPCNeeds addendum's Worry entry), because it's a genuine standing gap that doesn't need Maxime in the room to get a first draft — but it DOES need his sign-off before any of it becomes code, since "what moves a persisted number and by how much" is exactly the kind of new-system decision the project's own standing rule says to flag rather than just build.

## Why this, why now

`HubPilotSocialState.stress`/`.morale` have had a real persisted home since the Hub Build Plan's §19 (26 Aug). Nothing writes to either. It's been flagged as an open gap four separate times now — §19, §20, the NPCNeeds addendum, and again just now when I went looking for "what's buildable right now" and Worry (the strongest candidate) turned out to need a file that's temporarily off-limits. Stress/Morale is the next-best candidate for the same reason Worry was: it plugs into machinery that already exists (the persisted fields, the ambient-line-pool that already reads Stress for line selection in `pilot_creator.html`'s prototype) rather than requiring a new system from scratch. Unlike Worry, though, this one is a real design decision, not a locked one — hence a proposal, not a build.

## What already exists that this would reuse

- **The fields themselves** — `stress`/`morale`, plain numbers on `HubPilotSocialState`, same shape as `favorability`. `ensureHubSocialState()` already seeds and persists them.
- **A precedent for how a verb moves a number** — `favorabilityDelta` on `VerbOutcome`, already wired through Share a Drink and the three minigames' finish methods. A `stressDelta`/`moraleDelta` pair would sit right next to it — `verbs.ts`'s own comment already reserves this exact shape ("added when a real Stress-relief verb... does").
- **`pilot_creator.html`'s prototype** already reads Stress (≥70 = panicking) and a Morale panic threshold to pick which ambient line/echo an NPC draws — the read side of this is already designed and tested against real content, just not wired to anything that writes the number for real gameplay yet.
- **The CO/grotto hook** — Antfarm §11.3 already parks the CO as "a Stress-relief conversation partner once the grotto opens," kept deliberately separate from the CO-romance half-joke. That's a named, on-record consumer for Stress specifically, once the grotto's actual room content exists.

## Proposed triggers — sorted by how confident I am they're right

**High confidence — these are already-built Hub interactions, just missing the number-move:**

- **Share a Drink** → small Stress relief, no Morale change. It's already a Stress-coded activity in the Rec Room's own fiction (Antfarm §11.2's drinking flavor), just not mechanically tied to the stat yet.
- **A minigame win** (peg board / poker / darts) → small Morale gain. A loss → nothing, or a very small Stress tick — open question below on whether losing should cost anything at all, since these are meant to stay "flavor-only... no gameplay effect beyond the bay's own point cost" per Antfarm §11.2's own resolution, and I don't want to quietly reverse that call.
- **Ask Out accepted** → Morale gain (for both parties, symmetric). **Ask Out rejected** → small Stress tick for the asker only, nothing for the one who said no.
- **Getting drunk** (`drunkUntil` set) → temporary Stress relief that expires with the drunk state itself, rather than a permanent change — matches the fiction (numbing a feeling temporarily, not fixing it) and gives Stress a reason to visibly recover on its own sometimes, not just via deliberate action.

**Lower confidence — plausible, but reaches toward mission/campaign state I haven't looked at, on purpose, since that file is off-limits to me right now:**

- **A mission outcome** (a pilot lost, a mission failed, a costly win) moving surviving crew's Stress/Morale is the most obvious "why would this number ever go up" trigger, and it's the one `pilot_creator.html`'s own "grief-worn (too many lost Muntis)" state already gestures at existing somewhere. I don't actually know today what data `Debrief.ts`/`campaignState.ts` expose at the moment a mission resolves, since I haven't opened those files this session — this needs your read on it more than mine, both because it's tactical-side data and because "does losing a mission hurt morale" is a real tone call for the game, not just a wiring question.
- **The needs counter** (hunger/thirst/sleep, already parked in the NPCNeeds addendum) was flagged there as a plausible future Stress/Morale writer too — not proposing it be un-parked, just noting the two ideas would eventually feed the same two numbers if both get built.

## What I'm deliberately not proposing here

- **No UI for it yet.** Same fork the needs-counter addendum already named for itself: a visible bar (Sims-style) vs. staying implicit and only surfacing through ambient-line tone and behavior. The Favorability readout just got a relationship-status tag (§27) and could plausibly grow a Stress indicator the same way — but that's a real UI decision, not defaulting to it here.
- **No actual delta numbers.** Even "small"/"large" above is placeholder language, not proposed constants — every weight already in this file (`BERTHS_EXPLORE_WEIGHT`, `RIVAL_AVOID_CHANCE`, etc.) started as a guess and got left as an explicitly-flagged placeholder rather than presented as tuned; I'd rather do the same here than invent numbers with no playtesting behind them.
- **No mission-side wiring**, for the reason above — genuinely don't have the read on what's available there right now, and won't guess at tactical-side data structure from memory.

## Open questions, for you

1. Does a minigame loss cost anything, or does Antfarm §11.2's "flavor-only" call stand as-is and only wins matter?
2. Is a mission outcome in scope for this pass at all, or is that explicitly Phase-4/later territory since it reaches into campaign-level state this doc isn't touching?
3. Visible bar vs. implicit-only — same fork the needs counter already left open, worth deciding once for both rather than twice.
4. Is the CO/grotto Stress-relief hook (Antfarm §11.3) meant to be the *primary* way Stress goes down, once that room exists — which would make Share a Drink/getting drunk more like stopgaps than the real mechanism?

Nothing above gets built until you've weighed in — this is the write-up, not the commit.

---

## Resolved, 28 Aug 2026 — all four open questions answered, and this proposal's own trigger list superseded by what actually shipped

Maxime's own `claude_Bloom_Wars_Needs_Counter_Spec_v1.pdf` (see `claude/build_log/engine_systems/needs_counter.md` for the full build account) opens by naming this exact doc and these exact four questions, and answers all of them directly:

1. **Does a minigame loss cost anything?** No. Antfarm §11.2's "flavor-only" call stands untouched, unchanged.
2. **Is a mission outcome in scope?** No. Stays out of this pass — reaches into `Debrief.ts`/campaign state the needs-counter spec doesn't touch either; partial coverage already exists via the hot-topics mission echo and Munti-grief lines built earlier this project.
3. **Visible bar vs. implicit-only?** Implicit. No new UI element — matches how Stage and relationship-stage already surface, through readouts and dialogue tone, not a Sims-style meter.
4. **Is the CO/grotto hook the primary mechanism?** Not yet — no real CO Stress-relief content exists to hang it on. For now the needs counter itself is the primary passive driver; Share a Drink, the minigames, and Ask Out stay the active, player-triggered counterweights.

**What this means for the "Proposed triggers" list above: none of it has shipped.** The needs counter answers the four open questions but is a genuinely different trigger mechanism than anything proposed here — it drives Stress/Morale off three off-duty meters (Hunger/Thirst/Sleep) crossing a low threshold, not off Share a Drink, minigame wins, Ask Out outcomes, or getting drunk. Every trigger in the "High confidence" section above is **still unbuilt** and still a live option for a future pass — this proposal isn't superseded so much as it's now one of two plausible sources feeding the same two numbers, exactly as its own "Lower confidence" section predicted the needs counter would eventually be. Worth Maxime's own read on whether the Share-a-Drink/minigame/Ask-Out triggers are still wanted now that Stress/Morale has a real driver, or whether the needs counter alone is enough for a while.

---

## Resolved, 1 Sep 2026 — the four "High confidence" triggers built, active alongside the needs counter

Forgotten Plans Audit pass. Closes the question the 28 Aug section above left open. Maxime's own call: "active trigger too. its mor ehuman to have passive and active trigger. and it fit my vision. your call on their value, some thing should decrase familiarity tho." — passive (needs counter) and active (this) both drive Stress/Morale now, side by side, neither replacing the other, exactly as he wanted. Specific numbers below were my own call under that latitude, not something he specified.

- **Share a Drink** → -8 Stress, no Morale change (`verbs.ts`'s `VerbOutcome.stressDelta`, applied in `Hub.ts`'s `shareADrink()`). Also stands in for **getting drunk** — `setsDrunk` already fires on every Share a Drink, so one instant relief tick covers both named triggers rather than building a second, timed effect that reverts when `drunkUntil` expires. Flagged as a deliberate simplification: the original proposal's version of "getting drunk" (temporary relief that expires with the drunk state) is not what shipped.
- **Minigame win/draw/loss** → Morale/Stress move together per game, not one flat number across all three — poker's swing is the widest (real-stakes feel vs. peg board/darts' lighter one). Peg board and darts: win +4 Morale, draw +1 Morale, loss +2 Stress. Poker: win +5 Morale, loss +3 Stress (no draw state in poker). This also answers open question 1 above a second, independent way and satisfies "something should decrease familiarity" without inventing anything new — all three minigames already had a Favorability hit on loss (-2/-3/-2) from before tonight; Stress/Morale just layers onto the existing win/draw/lose branches.
- **Ask Out accepted** → +10 Morale for the target NPC. **Rejected** → no Stress/Morale change.
- **Not shipped, flagged on purpose:** the original proposal's "symmetric both parties" (Ask Out accepted) and "small Stress tick for the asker" (Ask Out rejected). The player character has no walkable, ambient-tracked Stress/Morale state in `Hub.ts` — `verbs.ts`'s own header note: "Actor isn't modeled... always the MC" — so there's nowhere to apply either half. Named as a gap in code comments at both call sites, not silently dropped; a real follow-up if the MC ever gets ambient state of their own.

Open questions 2 and 4 above stay exactly where the 28 Aug section left them — mission outcomes and the CO/grotto hook are still out of scope, no real CO content exists to hang that hook on yet.
