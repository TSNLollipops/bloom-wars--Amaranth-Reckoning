# The Bloom Wars — Heirloom Naming Update, 2 Sep 2026

*Originally written the same day in response to Maxime reacting to the Glossary Codex doc's own §0 flag (whether "Severance" or "Requiem" was the name a player would actually see on the ability button). His answer: **"i think heirloom should simply have special heirloom name. like peregrine is called the celestial magi. in code term, its the requiem system."***

***RESOLVED AND SHIPPED, later the same day.** Bosk's weapon is **Gjallar**, and the naming treatment was extended to all ten Heirlooms at Maxime's own direction — first **"give it an epic fantasy sounding name. relate to its action, can be in another language. like zaibatsu"**, then, after the first pick landed, **"same pass for the other weapon name."** Sections 1-2 below are the original reasoning, kept; §3 is now the record of what was actually chosen and why; §4 is what still needs updating and where.*

## 1. What's actually decided here

Two separate naming levels, where this project had been quietly running one word ("Requiem") across both without noticing it was doing two jobs at once:

**The system itself** — what the GDD calls "The Heirloom: Severance," what the code currently calls `SEVERANCE`/`abil_severance` — is now **the Requiem system**. This is the mechanic's own generic name: one company-wide charge, an 8-tile line, no friend-or-foe exception, ignores the full-HP cap, Collapse-checks a Bloom's Vitality directly. Every pilot who ever wields one is wielding "a Requiem-system weapon," the same way every gear-tier item is "a Meeps weapon" regardless of which specific named gun it is.

**Each specific pilot's own weapon gets its own special title on top of that** — Maxime's own example, "Peregrine is called the Celestial Magi," is exactly the pattern the Independent Campaign doc's own 20-entry Heirloom table already used for nineteen of its twenty rows. The twentieth row was the problem: Bosk's own entry was simply labeled **"Requiem"** — the system's own name doing double duty as if it were also Bosk's specific title. It can only be one of those, and Maxime's own words put "Requiem" at the system level.

## 2. What was genuinely at risk

Worth having named honestly rather than just executed: "Requiem" was a *good* title for Bosk's own weapon specifically — a requiem is a mass for the dead, and this weapon passes from Bosk to Rourke at the exact moment he's lost. That is the best piece of thematic work in the original table, and it wasn't an accident.

**Gjallar keeps it.** Old Norse, "the resounding" — Heimdall's horn, the one blown once at the end, heard by everyone. It is still a sound made for the dead, still a thing sounded exactly once at the moment everything changes. The resonance survived the rename rather than being traded away for it, which is the whole reason this option beat the alternatives.

## 3. The names — decided and shipped, 2 Sep 2026

**The rule, so future additions don't have to re-derive it:**

- The **Heirloom** carries a grand name in a real language, chosen to describe **what the weapon does**, not what it costs.
- Its **signature ability** carries that same name, because the signature *is* the weapon firing.
- Every **other ability keeps a plain English field name**. That's the crew's own name for a move, not the house's name for an artifact — and keeping them plain is the only thing that stops the grand names from turning into noise.
- The **old design-doc title is kept as an epithet** (`HeirloomDef.epithet`), not discarded. Several of them are good, and a codex line reads better as "Skuld, the Widow's Ledger" than as either name alone.

This also honours a convention this project already held: Heirloom-grade gear "should sound like inherited privilege rather than earned gear." Every other tier of kit in the game is deliberately punchy and plain-spoken by comparison, which is what makes the contrast land.

| Heirloom | Name | Language | Meaning, and why this one |
|---|---|---|---|
| Bosk's, then Rourke's | **Gjallar** | Old Norse | "The resounding" — Heimdall's horn. Sounded once, heard by everyone, and it means the end has started. |
| The Stolen Seal | **Simulacrum** | Latin | "A likeness, a phantom." A jury-rigged spoof wearing a real key's face — and a kit whose signature is literally copying whatever it just fought. |
| Widow's Ledger | **Skuld** | Old Norse | "Debt — that which is owed"; also the Norn of what must come. Ledger Entry is a tally that grows every kill until it's collected in one stroke. |
| The Iron Oath | **Vindex** | Latin | "One who stands surety for another." Not a generic word for a shield — the exact legal sense of taking on someone else's liability, which is Oathkeeper (damage deferred, not avoided) and Debt Paid (an ally's hit redirected onto you) in one word. |
| Deadfall | **Ichigeki** (一撃) | Japanese | "A single blow." One unavoidable, uncounterable strike — and then every enemy on the map knows exactly where you are. |
| The Last Word | **Migawari** (身代わり) | Japanese | "One who takes another's place" — the word for a substitute who absorbs a fate meant for someone else. The substitution here is literal: the wielder's own max HP, permanently, for an ally's life. |
| Salt the Root | **Delenda** | Latin | From *Carthago delenda est*, "that which must be destroyed." Carries the salted-earth association the old title was reaching for, in the language that association comes from. |
| The Cutting Room | **Zanretsu** (斬裂) | Japanese | "Cut and rend." A line of cuts through everything in the way, which cannot be called off once begun. |
| Cinder Line | **Surtr** | Old Norse | The fire-giant who burns the world at the end of it. Halden's own hook is "better it burns than passes to whoever's circling" — that myth's logic applied to a family estate. |
| Farsight's Reckoning | **Panoptes** | Greek | Πανόπτης, "all-seeing" — the epithet of hundred-eyed Argus. Reveals every hostile on the map, burrowed included, then kills one of them from anywhere. |

**Language spread is deliberate, three-three-three-one** (Old Norse / Latin / Japanese / Greek). Nothing enforces it, and no single choice depends on it — but old houses naming their artifacts in different old tongues is a free piece of worldbuilding that costs nothing and reads as intentional rather than as a grab bag.

**Any single one of these is a one-line change to revert.** `displayName` in `src/data/heirlooms.ts`, plus its matching signature-ability `displayName` — the test suite pins that those two always agree, so a rename that forgets the second half fails rather than shipping half-done.

## 4. What's updated, and what's still owed

**Done, this session:**
- `src/data/heirlooms.ts` — all ten `displayName`s, all ten signature abilities, nine `epithet`s, plus the naming rule written into `HeirloomDef`'s own doc comment so it survives outside chat history.
- `src/engine/__tests__/heirlooms.test.ts` — four new tests pinning the rule: every signature matches its Heirloom's name, no non-signature does, every Heirloom but Gjallar keeps an epithet, and all ten names are distinct.
- `Bloom_Wars_Independent_Campaign_The_Amaranth_Reckoning.md` §9 — the Gjallar row, the §9 heading, and a dated note explaining that the twenty-entry table is the original brainstorm rather than the shipped ten. The row-by-row mapping between the two is deliberately NOT written out: the shipped versions were redesigned, not renamed, and one draws on two different rows at once, so a clean correspondence would be an invented history.
- `Bloom_Wars_Glossary_Codex_Entries_v1.md` — the Heirloom entry's "still being decided" flag is closed.

**Still owed, blocked on the same `.docx`-byte-access issue `Bloom_Wars_Docx_Pending_Edits_Status_28Aug2026.md` already tracks for four other edits:**
- GDD §8's heading, "The Heirloom: Severance" → "The Heirloom: the Requiem system," plus §8.1-8.3's prose wherever it names the mechanic "Severance" directly.
- Data Pack §11.5's `const SEVERANCE = { id: "abil_severance", ... }` → `REQUIEM` / `abil_requiem`.

**Still owed in code, deliberately not attempted this pass:** the actual identifier rename — `data/abilities.ts`'s shipped `SEVERANCE` constant and its `abil_severance` id string, and `data/heirlooms.ts`'s own `requiem_severance` ability id. Only the player-facing strings moved. Renaming a shipped ability id touches the combat path, the Player AI's ability table and any saved state keyed on it, which is real work with real regression surface — separate from a naming decision, and worth doing on its own.

## 5. Naming-lock safety check

Every name above is drawn from a real, documented word in Old Norse, Latin, Japanese or Greek, with a meaning cited. None is invented, and none is sourced from Qiraki material.

**Honest limitation, and it's a real one, worth Maxime's own eyes:** the build's own spoiler lint (`tools/lint-spoiler.mjs`) could NOT be run against this change, because it reads the reserved term from `BW_RESERVED_TERM` in a git-ignored `.env.local` — and that file does not exist in the repo on Maxime's machine either. The lint prints its "skipping the spoiler lock this run" warning and exits 0, which means `npm run build` and `npm run test` have both been passing that gate vacuously. See the build-log addendum's own "Findings" section for the full account; the short version is that the lock the Master Index describes as "a build-failing lint rule, not a convention" is currently enforcing nothing, and has one term configured where the project describes two.
