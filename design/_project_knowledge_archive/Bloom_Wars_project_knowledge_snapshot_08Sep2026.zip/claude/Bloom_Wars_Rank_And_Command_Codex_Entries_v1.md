# The Bloom Wars — Ranks & Command Codex Entries v1

*Written 2 Sep 2026, continuing the Codex content backlog. Checked against `Bloom_Wars_Rank_And_Command_v1.md` in full before writing a word — that doc is explicit it's "paper only, nothing here is built," and `Bloom_Wars_Codex_Design_v1.md`'s own category table flags this section as flavor-only, describing a system that isn't mechanically live yet. Both entries below are written to read as real, settled military structure without ever implying either ladder does anything to a pilot's numbers — because right now, neither does.*

## 0. One thing handled quietly rather than exposed

`Rank_And_Command_v1.md` §2 flags a real, still-open design fork: whether named pilots (Bosk, Anand, Lask, Iyari, Rourke) keep their story-locked titles as fixed flavor regardless of gear tier, or whether their displayed rank should track the mechanical G→A ladder like a generated recruit's would. That's an internal, unresolved question about how the code should compute a display string — not something a player-facing codex entry should ever surface as an open question. The entry below is written against what's actually already true in every shipped bio and mission line (Bosk is M.Sgt., Anand is Cpl., Lask is Spec., full stop) rather than hedging in-fiction about how that number gets calculated. If the underlying resolution ever changes, this entry's text doesn't need to — it was never written to depend on the answer.

## 1. The entries

> **codex_rank_personal** *(unlocks — Mission 1, first rank titles appear on the roster)*
> **Personal Rank**
> Every pilot climbs the same ladder, earned through gear rather than time served — showing up and training isn't separately rewarded here, only real capability is. **Pvt.** at the bottom, then **Pfc.**, **Cpl.**, **Sgt.**, **Staff Sgt.**, **M.Sgt.**, and at the very top of what an enlisted pilot can reach without a command posting, **Sgt. Maj.**
>
> Munti pilots often carry a different title at the same rungs — **Spec.** in place of Cpl. or Sgt. — the same old habit real militaries have of marking support and technical roles apart from the line, not a separate ladder, just a different name painted on the same climb.

> **codex_rank_command** *(unlocks — Mission 1, Rourke's own title already shows it)*
> **Command Position**
> A role, not a rung — layered on top of personal rank rather than replacing it. **Lance Lead** runs one five-pilot lance day to day, carrying the title **2nd Lt.** **Company Commander** sits above that, running the whole force, carrying **Capt.** and later **Maj.** as the company grows.
>
> The two aren't a hand-off. When a Lance Lead gets promoted to Company Commander, they don't step back from the lance they were already running — they keep leading it in person, on top of everything else now answering to them. Rourke's own record is the clearest example: still Lance A's Lead, the exact same lance she's led since her very first mission, and Company Commander over the whole of Warden Company besides.

## 2. Naming-lock safety check

Every title used above (Pvt. through Sgt. Maj., 2nd Lt./Capt./Maj.) is real-world military vocabulary already in active, locked use on named pilots' own character sheets — no new terminology, nothing borrowed from either reserved book term.

## 3. Status

Two entries, matching `Rank_And_Command_v1.md`'s own two-axis structure exactly (§1: personal rank vs. command position). Nothing here overclaims mechanical weight the system doesn't have yet — see §0 above and that doc's own §6 open-items list, which separately flags "whether personal rank should carry mechanical teeth" as a real future question, not one this entry answers or needs to.
