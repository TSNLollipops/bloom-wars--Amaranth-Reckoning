# THE BLOOM WARS — Ambient Line Bank Expansion: Content Delivery v1

**Written 26 Aug 2026**, executing `claude/Bloom_Wars_Ambient_Line_Content_Brief_v1.md` (Phases A–C). Scope per Maxime's confirmation: **generic catalyst bank only** — pilot names are generated from game data and need no work; no separate named-pilot pass.

**Reserved-term note (Brief §0):** every line below uses only vocabulary already established in game-side docs — no new proper nouns were invented anywhere in this delivery, which is the strongest protection available against the naming lock. Final say still belongs to `tools/lint-spoiler.mjs` at build time. No book-side (Qiraki) documents were opened while writing this.

**Munti Respect bank folded in, 27 Aug 2026 (roadmap #14).** The 18-line `Bloom_Wars_Munti_Respect_Line_Bank_v1.md` bank, delivered later the same day as this doc's own creation, was deliberately kept out of the tables and census below at the time — see that doc's own §1 note on why. It's now merged in: one row per line, added to its already-tagged catalyst's table below (same Echo/Stage/Ctx/Line/Slot-variant/Src schema, no new columns needed), each catalyst's own delivered-count line updated, and the §12 census re-run over the combined 720-line total. Re-verified two ways before this shipped: every one of the 18 lines' exact text is confirmed present in `ambientLines.ts`'s live `LINE_BANK` in its intended bucket, and the bank's total line count came out to exactly 702 (this doc's prior total) + 18 = 720, with no other line moved, lost, or duplicated in the process — same "flatten and compare" verification discipline the stage-axis fold-in used.

---

## 1. Correction to the brief, verified against the file

The brief's §1 claims `claude/pilot_creator.html`'s `LINE_BANK` is a flat 180 lines with no stage axis. **That does not match the file as it exists in the project.** Read in full on 26 Aug 2026: the sandbox's `LINE_BANK` is keyed `catalyst → echo → stage` and holds **324 lines** — 9 catalysts × 4 echoes × (2 Green + 5 Blooded + 2 Command). The stage picker, Promote button, and `pickLineFor`'s stage lookup are all wired around it. So the Crew Banter doc's STATUS UPDATE and the NPC-needs addendum — which the brief marked stale — were describing something real.

What could not be checked from this session: the repo's `src/data/ambientLines.ts`. The brief's claim that it is a flat 180 (5 per catalyst × echo bucket) is plausible and consistent — that shape exactly matches the sandbox's **Blooded tier**, so the likely story is that the real bank was ported before the sandbox grew its Green/Command wings. **Assumption used throughout this doc: shipped bank = sandbox Blooded tier.** If a repo check says otherwise, only the census columns change — none of the content below does.

Practical consequence: the sandbox's 324 lines are already correctly axised and need **zero re-sort work**. They are not reproduced here (one copy of the truth — port them from `pilot_creator.html` directly). This delivery adds on top of them.

## 2. How to read this doc

Everything sits in per-catalyst tables, one row per line:

- **Echo** — which of the four states the line fires in. Tagged by **firing condition, not abstract mood**, matching how `pickEchoForPilot` actually selects: **fear** fires while a pilot is panicking (Stress ≥ 70) — lines must read as live worry/hypervigilance; **sadness** fires at low Morale or grief-worn (Munti losses) — lines must survive being spoken right after a death; **anger** fires on bad blood, defeats, and half of drunk — friction, defiance, grievance; **love** fires on close bonds, wins, the other half of drunk, and the forced close-call-restock beat — warmth, pride, invitations, and every close-call joke that would feel obscene in a darker state.
- **Stage** — G / B / C (Green / Blooded / Command), carried straight from the Crew Banter doc's own sections for re-sorted lines, assigned for new ones. Kept on every row so the stage-axis decision (Brief §5) stays free either way.
- **Ctx** — original context, reference only: H = Hangar, AA = After Action, OD = Off Duty, UP = Under Pressure, CC = Close Call, — = new line.
- **Slot variant** — Phase C: a ready-to-use templated sibling using the §11 slot vocabulary the engine already has data for ({SQUADMATE}, {CLASS}, {LOADOUT}, {ENEMY}, {MISSION}, {ROOM}, {SHIP}). Only where a slot lands naturally; — otherwise. The flat line and the variant are both deliverable — the resolver picks the variant only when it has data to fill it (resolver wiring is Phase D, not this doc).
- **Src** — `CB §n` = verbatim from Crew Banter §n; `CB §n (adapted)` = same line, trimmed or re-pointed; `NEW` = written for this delivery.

Tagging judgment calls follow one safety rule: when a line sits between a warm echo and a dark one, it goes where it can never feel wrong in context — a joke never tags into sadness, a memorial toast never tags into a win-state echo.

---

## 3. WOLF — teamwork

Voice (CB §1): eager to belong → trusts because it's been tested → leads by making the squad feel like one unit. Anger here is always *protective* — about the line holding, never personal spite.

| Echo | Stage | Ctx | Line | Slot variant | Src |
|---|---|---|---|---|---|
| love | G | H | Just tell me where you need me and I'll be there. That's — that's the whole plan, right? Stick together? | — | CB §1 |
| love | G | H | Nobody warned me how much of this job is just knowing where everyone else is standing. | — | CB §1 |
| love | G | AA | That was the first time I actually felt like part of something instead of just next to it. | — | CB §1 |
| love | G | AA | I moved because you moved. Didn't even think about it. Is that bad? | — | CB §1 |
| love | G | OD | Deal me in. I'm terrible at this, but I'd rather lose with everyone watching than win alone. | — | CB §1 |
| love | G | OD | One drink. I want to remember tonight, not black it out. | — | CB §1 |
| love | G | CC | Okay — okay, that's twice now I've almost had a heart attack over someone who's standing right there laughing at me. | — | CB §1 |
| love | B | H | Ask me who's got point today and I already know, without checking the board. | Ask me where {SQUADMATE}'s standing right now. I know without checking the board. | CB §1 |
| love | B | AA | Nobody got left. I stopped taking that for granted a while ago. | — | CB §1 |
| love | B | AA | You covered a lane you didn't have to. I noticed. I always notice now. | You covered for {SQUADMATE} out there when you didn't have to. I noticed. I always notice now. | CB §1 |
| love | B | AA | There's a version of that fight where I go it alone and it goes worse. I know which version I picked. | — | CB §1 |
| love | B | OD | Fletchers, and I'm not letting anyone hustle me twice in one deployment. | — | CB §1 |
| love | B | OD | Buy the next round. Not because I lost — because we're all still here to drink it. | — | CB §1 |
| love | B | CC | You scared ten years off every one of us. Ten. We counted. | — | CB §1 |
| love | C | H | This isn't my squad. It's ours. I just happen to be the one who says 'move' first. | — | CB §1 |
| love | C | H | Half of leading is knowing which of you needs a push and which of you needs me to shut up and trust it. | — | CB §1 |
| love | C | H | I've stopped keeping score of who saved who. Lost track years ago. That's the point. | — | CB §1 |
| love | C | AA | Every one of you walked back. I don't say that lightly and I don't say it every time — today I'm saying it. | Every one of you walked back from {MISSION}. I don't say that lightly and I don't say it every time — today I'm saying it. | CB §1 |
| love | C | AA | That's what a squad that trusts each other looks like from the outside. Good. Remember what it felt like. | — | CB §1 |
| love | C | AA | I gave the order. You made it work. Don't let anyone tell you different, including me on a bad day. | — | CB §1 |
| love | C | OD | Pull up a chair. Rank doesn't get you out of losing at Fletchers on my watch. | — | CB §1 |
| love | C | OD | Drink's on me tonight. Every one of you earned it in a different way and I noticed all of them. | — | CB §1 |
| love | C | CC | We're framing that moment. Someday it's a story with a happy ending instead of the alternative, and I want it on the wall. | — | CB §1 |
| fear | G | H | I keep counting heads before I move. Probably overkill this early. Feels wrong not to. | — | CB §1 |
| fear | G | AA | We didn't lose anyone. I keep saying that like it's not the whole point. | We didn't lose anyone on {MISSION}. I keep saying that like it's not the whole point. | CB §1 |
| fear | G | UP | I don't know how to be useful to people I haven't fought next to yet. | — | CB §1 |
| fear | G | UP | Tell me the squad's fine and I'll believe whatever else you say after that. | — | CB §1 |
| fear | B | UP | I don't spiral anymore when someone's late back. I used to. The squad taught me patience I didn't have. | — | CB §1 |
| fear | B | UP | Talk to me like I'm one of the team having a bad day, not like I'm about to break. | Talk to me like I'm one of the team having a bad day, not like I'm about to break — same as you would for {SQUADMATE}. | CB §1 |
| fear | C | UP | I've learned to say 'I need a minute' out loud instead of pretending I don't. Try it. It works. | — | CB §1 |
| fear | C | — | Quiet comms make my neck itch. Everyone check in — humor me. | — | NEW |
| fear | C | — | I've planned for every way tomorrow goes wrong. It's the ways I haven't thought of that keep me up. | — | NEW |
| anger | G | — | I lost sight of you for one minute out there and I'm still mad about it. At me, not you. | — | NEW |
| anger | G | — | Don't plan around me like I'm not standing right here. I'm part of this squad too. | — | NEW |
| anger | B | — | You broke formation for a kill and it worked. That's the only reason this is a talk and not a shouting match. | — | NEW |
| anger | C | — | You went dark on comms mid-push. Once. That's the whole allowance you get from me. | — | NEW |
| anger | C | — | I don't spend pilots to win faster. Whoever's math that is, it isn't mine. | — | NEW |
| sadness | G | — | I memorized everyone's names my first day. Didn't think I'd be crossing one out this soon. | — | NEW |
| sadness | G | — | The table's just quieter than it's supposed to be. Nobody warned me about that part. | — | NEW |
| sadness | B | H | I used to think 'watch each other's backs' was just something people said. Turns out it's a skill. Took losing count to learn it. | — | CB §1 |
| sadness | B | H | We don't talk about the ones we lost keeping this squad tight. Maybe we should. Not today. | — | CB §1 |
| sadness | C | UP | You don't have to carry that alone just because you outrank the person who'd help you carry it. | — | CB §1 |
| sadness | C | — | Some mornings I still count one head too many before I catch myself. The catching is the part that stings. | — | NEW |
| sadness | C | — | I write the letters home myself. Every single one. That duty doesn't get delegated. | — | NEW |
| love | G | H | First thing anyone told me in this unit wasn't "don't die." It was "don't let the Munti go down first." Everything else about staying alive comes after that one rule. | — | NEW (Munti Respect) |
| anger | B | UP | Anyone comes after our Munti in a fight, they've got me to go through first. That's not strategy. That's just how it works around here now. | — | NEW (Munti Respect) |

**Wolf delivered:** 33 re-sorted + 11 new + 2 Munti Respect = 46. Bucket totals with sandbox bank (9 per echo): love 33 · fear 18 · anger 15 · sadness 16 (total 82).

---

## 4. DOG — loyalty

Voice (CB §2): fast, slightly naive attachment → loyalty that survived a real scare → the thing the whole unit structurally relies on. Dog anger is *personal* — someone touched their people.

| Echo | Stage | Ctx | Line | Slot variant | Src |
|---|---|---|---|---|---|
| love | G | H | You're my wingman now. I've decided. You don't get a vote. | — | CB §2 |
| love | G | H | I already know I'd take a hit for half this lance and we've known each other a week. | I already know I'd take a hit for {SQUADMATE} and we've known each other a week. | CB §2 |
| love | G | H | Is it weird that I feel more loyal to you people than I did to half my old unit? | — | CB §2 |
| love | G | AA | You didn't have to circle back for me. You did anyway. I'm not going to forget that. | You didn't have to circle back for me on {MISSION}. You did anyway. I'm not going to forget that. | CB §2 |
| love | G | AA | I stuck by you out there because that's just — that's just what you do. Right? | — | CB §2 |
| love | G | AA | First mission and I already know who I'm not leaving behind. That was fast. | — | CB §2 |
| love | G | OD | I'll sit with you even if you don't want to talk. Just say the word. | — | CB §2 |
| love | G | OD | Pull up a stool. You don't drink alone on my watch, not tonight. | — | CB §2 |
| love | G | CC | Don't you ever do that to me again. I mean it. Also — glad you're fine. Also, don't. | — | CB §2 |
| love | B | H | You don't have to earn my loyalty twice. Once was enough, and it's still holding. | — | CB §2 |
| love | B | H | I choose who I stand next to now. It's not automatic anymore. It's better because it's not. | — | CB §2 |
| love | B | AA | I've buried the version of loyalty that just runs on instinct. What's left is the kind that survives losing someone. This is that kind. | — | CB §2 |
| love | B | AA | You'd have done the same for me. I know because I've watched you do it for someone else. | You'd have done the same for me. I know because I've watched you do it for {SQUADMATE}. | CB §2 |
| love | B | AA | That's the third time we've walked off the same field together. I keep a count now. Didn't used to. | We walked off {MISSION} together. I keep a count of those now. Didn't used to. | CB §2 |
| love | B | OD | Peg board. Loser buys, same as always, and I'm not losing to you again. | — | CB §2 |
| love | B | OD | One drink for the ones who made it back. Second one's just because I like your company. | — | CB §2 |
| love | B | CC | You keep doing this to me. I keep showing up anyway. That's the deal, apparently. | — | CB §2 |
| love | C | H | People say loyalty like it, but around here it's a job. I do the job. Every day, on purpose. | — | CB §2 |
| love | C | H | I've earned the right to worry about all of you out loud now. Don't take that away from me. | — | CB §2 |
| love | C | AA | Every one of you knows exactly where I stand. That's not an accident. That's years of showing up. | — | CB §2 |
| love | C | AA | I don't say 'I've got you' lightly anymore. When I say it, it's load-bearing. | — | CB §2 |
| love | C | OD | Sit. Drink. I'll tell you which one of you I'm proudest of tonight, and it changes every week. | Sit. Drink. Tonight the one I'm proudest of is {SQUADMATE}, and next week it'll change. | CB §2 |
| love | C | UP | You don't need to prove anything to me. That ship sailed a long time ago, in your favor. | — | CB §2 |
| love | C | CC | I've stopped being surprised when this squad pulls someone back from the edge. I'd be more surprised if we ever stopped. | — | CB §2 |
| fear | G | UP | I get attached fast. I know. I'm working on not making that everyone else's problem. | — | CB §2 |
| fear | G | UP | Tell me you're okay and I'll believe you even when I shouldn't. That's on me to fix. | — | CB §2 |
| fear | B | UP | I don't panic when someone I care about gets hurt anymore. I get quiet and I fix it. Learned that the hard way. | I don't panic when {SQUADMATE} gets hurt anymore. I get quiet and I fix it. Learned that the hard way. | CB §2 |
| fear | B | UP | Ask me how I'm holding up. I'll actually tell you now instead of saying 'fine.' | — | CB §2 |
| fear | C | UP | I've learned the difference between loyalty and not letting people rest. Go rest. I've got the watch. | — | CB §2 |
| fear | C | — | I know everyone's footsteps on this deck. I notice a missing set before the roster does. | — | NEW |
| anger | G | — | They benched you and told me it wasn't my business. You are my business. That's the whole arrangement. | — | NEW |
| anger | G | — | I heard what got said in the mess about them. Say it once more where I'm standing. | — | NEW |
| anger | B | — | You lied to me about being fine. I'd forgive you anything, but don't do that. | — | NEW |
| anger | C | H | You can rotate anyone out of this squad except the loyalty. That part's not for sale. | — | CB §2 |
| anger | C | — | Don't tell me who's worth going back for. It's everyone. It's always been everyone. | — | NEW |
| anger | C | — | Orders end where they start costing my people. That line is older than my rank. | — | NEW |
| sadness | G | — | I said 'see you at chow' like always. That's the part I can't stop hearing. | — | NEW |
| sadness | G | — | Everyone says I attach too fast. Maybe. It just means I already had something to lose. | — | NEW |
| sadness | B | H | I lost someone I was that loyal to once. Doesn't stop me being loyal again. Just makes it heavier. | — | CB §2 |
| sadness | B | — | Their old callsign still tops my comms list. I can't bring myself to bump it down. | — | NEW |
| sadness | C | AA | I've buried people I was loyal to. That doesn't make me loyal to the rest of you any less — it makes me sure of what I'm choosing. | — | CB §2 |
| sadness | C | OD | Poker night. I'm buying because I remember what it cost to still have a table full of people to buy for. | — | CB §2 |
| love | G | AA | Didn't understand why command drills "protect the Munti" into every green pilot until I watched what happens the mission after we don't. Now I get it in my bones. | — | NEW (Munti Respect) |
| anger | B | CC | Somebody flanked him today. I was already moving before I decided to. Touch our Munti again and find out what happens to the rest of your afternoon. | Touch {SQUADMATE} again and find out what happens to the rest of your afternoon. | NEW (Munti Respect) |

**Dog delivered:** 33 re-sorted + 9 new + 2 Munti Respect = 44. Bucket totals with sandbox bank: love 34 · fear 15 · anger 16 · sadness 15 (total 80).

---

## 5. CAT — selfishness

Voice (CB §3): blunt, almost comic self-interest → selective investment because it pays off → squad-survival reframed as self-interest, matured. Cat sadness is grief colliding with their own math — the ledger that stops adding up.

| Echo | Stage | Ctx | Line | Slot variant | Src |
|---|---|---|---|---|---|
| love | G | AA | I covered you because a dead squad is a squad that can't cover me next time. Purely practical. | I covered {SQUADMATE} because a dead squad is a squad that can't cover me next time. Purely practical. | CB §3 |
| love | G | AA | Don't thank me. I did the math and helping you was the correct play. | — | CB §3 |
| love | G | OD | I'm playing to win, not to be friendly. Ante up. | — | CB §3 |
| love | G | CC | Glad you're not dead. Would've been annoying to train a replacement. | — | CB §3 |
| love | B | H | Turns out keeping a couple of you alive is cheaper long-term than starting over with strangers. I've done the math twice now. | — | CB §3 |
| love | B | H | I still don't do this out of the goodness of my heart. I do it because losing you costs me something real now. | — | CB §3 |
| love | B | H | Careful — I've started caring what happens to a few of you specifically. Don't make it weird. | — | CB §3 |
| love | B | AA | I covered you because losing you would actually cost me something now. That's new. I'm not thrilled about it. | — | CB §3 |
| love | B | AA | You'd have done the same for me by now. I checked. You would have. | — | CB §3 |
| love | B | AA | I got everyone out intact this time. Even me being smug about it is a group activity, apparently. | I got everyone out of {MISSION} intact. Even me being smug about it is a group activity, apparently. | CB §3 |
| love | B | OD | Fletchers. I'm still playing to win, but I'll admit it's better with people I don't hate. | — | CB §3 |
| love | B | OD | Fine. I'll buy the round. Don't make this a thing. | — | CB §3 |
| love | C | H | I still call it self-interest. Nobody's corrected me because they've noticed my self-interest looks a lot like protecting all of you now. | — | CB §3 |
| love | C | H | I've stopped pretending this is transactional. It just sounds better when I keep saying it is. | — | CB §3 |
| love | C | H | Ask anyone — I still negotiate everything. I just negotiate on your behalf now too. | — | CB §3 |
| love | C | AA | Everyone's accounted for. I'd call that a good return on investment, if I still believed that's what this is. | Everyone's accounted for after {MISSION}. I'd call that a good return on investment, if I still believed that's what this is. | CB §3 |
| love | C | AA | I used to keep score of what I owed people. I've lost track completely. Feels like losing, honestly. I don't mind. | — | CB §3 |
| love | C | AA | You're all mine to look after now, whether I ever agreed to that in so many words or not. | — | CB §3 |
| love | C | OD | I'm still playing to win. I'm also making sure everyone's actually having a good night. Both things, apparently. | — | CB §3 |
| love | C | OD | Round's on me. Don't read into it. Read into it a little. | — | CB §3 |
| love | C | UP | I've learned looking after people isn't weakness. It's just a longer-term kind of selfish. I'm at peace with that. | — | CB §3 |
| love | C | CC | I nearly lost someone I've spent years pretending I don't care about. Pretending's officially over. | — | CB §3 |
| fear | G | H | I keep my gear in better shape than anyone here. That's not vanity, that's math. | — | CB §3 |
| fear | G | UP | I don't do the whole 'talk about your feelings' thing. Ask me something useful instead. | — | CB §3 |
| fear | G | UP | I'm fine. I'm always fine. It's less effort than not being fine. | — | CB §3 |
| fear | B | UP | I don't do feelings talk. I do 'here's the actual problem, let's fix it.' Same effect, less crying. | — | CB §3 |
| fear | B | UP | I'm not fine, and unlike a year ago I'll admit that to exactly one or two people. You're one of them. | — | CB §3 |
| fear | B | CC | You scared me. I don't love saying that. But you scared me, and I'm saying it. | — | CB §3 |
| fear | C | UP | I don't do sentiment. I do results. The result, right now, is you sitting down and letting me handle this. | — | CB §3 |
| fear | C | — | I've counted the exits in this room already. Old habit. It's kept everyone I bother keeping. | — | NEW |
| fear | C | — | I plan like I'm the only one coming back. That way any number above one is good news. | — | NEW |
| anger | G | H | I'm not here to make friends. I'm here to not die. If those overlap, great. | — | CB §3 |
| anger | G | H | What's in it for me if I cover your flank? I'm asking for real. | What's in it for me if I cover {SQUADMATE}'s flank? I'm asking for real. | CB §3 |
| anger | G | AA | I got mine out intact. Everyone else's business is everyone else's business. | — | CB §3 |
| anger | G | OD | One drink. I'm not buying a round for people I've known a week. | — | CB §3 |
| anger | B | — | I did my half and everyone's still breathing. Take the complaint somewhere it's earned. | — | NEW |
| anger | C | — | My people come home whole. That's the one clause I don't negotiate. | — | NEW |
| anger | C | — | You spent my squad like loose change out there. I count change. I always count change. | — | NEW |
| sadness | G | — | Barely knew them. My math says that shouldn't cost anything. My math's wrong. | — | NEW |
| sadness | G | — | I came in with everything I own in one crate. Turns out that's not the stuff you can lose. | — | NEW |
| sadness | B | — | I priced getting attached out here exactly once. Paid it anyway. Worst deal I keep making. | — | NEW |
| sadness | C | — | I ran the numbers on caring about all of you years ago. Losing one still isn't a cost I know where to file. | — | NEW |
| sadness | C | — | The seat I always pretend I'm not saving — it's empty tonight for real. I hate that I can tell the difference. | — | NEW |
| love | B | H | I don't do sentiment, officially. I keep the Munti's sightline clear anyway. Lose him and the whole squad's insurance policy goes with him. That's just math I can live with. | — | NEW (Munti Respect) |
| love | C | AA | Everyone else chases kill count. I've started chasing "is the Munti still standing" instead. Didn't expect that particular math to change on me, but here we are. | — | NEW (Munti Respect) |

**Cat delivered:** 33 re-sorted + 10 new + 2 Munti Respect = 45. Bucket totals with sandbox bank: love 33 · fear 18 · anger 16 · sadness 14 (total 81).

---

## 6. CROW — indulgence

Voice (CB §4): scattered, chasing distractions → indulgence becomes deliberate stress management → the appetite for the unusual becomes real expertise, owned with humor. Crow grief goes through their obsessions — the theory with no one left to hear it.

| Echo | Stage | Ctx | Line | Slot variant | Src |
|---|---|---|---|---|---|
| love | G | H | Okay but hear me out — what if the Bloom isn't random, what if there's a pattern, I've been tracking it— | — | CB §4 |
| love | G | H | I collect weird stuff. Bolts, bad jokes, one Bloom carapace piece I'm definitely not supposed to have. | — | CB §4 |
| love | G | H | Give me five minutes and a bored afternoon and I will find you a conspiracy theory about literally anything on this ship. | Give me five minutes and a bored afternoon and I will find you a conspiracy theory about anything on {SHIP}. | CB §4 |
| love | G | AA | That fight is going straight into my theory. Everything goes into the theory eventually. | {ENEMY} is going straight into my theory. Everything goes into the theory eventually. | CB §4 |
| love | G | AA | I got distracted mid-fight thinking about why the pack broke formation like that. Nearly got hit. Worth it, probably. | — | CB §4 |
| love | G | AA | New data point! I'm annoyingly pleased about this given what it cost to get it. | — | CB §4 |
| love | G | OD | Poker's just an excuse for me to watch everyone's faces and build theories about them. Deal me in. | — | CB §4 |
| love | G | OD | One drink turns into me explaining my whole Bloom-migration theory to whoever's still listening. Fair warning. | — | CB §4 |
| love | G | CC | See, THIS is going in the theory. 'Munti saves override probability entirely.' I'm onto something. | — | CB §4 |
| love | B | H | My theories used to be about the Bloom. Half of them are about keeping this squad alive now. Priorities shifted. | My theories used to be about the Bloom. The current one is about keeping {SQUADMATE} alive. Priorities shifted. | CB §4 |
| love | B | H | I still chase every weird lead. I've just learned which ones are worth chasing during a fight and which ones wait. | — | CB §4 |
| love | B | H | Turns out half my 'conspiracy theories' were just me noticing patterns nobody else had time to. That's a compliment I give myself now. | — | CB §4 |
| love | B | AA | My attention wanders less in a fight now. Not gone. Less. I call that progress. | — | CB §4 |
| love | B | AA | That detail I obsessed over last month just saved someone's life today. I'm allowed to be smug about that one. | That detail I obsessed over last month just saved {SQUADMATE}'s life today. I'm allowed to be smug about that one. | CB §4 |
| love | B | OD | Peg board. I've got a theory about the pattern in this game too. Of course I do. | — | CB §4 |
| love | B | OD | One drink, one new obsession explained in too much detail. It's basically a ritual at this point. | — | CB §4 |
| love | B | CC | That's going in the log under 'things that nearly broke my brain and also my heart, same afternoon.' | — | CB §4 |
| love | C | H | People used to roll their eyes at my theories. Half of them are standard doctrine around here now. I notice things. Turns out that's a skill. | — | CB §4 |
| love | C | H | I still chase tangents. I've just learned to bring the squad along for the useful ones. | — | CB §4 |
| love | C | H | Ask me anything. I probably have a theory. Most of them are right now, which honestly still surprises me. | — | CB §4 |
| love | C | AA | I called that pack shift four minutes before it happened. Nobody's surprised anymore. I still am, a little. | I called the {ENEMY} shift four minutes before it happened. Nobody's surprised anymore. I still am, a little. | CB §4 |
| love | C | AA | My attention doesn't wander in a fight anymore. It's not that I stopped noticing everything — I just stopped letting it cost anyone. | — | CB §4 |
| love | C | AA | Every strange detail I ever chased down came together today. I'd call that vindication, if I were the type to gloat. I am the type. | — | CB §4 |
| love | C | OD | Fletchers. I'll walk you through my current theory whether you asked or not — that's the deal, that's always been the deal. | — | CB §4 |
| love | C | OD | Drinks are on me. Ask me what I'm obsessed with this week. It's a good story, I promise. | — | CB §4 |
| fear | G | UP | I deal with stress by finding something new to obsess over. It's not healthy. It works, though. | — | CB §4 |
| fear | G | UP | Don't ask me how I'm doing, ask me what I'm currently fixated on. Same answer, better mood. | — | CB §4 |
| fear | B | UP | I chase distractions on purpose now. It's not avoidance, it's maintenance. There's a difference and I've learned it. | — | CB §4 |
| fear | B | UP | Give me something to dig into and I'll steady out. Always has worked. Now I actually trust that about myself. | — | CB §4 |
| fear | C | UP | I still cope by chasing something strange and specific. I've just learned to notice when someone else needs that same outlet, and hand it to them. | — | CB §4 |
| fear | C | UP | My mind still won't sit still. I've made peace with steering it instead of fighting it. Recommend it, honestly. | — | CB §4 |
| anger | G | — | Somebody 'tidied' my collection while we were dirtside. Tidied. I had a system. I want a tribunal. | — | NEW |
| anger | G | — | I called that ambush two days ago and got laughed out of the briefing. Next time I'm charging admission to be right. | — | NEW |
| anger | B | AA | I clocked the pack behavior shift before anyone called it. Nobody believed me the first three times. I've stopped needing them to. | — | CB §4 |
| anger | C | — | I don't get dismissed in briefings anymore. It cost me years of being right in public to buy that. It shouldn't have. | — | NEW |
| anger | C | — | Whoever decided pattern-watching wasn't 'real soldiering' can come read my file of confirmed calls. Slowly. Out loud. | — | NEW |
| sadness | G | — | They never did hear the end of my migration theory. I keep catching myself saving up the next part. | — | NEW |
| sadness | G | — | My collection's just stuff today. That's the tell, when it all goes flat like that. | — | NEW |
| sadness | B | — | I know sixteen facts about the Bloom nobody asked for and not one thing to say at a memorial. Working on it. | — | NEW |
| sadness | C | CC | I've got a whole file of near-misses like that one. I don't reread it for fun anymore. I reread it because it reminds me why we do the rest of this. | — | CB §4 |
| sadness | C | — | I've catalogued every way this war surprises you. The grief ones I still file under 'pending.' | — | NEW |
| love | B | AA | I've catalogued every save our Munti's pulled off this tour. Funny thing — the board never credits a single one as a kill. I keep my own ledger. Different math than command's. | — | NEW (Munti Respect) |
| sadness | C | — | Lost a Munti once. Half the squad who went quiet that week never even flew a mission with him. Turns out that particular grief doesn't check your logbook first — it just checks whether anyone's left to catch the next fall. | — | NEW (Munti Respect) |

**Crow delivered:** 33 re-sorted + 8 new + 2 Munti Respect = 43. Bucket totals with sandbox bank: love 35 · fear 15 · anger 14 · sadness 15 (total 79).

---

## 7. RAVEN — instruction

Voice (CB §5): over-explains before earning the authority → instructs from real scar tissue → the generous, patient mentor others seek out. Raven anger is always about *preventable* things — the brief unread, the checklist skipped.

| Echo | Stage | Ctx | Line | Slot variant | Src |
|---|---|---|---|---|---|
| love | G | H | Actually, you'll want to angle your approach two degrees wider than that — I read it in a manual, don't look at me like that. | You'll want a wider angle running {LOADOUT} — I read it in a manual, don't look at me like that. | CB §5 |
| love | G | H | I know I sound like I've done this for years. I have not. I've just read everything. | — | CB §5 |
| love | G | H | Let me walk you through why that worked. I promise it's useful and not just me showing off. Mostly. | — | CB §5 |
| love | G | AA | Told you the approach angle mattered. I wasn't sure until it actually worked, if I'm honest. | — | CB §5 |
| love | G | AA | I called the timing on that and got lucky it landed right. I'll take it. | — | CB §5 |
| love | G | AA | Next time, hold two turns longer before the push. I'm learning this in real time right alongside you. | — | CB §5 |
| love | G | OD | I can walk you through Fletchers technique or we can just play. Your call. I vote technique. | — | CB §5 |
| love | G | OD | One drink and I promise not to explain the fermentation process. No promises on anything else. | — | CB §5 |
| love | B | H | I only teach what actually almost got someone killed now. Cuts the material down a lot, honestly. | — | CB §5 |
| love | B | H | I used to explain everything. I've learned which lessons land and which ones just make me feel useful. Different skill. | — | CB §5 |
| love | B | H | Ask me a real question and I'll give you a real answer, no manual quotes attached. Learned that the hard way. | — | CB §5 |
| love | B | AA | I taught you that angle because I've seen what happens to pilots who never learn it. Once was enough. | — | CB §5 (adapted) |
| love | B | AA | Good instinct out there. You didn't need my help on that one and I noticed. | Good instinct out there on {MISSION}. You didn't need my help and I noticed. | CB §5 |
| love | B | OD | Peg board — I'll teach you the pattern this time, no lecture attached, I promise. | — | CB §5 |
| love | B | OD | One drink. I'll actually just talk instead of instructing for once. Rare, savor it. | — | CB §5 |
| love | C | H | People come to me before a fight now, not after. That's the actual job, I think. Nobody told me, I just noticed. | — | CB §5 |
| love | C | H | I don't lecture anymore unless it's asked for. Funny how much more people listen once you stop insisting. | — | CB §5 |
| love | C | H | Every hard lesson I've got, I'll hand over free. No charge, no ego attached anymore. | Every hard lesson I've got about {ENEMY}, I'll hand over free. No charge, no ego attached. | CB §5 |
| love | C | AA | You made that call yourself out there. I didn't have to say a word. That's the whole point of teaching, and I finally believe it. | You made that call on {MISSION} yourself. I didn't have to say a word. That's the whole point of teaching. | CB §5 |
| love | C | AA | I've buried the version of me that needed to be the smartest person in the briefing. What's left just wants everyone walking home. | — | CB §5 |
| love | C | OD | Sit. I'll teach you the peg board properly this time — not to win, just because it's a good thing to know. | — | CB §5 |
| love | C | OD | Drinks on me. Ask me anything. I've got fewer answers than I used to pretend, and I'm finally okay saying that. | — | CB §5 |
| love | C | CC | I've watched that scenario go every possible way over the years. I'll take this ending every single time. | — | CB §5 |
| fear | G | UP | I deal with nerves by explaining things to people whether they asked or not. Bear with me. | — | CB §5 |
| fear | G | UP | Ask me something you actually want to know. I'm better at answering than I am at just sitting with it. | — | CB §5 |
| fear | G | CC | See, that's exactly the scenario the manual warns about. I did not expect to see it in person quite so fast. | — | CB §5 |
| fear | B | UP | I've stopped explaining my way through everything. Some things you just have to sit in. Learning that too. | — | CB §5 |
| fear | B | UP | Tell me what's actually wrong. I'll skip the lesson and just listen this time. | — | CB §5 |
| fear | C | UP | You don't need a lesson right now. You need someone to sit with you. I can do both, but I know which one this is. | — | CB §5 |
| fear | C | UP | I've learned the best thing I can teach is that it's fine to not have it together today. | — | CB §5 |
| anger | G | — | I flagged that hazard in the pre-brief. Page two. Highlighted. I'm allowed to be loud about that for one day. | — | NEW |
| anger | G | — | You skimmed the brief. People improvised with my flank because of it. Read. The. Brief. | — | NEW |
| anger | B | — | There's a checklist for exactly this, and it's written in someone's bad day. Use it. | — | NEW |
| anger | C | — | I've rewritten that doctrine twice with better information. Command shelved it twice. Third draft's going over their heads. | — | NEW |
| anger | C | — | Every shortcut you're defending, I've watched cost somebody something. Pick a different hill. | — | NEW |
| sadness | G | — | My manuals don't have a chapter for this part. First gap I've found in them. I hate it. | — | NEW |
| sadness | G | — | I read everything before I got here. Nothing I read weighs anything today. | — | NEW |
| sadness | B | AA | That call I made — I got it from a mistake I watched someone else make once. Didn't want to repeat it. | — | CB §5 |
| sadness | B | CC | I've seen that exact scenario end differently. I'm glad this is the version I get to remember instead. | — | CB §5 |
| sadness | C | AA | That's a lesson I learned from losing someone. I'd rather hand it to you than watch you learn it the same way. | — | CB §5 |
| sadness | C | — | Somewhere in every lesson I give, there's a name I don't say out loud. The good students hear it anyway. | — | NEW |
| sadness | C | — | I've taught the recovery drill a hundred times. Today I finally understand why my own teacher's voice always went quiet on it. | — | NEW |
| love | G | H | First lesson I give any green pilot, before tactics, before anything: learn exactly where your Munti's standing. Every other lesson assumes that one already landed. | — | NEW (Munti Respect) |
| anger | C | AA | Somebody left the Munti exposed on that approach. That's not bad luck. That's a briefing nobody actually sat through — because the day we lose him is the day the rest of this unit stops getting second chances. | — | NEW (Munti Respect) |

**Raven delivered:** 33 re-sorted + 9 new + 2 Munti Respect = 44. Bucket totals with sandbox bank: love 33 · fear 16 · anger 15 · sadness 16 (total 80).

---

## 8. BEAR — isolation

Voice (CB §6): newly guarded, a little defensive about it → isolation becomes respected professional posture → softens at the edges without disappearing; the squad becomes the one exception. Bear grief is the watcher's grief — they saw everything except the one moment that counted.

| Echo | Stage | Ctx | Line | Slot variant | Src |
|---|---|---|---|---|---|
| love | G | H | I don't know how to small-talk. I know how to watch a room. That's what I've got right now. | — | CB §6 |
| love | G | AA | I hung back and covered the angle nobody else was watching. That's just where I end up. | — | CB §6 |
| love | G | AA | I don't celebrate loud. I noticed everyone made it back, though. That's mine, quietly. | — | CB §6 |
| love | G | AA | Ask someone else how it went. I'll just say it went fine and mean it more than it sounds. | — | CB §6 |
| love | G | OD | I'll watch the game. I don't need to be dealt in to enjoy it. | — | CB §6 |
| love | G | OD | One drink, alone, at the end of the bar. That's not a rejection. That's just the shape of my evening. | — | CB §6 |
| love | G | CC | I noticed before anyone called it. Didn't say anything. Would've if it went the other way. | I noticed before anyone called it on {MISSION}. Didn't say anything. Would've if it went the other way. | CB §6 |
| love | B | H | I still take the corner table. Nobody questions it anymore. That's its own kind of belonging, I've decided. | — | CB §6 |
| love | B | H | I watch the room because it's useful, not because I'm avoiding it. Both used to be true. Now it's mostly the first one. | — | CB §6 |
| love | B | H | I don't talk much. When I do, people have started actually listening. That's new, and I don't hate it. | — | CB §6 |
| love | B | AA | I caught the angle nobody else had eyes on. Again. Somebody has to be the one watching the edges. | I caught the angle nobody else had eyes on during {MISSION}. Again. Somebody has to watch the edges. | CB §6 |
| love | B | AA | I don't need thanks for holding the line alone out there. I'd have done it whether anyone noticed or not. | — | CB §6 |
| love | B | AA | Everyone made it back. I'll admit that mattered to me more than I let on. | — | CB §6 |
| love | B | OD | I'll sit at the edge of the table. Deal me in anyway. I like watching more than I like winning. | — | CB §6 |
| love | B | OD | One drink, still alone, still at the end of the bar. A couple of you have started just — sitting there with me. I've stopped minding. | — | CB §6 |
| love | B | CC | I don't do relief out loud well. Just know I felt it. All of it. | — | CB §6 |
| love | C | H | I still keep to the edges. I've just noticed the edges are where this whole squad's safety usually gets decided, so I don't mind the reputation. | — | CB §6 |
| love | C | H | People assume isolation means I don't care. It's the opposite. I watch you all closer than anyone. | — | CB §6 |
| love | C | H | I don't need the room anymore. I've got the handful of you that matter, and that's plenty. | — | CB §6 |
| love | C | AA | I watched every angle out there so none of you had to. That's the job I picked, and I'd pick it again. | — | CB §6 |
| love | C | AA | I don't say this often — I was glad every one of you made it back. Write that down, it won't happen twice this month. | I don't say this often — I was glad every one of you walked out of {MISSION}. Write that down. | CB §6 (adapted) |
| love | C | AA | Solitude taught me to notice everything. Everything I notice, I spend on keeping you alive now. | — | CB §6 |
| love | C | OD | I'll sit with the squad tonight. Still not talking much. Still here. That's the whole message. | — | CB §6 |
| love | C | OD | Drink's on me, for once. I don't do this for many people. Consider it noted. | — | CB §6 |
| love | C | CC | I don't scare easy. That scared me. I'm not going to pretend otherwise anymore — not to you. | — | CB §6 |
| fear | G | H | I'm not being rude. I just don't do the group thing well yet. Give it time. | — | CB §6 |
| fear | G | H | I'll take the corner table. Not because I dislike you. I just need the corner. | — | CB §6 |
| fear | G | UP | I don't want company right now. I might in an hour. Ask again in an hour. | — | CB §6 |
| fear | G | UP | I process things by myself first. Always have. I'll talk when there's something worth saying. | — | CB §6 |
| fear | B | UP | I still need distance first. I've learned to say so instead of just disappearing. Small improvement, real one. | — | CB §6 |
| fear | B | UP | I don't need you to fix it. I need you to know it's there. That's enough. | — | CB §6 |
| fear | C | UP | I've learned the difference between needing space and needing to be alone. Come find me when I need the first one. I'll let you, now. | — | CB §6 |
| fear | C | UP | You don't have to talk me through it. Just don't leave the room yet. That's what I actually need. | — | CB §6 |
| anger | G | — | You moved my kit to 'make room.' Put it back. The corner works because nobody helps it work. | — | NEW |
| anger | G | — | Stop translating me to people. If I wanted the room to know, the room would know. | — | NEW |
| anger | B | — | I don't raise my voice. Notice how quiet I just got instead. | — | NEW |
| anger | C | — | Anyone with opinions about my distance can hold the edge themselves for a year. Then we'll talk. | — | NEW |
| anger | C | — | Crowd me in a briefing again and I'll start attending by comms. Your pick. | — | NEW |
| sadness | G | — | I only knew how to like them from across the room. Should've crossed the room. | — | NEW |
| sadness | G | — | People keep asking if I'm okay. I was quiet before. It's a different quiet now. | — | NEW |
| sadness | B | — | They were the only one who never tried to fix the silence. Sitting here's harder without that. | — | NEW |
| sadness | C | — | I've watched this deck from the same corner for years. It's never once looked this empty with this many people on it. | — | NEW |
| sadness | C | — | I keep watch so I never lose anyone I'm looking at. Wasn't looking. That's the whole wound. | — | NEW |
| love | B | H | I don't talk to most of the squad. I watch the Munti's flank without being asked, every fight, no exceptions. That's the version of caring I've got, and it counts for more than talking would. | — | NEW (Munti Respect) |
| love | C | AA | Nobody clocked me holding position near him the whole fight. Good. I don't need the credit. I need him standing at the end of it, same as everyone else does, whether they say so or not. | — | NEW (Munti Respect) |

**Bear delivered:** 33 re-sorted + 10 new + 2 Munti Respect = 45. Bucket totals with sandbox bank: love 36 · fear 17 · anger 14 · sadness 14 (total 81).

---

## 9. FOX — trickery

Voice (CB §7): trickery for fun and showing off → feints and misdirection start saving lives → full tactical cunning, respected by command, humor kept. Fox sadness is the performer with no audience — grief is the one thing that won't be misdirected.

| Echo | Stage | Ctx | Line | Slot variant | Src |
|---|---|---|---|---|---|
| love | G | H | I swapped the labels on the ration crates. Don't tell the Quartermaster. Actually, tell him. It'll be funnier. | — | CB §7 |
| love | G | H | I like knowing something you don't. It's not personal. It's just fun. | — | CB §7 |
| love | G | H | Watch — I bet I can talk my way past that duty roster before end of shift. | — | CB §7 |
| love | G | AA | I baited them left, everyone else hit right. Worked better than I expected, honestly. | I baited {ENEMY} left, everyone else hit right. Worked better than I expected, honestly. | CB §7 |
| love | G | AA | I got a little too pleased with myself out there. In my defense, it worked. | — | CB §7 |
| love | G | AA | That feint was mostly improvised. Don't tell command it was mostly improvised. | — | CB §7 |
| love | G | OD | Poker. I will absolutely bluff you and I will absolutely enjoy it. | — | CB §7 |
| love | G | OD | One drink, and I'm definitely going to tell an exaggerated version of today. It's more fun that way. | — | CB §7 |
| love | B | H | I still like knowing something you don't. These days it's usually the thing that keeps you alive, so I've decided that's fine. | — | CB §7 |
| love | B | H | My tricks used to be for fun. Half of them are tactics now. The other half are still just for fun. | — | CB §7 |
| love | B | H | I read the room better these days. Mostly so I know exactly when to make it worse on purpose. | — | CB §7 |
| love | B | AA | That feint wasn't improvised this time. I planned it. Felt strange being the responsible one for a second. | — | CB §7 |
| love | B | AA | I baited the whole pack into a kill box. Command's going to ask how I knew that would work. I'm not telling them it was a guess. | I baited {ENEMY} into a kill box. Command's going to ask how I knew that would work. I'm not telling them it was a guess. | CB §7 |
| love | B | AA | I got everyone out using a trick that could've gone very wrong. I've started thinking harder before I commit to those. Progress. | — | CB §7 |
| love | B | OD | Fletchers. I'm still bluffing you, but I'll admit it's more fun when you actually see it coming half the time now. | — | CB §7 |
| love | B | OD | One drink, and this time the exaggerated story has an actual point to it. Character growth. | — | CB §7 |
| love | C | H | I don't play tricks for fun much anymore. I play them because I've watched the right one save a whole squad. That's a better reason. | — | CB §7 |
| love | C | H | People trust my read on a bad situation now. Feels strange, being the reliable one. I'm still funny about it, don't worry. | — | CB §7 |
| love | C | H | I know something you don't. This time it's a plan that keeps all of you breathing. Old habits, better reasons. | — | CB §7 |
| love | C | AA | I've stopped needing anyone to be impressed by the trick. I just need it to work. It worked. | — | CB §7 |
| love | C | AA | That misdirection came from years of learning exactly how far I can push a bad plan before it stops being clever. We're under that line. Barely. | — | CB §7 |
| love | C | AA | I got everyone home using a play nobody else would have tried. I don't need credit for it. I'll take it anyway, quietly. | I got everyone home from {MISSION} using a play nobody else would have tried. No credit needed. I'll take it anyway, quietly. | CB §7 (adapted) |
| love | C | OD | Poker night, my rules. I'll still bluff every one of you, and every one of you will still fall for it, and that's exactly why I love this crew. | — | CB §7 |
| love | C | OD | Drinks are on me. I'll tell the real version of the story tonight, for once. Don't get used to it. | — | CB §7 |
| love | C | CC | I've made peace with not turning every near-miss into a bit. This one, I'm just glad about. No joke attached. | — | CB §7 |
| fear | G | UP | I deal with nerves by pulling pranks. Bad coping mechanism. Effective one. | — | CB §7 |
| fear | G | UP | Don't take my jokes as me not taking this seriously. It's just how I get through it. | — | CB §7 |
| fear | G | CC | Okay, that one wasn't funny. I'm still going to make it funny later, but not right now. | — | CB §7 |
| fear | B | UP | I still crack jokes under stress. I've learned to check who needs the joke and who needs me to stop. | — | CB §7 |
| fear | B | UP | I trick my own head into calm the same way I trick the enemy into a bad position. Whatever works. | — | CB §7 |
| fear | C | UP | I still cope with a joke first. I've learned to follow it with something real, right after, so it doesn't just deflect. | — | CB §7 |
| fear | C | UP | I read this room the way I read a battlefield. Right now it's telling me someone needs quiet, not a punchline. I can do quiet. | — | CB §7 |
| anger | G | — | Somebody re-labeled MY crates back. Fine. FINE. This means escalation. | — | NEW |
| anger | G | — | They put my feint in the after-action report as 'unplanned maneuver.' Unplanned. I planned it TWICE. | — | NEW |
| anger | B | — | Three days setting that trap, and command marched us straight past it. The Bloom I forgive. Command, less. | — | NEW |
| anger | C | — | The play leaked and the other side adapted. Fine. The second version has no briefing document. | — | NEW |
| anger | C | — | I've run out of patience for people who call cunning 'cheating' right up until it saves their hull. | — | NEW |
| sadness | G | — | I had a whole bit ready for when they got back. It's just sitting there now. Worst timing I've ever done. | — | NEW |
| sadness | G | — | Turns out there's a kind of quiet I can't work a room out of. Today's kind. | — | NEW |
| sadness | B | CC | I'm going to make a joke about this eventually. Today's not that day. Ask me next week. | — | CB §7 |
| sadness | C | — | The best audience I ever had is gone. Everything I do lands a beat late now, and only I can hear it. | — | NEW |
| sadness | C | — | My whole trade is making things look like other things. This refuses to look like anything but what it is. | — | NEW |
| love | B | AA | Half my feints exist to pull attention off the Munti these days. Didn't used to. Learned the hard way what the squad actually loses if that trick fails. | — | NEW (Munti Respect) |
| love | C | H | Best trick I've got isn't a bluff anymore. It's making the enemy decide the Munti isn't worth the ammo. Keeps him standing. Keeps everyone's second chances standing right along with him. | — | NEW (Munti Respect) |

**Fox delivered:** 33 re-sorted + 9 new + 2 Munti Respect = 44. Bucket totals with sandbox bank: love 36 · fear 16 · anger 14 · sadness 14 (total 80).

---

## 10. RABBIT — nurturing

Voice (CB §8): anxious caretaking that doesn't trust its own judgment under fire → steadied by real competence → the squad's actual anchor, quietly load-bearing. Note the deliberate shape: rabbit Green is fear-heavy (8 of 11 source lines) — that IS the character, don't rebalance it away.

| Echo | Stage | Ctx | Line | Slot variant | Src |
|---|---|---|---|---|---|
| love | G | AA | I patched you up with my hands shaking the whole time. Got it done anyway. I'll take that as a win. | — | CB §8 |
| love | G | OD | I'll play, but I'm also going to check on you twice during the hand. Occupational habit. | — | CB §8 |
| love | G | OD | One drink, and I'm still going to ask if you're actually okay underneath the joking around. | — | CB §8 |
| love | B | H | I've saved enough of you now that I believe it when I say I've got this. Took a while to believe that. | — | CB §8 |
| love | B | H | Tell me if something hurts. I'll actually know what to do about it this time, and it won't be shaking while I do it. | — | CB §8 |
| love | B | AA | I got to you in time because I trusted the read instead of freezing on it. That's new. That's good. | I got to {SQUADMATE} in time because I trusted the read instead of freezing on it. That's new. That's good. | CB §8 |
| love | B | AA | I've stopped replaying every call after the fact. Mostly. I trust the ones I made today. | — | CB §8 |
| love | B | AA | Everyone's stable. I believed it the first time I said it, for once. | — | CB §8 |
| love | B | OD | I'll play properly this time instead of half-watching the room for injuries that aren't happening. Progress. | — | CB §8 |
| love | B | OD | One drink. I'm still checking on you underneath the joking. That part never goes away and I've stopped apologizing for it. | — | CB §8 |
| love | B | CC | I got there. My hands didn't even shake this time. I noticed that, right in the middle of it. | — | CB §8 |
| love | C | H | Everyone orients around me without saying it out loud. I noticed a while back. I try to be worth orienting around. | — | CB §8 |
| love | C | H | I don't panic-check the roster anymore. I just know. Years of this does that to you. | — | CB §8 |
| love | C | H | Tell me if something hurts. I'll fix it, and I won't need to be told twice, and I won't shake doing it. Not anymore. | — | CB §8 |
| love | C | AA | Nobody's down. That's not luck at this point. That's a decade of learning exactly where to be standing. | Nobody's down after {MISSION}. That's not luck. That's a decade of learning exactly where to be standing. | CB §8 (adapted) |
| love | C | AA | I stopped replaying my calls after the fact years ago. I trust them. They've earned it. | — | CB §8 |
| love | C | AA | Everyone's stable, and for once that sentence doesn't cost me anything to say. It's just true. | — | CB §8 |
| love | C | OD | I'll play, and for once I'm not watching the room for injuries — I'm just here, with all of you, actually resting. | — | CB §8 |
| love | C | OD | Drinks are on me tonight. I've spent years making sure you're all fine. Let me buy the round for once. | — | CB §8 |
| love | C | CC | I've stopped needing to say it three times before I believe it. One look, and I know. That's what all this practice was for. | — | CB §8 |
| fear | G | H | I keep a mental list of everyone's HP even when we're not in a fight. I don't know how to turn that off. | — | CB §8 |
| fear | G | H | Tell me if something hurts. Please. I'd rather know too early than too late. | — | CB §8 |
| fear | G | H | I'm not as steady as I want to be yet. I'm working on it. I promise I'm working on it. | — | CB §8 |
| fear | G | AA | I keep replaying whether I could've reached you faster. You're fine. I know you're fine. I still replay it. | I keep replaying whether I could've reached {SQUADMATE} faster. They're fine. I know they're fine. I still replay it. | CB §8 |
| fear | G | AA | Everyone's stable. I said it three times to myself before I believed it. | — | CB §8 |
| fear | G | UP | I worry about everyone else so I don't have to sit with how I'm doing. I know that's backwards. I do it anyway. | — | CB §8 |
| fear | G | UP | Ask me how I'm holding up and I'll deflect to how you're holding up. Every time. It's a whole thing. | — | CB §8 |
| fear | G | CC | I got there in time. I got there in time. I need to say that a few more times before my hands stop shaking. | — | CB §8 |
| fear | B | H | I still keep the mental list. It doesn't scare me the way it used to — I trust my hands now more than I trust my worry. | — | CB §8 |
| fear | B | UP | I've learned to let people worry about me back. Still strange. Still letting it happen. | — | CB §8 |
| fear | B | UP | Ask me how I'm doing and I might actually answer honestly this time. Might. | — | CB §8 |
| fear | C | UP | I let people take care of me now. Learned it late. Learned it anyway. | — | CB §8 |
| fear | C | UP | You don't have to hide it from me. I've built this whole life around noticing exactly this. Let me in. | — | CB §8 |
| anger | G | — | You walked on that leg for two days without telling me. I'm not mad you got hurt. I'm mad you hid it. | — | NEW |
| anger | G | — | Don't call it 'just a scratch' to make my job easier. My job was never supposed to be easy. | — | NEW |
| anger | B | — | Whoever cleared them to deploy at half-strength can come hold the kit while I fix what that decision cost. | — | NEW |
| anger | C | — | I can fix almost anything this war does to you. The preventable ones are the only ones I stay angry about. | — | NEW |
| anger | C | — | Push your luck with your own hide if you must. Push it with theirs and you'll find out how un-soft I can get. | — | NEW |
| sadness | G | — | My kit has everything they told me I'd need. Nobody packed the part for after. | — | NEW |
| sadness | G | — | I did my rounds tonight like always. There's one stop my feet keep trying to make. | — | NEW |
| sadness | B | — | I know exactly which calls I got right. It's the one I never got to make that stays. | — | NEW |
| sadness | C | — | I've learned to save almost everyone. It's the 'almost' I sit with after lights-out. | — | NEW |
| sadness | C | — | Everyone brings me their grief because I know how to hold it. Some nights I'd give anything to know where to put mine. | — | NEW |
| fear | G | UP | If we lose the Munti out there, I don't know how the rest of this works. I'm not being dramatic. I've just done the math on what happens after. | — | NEW (Munti Respect) |
| love | B | AA | I'm not the Munti. I get the job anyway, more than most — the one where the only stat anyone remembers is "was I there." I make sure somebody remembers he was there. | I'm not the Munti. I get the job anyway, more than most. I make sure somebody remembers {SQUADMATE} was there. | NEW (Munti Respect) |

**Rabbit delivered:** 33 re-sorted + 10 new + 2 Munti Respect = 45. Bucket totals with sandbox bank: love 30 · fear 23 · anger 14 · sadness 14 (total 81).

---

## 11. SHARK — ambition

Voice (CB §9): raw, slightly abrasive ambition that hasn't earned results yet → tempered by real cost, more calculating → matured into drive that lifts the squad. Shark's "give me the hard mission" chain is tagged anger on purpose — it's channelled aggression, and it fires right after defeats, which is exactly when a shark would say it.

| Echo | Stage | Ctx | Line | Slot variant | Src |
|---|---|---|---|---|---|
| love | G | H | I'm going to be the best pilot on this ship. Not being modest about it. Watch the board. | — | CB §9 |
| love | G | AA | I got the most kills today. I know that's not the point. I'm still going to mention it. | I got the most kills on {MISSION}. I know that's not the point. I'm still going to mention it. | CB §9 |
| love | G | AA | I pushed harder than I needed to. Nearly cost me. Worth it for the numbers, probably. | — | CB §9 |
| love | G | AA | Next time I want the lead position. I've earned it. I think I've earned it. | — | CB §9 |
| love | G | OD | Poker. I'm playing to win, obviously. What else would I be playing for? | — | CB §9 |
| love | G | OD | One drink, and yes I'm still thinking about tomorrow's board standings. Sue me. | — | CB §9 |
| love | G | CC | Glad you're fine. Also, that's going to mess up the squad's numbers if it happens again, so — glad you're fine, mostly. | — | CB §9 |
| love | B | H | I stopped chasing the kill count after watching what chasing it almost cost someone. Still competitive. Aimed it somewhere better. | — | CB §9 |
| love | B | H | I still want to be the best on this ship. I've just learned that includes making everyone around me better too. | — | CB §9 |
| love | B | AA | I didn't push past the line today. Learned that lesson the expensive way once already. Not doing it twice. | — | CB §9 |
| love | B | AA | Everyone's numbers looked good today, mine included. I've started meaning that plural on purpose. | Everyone's numbers looked good on {MISSION}, mine included. I've started meaning that plural on purpose. | CB §9 |
| love | B | OD | Fletchers. I'm still playing to win. I've just stopped needing you to lose badly for it to count. | — | CB §9 |
| love | B | OD | One drink. I'll admit the board standings mattered less to me tonight than just being here did. | — | CB §9 |
| love | B | CC | That would've cost the squad someone good. I'm allowed to care about that as its own thing, not just the math. | — | CB §9 |
| love | C | H | I stopped measuring myself against the board a while back. Now I measure myself against whether the people under me are getting better. Harder bar. Better one. | — | CB §9 |
| love | C | H | Ambition got me here. What keeps me here is making sure it's not just mine anymore. | — | CB §9 |
| love | C | AA | I don't chase the numbers anymore. I chase everyone walking back with a number attached to their name at all. Different math. | — | CB §9 |
| love | C | AA | Every one of you is sharper than when you started under me. That's the only score I actually track these days. | Every one of you is sharper than when you started under me. {SQUADMATE} especially, this month. That's the only score I track. | CB §9 (adapted) |
| love | C | OD | Poker night. I'll still win, probably. I've started enjoying watching the rest of you get good enough to actually threaten that. | — | CB §9 |
| love | C | OD | Drinks on me. I've spent a long time chasing being the best. Turns out the actual prize was building people who could take my place. | — | CB §9 |
| love | C | CC | I built rank chasing being the best pilot on this ship. Losing you would've cost more than any board position ever could. I mean that. | — | CB §9 |
| fear | G | UP | I don't like losing. To the Bloom, to a hand of cards, to anyone. I know that's a problem. Working on it. | — | CB §9 |
| fear | G | UP | Tell me I'm still on track. I need to hear it more than I'd like to admit. | — | CB §9 |
| fear | B | UP | I still hate losing. I've learned which losses are actually about me and which ones I need to let go of. | — | CB §9 |
| fear | B | UP | Tell me I'm still on track. I mean it differently now — less about the score, more about whether I'm still someone worth following. | — | CB §9 |
| fear | B | — | We're one bad week from being the lance people stop betting on. I don't sleep great on bad weeks. | — | NEW |
| fear | C | UP | I still don't love losing. I've learned some things are worth losing for. That took most of a career to learn. | — | CB §9 |
| fear | C | UP | Tell me the squad's still on track. That's the only scoreboard that's mattered to me in years. | — | CB §9 |
| anger | G | H | I clock everyone's kill count. Don't take it personally. I clock my own harder. | — | CB §9 |
| anger | G | H | Give me the hard mission. I want the one people remember. | — | CB §9 |
| anger | B | H | Give me the hard mission. I've earned it for real this time, not just on paper. | — | CB §9 |
| anger | C | H | Give me the hard mission — for the squad's sake this time, not the scoreboard's. | — | CB §9 |
| anger | C | — | You benched my best pilot to make a point. Points don't hold ground. People do. | — | NEW |
| sadness | G | — | I knew their numbers by heart. Turns out that's not the part of them I remember first. | — | NEW |
| sadness | G | — | The board updated this morning like nothing happened. First time I've ever hated seeing it current. | — | NEW |
| sadness | B | AA | I wanted the lead position and I got it and it cost more than I expected. I'm recalibrating what 'winning' actually means out here. | — | CB §9 |
| sadness | C | AA | I held the line instead of pushing for the kill. Old me would've pushed. Old me got someone hurt once doing that. I remember. | — | CB §9 |
| sadness | C | — | The record board keeps my name. The roster doesn't keep theirs. I've stopped calling the first one the real one. | — | NEW |
| love | B | H | Board doesn't put Munti saves on the assist list. Checked. I keep my own tally anyway — didn't sit right, a number like that going uncounted. | — | NEW (Munti Respect) |
| love | C | AA | Used to think the kill count was the whole score. Changed my mind the day I watched our Munti's save log hit double digits and did the actual math on how many of my own kills only happened because he kept me standing long enough to get them. | Used to think the kill count was the whole score. Changed my mind the day I watched {SQUADMATE}'s save log hit double digits and did the math on how many of my own kills only happened because they kept me standing that long. | NEW (Munti Respect) |

**Shark delivered:** 33 re-sorted + 5 new + 2 Munti Respect = 40. Bucket totals with sandbox bank: love 32 · fear 16 · anger 14 · sadness 14 (total 76).

*Shark gets the fewest new lines on purpose: its re-sort landed unusually even (the "give me the hard mission" chain covered anger natively), and "grieve fast, we move" is already the sandbox's whole shark-sadness voice — over-filling that bucket would soften the character.*

---

## 12. Bucket census — the whole pool after fold-in

Counts below are **sandbox bank (9 per bucket) + this delivery + the Munti Respect bank (folded in 27 Aug 2026, roadmap #14)**, i.e. what each catalyst × echo pool holds once everything is folded into `ambientLines.ts` — and, as of 27 Aug, actually is: this is the live `LINE_BANK`'s real bucket census, not a projection. Every bucket lands at 14+, with love naturally fat (the source material is warm — the brief predicted this and said not to force an even split).

| Catalyst | love | fear | anger | sadness | Total |
|---|---|---|---|---|---|
| Wolf | 33 | 18 | 15 | 16 | 82 |
| Dog | 34 | 15 | 16 | 15 | 80 |
| Cat | 33 | 18 | 16 | 14 | 81 |
| Crow | 35 | 15 | 14 | 15 | 79 |
| Raven | 33 | 16 | 15 | 16 | 80 |
| Bear | 36 | 17 | 14 | 14 | 81 |
| Fox | 36 | 16 | 14 | 14 | 80 |
| Rabbit | 30 | 23 | 14 | 14 | 81 |
| Shark | 32 | 16 | 14 | 14 | 76 |
| **All** | **302** | **154** | **132** | **132** | **720** |

**Delivered in this doc: 378 lines** (297 re-sorted + 81 new) **plus 36 slot variants, plus the 18-line Munti Respect bank folded in 27 Aug 2026.** Combined with the sandbox's 324, the total authored pool is **720 flat lines** — up from the original 702 this doc first delivered — and the 36 slot variants add roughly 350 more unique deliverable strings once the Phase D resolver exists (average ~10 fills each at mid-campaign roster/mission counts, per Crew Banter §11's own math).

Stage balance inside every bucket: each Green and Command cell holds at least 4 lines (sandbox 2 + delivery, plus a Munti Respect line in several cells), each Blooded cell at least 5. That's enough that if the stage axis ships, no rank tier ever draws from a near-empty pool; if it doesn't ship, the column just gets ignored at port time and the bucket plays as one pool.

Two honest findings from doing the re-sort, worth knowing even though neither is a problem:

1. **The Crew Banter material has almost no anger in it.** 297 lines re-sorted; only 10 read as anger. The brief predicted fear and sadness would need the most new writing — in practice they needed some, but **anger was the actual desert** (hence 40 of the 81 new lines). Worth remembering next time source material gets commissioned: warm and worried come easily, friction has to be asked for explicitly.
2. **Fear and sadness buckets are where Stress and grief mechanics actually spend lines** (`pickEchoForPilot`: Stress ≥ 70 forces fear, low Morale/grief-worn forces sadness), and they now sit at 14–23 per bucket. In a heavy Talk session those two states repeat most, so they got the floor priority the brief asked for.

## 13. The stage-axis question — recommendation: keep it

The brief left "does `stage` survive as a real tracked axis?" open. Having now handled all 621 staged lines (324 sandbox + 297 re-sorted), the recommendation is **yes, keep it**, on evidence rather than preference:

- The content already exists in staged shape on both sides — nothing new needs writing to support the axis, and flattening would *discard* real, already-authored voice differentiation (a Green wolf and a Command wolf genuinely do not sound alike; that contrast is the Crew Banter doc's best work).
- The sandbox already models the whole loop — stage picker, Promote button, per-stage line selection — so the design has been feel-tested, not just theorized.
- The engine cost is exactly what the brief scoped in Phase D and called small: a `stage` field on `AmbientPilotState`/`HubNpc`, derived from rank/gear tier per the already-locked §12 ladder (2nd Lt./G–F → Capt./E–C → Maj./B–A).
- If the shipped 180 turn out to match the sandbox's Blooded tier (the working assumption), they need no re-tagging at fold-in — they simply *are* the Blooded tier.

And if the call still comes back "flatten": ignore the Stage column when porting, lose nothing from this delivery. The tag was cheap insurance either way — that part of the brief was right.

**Status as of 27 Aug 2026: shipped.** The stage axis went live the same day this delivery's own recommendation was written up (Maxime: "do the ranking path") — see `Bloom_Wars_Master_Index.md` and Build Log Addendum §36 for the engineering side.

## 14. Fold-in notes for engineering (Phase D side — not this job, just the handoff)

- **Suggested port order:** (1) sandbox 324 into `ambientLines.ts` — a straight copy, already in final shape; (2) this doc's 378, keyed by the Echo/Stage columns; (3) slot variants last, gated behind the §11 template resolver, which still does not exist anywhere in code. **Status as of 27 Aug 2026: steps (1) and (2) are both live in `ambientLines.ts`'s `LINE_BANK`, plus the 18-line Munti Respect bank folded in the same day** — only step (3), the slot-variant resolver, remains unbuilt.
- **Slot syntax used here is exactly Crew Banter §11's:** {SQUADMATE}, {CLASS}, {LOADOUT}, {ENEMY}, {MISSION}, {ROOM}, {SHIP} — all seven fill from data the engine already tracks. The 36 variants in this doc are the high-confidence first pass; §11's own estimate says roughly a third of the full bank could eventually take one, so a second, more aggressive slot pass is real remaining headroom (~80 more candidates) if the resolver proves out.
- **Dedupe:** one Crew Banter line was adapted specifically to avoid a near-twin already in the sandbox (Raven's "I'd rather you learn it from me…" family). Everything else was checked against the sandbox bank while writing; remaining overlaps are thematic siblings (same character trait, different sentence), which is variety, not duplication.
- **Adjacent mini-banks already live in the sandbox and untouched here:** TOXIC_LINES, GOSSIP_WARM/TOXIC, CLOSE_CALL_LINES, RESCUE_LINES, REC_ACTIVITIES flavor. Nobody should re-commission those.
- **One stranded nugget:** Crew Banter §10 contains a single genuinely new named-pilot line (Rourke's Stage 1→2 promotion beat). It stays where it is — named-pilot content is out of scope per Maxime's confirmation — but it's the seed if promotion-moment lines ever become a thing.
- **Lint:** run `tools/lint-spoiler.mjs` over the folded bank same as any other content. This doc introduces no new proper nouns, but the lint is the authority, not this claim.

## 15. What this doc changes in the rest of the project

- `Bloom_Wars_Ambient_Line_Content_Brief_v1.md` — its §1 claim about `pilot_creator.html` needs the correction recorded in §1 above (a dated note has been added to that doc rather than rewriting its history).
- `Bloom_Wars_Crew_Banter_Phrase_Bank_v1.md` — remains the voice/arc reference; its 297 generic lines are now fully re-sorted here, so the STATUS UPDATE's "real remaining work" item is done. The doc itself needs no edit — this delivery supersedes that one open item, nothing else.
- `Bloom_Wars_Master_Index.md` — gains a pointer to this delivery under current state.
- The Spitball/NPC-needs addendum claims the brief called stale were, on the pilot_creator side, actually correct — no edits needed there.
- `Bloom_Wars_Munti_Respect_Line_Bank_v1.md` — as of 27 Aug 2026, its 18 lines are folded into the tables above and the live `LINE_BANK`; that doc's own §1 "do not add these without re-running the verification script" note has been updated to point here.
