# THE BLOOM WARS — Onboarding / Tutorial Plan v1

**Written 27 Aug 2026**, at Maxime's request, following directly from the Early Access Scope Triage naming this the one hard blocker on the whole pre-launch list. **Status: built and shipped, same day.** Maxime: "alright lets keep building. pick a few thing ask questions then lets batch it in." §3's recommended shape was built exactly as written below — no design changes needed between plan and build. Full write-up of what shipped, plus verification: `claude/Bloom_Wars_Master_Index.md`, "Mission 1 tutorial hints + Early Access rough-edge fixes."

## 0. Two different things are called "tutorial" in this project — this plan is only one of them

Worth separating before anything else, because conflating them would misscope this doc. `Bloom_Wars_Antfarm_Grid_v1.md` §3e already has a *different* tutorial on record — the Hub's empty-ship room-placement flow, where a new campaign starts with no rooms built and the player's first act is placing a starter set (Berths included, since the recruit-phase system needs it). That one is explicitly Maxime's own in-progress design thread — his words, "im planing this out" / "ill decide at the tutorial" — and this plan doesn't touch it or try to resolve it.

This plan is about the other one: the **combat tutorial** — teaching a first-time player the actual tactics loop (select, move, attack, read the board) before or during Mission 1. That's the one the Campaign Playtest Review flagged as the single cheapest, highest-leverage thing standing between "a prototype that plays like a real game" and "something you can hand a stranger," and it's the one the Early Access triage called a hard blocker rather than a judgment call.

## 1. What already exists — this isn't starting from zero

Two things are already built and worth reusing rather than re-inventing:

**`HOW_TO_PLAY.html`, the Field Manual.** Built 22–23 Aug, self-contained, dark-themed, nine sections behind an anchor nav (Controls, Reading the Board, Terrain, Health/Shield/Collapse, Class Triangle, Abilities & House Rules, Objectives, Warden Company roster, per-mission briefings). Every number in it was checked against live source at the time (`TILE_COLORS`, `engine/combat.ts`). It's genuinely thorough reference material — the problem the Playtest Review found isn't that this content doesn't exist, it's that nothing in the actual play flow points a new player at it. It sits in the repo root next to `README.md` and as a standalone Claude Artifact; a first-time player dropped straight into Mission 1 has no reason to know either exists. **One thing to verify before reusing it, not assume:** its per-mission briefings are numbered "I.1–I.4," which reads like the archived 4-mission Team One numbering, not the live Amaranth campaign's "Mission 1–12" Act I. Worth a real check of whether its content still describes the current campaign before pointing new players at it, per this project's own verify-before-relying-on-it rule. **Not touched by the 27 Aug build below** — still an open item if this doc is revisited.

**Mission 1 ("Muster") is already the designated tutorial mission**, per its own build-log entry — an open border-post map, a squad of five, no scripted hand-holding, but structurally the intended "first thing a player does." That's a real asset: this plan doesn't need to invent a new tutorial mission or map, just teach through the one that already exists for that job.

## 2. The actual gap, in the Playtest Review's own words

Not a vague "needs polish" — a specific, reproducible new-player experience: dropped into Mission 1's `eliminate_all` with a squad and a combat log, no prompt at all for select/move/attack, and — this is the concrete, fixable detail — terrain color and the movement-range highlight read similarly enough at a glance that real playtesting (mine, played straight, no cheating by reading source) burned several turns misreading one for the other before sorting it out. That's not a content gap closed by better prose; it's a legibility problem in the highlight itself, worth fixing alongside whatever hint text explains it.

Separately, and worth surfacing here rather than letting it hide inside "the tutorial": permadeath and the Munti-restock rule are this game's single biggest emotional hook — the Playtest Review calls watching a named pilot go permanently is "the thing a lot of tactics games gesture at and don't actually build." Right now nothing tells a new player this rule exists before it happens to them the first time. That's a real design tension, not a settled call — see §5.

## 3. Recommended shape — a contextual hint layer on Mission 1, not a separate teaching mode

Three shapes were worth weighing, cheapest to most involved:

**Floor: static text, always visible.** The Playtest Review's own minimum suggestion — a fixed corner readout: "click a unit · click a highlighted tile to move · click an enemy in range to attack." Closes most of the actual gap for basically no engineering (one UI element, no new state to track) but is dead weight for a second playthrough and doesn't address the terrain/highlight confusion directly.

**Recommended: state-gated contextual hints, Mission 1 only. — BUILT, 27 Aug 2026, exactly as designed here.** A small sequence, each hint tied to a real game-state check rather than a timer — "select a unit" shown until a unit is first selected; "click a highlighted tile to move" shown once a unit is selected and its move range is drawn, until the first move resolves; "click an enemy in range to attack" the same way for the first attack; then nothing. Reads existing engine state (selection, `reachable`, `attackable`) rather than inventing any — no new persisted data beyond the one seen-flag §5 already anticipated. Shipped as `Battle.ts`'s `tutorialActive`/`tutorialHas*` fields and `updateTutorialHint()`, gated to `mission_amaranth_1` and `!hasSeenTutorial()`. Closes the real gap, disappears on its own once a player demonstrably knows the loop, matching the sizing call made here.

**Ceiling: a forced walkthrough turn.** An XCOM-style locked first turn where the game moves your hand for you — click here, now click there. Genuinely the most airtight teaching, but it's the only one of the three that's a real new interaction mode rather than a presentation layer on top of what exists, and it risks feeling patronizing to exactly the genre-savvy audience the game already has. Not recommending this one — flagged so it's a real considered-and-rejected option, not an unconsidered gap. Still not built; the recommended tier above was sufficient.

**Alongside whichever tier — BUILT, 27 Aug 2026.** A real second look at the terrain-vs-highlight color legibility problem specifically. Shipped as a value tweak on the move-range overlay (fill alpha 0.35 → 0.55, plus a solid stroke border) — deliberately not a hue or content change, per §6's own caution about colliding with the Bloom Silhouette Doctrine proposal.

## 4. What this doesn't touch

No new mission, no new map — Mission 1 keeps its current data untouched (this plan is presentation only). No change to `HOW_TO_PLAY.html`'s content, beyond maybe surfacing a link to it from wherever a player would look for more depth than the in-mission hints give (a pause menu, most likely — not designed here, and still not built). No change to the Hub room-placement tutorial (§0). No GDD/Data Pack/Build Brief/Canon Pass edit — this is UI/UX, not a rule change; that held true for what actually shipped too.

## 5. Open questions — resolved, 27 Aug 2026 (one confirmed by Maxime, one defaulted)

**Does this ever explain permadeath/Munti before it happens, or stay silent and let the first loss land as designed? — Resolved: soft warn.** Maxime, asked directly: **"honestly. we should softly warn them."** Built as the middle option this section itself proposed — a single passive line riding along with the select prompt ("Losses out here can be permanent. Keep a Munti in the fight."), not the full mechanic explained, not silence either.

**Skippable on repeat campaigns, or shown every time? — Defaulted, not explicitly confirmed.** Maxime didn't pick a side on this one. Shipped defaulting to "shown once ever, tracked per browser" (a dedicated `localStorage` key outside `CampaignState`, so `clearCampaignState()`/New Game doesn't re-trigger it) — the lower-friction convention most games use. **Worth a quick confirm** if the intent was actually "every fresh campaign restart re-shows it" instead; that would be a small follow-up change, not a rebuild.

**Does the mission-title clip bug and the stalled-`eliminate_all` no-signal gap ride along with this work, or stay separate tickets? — Rode along, same batch.** Both shipped in the same 27 Aug pass as the hint layer and highlight fix, on the convenience grounds this section already named. A third named rough edge (Iyari's Rec Room seat blocking the bay path) was checked in the same pass and turned out to already be fixed, incidentally, by an unrelated earlier change (the Antfarm Grid v0 room re-centering) — no code change needed for that one.

## 6. Sizing, for the scope-growth flag this project always wants stated up front

The recommended shape (§3, middle tier) is small-to-medium: a new presentation-layer component reading existing engine state, no new persisted data beyond one seen-flag, no new systems, scoped to one already-designated mission. It does not, on its own, cross into "new system" territory the way Mek Workshop or the Stress/breakdown roadmap items do. **Held true for the actual build** — no scope growth beyond what's described here. The one part of this that could grow scope on its own if pulled in — a real color/contrast redesign of the move-range highlight, if that turns out to need more than a value tweak — did not materialize: the shipped fix was a value tweak only (alpha + stroke, same hue), deliberately kept clear of the still-open Bloom Silhouette Doctrine proposal's own territory rather than colliding with it.
