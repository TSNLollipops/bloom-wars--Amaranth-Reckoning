# THE BLOOM WARS — Combat Encounter Line Bank: Delivery v1 (first pass)

**Status: partial delivery, 27 Aug 2026.** Executing `claude/Bloom_Wars_Combat_Encounter_Line_Content_Brief_v1.md` against the brief's §4 deep-tie-in decision. This pass covers Bank 1's full nine-catalyst Act I voice plus Marrow's complete arc, and a solid Bank 2 slice anchored on the Mission 36 relief fleet. It does **not** yet cover Acts II/III catalyst-by-catalyst lines, or the full §5 taxonomy (PL/KO/VC/DF) for every bucket — that's the next pass, not silently treated as done here.

**Named this pass:** the Mission 36 relief fleet's commander — **Commodore Callan Reyes.** Staff-trained, requested this relief tasking personally on seeing how long Warden Company's manifest entry had sat untouched, arrives apologetic rather than triumphant. A deliberate mirror of Marrow: another professional who got closer to doing right by the people actually fighting than the institution around them ever did. This is a real creative call made in this pass, not pulled from any prior doc — flag it if the name or framing doesn't land, it's cheap to swap this early.

---

## Bank 1 — The Other Side (House Amaranth)

### Act I, all nine catalysts — First Sighting (FS) / Mid-combat exchange (MX)

| Catalyst | FS | MX |
| --- | --- | --- |
| Wolf | "This isn't a fight either of us actually wants. Stand down and nobody else's name goes on a wall today." | "Break formation on me again and I'm putting myself between you and my squad. Try me." |
| Dog | "Territory's yours on a map somebody drew before either of us was born. Doesn't mean you get my people." | "You want this checkpoint? Come take it off the ones who'll actually miss me." |
| Cat | "Not my war, not my land, not my house. But you shot first, so now it's my problem, and I bill for problems." | "Every one of you I put down is one less thing shooting at me tomorrow. Simple math." |
| Crow | "Same house colors as the checkpoint file said. Huh. Command actually got something right for once." | "You're bunching up wrong for veterans — somebody back there's calling shots by the book, not the ground. Noted." |
| Raven | "Odds favor whoever holds the angle, not whoever holds the deed. Might want to write that down before this gets worse for you." | "Leaving that flank open on purpose or by accident — either way I'm about to make it expensive to find out." |
| Bear | "I clocked your positions before your own scout did. Pull back now, or I stop just watching." | "I don't need to hear the argument to already know how this ends for you." |
| Fox | "Cute uniforms. Let's see if the discipline underneath is as tidy." | "You fell for that. I almost feel bad. Almost." |
| Rabbit | "Please — nobody has to get hurt today if you just pull back. I mean that." | "I don't want to be the one patching your people up tonight, but I will if it comes to that." |
| Shark | "House colors. Good. I was getting tired of shooting at things that don't shoot back." | "Give me your best mech, not your worst. I didn't come here to feel nothing." |

### House Amaranth's own voice, across the arc (generic trooper)

- **Act I (proud/territorial):** "Warden Company. Mercs playing soldier. Get off our line."
- **Act II, Mission 16 Collaborators, PL (parley/surrender):** "I didn't sign up to fight people — I signed up so my family keeps their terrace ration. Let us pull back. Please."
- **Post–Mission 23 (bargain confirmed):** "Don't tell me what the Lady Amaranth traded. I don't want to carry that too."
- **Act III (shame/desperation):** "We're not fighting for the House anymore. We're fighting because stopping means looking at what we did for it."

### Marrow — full arc, higher-fidelity lane

- **Pre-Mission 20, comms, distant:** "Rourke. Yes — I know your name too. Pull your people back. I'd rather not add you to a very long list."
- **Mission 20 duel, MX:** "You fight like someone who still thinks this war is fair. I did too, once."
- **Mission 20, withdrawing in good order, DF:** "This isn't a retreat. Note the difference before you write your report."
- **Post-23, reflective:** "You'll hate me properly once you understand what I traded and why. Take your time. I've hated me longer."
- **Mission 28, turning on Halcyon mid-battle:** "Thirty years I held this House's sword because someone had to and it was never going to be one of you. That ends today."
- **Mission 28, to Warden, same scene:** "Don't thank me. I'm not doing this for you. I'm doing it because I'm done being the only one who kept my word."

---

## Bank 2 — Coalition Force (Commodore Reyes + generic)

- **FS:** "Warden Company — you're still listed active on the Fleet manifest. Three years, and nobody flagged that as worth checking."
- **FS, personal:** "I'm Reyes. I asked for this relief tasking personally, once I saw how long that entry had been sitting untouched. I'm sorry it still took this long."
- **FS, re: the Warrant:** "Records show your Warrant's been vacant since before any of us shipped out. Who's actually been running this company?" → **Dog, in reply:** "Same person who's been running it since it needed running. You're a little late to ask."
- **AL, mid-fight:** "Hold formation, we'll take the flank. Whatever you've been doing out here without support, Staff is going to want it written up as doctrine."
- **AL:** "Coordinate fire on my mark — and if it doesn't land right the first time, that's on my training, not yours." → **Shark, in reply:** "Try to keep up, regulars."
- **KO:** "Voss is down — get their Munti a lane, now. Nobody else's manifest goes untouched on my watch."
- **VC:** "Objective secured. Somebody get Warden Company's actual current status logged properly this time. I'll be checking."
- **PR, quieter:** "Off-Roll, on-Roll — out here I'm not sure the difference ever meant anything. Wish someone back home could see this."
- **PR, to Rourke directly:** "Whatever rank you're actually owed after this, Major, I intend to make it someone's problem to sign off on. You've earned worse fights than that one."

### HB (Hub reflection, After-Action context, generic Warden catalyst voice)

- **Dog:** "Three years we told ourselves nobody was coming. Turns out somebody was. Just took the paperwork a while."
- **Cat:** "They called it a manifest entry. We call it a family reunion nobody RSVP'd to. Same thing, I guess."
- **Rabbit:** "I don't know whether to be relieved or angry help showed up. Maybe I get to be both. Is that allowed?"

---

## Bonus ideas, not requested, offered anyway

- **Running gag:** Coalition crew keep reading Warden pilots' official service-record names off the manifest and butchering them, since Warden's only ever used callsigns among themselves — "Voss" above is a seed for this, not a named Warden pilot.
- **A non-dialogue beat for Mission 36:** Reyes salutes Rourke first, breaking protocol, before Rourke can salute a superior rank — a wordless way to land "the institution is finally the one that owes something here." Flagged as a staging idea for whoever writes the actual mission script, not a line.
- **Long-tail hook, optional, not needed for this bank:** the Qiraki Political Web doc's own POL-05 open question ("does the Warrant system survive Trav's victory, renamed?") could someday echo forward if Reyes ever recurs — Warden Company's own story becoming part of the argument for reforming the system that abandoned it. Purely a someday-idea, not scoped here.

---

## Still not covered — next pass, not silently treated as done

- Acts II and III, catalyst-by-catalyst (this pass is Act I only for the 9-catalyst table).
- Full §5 taxonomy for every bucket — PL, KO, VC, DF are sampled, not exhaustive, for Bank 1; House Amaranth doesn't get an AL bucket at all under current campaign canon (they never fight *for* Warden).
- Slot-variant treatment (the {SQUADMATE}/{ENEMY}/{MISSION} template system the Ambient bank already uses) — not attempted yet for this bank.
- Doc reconciliation from the brief's §4 (Spitball Ideas, Independent Campaign §6, Master Index) — still pending Maxime's confirmation the origin story lands, per the brief.
