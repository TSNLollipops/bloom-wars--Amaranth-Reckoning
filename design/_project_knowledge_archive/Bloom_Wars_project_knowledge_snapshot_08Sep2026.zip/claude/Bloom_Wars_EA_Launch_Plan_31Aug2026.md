# THE BLOOM WARS — Early Access Launch Plan, 31 Aug → 26 Oct 2026

**Status: the plan, agreed with Maxime 31 Aug 2026.** Written after reconciling three sources that had drifted apart — the synced Claude.ai Project docs (current through 29 Aug), and two files sitting only in the device repo's `design/` folder that turned out to be more current: `Bloom_Wars_Hub_Early_Access_Readiness_Plan_v1.md` (30 Aug) and `Consolidated_Build_Plan_Progress.md` (31 Aug, the execution log against the 29 Aug Consolidated Build Plan). A day-by-day interactive tracker version of this plan was also published as an artifact for daily use; this doc is the canonical, indexable record of the same plan and the reasoning behind it.

## The three scope calls, made 31 Aug 2026

Asked directly, Maxime chose all three recommended options:

1. **EA ships Warden Company only.** House Amaranth — currently 19 of 36 missions built, its own Hub (`HubHouseAmaranth.ts`) not started at all — becomes the first big post-launch content update, built in the open, not squeezed into this window.
2. **Bandwidth:** evenings most nights (decisions/testing/steering) plus unattended Claude stretches (overnight, while away) kicked off with a clear backlog queued.
3. **Launch target: itch.io only.** Free browser demo + a paid Electron-packaged download, PayPal direct. Steam is explicitly deferred to after an art pass, per the existing Selling & Launch Plan's own recommendation.

## Ground truth at the start of this plan (31 Aug 2026)

Reconciled from the code and the two most-current device-only docs above, not from the synced Project docs alone, which were two days stale on several of these points:

- **Warden Company:** all 36 missions built, sim-tuned. Test suite: 1192/1192 passing.
- **The Hub:** far deeper than the original Phase-1 plan — 8 walkable rooms across 3 decks, the full verb framework (Talk, Ask Out, Share a Drink, 3 minigames, Anger Blowup, Breakdown), autonomous NPC roaming/cliques, rumor propagation, typed chat, Mek NPCs. Tiers 0–6 of the 29 Aug Consolidated Build Plan are all code-complete (Player AI class-triangle targeting, all 4 Hub collision/movement bugs, minigame room gating, roster-driven population, the Hangar panel, Ambush→stealth redesign, the enemy-variety pass). **Correction, 31 Aug 2026, from Maxime directly: he does click-test the game live as things get built** — several of the currently-open bugs (Hub NPC clustering, muster cross-deck routing) were found exactly that way, playing it himself. The real gap isn't "nothing gets tested" — it's that no single pass has yet run the full checklist together as one system, and a few of the newest slices (the concurrent session's Tier 0–2 fixes, the latest Player AI rounds) haven't specifically had his hands on them since they shipped. Worth remembering going forward so this doesn't get overstated again.
- **Still genuinely unbuilt on the Hub:** the Vault (Heirloom dedication scene, now also the Heirloom Pilot acquisition gate per Maxime's 30 Aug addition), CIC/Bridge (fire-support config, Energy allocation), the calendar/day-cost economy (a locked 25 Aug design decision that was never implemented), full Mek backstories/personality beyond a mechanical stub.
- **Art:** all 15 named pilot portraits + 4 splash images already generated and in the repo — ahead of schedule. Battle art stays placeholder geometric shapes for EA; that's an explicit, already-made decision (Stage 4 art is gated on having an artist, not on this launch).
- **Selling:** itch.io can't paywall a browser-embedded game — the real blocker is that the game has no downloadable form yet. Electron packaging is the unavoidable first step; it hasn't been started.
- **Known open bugs/balance items, not launch-blocking on their own:** Player AI commander-protection (4 attempts, Maxime's own call: "I'll do an AI pass later" — deferred). **Balance philosophy corrected 4 Sep 2026, directly by Maxime.** Warden Act I's inversion (Missions 1, 7, 12, 21 near-unwinnable at every AI tier) is his own to fix, on his own schedule, not a Claude task: *"Missions issue are mine to deal with. I will personally tune each of them but later."* Separately, and more importantly for how this whole line should be read going forward: the 1-2 Sep "AI win-rate target bands" proposal (`Bloom_Wars_Player_AI_Difficulty_Tiers_Plan_v1.md` §6) was built on a premise Maxime says is wrong — *"Ai arent really suposed to win the mission btw. Ai test are to see if mission is cheesable."* The AI batch sim's real job is catching cheese (a degenerate exploit that trivializes a mission regardless of its intended difficulty), not hitting win-rate targets by tier. A mission the AI loses every time, even on Hard, isn't inherently a problem on its own. That retires the target-band system as "the working rule" it had been informally running as since 2 Sep. Full write-up and what's still genuinely open: `Bloom_Wars_Build_Log_Addendum_BalancePhilosophyCorrection_04Sep2026.md`.

## What ships 26 Oct

Warden Company's 36-mission campaign, hardened and verified live; the Hub as it stands today plus the Vault; HOW_TO_PLAY.html with a real Hub section; an Electron-packaged Windows download alongside the free browser demo; the itch.io page with PayPal Business connected and a price set inside Maxime's own $5–$20 ceiling; one outside playtesting round; a final naming-lock sweep.

## What's deliberately deferred, not forgotten

House Amaranth (missions 20–36 and its entire Hub); Steam; the calendar/day-cost economy (pending a Week 1 decision, recommendation: defer and record it, not build it); CIC/Bridge fire-support and Energy allocation; Mek backstories/personality past a names-only pass (also pending a Week 1 decision); the rest of the Social Sim Roadmap; a real battle-sprite art pass.

## The eight weeks

| Week | Dates | Theme |
|---|---|---|
| 1 | 31 Aug – 6 Sep | Ground Truth & Scope Lock — full whole-system verification pass, three open decisions locked (calendar economy, Vault/CIC cut line, Mek scope), cheap hardening (dev labels, Iyari collision, extract-mission briefing text) |
| 2 | 7–13 Sep | Build the Vault — dedication scene + Heirloom Pilot acquisition gate + 1-per-mission deploy cap |
| 3 | 14–20 Sep | Docs & tech debt — HOW_TO_PLAY.html Hub section (done early, 4 Sep — see addendum), Hub.ts test coverage (stretch, still open), balance triage (Mission 5/10 re-diagnosed early, 4 Sep; Act I inversion is Maxime's own to tune later, not a Claude task; the AI-sim's real purpose is cheese detection, not win-rate targets — see addenda) |
| 4 | 21–27 Sep | Electron packaging — the one step every sales path depends on; first time doing this, budget the whole week |
| 5 | 28 Sep – 4 Oct | itch.io page (copy, screenshots, trailer) + naming-lock sweep + a second full verification pass |
| 6 | 5–11 Oct | Outside playtesting round + PayPal Business setup + price lock |
| 7 | 12–18 Oct | Close out playtester feedback + first devlog post + scope freeze |
| 8 | 19–25 Oct | Final regression pass, final installer build, soft-launch on itch.io, draft the announcement |
| — | **26 Oct** | **Launch.** |

Full day-by-day task breakdown (with QUEUE/EVENING/DECISION/BUFFER tags and a checkbox tracker) lives in the published artifact — same content, meant for daily use rather than re-reading this doc every night.

## The two places this is most likely to slip

**Week 1's verification pass.** Not a "first ever" test — Maxime already click-tests as things get built. The real gap is a single pass that runs the full checklist together, plus the newest slices that haven't had his hands on them yet. If that surfaces more than expected, that's the week to re-plan around, not push through.

**Week 4's Electron packaging.** Genuinely new territory, and it's the one dependency every other selling step sits on. The weekend right after is buffer on purpose.

## Not yet done as part of this plan, worth a note for whoever picks this up next

The Master Index (`Bloom_Wars_Master_Index.md`) has not been updated to point at this plan or at the two device-only docs (`Bloom_Wars_Hub_Early_Access_Readiness_Plan_v1.md`, `Consolidated_Build_Plan_Progress.md`) that turned out to be more current than the synced Project — worth doing on the next pass through it, rather than as a full rewrite here, given its size and the risk of a full-document rewrite dropping something.

## Addendum, 3 Sep 2026 — an unscheduled Week 1 detour: the ship interior pass

**What happened, plainly.** During Week 1 ("Ground Truth & Scope Lock"), a same-day conversation about the Hub's growth led to a real, shipped ship-interior rebuild — real walls, doorways, and A* pathfinding between every room on a deck, plus a carrier scale-up (bigger decks, camera scroll, the Workshop and Berths each split into three per-lance instances, new Heads and Engineering rooms). Full detail in `Bloom_Wars_Build_Log_Addendum_ShipInterior_WallsCorridorsPathfinding_03Sep2026.md` and `Bloom_Wars_Build_Log_Addendum_CarrierScaleUp_Phases1and2_03Sep2026.md`. This is real, working, shipped code, not a design doc — same status as the rest of the Hub work this plan already tracks as "far deeper than the original Phase-1 plan."

**Why it's worth flagging here specifically:** none of it was in this plan's Week 1 task list above (verification pass, three decisions, dev-label/Iyari-collision/briefing-text hardening). It's a meaningfully new system by this project's own scope-flagging rule — a second movement/rendering mode for the Hub, not a hardening pass — and it landed inside the week this plan reserved for locking scope down, not growing it. Not raised as a problem after the fact — the work already shipped and was live-verified in the browser before this note was written — just recorded honestly so Week 1's own actual contents match what this plan says Week 1 was for, rather than the plan quietly going stale next to what actually happened.

**Practical consequence for the rest of Week 1:** the three open decisions this plan's Week 1 line still names (calendar economy, Vault/CIC cut line, Mek scope) are unaffected — all three were already locked before this detour started (calendar economy and Vault/CIC cut line via the Week 1 Hardening addendum, 1 Sep; Mek scope resolved the same day, see `Bloom_Wars_Build_Log_Addendum_MekScopeDecision_01Sep2026.md`). **Correction, same pass this note was written:** an earlier draft of this addendum claimed Mek scope was "still open" — wrong, caught by actually checking the Mek Scope Decision doc rather than assuming from an older summary, per this project's own standing rule to verify against the current file. Week 1's three decisions have been fully closed since 1 Sep. What the whole-system verification pass still owes, though, is real: it should now also cover the ship interior pass specifically, since that's new enough (a new movement/collision system, shipped after the 1 Sep verification pass) that the existing checklist wasn't written with it in mind.

**A real design question came out of this detour, not just code — resolved same day.** The ship interior pass's walls-and-doors model sat in direct tension with an earlier, explicit design call in `Bloom_Wars_Antfarm_Grid_v1.md` §3f (26 Aug 2026 — "the deck itself is one continuous walkable floor, no door, no scene-swap"). Asked directly which design to keep, Maxime: "wall is better." Both `Bloom_Wars_Antfarm_Grid_v1.md` and `Bloom_Wars_Antfarm_Carrier_Hub_v1.md` now record walls-and-doors as the locked model going forward.

## Before-EA punch list — small, not urgent, easy to lose track of

Maxime, 4 Sep 2026, after the Codex Rebuild & Live Briefing work shipped: **"mark those to do before ea. not urgent."** These are small polish items surfaced along the way that belong in the Warden Company EA build (not the House Amaranth deferral bucket above) but don't need attention now — a place to park them so they don't get forgotten, not a scheduling commitment to any particular week above.

- **The CO's real display name.** His in-code `displayName` is still a placeholder string (`Codex.ts` hardcodes a safe stand-in so the Personnel tab doesn't show it as-is). One-line fix once Maxime actually picks the name — worth doing before EA since he's a visible, talkable NPC in the build that ships.
- **Rourke's "empty bio" flavor idea.** `Bloom_Wars_Personnel_Codex_Entries_v1.md` floats an idea for her own Personnel entry reading differently depending on save state; only her live status line does that today, her bio text itself is static. Small, cosmetic, no mechanical dependency — fine to fold in whenever a Codex pass happens again.
- **House Amaranth's own Codex content (Personnel/Bestiary/World), flagged for completeness — but honestly, this one's probably a non-issue.** Since House Amaranth itself ships post-launch (see "What's deliberately deferred" above), its Codex content is already covered by that same deferral, not a separate before-EA task. Listed here only so it isn't independently rediscovered and treated as a surprise gap later.

Full context for all three: `claude/Bloom_Wars_Build_Log_Addendum_CodexRebuildAndLiveBriefing_04Sep2026.md`.
