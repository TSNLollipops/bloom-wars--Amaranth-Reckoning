# THE BLOOM WARS — Bloom Silhouette Doctrine, Proposal v1

**Written 27 Aug 2026**, in response to Maxime asking what could make the Bloom more visually distinct. Visual reference and full spec live at the artifact linked below — this doc is the citable text version for the project's own record.

**Visual reference:** https://claude.ai/code/artifact/998b33de-dd98-4cf5-a02a-95d4299254b7 (all five shape families rendered at scale, plus the two supporting refinements — read that first, this doc is the text backing it)

**Status: shipped and fully visually confirmed, 27 Aug 2026.** Maxime: "it should be an automatic in. and built when possible." Built into `Battle.ts` the same day — `bloomSilhouetteKind()` maps `movementType` to one of the five families below, wired into both `drawUnit`'s fill pass and `strokeSilhouette`'s outline pass. All five shape families are now confirmed pixel-correct in live play — see §7 for the full build/verification record, including a real cross-session file-collision that had to be caught and merged before this pass could even start.

## 0. The gap this closes

Player units already get a formal encoded silhouette (GDD §12.1) — combat path drives shape, so a triangle/square/diamond/circle-with-crossbar tells you how a unit fights before you read a stat. The Bloom never got the equivalent rule: each of the seven archetypes has a locked color palette (Canon Pass §E, pulled from the Bioterror Bank's generative system), but no formal shape rule — `spriteKey` implies distinct shapes per archetype (`bloom_blob_small`, `bloom_spike_burrow`, `bloom_mass_large`) but this was never confirmed against the actual renderer this session. Right now the Bloom reads as "the stuff with weird colors," not as seven recognizably different threats.

**Confirmed at build time (§7 below):** the gap was real. Before this pass, every Bloom unit rendered as the same plain circle ("blob") regardless of archetype — `Battle.ts`'s own prior code comment described "blob" as covering all Bloom units — so color was genuinely the only distinguishing signal on the board before today.

## 1. The rule

**A Bloom unit's `movementType` determines its silhouette family** — the same logic as the player side's combat-path encoding, applied to arguably the single most tactically urgent thing to know about a Bloom unit on sight: can it reach me, does it need to surface first, is it rooted in place.

This slots into the existing GDD §12.1 table as one new row:

| Property | Encoded as | Values |
| --- | --- | --- |
| Combat path | Silhouette | Meeps = triangle · Tank = square · Reeps = diamond · Munti = circle w/ crossbar |
| Faction | Fill colour | Player = steel blue #2E5C7A · Hostile mech = ochre grey #7A6A55 · Bloom = per-archetype palette |
| Species chassis | Outline treatment | Human = single outline · Hiopi = double outline · Osnius = whisker ticks |
| Gear tier | Corner pips | G = none … A = six |
| Current HP | Segment bar | Mechs = one segment · Bloom = two (Endurance, then Vitality) |
| **Movement type (new)** | **Silhouette family** | **Swarm · Burrow · Sessile · Flight · Limbless — this doc** |

## 2. The five families

| Movement type | Archetypes | Silhouette | Reads as |
| --- | --- | --- | --- |
| Swarm | Crawlmass, Splitfang | Small, round, overlapping cluster shapes | Individually weak, dangerous in numbers — don't waste a turn on just one |
| Burrow | Undertow | Jagged/spiked, only rendered when surfaced | Hidden until it strikes; the shape only appears in the ×1.5 damage window |
| Sessile | Gallcyst, The Heartwood | Wide-based dome with root/tendril marks into the tile | Can't come to you, still hurts at range — reads immobile before checking its move stat |
| Flight | Sirenmaw | Swept-wing outline, lifted off the tile with a shadow beneath | Ignores terrain, can't be blocked — reads airborne before checking `movementType` |
| Limbless | Sporethrower | Elongated, legless curve, one lit gland at the launch point | Ranged, not melee, and can't run either — nothing about the shape suggests speed |

Every silhouette is deliberately irregular/asymmetric, never a clean mirrored polygon — this pairs with a second, free layer described below.

## 3. Two layers underneath, one flag alongside

**Organic vs. geometric edges (already reflected in the shapes above).** Player and mech silhouettes are precision geometry — triangle, square, diamond. Bloom should never share that vocabulary: the Bioterror Bank's own rule is "no symmetry in patterning … blotches and asymmetric bleed read as biological." Every shape family above is built un-mirrored for this reason — it costs nothing extra once the family shapes exist, but it's worth stating as a deliberate rule rather than an accident of how the paths were drawn.

**Swarm cluster variation (proposed, not required).** The Bioterror Bank also specifies swarm-type units shouldn't be color-uniform — individual variation per unit or cluster reads as "mass of living things," flat uniform color reads as a texture asset. The current schema has one static `colorPalette` per archetype. Rolling 2–3 palette variants at spawn (or a small per-unit jitter) for Crawlmass/Splitfang specifically would close this; genuinely a nice-to-have, not a blocker for the shape-family rule shipping without it. **Still not built** — shipped exactly as scoped, this refinement wasn't part of the 27 Aug pass.

**Collapse-state visual cue — a separate proposal, flagged only because it lives in the same renderer.** Data Pack §8.3: a Bloom creature at 0 Endurance hits at full strength — the Collapse clause means the moment its indicator changes is the moment it becomes most dangerous, exactly when a linearly-draining health bar would suggest the opposite. A visual state change (cracked shell, brighter core bleeding through) would telegraph "more dangerous now," matching the same "read the board without a legend" logic as the shape families — but it's driven by a different stat (Endurance state, not movementType) and should be decided on its own rather than bundled into this rule. **Still a separate, unbuilt proposal** — not touched by the 27 Aug pass.

## 4. Scope, plainly

This was a real small new rendering system, not a data-only change — new draw logic in the same place the player-unit encoding already lives (`Battle.ts`'s `drawUnit`/`strokeSilhouette`), not just edited data values. Flagged per the project's own scope rule before it got built; Maxime's "automatic in" greenlit building it the same day it was flagged.

## 5. What stays open regardless of whether this ships

- **Choir, Wellroot, and the Unnamed still have no locked colour palette** (Canon Pass §E only covers the original seven archetypes) — they'd need one, and a `movementType`, before a shape family could apply to them at all. Choir and the Unnamed already have `movementType` set in `data/bloom.ts` (both inherit their lineage archetype's — `flight_membrane` and `sessile` respectively) so the shape-family rule already applies to them mechanically; the missing piece is specifically the locked palette, not the shape. Wellroot doesn't yet exist as a `BLOOM` entry at all as of this pass.
- **Render size is still ad hoc.** A boss reads "large" today only because its `spriteKey` happened to get named that way by hand, not because of a formal rule tying tile footprint to Endurance or a composite threat score. Worth its own follow-up pass, separate from this doc.

## 6. If this gets adopted

GDD §12.1's encoding table would need a new row added (§2 above gives the exact text). Canon Pass §E would need three new palette entries once Choir/Wellroot/Unnamed get one. **Neither has been edited yet** — the code shipped 27 Aug 2026, but the GDD/Canon Pass `.docx` edits this section calls for are a deliberate fast-follow, not done in the same pass (a heavier unzip/edit-XML/rezip workflow, tracked separately rather than rushed alongside the code).

## 7. Build status, 27 Aug 2026

Built the same day Maxime greenlit it ("it should be an automatic in. and built when possible.") — `type SilhouetteKind` extended from 5 to 10 values, a new `bloomSilhouetteKind(movementType)` helper added, and both `drawUnit`'s fill pass and `strokeSilhouette`'s outline pass extended with the five new branches. The pre-existing burrowed-Undertow hidden state (dashed outline, 40% opacity, plain "blob" fallback until it surfaces) was preserved exactly — a surfaced Undertow gets the real jagged spike shape, a burrowed one still reads as the generic blob per §2's own "the shape only appears in the ×1.5 damage window" line.

**Verification, initial pass (same session that built it):** `tsc --noEmit`, `eslint --max-warnings=0`, the full `vitest` suite (910/910 passing), and `npm run build` all clean. Battle rendering has no dedicated unit-test coverage, so this was followed up with a live headless-browser smoke test (Playwright + a local Vite dev server) across several real missions and turn advances — zero console/page errors throughout, and the pre-existing player-unit silhouette system (meeps/tank/reeps/munti/hiopi/osnius) confirmed unaffected. Two of five families were visually confirmed pixel-correct that pass, by screenshot in real missions: **Swarm** (Crawlmass/Splitfang, Mission I.4 "Tunnel Rats") and **Sessile** (Gallcyst/Heartwood/Unnamed, Mission I.9 "Cut Off"). The other three — Burrow, Flight, Limbless — weren't reachable that pass: their missions all spawn at `enemy_deploy` (a non-fixed position), and on the maps tried, that zone sat outside what the smoke test's turn-advance window actually captured. Flagged, not assumed correct, and left as a real "check this next" note.

## 8. Follow-up pass, same day — the remaining three families confirmed, plus a real cross-session collision caught and fixed

Maxime, in a separate conversation, asked this session to "test it out" — the follow-up this doc's own §7 had already flagged as needed. Before any visual check could run, syncing this session's own local working copy against the actual on-device `Battle.ts` turned up a real problem: **this doctrine's code had been built on top of an older copy of `Battle.ts` that predated a separate, already-shipped batch of work from earlier the same day** (the Mission 1 tutorial hint layer, the mission-title clip fix, and the reachable-tile highlight contrast pass — see the Master Index's own entry for that batch). When the doctrine's own changes synced to the device, they silently carried the *old* version of everything else in the file along with them — `HUD_TOP` reverted from 40 back to 12 (re-breaking the title-clip fix), the highlight contrast fix reverted to its pre-fix alpha, and every tutorial-hint field, hook, and method were gone outright. Two other data files (`campaignAmaranth.ts`, `mapsAmaranth.ts`) had also drifted from this session's own stale local copies, from unrelated concurrent work elsewhere — adopted as-is, untouched, purely so this session's own test environment reflected the real current state rather than a stale one.

Not something to build around quietly: the two batches were merged by hand, edit by edit, back onto the current on-device file, then verified clean (`tsc --noEmit`, lint, `npm run test` — 929/929, `npm run build`) and re-synced to the device before any visual testing began. Both features now coexist correctly in the one shipped file — confirmed live in the same Playwright pass below, screenshot showing the tutorial hint banner rendering correctly alongside Bloom units drawn with their new silhouettes.

**The actual visual check, forcing the three untested families onto the board directly** (their real missions spawn them off in a dynamic `enemy_deploy` zone that a short automated pass can't reliably land a screenshot on) rather than waiting on spawn timing: loaded Mission 1, used a temporary debug hook to reassign a few of the mission's own live hostile units to the untested archetypes at fixed, clearly visible board tiles, and re-rendered. All three confirmed pixel-correct against §2's own spec, by zoomed screenshot:

- **Burrow** (Undertow, surfaced) — a clean six-point jagged spike, dark navy fill matching the archetype's own locked palette, light outline. Matches "jagged/spiked."
- **Flight** (Sirenmaw) — a swept-wing silhouette lifted above the tile with a dark shadow ellipse beneath it. Matches "swept-wing outline, lifted off the tile with a shadow beneath."
- **Limbless** (Sporethrower) — an elongated capsule with one lit yellow gland at the launch-point end. Matches "elongated, legless curve, one lit gland at the launch point."

Swarm and Sessile were also re-drawn in the same screenshot as a same-pass regression check, alongside the three new ones — both still read correctly, unaffected by anything in this pass. Zero console/page errors throughout. The debug hook was removed and the file confirmed byte-identical to its pre-hook state before the final sync.

**All five silhouette families are now visually confirmed correct, in a real running build, matching this doc's own §2 spec exactly.** Nothing left open on the rendering side. What's still open is unchanged from §5/§6 above: Choir/Wellroot/Unnamed's missing locked colour palettes, render size still being ad hoc, and the GDD §12.1/Canon Pass §E `.docx` edits this doc calls for still being a deliberate, not-yet-done fast-follow.
