# THE BLOOM WARS — Calendar System v1

> **CORRECTED, 2 September 2026 — read this box before the doc.** The core
> mechanism specified below (§1: "fixed cost per mission... regardless of how
> long the player personally took," explicitly "independent of real play
> speed") was **overturned by Maxime on 2 Sep 2026** and is no longer what the
> game does. His replacement model, verbatim: *"time spent in the hub and time
> spent on mission run on the same ckock. depend on time player spend in each.
> like a inevitable day night cycle in wow. the calandar run when you play. no
> matter what you do. some event take some times some less."*
>
> The calendar is now a **real-time clock** fed by actual play in the Hub and
> in Battle, with small per-activity accents on top. It is **built and
> shipped** as of the same day.
>
> Authoritative docs, in order:
> `claude/Bloom_Wars_Calendar_Economy_Build_Proposal_v2_RealTimeClock.md` (the
> model and the numbers) and
> `claude/Bloom_Wars_Build_Log_Addendum_CalendarEconomy_02Sep2026.md` (what
> actually shipped). This doc is kept for the parts that survived — they are
> marked inline below — and as the record of what changed.
>
> **What survived unchanged:** the in-fiction date-stamp display shape ("Day 47
> — Muster"), cosmetic-only/no-fail-state, the itemized-not-flat pricing
> principle and its cost ordering, and the cross-player-comparison default.
> **What did not:** §1 entirely, and the *reasoning* (not the conclusion) in
> the two-clocks section.

**Confirmed direction, 28 Aug 2026, most of the shape decided the same day — first real numbers still owed.** Same status tier as `Bloom_Wars_Worries_System_Proposal_v1.md`: real design to build against, not something already shipped.

## Why now

This idea has been queued since 25 Aug 2026 (`Bloom_Wars_Spitball_Ideas.md`), deliberately parked behind two of Maxime's own sequencing calls: "keep it queue. we gonna add the full calandar when we are done with the mission building. because after than I want to work on the ui for non combat interaction." Both conditions are met — the 36-mission campaign is done, and the project is deep into non-combat/Hub work right now. A second, sharper trigger arrived the same day this doc was written: `Bloom_Wars_Worries_System_Proposal_v1.md`'s own "two clocks" problem exposed that nothing in this codebase has an in-game clock for anything to normalize against. Maxime's call once that was surfaced: **"we should probably do the calendar noe. its needed fkr furter game expention."**

Two other things are already stalled waiting on this system existing:
- `Bloom_Wars_Worries_System_Proposal_v1.md`'s two-clocks problem (see "What this unblocks" below).
- `Bloom_Wars_Mek_Workshop_And_Weapon_Progression_v1.md`, which already names the calendar as "the natural home" for a build-queue time cost, if weapon/mek fabrication ever gets a "takes time" mechanic.

## What this is

An in-fiction calendar, visible throughout the campaign, distinct on every axis from the existing mission real-time clock (`engine/campaignState.ts` §9 — real-world wall-clock minutes/hours, running only during an active mission attempt, hard 12-hour fail-and-recall). This calendar is in-fiction time, runs across the whole campaign rather than one mission at a time, and — per Maxime's original framing, "so player can see how much time passed," not "so player fails if they take too long" — is a visible, ambient number with no fail state attached.

Origin, Maxime's own words, 25 Aug 2026: "like a calanda a canon based one. but with obiously a tracking clock in it. so player can see how much time passed. becasue its gonna be relevant when we do the social game. social stuff take time. and time u do social u aint fighting." The core idea: every stretch spent on hub/social activities is calendar time the war keeps moving without you — a real opportunity-cost mechanic, not flavor text.

**Confirmed display shape, 25 Aug 2026.** Not a bare running total in a corner — an in-fiction date-stamp, doubling as a pacing landmark for major beats: "Day 47 — Muster," "Day 212 — The Reckoning." Maxime: "yeah that would be cool. indeed." *(Still accurate. Shipped as a "Day 47 → Day 52" transition stamp on the Debrief screen plus a live "Day N" readout in the Hub HUD. The named landmarks themselves — which specific days earn a name like "Muster" — remain an open content/writing task, not a mechanical one.)*

## The three questions, answered 28 Aug 2026

**1. What advances the calendar: fixed cost per mission.** ~~Each mission costs a flat or mission-specific number of in-fiction days, regardless of how long the player personally took. The number is purely about choices — how much social time was bought — not play speed. Deliberately does NOT fold in the real-world 12-hour mission clock; a player who dawdles in a live mission doesn't burn extra calendar time. Matches the calendar's own original purpose ("so player can compare each other") — a fair comparison needs the number to reflect decisions, not connection speed or how many breaks someone took mid-mission.~~

> **OVERTURNED, 2 Sep 2026.** This answer is now exactly backwards: real play
> time in the Hub and in Battle is the *primary* driver, and the flat
> per-mission cost survives only as a small add-on for the transit and prep a
> mission implies but never shows on screen.
>
> The strongest argument this paragraph made — that a comparison number should
> reflect decisions rather than connection speed — was real, and the new model
> accepts the cost knowingly rather than having missed it. Two things blunt it
> in practice: the comparison was already only ever a cheap shareable end
> screen (§4 below), never a competitive leaderboard, so the fairness bar is
> low; and the model that replaced it buys something this one couldn't have —
> an ambient clock the player feels continuously while playing, instead of a
> number that only jumps at a debrief screen. One real consequence is
> documented rather than papered over: a player who idles in the Hub burns
> days for nothing. Harmless while the calendar is cosmetic; the first thing
> to revisit if teeth are ever added.

**2. What social/hub activities cost: an itemized price list, not a flat tax.** Different activities cost different amounts — a Rec Room night costs less than a Berths romance scene, a CO conversation costs less than either. This is the same per-activity pricing work Favorability/Stress already owe the project (Antfarm Hub doc §13, §11.4) once built — one cost model, designed together, not two uncoordinated ones. Actual numbers not set here — same "don't invent tuning numbers before playtesting" discipline held everywhere else in this project.

> **Survives, demoted, 2 Sep 2026.** The principle and the ordering both held
> up and are implemented: conversation (including CO conversation) is free,
> Rec Room activities cost more, and the romance-tier action costs most,
> exactly the ordering locked here. What changed is its *role* — these are now
> small accents layered on a real-time base, not the thing that moves the
> calendar. Maxime's steer on the spread was "narrow the gap," so the whole
> range sits between 0 and half a day. Numbers in the v2 proposal.

**3. Does elapsed time have mechanical teeth: cosmetic only, for now.** A visible day count during play plus a comparison number at the credits — nothing in the war reacts to it mechanically yet. Cheapest version to ship first; the "real teeth" version (war state quietly worsening the longer a campaign runs, missions reading differently at day 400 vs. day 150) stays a real option for later, once the base system's been felt in actual play. Fits the tone this project already has for Sessile ("meet one too early and you die" already treats time-in-campaign as a threat-scaling axis, just for one creature type) but is separate design and content work, not part of this pass. *(Still accurate and still the shipped behavior — and now load-bearing for a reason this doc couldn't have known: with a real-time clock, an idle player accrues days, which is only harmless because nothing reacts to the number.)*

**4. Cross-player comparison infrastructure — still genuinely open, not asked as a question this round.** The original idea ("so player can compare each other") still has no infrastructure to run on: this is a pure local-browser game, `localStorage` only, no accounts, no backend. Defaulting to the cheap reading (a shareable result — a code, or a screenshot-ready end screen with the final day count) rather than a real leaderboard, since nothing else in this project has a server-side component and building one would be a large, separate piece of scope on its own. Flagging this default rather than deciding it — worth an explicit check whenever this actually gets built, in case Maxime wants something more than the cheap version. *(Still open, and the check flagged here is still owed. Note the real-time model makes a competitive comparison meaningfully less fair than this doc assumed, which is an argument for keeping the cheap version rather than growing it.)*

## What this unblocks: the Worries proposal's two-clocks problem

`Bloom_Wars_Worries_System_Proposal_v1.md` left open whether `WorryEntry.intensity` values from different sources (real-time Mission Worry vs. an eventual in-game-time source) should normalize to one clock or compare directly on the 0-1 intensity scale regardless of native clock. That doc's own verification pass (28 Aug 2026) already recommended keeping native clocks (option 2), for two reasons:

- ~~**The calendar's own granularity is per-mission, not continuous.** It advances by a fixed cost when a mission resolves — it does not tick minute-by-minute during an open mission attempt. Mission Worry's ramp (`WORRY_ONSET_MS`/`WORRY_RAMP_MS`) needs to resolve *while* a mission attempt is still open, sitting in real time between BEAM DOWN and Debrief — a window the calendar never ticks inside at all. There's no way to express "4 minutes into a still-open attempt" as a calendar-day value, because the calendar has no resolution finer than a whole mission. Normalizing Mission Worry onto the calendar isn't just harder, it's structurally incompatible with how the calendar advances.~~
- **Worry was already locked to real time, on purpose, before this calendar existed.** 25 Aug 2026, on the general ambient-worry concept this later became `missionWorry.ts`: Maxime, asked to resolve the same wall-clock-vs-calendar fork for worry specifically: "the worry goes paralel to mission time. it run until the player exit, what isnt saved is lost." Real wall-clock, explicitly not calendar-tick, explicitly not persisted. That's a standing decision about worry specifically, not just a guess this doc made — routing Worry through calendar time now would reverse an already-locked call.

> **The conclusion survives; the first reason for it does not, 2 Sep 2026.**
> Worth correcting explicitly rather than leaving in place, because the struck
> paragraph is now false in a way that would mislead anyone reading it as
> current: the calendar IS continuous now, it DOES tick during an open mission
> attempt (Battle feeds it), and "4 minutes into a still-open attempt" is
> perfectly expressible as a calendar-day fraction. The structural
> incompatibility it describes no longer exists.
>
> Keeping native clocks is still right, for the second reason above (a standing
> locked decision) and now for a simpler third one: with the calendar itself
> running on real time, both clocks already sit on the same substrate. There is
> nothing left to normalize. The Worries doc's own `expiresAt: <1 in-game day
> for Hub-context entries` line still wants fixing to real elapsed time — the
> recommendation below is unchanged, though the reasoning is now "match Mission
> Worry's convention," not "the calendar can't represent it."

Net: Worries entries keep their native clock (real time for Mission Worry, whatever a combat/domestic source ends up using) and compare only on the resulting 0-1 intensity number.

## Not decided here

*(All but one of these are now decided — see the v2 proposal and the build-log addendum. Left in place with their resolutions rather than deleted, so the record of what was open when reads straight.)*

- ~~Actual day-cost numbers per mission, and the itemized per-activity price list~~ — **decided 2 Sep 2026.** 1 day per 6 real minutes of play; +2 days flat per mission; per-verb accents 0 / 0.25 / 0.5. All placeholders pending playtesting, as this doc's own discipline demanded.
- **Whether "teeth" ever gets built, and if so what it changes — still genuinely open.** The only item on this list that is.
- ~~The cross-player comparison mechanism (question 4 above).~~ — defaulted to the cheap end-of-campaign day count; the explicit check with Maxime is still owed, see §4.
- ~~Where the day count and date-stamp actually render in the Hub UI.~~ — **decided:** a live "Day N" readout in the Hub's top HUD row (right-aligned, x=700, sharing the row with the rank line and THREAT), plus a "Day 47 → Day 52" transition stamp in the Debrief header.
- ~~Campaign start date / calendar epoch (what "Day 1" corresponds to in-fiction).~~ — **decided:** Day 1 is campaign start (first Hub load on a new save), not first mission completed. What Day 1 corresponds to *in-fiction* — an actual in-world date, if that ever matters for tone — is still unwritten, and is a lore question rather than a systems one.
