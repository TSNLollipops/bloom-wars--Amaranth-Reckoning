# THE BLOOM WARS — Background Zones: Birthplace / Academy / Planet / Sector v1

**Design pass only — zero code, matching `Bloom_Wars_Character_Editor_v1.md` and `Bloom_Wars_NPC_Reaction_Engine_v1.md`'s own standing rule.**

*Written 1 September 2026, at Maxime's direct request: "Give our npc a worthy background wheel the npc creator... this is the formula with the planet and the pillar... lets make birth place, academies and planets and sector for our games. the richer we make those now, the less work we will have later when we expend the game universe." Built using the Qiraki canon bridge Maxime connected this session (`design/qiraki-canon-bridge/` on his device), per his own instruction to ground this in book canon rather than invent from nothing.*

**Update, same day — both open calls confirmed.** Maxime's own words: *"i like the naming lock. and the pressure thing look good to me. it fit the pilar way of explaining itself."* That closes the two judgment calls this document flagged as open: §1's naming-lock call (invent fresh proper nouns rather than port real Qiraki locations) and §6's Zone × Pressure → Planet-12 table are both now locked design intent, not proposals. Both sections are edited below to say so directly. What's still genuinely open is narrower now — see §10.

## 0. What this is actually answering

Two open questions this project has been carrying since 25 August, named explicitly rather than reopened from scratch:

1. **`Bloom_Wars_NPC_Reaction_Engine_v1.md` §4:** "How a pilot's Planet position, pillar weights, and archetype get assigned — by hand per named pilot, generated for player-created recruits, or some mix of the two." Character Editor v1 §2 answered half of this — the **animal label** (Wolf/Dog/Cat/Crow/Raven/Bear/Fox/Rabbit/Shark) seeds a pilot's *catalyst* behavior. It never touched the other half: a pilot's **origin**.
2. **`Bloom_Wars_NPC_Reaction_Engine_Audit_And_Closing_Plan_v1.md` §1, row "A":** "This is the whole reason **Background Zones** has nowhere to plug in yet — it's not an assignment-method question, there's no seam to assign into." That audit named this system before it existed. This document is that system.

**The two axes are complementary, not competing.** The animal label seeds **c** — what a pilot is visibly doing right now, moment to moment. Background seeds something closer to **B**'s own definition in the newer Applied Model source (v6, shared this session): *"accumulated memory... accumulated experience... basic b⁴, their default four-echo pattern... the trait, not the event."* A pilot's origin is exactly this kind of trait-level history — the thing the formula's own closing principle points at directly: *"the formula never supplies the tiebreaker — character history does."* Background is character history, supplied at creation instead of accumulated through play, for a pilot who otherwise has none yet.

**What this document delivers, concretely:** a Sector layer (5), a Planet layer (10, two per sector), an Academy layer (5, plus a deliberate no-academy option), and a Birthplace Texture layer (8, cross-cutting) — enough combinatorial richness that a "Generate" pilot reads as textured without hand-authoring individual biographies, plus a locked design for how Zone (a sector's Core/Mid-Rim/Frontier tier) and Pressure (a derived reading of how early and how hard real stakes landed on this pilot) seed the hidden Planet-12 position and pillar weight Character Editor's own §2 already promised the player would never have to see directly.

## 1. The naming-lock call this document had to make, stated plainly

This is the one place today's work runs directly into the project's shared rule, so it gets its own section rather than a footnote.

**Locked, 1 September 2026 — Maxime confirmed this call directly ("i like the naming lock").**

**What's actually locked, as best this session can tell — the absolute reserved term is deliberately never written anywhere in this project's own docs, including the Build Brief's own lint script, which pulls it from an environment variable specifically so the checker itself never contains it.** Reading the Qiraki bridge's own README plainly: the enemy's true name is spoiler-locked *in the novel*, and the bridge's own words are "it's your call whether Bloom Wars... needs to honor it too." Given how the Build Brief's carve-out is worded — the reserved term "appears in this design document only where it names one of your own source files, which never ship" — the term almost certainly *is* that name, used freely in this project's own meta-conversation and file citations (which never ship) but barred from anything that does. **"The Synker Wars"** is separately and explicitly reserved as the book's own military-arc name.

**The call made here:** rather than try to guess the edge of a term this project has gone out of its way not to show me, this document invents entirely fresh proper nouns for every sector, planet, and academy below, rather than porting Qiraki's own named locations (the four hub worlds, Devereux-Kastel) directly. This is a *stricter* standard than this project's own precedent — species, class names, gear tiers, and color systems have all been ported directly and are explicitly endorsed as "deliberate shared-universe borrowing... now the standing default" per the Master Index's own 26 Aug policy note. Two reasons for the stricter call specifically here, not as a blanket rule for everything else:

- **Warden Company's own roster is Bloom Wars-original, post-Team-One.** Team One — Fracrals Thyns, Derek Barasj, Hiro Nagori, Yren Tourignie, and Trav Calder himself — was a direct, deliberate port of Qiraki's actual Book 8 cast, and all four died in the Mission 3 wipe. Whoever a player builds through the Character Editor is filling a roster that already diverged from the book's own story the moment that wipe happened. Giving them Bloom Wars-original geography, not Trav's own home academy, keeps that divergence honest rather than quietly implying the player's new pilots grew up inside a story already being told elsewhere.
- **Volume.** This document invents roughly twenty proper nouns. Reusing real Qiraki place names for a handful of curated, load-bearing cross-references (Fracrals Thyns' species, a gear tier, a color palette) is a different kind of risk than inventing twenty new ones under a locked term this session can't see — more surface area, more chances to land on something that matters to the book without knowing it.

**What's still safely reused, structurally, per the existing precedent:** the Coalition's real Core/Mid-Rim/Frontier zone-by-radius geography (`Qiraki_Concept_v4.md`, "Galaxy map, LOCKED"), the five political factions and what each one wants, the Roll/off-Roll class axis, and the academy pipeline's own real institutional logic (subsidized recruitment, a soldier with no house has no claim). None of that is spoiler-sensitive — it's setting mechanics, already flagged reusable, and it's what makes the five sectors below read as part of the same galaxy rather than a disconnected pocket universe.

**Still available later, if you ever want it:** tighter integration — Warden Company's roster drawing explicitly from, say, Terra or the Hiopi worlds by name — is a real option this document deliberately didn't take. Noted here in case that changes down the line; nothing below assumes it will.

## 2. The Sector layer — five, at three zone tiers

Each sector gets a one-line political temperament (which of the five COE factions' logic dominates locally — not stated on the page in any future in-game text, per the project's own "never explain the Roll" discipline already established) and a **Zone** tag: Core, Mid-Rim, or Frontier, taken directly from the Coalition's own locked geography (Core 0–50ly from Osnius: the four hub worlds, oldest infrastructure, most secure; Mid-Rim 50–300ly: heavily settled, most established academies; Frontier 300–800+ly: where the war is actually fought, poorer, rougher).

### 2.1 The Cordage Belt — Mid-Rim, Ledger-leaning

Orbital shipyards and fiber-and-cable manufacturing, strung across a belt of asteroid docks and two settled worlds. Generational dock families, apprenticeship culture, a place that thinks in tonnage and tolerances. The Ledger's whole temperament — margin and stability over ideology — is just how people here already talk, not an import.

- **Tallowmere** — the belt's anchor world, heavy orbital yards, smoke and steel, half the Coalition's carrier hulls started as a keel laid here.
- **Skeinreach** — a fiber-farm and weave-mill colony, the actual "cordage" the belt is named for; supplies rigging, cable, and tether line to every yard in the sector.

### 2.2 The Long Marches — Frontier, Frontier-Compact-leaning

A wind-scoured high-plateau ranching frontier and its river-canyon salvage neighbor. Cattle-drives, border militia, a place that has been filing for a better Draw for longer than anyone currently serving has been alive. Poor, tough, and the first to actually feel it when the war's own arithmetic tightens at home.

- **Harrow's Table** — the plateau world itself, cattle and grain on a knife's-edge growing season, a real border-militia tradition that predates the war.
- **Cutbank** — river-canyon mining and salvage, already Bloom-scarred at the edges; the kind of place that reads a downed transport as a resource before anyone finishes asking whose it was.

### 2.3 The Glasswater Reach — Core, Hearth-Bloc-leaning

A wealthy, tide-terraced coastal world and its smaller reclamation-and-leisure sister colony. Old money, real manners, genuine belief in its own stewardship — the Hearth Bloc's actual texture, not a caricature of it. Terraforming rights run generations deep here; a family's standing and its shoreline are often the same fact.

- **Glasswater** — the sector capital, tide-terraced estates stepping down into the water, generational wealth that has never had to ask what a bad Draw feels like.
- **Pale Cistern** — the smaller colony, water-reclamation infrastructure and a pleasure-barge economy built on top of it; where Glasswater's own money goes to relax.

### 2.4 The Understrand — Mid-Rim, Standing-Service-leaning

A dense, stacked arcology world and its data-processing colony neighbor — the Coalition's own filing cabinet, run by people who are good at it and quietly proud of being good at it. Not the Cradle Circle's pipeline logic and not the Hearth Bloc's inherited confidence — the Standing Service's own texture: competent, respectable, permanently capped, and correct about it more often than anyone above them wants to admit.

- **Cistgate** — the sector's central arcology, city stacked on city, real vertical class geography (whose window actually sees daylight is not a small fact here).
- **Loomvale** — a registry-and-records colony, quiet, orderly, the kind of place a person is born already halfway to a desk job and mostly all right with that.

### 2.5 The Emberfall Drift — Frontier, Osnian-Honor-Guard-adjacent

A volcanic refinery world and its garrison-colony neighbor, hit early and hard enough by the Bloom that the sector's own memory of "before" is thin. A real, if informal, Osnius military presence gives the Drift a harder, more honor-bound frontier culture than the Long Marches' looser militia tradition — less filing for a better Draw, more standing where you're told to stand.

- **Emberfall** — the namesake world, active volcanism, refinery stacks, and the sector's own first real look at what the Bloom does up close.
- **Greywatch** — an Osnius-heavy garrison colony, honor-code discipline layered over ordinary frontier hardship; the Drift's actual military spine.

## 3. The Academy layer — five, plus the honest sixth option

Each academy leans a cadet toward a class path without hard-locking it — flavor and a soft nudge, matching how this project already treats everything else about a created pilot ("natural balance" stays locked; nothing here reopens stat allocation).

- **The Tallowmere Fitting Yards** *(Cordage Belt)* — trade-school-turned-academy, apprenticeship-paced, real engineering fundamentals over ceremony. Leans Tank/Munti — people who came up learning to keep a hull and a chassis both alive.
- **The Cutbank Muster School** *(Long Marches)* — a militia academy that became a real feeder school once the war widened. Minimal ceremony, maximal survival drilling. Leans Meeps — reflexive, close-range, no patience for a slow plan.
- **Glasswater Conservatory of Arms** *(Glasswater Reach)* — a genuine prestige academy, the Coalition's closest thing to a finishing school with live-fire electives. Real rivalry-with-money texture, the kind of place where losing gracefully is itself a taught skill. Leans Reeps — range, control, the confidence to wait for the right shot.
- **The Cistgate Ledgerworks** *(The Understrand)* — technically a Standing Service training ground first, an academy second, structurally similar to how Devereux-Kastel's own Ledgerhall district works without reusing it directly. Produces sharp, procedural cadets who read a battlefield the way a pegger reads a form. Leans Reeps/Runemaster support.
- **The Greywatch Muster** *(Emberfall Drift)* — a garrison-attached combat academy, Osnian-honor-culture-inflected, no-nonsense. Leans Tank/Meeps — the kind of discipline that holds a line because holding is the whole point.
- **No Academy — Line-Trained** *(any sector, most common on the Long Marches and the Emberfall Drift)* — never went through the pipeline at all. Emergency-recruit lineage, matching the existing recruit-creation baseline directly (`Bloom_Wars_Spitball_Ideas.md`'s "real, nameable, customizable recruits, not placeholders"). Learned everything in the field, which reads as a real, honest gap next to an academy cadet, not a lesser option — some of this project's own best-loved named pilots could plausibly have started here.

## 4. The Birthplace Texture layer — eight, cross-cutting every planet

Rather than hand-authoring individual named towns (a lot of content for not much payoff at this stage), each planet crosses against a small set of upbringing textures. Five sectors × two planets × eight textures is 80 distinct, coherent one-line origins without writing eighty lines by hand — the actual "richer now, less work later" payoff Maxime asked for. A few sample crosses are spelled out below so the shape is concrete, not just described.

- **Dockside** — grew up in a working port, ships and logistics as the ordinary rhythm of a childhood.
- **Terrace Farmstead** — generational land, agricultural, a family that measures time in growing seasons.
- **Arcology Stack** — dense vertical city housing; whose window sees real daylight is a real, felt fact of a childhood here.
- **Garrison Quarter** — grew up on or against a military base, a soldier's kid before they were ever a soldier themselves.
- **Drift Colony** — void-born or near enough, raised on a mobile habitat or a long-haul convoy rather than a fixed world.
- **Company Housing** — a charter-house-adjacent labor family, on-Roll money at one remove, never the seat itself.
- **Preserve-Adjacent** — grew up near a preserve-world boundary, close enough to a population under permanent observation to have questions nobody in the family answered directly. (Handled carefully — this is the one texture that borrows the Qiraki preserve system's own quiet-critique weight rather than its content. It should read as an unstated backdrop fact a pilot carries, never a lecture a pilot delivers.)
- **Academy Ward** — grew up in or around an academy campus itself, a faculty or staff kid, half-raised by an institution rather than a household.

**Sample crosses, illustrative:**

- *Tallowmere + Dockside* — a dock family for three generations, learned to read a hull's stress fractures before reading a full sentence.
- *Harrow's Table + Garrison Quarter* — raised inside the plateau's own border militia, knew the muster horn's cadence before they knew their own house's address.
- *Glasswater + Company Housing* — on-Roll money's own shadow, close enough to the estates to know exactly what they didn't have.
- *Cistgate + Arcology Stack* — eleven levels down, learned early that "up" was a direction other people got to take for granted.
- *Emberfall + Preserve-Adjacent* — a refinery-world childhood with a treaty line at the edge of town nobody in the family would talk about directly.

## 5. Reconciling with the animal label — background drives catalyst

**Superseded, 1 September 2026 — Maxime's own words: "Background drives catalyst."** This section originally proposed background as a second, independent axis running alongside the animal label ("two axes, one pilot," background as a parallel, non-determining trait). That framing is no longer the design. Background is now the determining input for a pilot's catalyst, not a separate trait sitting next to it. The full mechanism — the locked Planet-12 → Catalyst table, the reverse-fit safety rule for already-shipped catalysts, and the complete roster assignment — lives in `claude/Bloom_Wars_NPC_Catalyst_Formula_Closing_And_Roster_Assignments_v1.md` §2 (the table itself) and §3–§4 (the safety rule and the full 49-entry roster). This section is kept here, edited rather than deleted, so the record of how the design changed stays honest — per this project's own standing rule about not letting docs quietly drift from what was actually decided.

Character Editor v1 §2's animal-label picker is unchanged in one specific sense: a player still only ever sees and picks the animal name, never the diagram underneath. What changed is what determines that name for everyone who isn't hand-picking it themselves:

| Axis | What it seeds | Player sees | Source |
| --- | --- | --- | --- |
| **Background** (Sector → Planet → Birthplace Texture → Academy) | Zone × Pressure → a Planet-12 position (§6 below), which now determines **c** — the animal label — via the locked formula in the Catalyst Formula doc's §2 | Sector/planet/academy/birthplace names only — the diagram and the derived catalyst stay internal | This document (the origin layer) + the Catalyst Formula doc (the mapping) |
| **Animal label** (Wolf/Dog/Cat/Crow/Raven/Bear/Fox/Rabbit/Shark) | **c** — catalyst, moment-to-moment behavior | The animal name only (Character Editor v1 §2, unchanged) | Derived from background — no longer an independent pick for anyone this document's roster pass covers |

A created pilot's background is now the actual source of their animal label, not a second free-standing trait chosen independently next to it. For the Generate path this is mechanical: roll the background, run Zone × Pressure through the locked Planet-12 → Catalyst table, done — one fewer independent roll, not one more. For hand-built pilots in the Character Editor, whether the animal-label picker stays available as a direct override once background is set is Character Editor's own UX call, not reopened here.

This section's original close said named, hand-authored pilots "stay untouched by either" axis. That is also superseded — see §10 below, updated in the same pass.

## 6. The hidden mechanism — Zone × Pressure, locked design

**Kept internal, same discipline Character Editor v1 §2 already set: "the actual 12-point diagram... deliberately kept out of this project's docs in detail... The player only ever sees and picks" the fictional label.** This section names the real Planet-12 positions (Mercury/Venus/Earth/Mars/Jupiter/Saturn/Uranus/Neptune/Spider, plus the Time/Volume/Matter pillars) because this is a design document, exactly the way `Bloom_Wars_NPC_Reaction_Engine_v1.md` already does — none of this reaches a player-facing string.

**Zone** comes for free off the Sector pick — Core, Mid-Rim, or Frontier, no extra player choice needed.

**Pressure** is a derived three-tier read of how early and how hard real stakes landed on this pilot, before they ever reached a cockpit — a function of Academy × Birthplace Texture (a Garrison Quarter kid from a Frontier militia academy reads very differently from an Academy Ward raised inside a prestige conservatory, even from the same sector):

- **Sheltered** — real stakes arrived late, filtered through family or institution.
- **Tested** — real, survivable hardship — ordinary frontier toughness, a bad Draw felt at home.
- **Forged** — real stakes arrived early and direct, before the pilot had any say in it.

**Zone × Pressure → home Planet-12 lean — Maxime-approved, 1 September 2026, in his own words: "the pressure thing look good to me. it fit the pilar way of explaining itself."** The qualitative mapping below is locked design intent, not a placeholder to be second-guessed later. What's *not* yet settled is purely numeric — pillar weights (which of Time/Volume/Matter reads strongest) still can't be specified, because no such field exists anywhere in the engine yet (Audit doc §1, row A). The shape is locked; the numbers wait on the field existing to hold them.

| | Sheltered | Tested | Forged |
| --- | --- | --- | --- |
| **Core** | **Earth** (home) — stability still the center of their world | **Uranus** (comprehension) — processing a gap between their comfort and what they've started to see | **Neptune** (mind beyond self) — rare; real early loss despite institutional shelter, forced outward fast |
| **Mid-Rim** | **Saturn** (commitment) — steady, dutiful, unremarkable in the best way | **Mars** (advancement through conflict) — the project's own default soldier's read | **Jupiter** (might exceeding comprehension) — hit by something bigger than they were ready for |
| **Frontier** | **Mercury** (change/becoming) — rare; a frontier world's own sheltered exception, about to have their world catch up with them | **Venus** (life/wonder) — an earned, deliberate optimism, not naivety — chose to keep finding it anyway | **Spider** (enigma, the unspoken center) — the hardest-hit case; the pilot whose real interior nobody has fully mapped, maybe not even them |

This gives every one of the nine cells a distinct, thematically legible read rather than a flat default, and it deliberately produces uneven rarity — a Frontier-Sheltered pilot (a governor's kid, a charter officer's family posted out there) should read as a genuine, interesting outlier, not one-ninth of the roster by construction.

## 7. The wheel — proposed flow

Slots into Character Editor v1's existing Layer 1 → Layer 2 sequence as a new step between chassis/class and the animal-label pick, both for hand-built and Generate paths:

1. **Chassis / species / class / name / portrait** — unchanged, Layer 1.
2. **Sector** — five choices, one line of flavor each, or Generate rolls one.
3. **Planet** — two choices within the picked sector, or Generate rolls one.
4. **Birthplace Texture** — eight choices, cross-cutting any planet, or Generate rolls one (optionally weighted away from a flat uniform roll, matching the same "not perfectly uniform" note Character Editor v1 §4 already flags for animal-label generation).
5. **Academy** — five named options plus Line-Trained, filtered lightly toward the pilot's picked sector's own local academy as the "obvious" choice, with the other four and Line-Trained always available (a Long Marches kid who tested into Glasswater Conservatory is a real, available story, not blocked).
6. **Animal label** — unchanged, Layer 2, Character Editor v1 §2.

Every step after chassis/class is skippable via Generate, matching the existing "most of a roster gets generated and lightly reviewed" design already locked for the fifty-pilot problem (Character Editor v1 §4).

## 8. Naming-lock safety check

Every proper noun invented in this document, checked against both known constraints:

Cordage Belt, Tallowmere, Skeinreach, Long Marches, Harrow's Table, Cutbank, Glasswater Reach, Glasswater, Pale Cistern, The Understrand, Cistgate, Loomvale, Emberfall Drift, Emberfall, Greywatch, Tallowmere Fitting Yards, Cutbank Muster School, Glasswater Conservatory of Arms, Cistgate Ledgerworks, Greywatch Muster.

None contain, echo, or abbreviate "The Synker Wars." None are the reserved term this session cannot see — by construction, since none of them are Qiraki proper nouns at all (per §1's own stricter call, everything here is invented fresh rather than ported). Also checked against this project's own existing vocabulary — no collision with any of the 36 Amaranth mission names, House Amaranth's own places (Meridian, the Amaranth Reach), or any named pilot, mek, or Bloom archetype already shipped.

## 9. Scope flag, per the project's own standing rule

This is a new content layer, not a tuning pass — worth saying plainly rather than letting twenty new proper nouns and a new derived-trait mechanism slide in as if they were always there. Nothing here is built, and nothing here jumps ahead of the sequencing rule already locked in Spitball Ideas (hard tactical loop, then the social layer). If and when Background Zones does get built, it touches: `Bloom_Wars_Character_Editor_v1.md` §2 and §7 (a new cross-reference, and one of its "still open" items partially answered), `Bloom_Wars_NPC_Reaction_Engine_v1.md` §4 (the Planet-position-assignment question, now answered for backgrounds the same way animal labels already answered it for catalysts), and the Master Index's own "Cross-project references" section (this document exists and should be indexed once it's read back into that doc). None of the four core `.docx` files need touching — this is entirely new social-layer content, not a change to the GDD/Data Pack/Build Brief/Canon Pass's own locked material. These are still just pointers, not applied — no doc besides this one has been edited yet.

## 10. What this document does not decide

- The Pressure-tier derivation and the Zone × Pressure → Planet-12 lean (§6) are now locked as design intent (Maxime-approved, 1 Sept 2026) — but the numeric pillar weights that would eventually ride on top of a Planet-12 assignment genuinely can't be specified yet; no field for them exists in the engine (Audit doc §1, row A). That's a real pass for once `A` gets its first actual code field, not a decision anyone is sitting on today.
- **Resolved, 1 September 2026.** This bullet originally read: "Whether named, hand-authored pilots (Rourke, Bosk, Iyari, Anand, Lask) get retrofitted with a Sector/Planet/Academy of their own, the way this document proposes for created and generated pilots — a real, separate question, not addressed here." It's been addressed. Maxime confirmed background should drive catalyst, and confirmed scope as everyone except Team One (already dead in-story) and the two player protagonists (Rourke for Warden Company, Marrow for House Amaranth). Every other named pilot and Mek across both campaigns — 49 entries total — now has a real Sector/Planet/Academy/Birthplace Texture background. Where a pilot or Mek's catalyst was already locked in shipped dialogue (Bosk, Iyari, Anand, Lask, and 18 others), their background was reverse-fit to a Zone × Pressure cell that resolves to that same catalyst, so nothing already live changes — they gained an origin story, not a new personality. Full table and the reverse-fit method: `claude/Bloom_Wars_NPC_Catalyst_Formula_Closing_And_Roster_Assignments_v1.md` §3–§4.
- Whether any of the five sectors deserves to become real mission content (a birthplace a player recognizes from a bio becoming an actual map) — flagged as a natural, cheap future hook, not proposed as a build item today.
- **Academy-taught starting skills tied to background — not this game, flagged for the record.** Maxime's own idea, floated same-day: a future, separate game where academies actually train pilots and starting skills derive from background, getting real mileage out of "the social engine." Explicitly framed as later/different-game, not a Bloom Wars scope item — noted here only so it isn't lost, not because anything in this document assumes it.

## Cross-references

- `claude/Bloom_Wars_Character_Editor_v1.md` §2, §4, §7 — the animal-label axis this document sits alongside, and the open questions it partially answers.
- `claude/Bloom_Wars_NPC_Reaction_Engine_v1.md` §1, §4 — the formula this feeds, and the open assignment question this document is the background half of.
- `claude/Bloom_Wars_NPC_Catalyst_Formula_Closing_And_Roster_Assignments_v1.md` — the document that actually closes the loop this one opened: locks the Planet-12 → Catalyst formula (§2), states the reverse-fit safety rule for already-shipped catalysts (§3), and assigns real backgrounds to all 49 named pilots and Meks this document's scope covers (§4). §5 above and §10's second bullet were both updated to point here rather than silently going stale.
- `design/Bloom_Wars_NPC_Reaction_Engine_Audit_And_Closing_Plan_v1.md` (Maxime's device) — named "Background Zones" first, confirmed the engine has no seam for it yet, and gave this document its actual job.
- `design/qiraki-canon-bridge/Qiraki_Concept_v4.md` ("Galaxy map, LOCKED") and `Qiraki_Political_Web.md` (the five factions, the Roll) — the real structural material this document's sectors are grounded in.
