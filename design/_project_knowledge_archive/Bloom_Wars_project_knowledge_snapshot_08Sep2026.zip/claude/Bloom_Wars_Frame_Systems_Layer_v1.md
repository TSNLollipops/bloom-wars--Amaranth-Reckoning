# Bloom Wars — The Frame Systems Layer, v1

*Started 27 Aug 2026; three of its open calls decided the same day (see §9, §7, §12). Five more decided 6 Sep 2026 (see §14) — the economy sim harness §12 calls for also shipped that day, `npm run sim:economy`; see `Bloom_Wars_Build_Log_Addendum_FrameSystemsEconomySimHarness_06Sep2026.md`. **Tier 1 (§10) shipped later the same day, second mount included — see `Bloom_Wars_Build_Log_Addendum_FrameSystemsTier1_06Sep2026.md` for what was built as written, what was reinterpreted, and what was left out; §5, §10, §12 and §14 below carry the status notes.** Tiers 2 and 3 remain proposals — nothing there starts building without a separate go-ahead. Direct answer to Maxime, verbatim: "weapon and progression doesnt cover enough system of a mech to incrase to g-a rank. lets go ham and incrase the number of system, like in Lancer. dont crib it, just inspire ourself from it."*

*One sourcing caveat, stated up front per this project's own "verify against the actual current file" rule: I could not reach the repo this session (no folder connected to the device). Everything below is checked against the project docs — GDD §4.1–§4.6 and §6.1–§6.4, Data Pack §3/§5/§5.1/§12, the Mek Workshop doc, the Weapon Branch doc, the Act I build log — not against live code. The two places where I suspect the docs have already drifted from the engine are flagged inline (§1b) rather than assumed either way.*

---

## 0. The complaint, restated so it can be designed against

"G→A doesn't cover enough system of a mech." That's a precise diagnosis and it's correct. Here is exactly why, in the game's own numbers.

The damage formula (GDD §4.5) is:

```
damage = P[attackerPath][defenderPath]
       × (currentHP / 100)
       × (ATK / 100)
       × (100 / DEF)
       × terrain
       × charge
```

Gear tier touches exactly four things: `ATK`, `DEF`, `HP`, and `move`. That's it. Across all six purchases, G→A moves ATK 100→140 and move +0→+2. **So the entire six-step, 1,320-point progression ladder changes how hard a mech hits and how far it walks — and never once changes what it can do.**

Everything that actually makes a pilot *interesting* — path, chassis, mek track — is locked at recruitment and never changes again for the rest of the campaign. Which means the whole campaign-long progression is one slider being dragged right. No wonder it doesn't feel like a mech gaining systems. It isn't one. It's the same mech with better numbers.

## 1. What Lancer actually does right, in one paragraph

Not "more guns." The structural thing Lancer gets right is that **it has three separate gates instead of one**:

- **License level** gates *what exists* — you can't buy gear you haven't earned access to, no matter how rich you are.
- **Money** gates *what you own*.
- **Mounts and System Points** gate *what you can carry at once* — a fixed budget you spend on a loadout, so every build is a real subtraction, not an accumulation.

Bloom Wars currently has one gate: points. Buy the thing, have the thing, forever, no budget, no capacity ceiling, no unlock condition. **That's the actual gap, and it's a structural one — it's not fixed by adding more items to a shop list.**

Secondary lesson, also structural: in Lancer a frame is a *shape* — a chassis with a specific number and size of mounts and a specific SP budget — and that shape is what makes two mechs of the same role feel different. Bloom Wars has a chassis layer (§4.3) that only touches movement and sensor. It's a shape with nothing hung on it.

### 1b. Two things I think are already drifted, worth checking against the repo

- **GDD §4.4's tier table says "D — first ability slot" and "B — second ability slot."** Nothing in the Data Pack, the Act I build log, or the ability work describes tier-gated ability slots — abilities in the engine are path-locked and (for Taunt) mission-gated, not tier-purchased. **So the GDD already promised a slot system at D and B and it was never built.** This proposal is the natural place to either cash that promise or delete the line. Worth confirming in `data/abilities.ts` before either.
- **Data Pack §6's ability table lists six abilities; the build log says the engine has ten** (`abil_ambush`, `abil_interdict`, `abil_screen`, `abil_clear_bloom`, `abil_taunt` all shipped and undocumented there). That's a known, pre-existing drift the build log already flagged on 23 Aug. Not this doc's job to fix, but it needs fixing before anyone writes a system that interacts with abilities.

## 2. What NOT to import from Lancer — naming this first, same discipline as the WoT doc's §2

- **No heat economy on every unit, every turn.** Lancer's heat/stress track is excellent for a five-player tabletop skirmish. Bloom Wars fields up to 15 units a side on an Advance Wars-lite grid — a per-unit second resource that has to be tracked, displayed, and reasoned about every single turn would make the game fiddly in exactly the place it's currently clean. (There is a cheaper way to get some of heat's *tension* without the bookkeeping — §7's salvage instability — and a real "if you actually want it" version in §11.)
- **No mech-vs-pilot split.** Lancer runs two separate character sheets, a pilot with talents and a mech with systems. Bloom Wars already has that split and already solved it differently: the pilot's growth is the personal-points ladder, the mech's partner is the mek. Adding a third sheet dilutes both.
- **No manufacturer factions.** Lancer's four corpos are worldbuilding load-bearing for its setting. Bloom Wars has a better native answer to the same structural need — §7's two supply lines.
- **No frame collecting.** Lancer has dozens of frames because it's a build-a-mech game. Bloom Wars has 15 fixed, named people you get attached to, and permadeath. The frame layer has to deepen *those* pilots, not offer alternatives to them. Concretely: **one frame per path, refittable once at A tier (§8).** Not a catalogue.
- **No mid-mission loadout changes.** Everything here is decided before the drop. Same rule the Weapon Branch doc already locked.

**What does carry over, deliberately:** three gates instead of one; a budget that makes a loadout a subtraction; capacity that grows so an A-tier frame is visibly a different machine rather than a stronger one; and gear whose unlock condition is a story beat rather than a bank balance.

## 3. The reframe: gear tier stops being a stat ladder and becomes a capacity ladder

Stats still climb exactly as they do today — **the §4.4 table's ATK/DEF/HP/Move numbers do not change, so nothing in the sim needs re-tuning for this.** What changes is that each step also grants *capacity*, and capacity is the headline.

| Tier | Stats (unchanged) | Mounts | Draw | What the step actually unlocks |
|---|---|---|---|---|
| **G** | 100/100/100 | 1 | 2 | Starting frame. One weapon, one small system. |
| **F** | 106/104/100 | 1 | 3 | Draw +1 — a second cheap system, or one better one. |
| **E** | 112/108/105 | 1 | 4 | Draw +1. |
| **D** | 118/113/110, +1 mv | 1 | 5 | **First weapon branch purchasable** (unchanged from the Weapon Branch doc). |
| **C** | 125/119/115, +1 mv | **2** | 6 | **Second mount — carry two branches into the same mission.** |
| **B** | 132/125/120, +1 mv | 2 | 8 | **Core slot opens** (§9). Draw +2, the biggest single jump. |
| **A** | 140/132/130, +2 mv | 2 | 10 | **Frame Refit** (§8) — the identity fork. |

Read that column and the ladder finally has seven distinct events on it instead of six identical ones. F and E are still the quiet steps — that's fine and probably correct, they're the early-campaign filler steps — but D, C, B and A each now do something a player can describe out loud.

**Draw** is the budget word. Every system costs 1–3 Draw; your frame has a ceiling; you can own more systems than you can fit, and choosing which ones go in is the actual game. Naming is your call as always — Draw is plain-language enough that it explains itself ("power draw"), and it's a word the meks would use. *(Still open as of 6 Sep 2026 — see §14. Claude's own recommendation, given in chat, is to keep it; not put to a formal decision. Now live in the UI as of Tier 1, so renaming gets dearer the longer it sits.)*

The Weapon Branch doc's §3 currently says one branch equipped at a time. **The second mount at C is a direct amendment to that** — it doesn't contradict the collect-and-swap decision, it extends it: below C you own several and swap between them, from C you carry two at once. Flagging it because that doc needs the edit. *(Shipped 6 Sep 2026 as "both branches fully live, effects stack" — the doc never said which, and the alternative was a second mechanic; see the Tier 1 addendum's flagged decisions. The Weapon Branch doc §3 edit is still owed.)*

## 4. The slot model, concretely

A frame has four kinds of space, and they don't compete with each other:

1. **Mounts** (1, then 2 from C) — hold weapon branches. Already designed, §3–§4 of the Weapon Branch doc.
2. **System slots** — no fixed count. Bounded by **Draw**, not by slot number. This is deliberate: a Draw budget means a big system genuinely costs you two small ones, whereas fixed slots make everything cost the same regardless of power.
3. **Core slot** (from B) — exactly one, holds a once-per-mission signature system. §9.
4. **Refit** (at A) — not a slot at all; a permanent one-time reshape of the frame's base numbers. §8.

**Systems are bought with personal points, owned permanently, equipped freely pre-mission.** Same shape as weapon branches, same pool, same rule: personal = pilot identity, company = squad logistics (the Weapon Branch doc's §6 rule, unchanged).

**Where systems plug into the math — the good news.** Data Pack §5.1 already defines a fixed additive order of application:

```
effectiveAttack = archetype.baseAttack + tierModifier - 100 + mekAttackBonus
```

A system layer is one more additive term on each line — `+ systemAttackBonus(pilot.systems)`, and the same for defense, HP, vision, move. That's it. **Every purely numeric system in §5 below is a data-only change that slots into an ordering rule this project already wrote down and already tests against.** No new engine concept required.

## 5. The system catalog — going ham

Draw cost in brackets. **Bold = pure numbers, ships with zero new engine work.** Anything not bold needs real engineering and is called out in §10. Every name is a placeholder, per project convention.

*Status, 6 Sep 2026 (Tier 1 shipped, then a second pass the same evening): every bold system below is in `src/data/frameSystems.ts` — 17 of them — with three departures from this list. **Stabilizer Struts** was left out of the first pass because there was no stationary-repair rule for it to modify (the Fieldwright mek track's own heal was dead data); Maxime had the heal wired and Struts built the same evening. **Crash Foam Lining is cut**, on his call: its premise was the Fabricator mid-mission redeploy, and he ruled "its the beacon job to give in battle restock" — spare parts now feed Beacon Control instead, which already restores to full. **Heartwood Graft is now Gallcyst Graft** (same +20 HP / −1 move, gated on Gallcyst kills), because `bloom_heartwood` never spawns in either shipped campaign. Field Repair Kit was reinterpreted as +25% Repair output — Repair has no charges to add one to. And "pure numbers, zero engine work" was optimistic: only 4 of the shipped systems are pure stat deltas; the rest each needed a real engine hook. Non-bold systems are all still unbuilt (Tier 2/3).*

### 5a. Frame — survivability (any path)
- **Reinforced Plating [2]** — +6 DEF, −1 move.
- **Spall Liner [1]** — take 50% less counterattack damage.
- **Sealed Cockpit [1]** — immune to bloom-mat acid (the 5/turn tile hazard). Cheap, and it changes which tiles a map's shape actually denies you.
- ~~**Crash Foam Lining [1]** — restock at 75% HP instead of 50% when a Fabricator part redeploys you.~~ *Cut 6 Sep 2026 — see the status note above.*
- Ablative Shell [2] — absorbs the first 40 damage taken this mission, then it's spent. *Needs a per-mission spent-flag.*
- **Redundant Actuators [2]** — ignore chassis terrain penalties. Reads as the centauroid's own fix, which makes it a genuinely different purchase depending on who buys it — that's the kind of asymmetry worth having.

### 5b. Drive — mobility
- **Sprint Cell [2]** — +1 move.
- **Low-Profile Gait [1]** — +1 effective terrain defence star when you end your move on cover. *(Shipped as "on a tile with 2+ stars" — plain ground has 1 star in this engine, so "any cover" would have fired everywhere.)*
- **Bloomwalkers [1]** — bloom mat costs 1 move instead of 2.
- Grapple Line [1] — once per mission, move 3 tiles ignoring terrain cost. *Needs a one-shot movement verb.*
- Kickoff Thrusters [2] — after attacking, step 1 tile. *Needs post-attack movement; this is the single most build-defining mobility system and also the most expensive to build.*

### 5c. Sensor and command
- **Signal Booster [1]** — +1 vision.
- **Seismic Tap [2]** — detects burrowed units within 3 tiles. **Deliberately weaker than the Runemaster mek's "anywhere in vision" detection and the vibrissal chassis's own** — this is the poor man's version, so a system can't make the mek track or the Osnian chassis redundant. That non-redundancy rule matters more than the number does. *(As shipped, Seismic Tap is the only passive burrow detection in the engine — Sensor Sweep still reveals actively, but the Runemaster's own `burrowDetection` is a data field nothing reads, so the "deliberately weaker than" comparison has nothing to be weaker than yet. Flagged in the Tier 1 addendum and §14 item 17.)*
- Threat Ledger [1] — shows the exact damage a visible hostile would deal to each of your units. *UI-only, no combat change — probably the cheapest real quality-of-life system on this list.*
- Spotter Uplink [2] — allies attacking a target inside your vision get +5 ATK. *Needs a cross-unit lookup at attack time.*
- Relay Mast [2] — extends an adjacent ally's Overwatch trigger radius by 1. *Needs the reaction-fire system touched.*

### 5d. Ordnance
- **Focusing Optics [2]** — +8 ATK against targets at your maximum range. Reeps-flavoured but not Reeps-locked.
- **Shredder Rounds [2]** — ignore 25% of the target's DEF. Sharpens Reeps-beats-Tank rather than blurring it. *(Shipped additive with Rail Lance's own 25% — 50% against a Tank, capped 90%. Could be non-stacking; Maxime's call.)*
- **Overpressure Regulator [3]** — your first attack each mission deals ×1.4. Expensive in Draw on purpose: it's an alpha-strike build, not a passive.
- Concussive Loads [2] — knockback 1 on hit. *Needs knockback — already flagged by the Mek Workshop doc's Riot Drum.*
- Target Painter [1] — marked target takes +10% from everyone for one turn. *Needs a debuff.*
- Breach Charges [1] — once per mission, destroy one structure tile. *Needs terrain mutation, which nothing in the engine does today. Genuinely fun — a Tank opening a wall for the squad is a real tactical moment — and genuinely the most invasive thing on this list.*

### 5e. Support and logistics
- **Field Repair Kit [1]** — one extra Repair charge per mission. *(Shipped as +25% Repair output — see the status note above.)*
- **Salve Drone [2]** — passive regen aura +3 HP, radius 1.
- **Stabilizer Struts [1]** — Fieldwright's stationary repair also works if you moved 1 tile. Small, but it un-punishes a repair build for repositioning. *(Built 6 Sep 2026, second pass, once the Fieldwright heal existed. Two 1-tile moves in one turn read as 2 and don't qualify.)*
- Transfer Coupler [2] — Repair also heals one adjacent ally for 50%. *Needs a splash-heal target resolver.*

### 5f. Salvage — the Bloom-derived line. This is the interesting family; see §7.
- **Wellroot Filament [2]** — regen 8/turn while standing on bloom mat. Turns the map's own hazard into your ground. Thematically the best one on this list.
- **Gallcyst Graft [3]** (the doc's Heartwood Graft, re-sourced 6 Sep 2026) — +20 max HP, −1 move. A real, ugly tradeoff for a Tank. *(Heartwood never spawns in either shipped campaign; Gallcyst is the rarest Bloom that does and isn't claimed by another salvage entry. §7's own salvage-archetype list never included Heartwood either.)*
- Choir Membrane [2] — once per mission, negate one incoming attack entirely. *One-shot flag.*
- Sirenmaw Resonator [3] — small AoE attack-debuff aura. *Ports a Bloom ability the engine already runs — cheaper than inventing one, per the Mek Workshop doc's own point about Suppression Autocannon.*
- Undertow Spines [2] — your melee hits apply a 1-turn slow. *Needs a slow.*
- Sporethrower Glands [2] — your ranged hits apply damage-over-time. *Needs DoT — though note the Runemaster mek's effect-potency bonus already references "DoT duration" as if DoT exists, which is worth checking in the repo; if it already does, this drops to nearly free.*

That's 24 systems across six families, of which **13 are pure numbers and ship with no new engine work at all.** *(Correction, 6 Sep 2026: the list above actually holds 32 systems, 18 bold. The count drifted from the list; the list is the content. Tier 1 built from the list.)* Add the 16 weapon/support branches already designed and you get roughly 40 build components against 15 pilots. That's genuinely wide without being a Lancer-sized catalogue.

## 6. What this does to the actual feel of G→A

A worked comparison, using Bosk (Tank/human, the Warden Company anchor):

**Today, G→A:** ATK 100→140, DEF 100→132, HP 105→135, move 3→5. Same unit, bigger.

**Under this proposal, G→A:** starts with a Slam Cannon and one Draw-2 system. Ends with two mounts (Slam Cannon plus a Maser Lance for the mission that needs it), 10 Draw spent across four systems — Reinforced Plating, Heartwood Graft, Redundant Actuators, Sealed Cockpit — a core system in the B slot (**unless he's still carrying Gjallar/Requiem at that point — decided 6 Sep 2026 that Requiem takes the core slot instead; see §14 items 4-5**), and a Bastion refit that traded his last move point for a wider overshield. He is now a specific, describable machine that another player's Bosk would not match. **That's the difference between a stat ladder and a progression system**, and it's most of what the complaint was pointing at.

## 7. Two supply lines — the Bloom Wars answer to license levels

This is the piece I'd fight for hardest, because it's the one idea here that isn't imported at all — it falls out of the game's own fiction.

**Foundry systems** are built by the meks in the Workshop. Bought with personal points, reliable, no strings. Most of §5.

**Salvage systems (§5f) are cut off dead Bloom.** They can't be bought at all until you've killed enough of the thing they come from. Wellroot Filament needs Wellroot kills. Choir Membrane needs Choir kills. Undertow Spines need Undertow kills.

Three things this buys, all real:

1. **It's a license level, and it's free.** Lancer's LL gates what exists behind a progression you earn. This gates what exists behind a progression you *already earn every mission and currently don't record*. The Bestiary is already a per-archetype system (GDD §5.1); tracking "how many of archetype X has this company killed" is one persisted counter.
2. **It makes the Bestiary do double duty.** Killing a Sirenmaw in Act II stops being just a fight and becomes an unlock. Mission content feeds build content without anybody writing new mission content.
3. **It gives salvage a downside without inventing a heat system.** Proposed cheap version: **a salvage system costs +1 Draw on any pilot whose mek is not a Runemaster.** Rune tech is already the game's established answer to weird tech (GDD §6.2, "stronger weapon effect," effect potency ×1.5). So salvage builds pull toward Runemaster meks, which makes an existing, currently-forgettable choice matter for the whole rest of the campaign — and it needs zero new engine machinery. The richer alternative is hanging salvage instability off the Stress/Morale proposal instead, which is better fiction and much more work; noted, not recommended for a first pass.

**Decided 27 Aug 2026: in.** Maxime picked it as the point of the whole layer rather than an optional extra, so the per-archetype kill counter is real work that has to get planned for, not a maybe. Build-order note that follows from that: the counter should start recording **before** any salvage system is purchasable — ideally shipped with Tier 1 as a silent, invisible counter — so a player who is already mid-campaign when the salvage line lands isn't told their first twenty missions of kills didn't count. That's a cheap thing to get right early and an ugly thing to retrofit. **Decided 6 Sep 2026: Tier 1 and salvage now ship together, not staggered — see §14 item 3.** The kill-counter-starts-silently-early recommendation still stands regardless of that sequencing choice.

**Shipped 6 Sep 2026 with Tier 1:** `CampaignState.hostileKillsByArchetype`, recorded from every Debrief; per-archetype gates on each salvage system (placeholder: 1 kill each); the +1 Draw non-Runemaster surcharge exactly as proposed here; and a hide rule so a salvage system whose source archetype never appears in the current campaign isn't shown as a lock the player can never open. Saves from before that date start counting from their next Debrief, not retroactively — the "ugly retrofit" this paragraph warned about is real for any in-progress campaign, just bounded.

Honest flag on this section: it's the biggest *new* concept in the doc and the one most likely to be more work than it looks, because "kills by archetype, persisted, per company" is new campaign state and it needs to survive a save/load and a permadeath.

## 8. Frame Refits — the A-tier payoff

At A, a pilot picks one permanent refit. All of these are pure number changes, so the whole feature is data plus one shop button.

| Path | Refit A | Refit B |
|---|---|---|
| **Meeps** | *Skirmish Frame* — +2 move, −15 max HP | *Breacher Frame* — +12 ATK, −1 move |
| **Tank** | *Bastion* — overshield covers +1 radius, −1 move | *Ram Frame* — ×1.25 damage when you move 2+ tiles into the attack |
| **Reeps** | *Battery Frame* — range 2–5, cannot move and attack the same turn | *Skirmish Battery* — range 2–3, +1 move |
| **Munti** | *Aid Station* — repair range 3, −1 move | *Vanguard Medic* — +1 move, repair range 1 |

**Hard rule, restated so nobody proposes past it later: a refit can never touch the triangle.** Tank never gets reach. Reeps never gains a counterattack and never becomes counterattackable at range ≥2 — GDD §4.2 calls that one line "the entire mechanical reason Reeps beats Tank" and "do not soften it," and it stands. Meeps never gets durable enough to trade with Tank. A refit bends a path's internal shape; it does not move a corner of the triangle.

Note the Ram Frame is deliberately the centauroid Charge rule available to a bipedal Tank. That's intentional — at A tier, a refit letting you buy into another chassis's signature trick is a good use of the last purchase in the game.

**Decided 6 Sep 2026: the Refit is the sole A-tier capstone purchase.** Meeps and Tank are not being forced into a symmetric 4th weapon branch just because Munti's 4th (Combat Medic) shipped 5 Sep — see §14 item 2 for the reasoning, and Now & Next's own "Needs Maxime's call" for the same question from the weapon-branch side.

*All eight shipped 6 Sep 2026, "all pure number changes" included the usual honesty tax: Bastion, Ram Frame, and Battery Frame's move-then-can't-attack each needed a small engine hook, and Aid Station's "repair range 3" shipped as +2 on top of whatever the branch already gives rather than a fixed 3. Ram Frame reuses the centauroid charge flag exactly as this section intended.*

## 9. Core systems — decided 27 Aug 2026: build them, keep them small

One core slot opens at B tier and holds a single once-per-mission signature system. **Maxime's call between the three options below was A — build them, but deliberately sized as strong *turns*, not ultimates.**

### 9a. The line that keeps Severance categorically bigger

This is the rule that makes option A work, and it should be written into the GDD rather than left as a design intention:

> **A core system never ignores the full-HP damage cap, and never harms a friendly unit. Both of those properties belong to Severance alone.**

That's enforceable in code as two assertions, it's explainable to a player in one sentence, and it means a core system can be genuinely exciting without ever being confused for the Heirloom. Severance stays the thing that breaks the game's own rules; a core system is the thing your frame finally does once it's grown up.

### 9b. One core per path, no menu

Deliberately not another choice. The core is what your *path* does when the frame comes online — it arrives as a capability, not a shopping decision, which keeps this the cheapest version of the feature and stops the B step from becoming a fifth catalogue to read. **(Decided 6 Sep 2026: granted free at B, not purchased with personal points — see §14 item 1.)**

| Path | Core system | What it does, once per mission |
|---|---|---|
| **Meeps** | *Vault Strike* | Move up to your full move ignoring unit collision — pass straight through bodies, friendly or hostile — then attack at ×1.25. A positioning ultimate, not a damage one: it's the answer to a Tank wall standing between you and the backline, which is the exact problem GDD §4.1 says the Meeps exists to solve. |
| **Tank** | *Bulwark Dome* | For one full round, every ally within radius 2 takes 25% less damage. Doesn't move, doesn't attack, doesn't stack with itself. The Tank's whole job is bodyguarding the backline; this is that job turned up for one round at the moment it matters. |
| **Reeps** | *Ranging Shot* | One attack at unlimited range against any target *currently visible to your squad*. No counterattack, as normal. **Vision is the limiter, and that's the point** — it makes Signal Booster, a Runemaster mek, and the Osnian vibrissal chassis all suddenly matter to a Reeps build that previously didn't care about sensors. |
| **Munti** | *Triage Pulse* | Repair every ally within radius 2 for 50% of your normal repair output. Doesn't revive, doesn't restock, doesn't touch the Munti permadeath rule at all — it's a wide, shallow heal for the turn after something went wrong. |

None of the four ignores the damage cap. None of the four can hit a friendly. Two of them (Bulwark Dome, Triage Pulse) deal no damage whatsoever. That's what "small" means here — not weak, but structurally incapable of being the game's biggest button.

**Decided 6 Sep 2026 — the Heirloom/core interaction:** an Heirloom holder (Bosk today, carrying Gjallar/Requiem from Mission 2) still climbs the ordinary G→A ladder like anyone else, but **Requiem takes that pilot's core slot** rather than stacking alongside their path's own core. So Bosk doesn't get Bulwark Dome while he carries Gjallar; if Gjallar ever passes to Rourke (per its own design, only on Bosk's death), whatever core her own path would have granted is superseded by Requiem the moment she picks it up. See §14 items 4-5.

### 9c. What this costs to build, honestly

Core systems stay in §10's Tier 3 even though they're now in scope, because all four need genuinely new engine work: a per-pilot per-mission charge flag, a new action-bar entry with its own targeting mode, and — for Vault Strike specifically — movement that ignores unit collision, which the pathfinder does not currently do for anything. Bulwark Dome and Triage Pulse both need a radius-based multi-target resolver that also doesn't exist yet, though Triage Pulse can likely reuse whatever Screen already does for multi-unit selection. Ranging Shot is the cheapest of the four by a distance: it's an ordinary attack with the range check skipped and the visibility check kept.

**Build-order recommendation that follows from that:** ship Ranging Shot first as the single-path proof, on its own, before committing to the other three. If a once-per-mission core reads as flat in play, that's a cheap thing to find out with one path's version rather than four.

### 9d. The three options, kept on record

- **A — build core systems, keep them small.** ✅ **Chosen, 27 Aug 2026.**
- **B — skip them entirely**, bigger Draw jump at B tier instead, refit is the sole capstone.
- **C — one shared company core per mission**, owned across the squad, only one fires per drop.

C is worth remembering rather than deleting: if core systems ever start to feel too common once several pilots are at B tier, C is the shape that fixes it without removing the feature, and the per-pilot version built under A is a strict subset of what C needs.

## 10. Honest engine cost — three tiers

**Tier 1 — data and shop UI only. No new engine concepts.** ✅ **Shipped 6 Sep 2026, second mount included** — `Bloom_Wars_Build_Log_Addendum_FrameSystemsTier1_06Sep2026.md`; Stabilizer Struts, the Gallcyst re-source and the Crash Foam cut followed the same evening in `Bloom_Wars_Build_Log_Addendum_MekTrackEffectsWired_06Sep2026.md`. "No new engine concepts" held for the concept layer (nothing here is a status effect, a one-shot flag, or a new action); it did not hold for hooks — most systems and three of the eight refits each needed one, all built no-op-when-absent so the combat sim's cases stayed byte-identical.
Draw budget and per-tier capacity; the second mount at C; all 13 pure-number systems in §5; all eight frame refits; the additive `systemBonuses()` term in the §5.1 order of application; the equip screen. This tier alone converts G→A from one slider into seven distinct events and roughly triples the number of build decisions in the game. **If only one thing gets built, build this.**

**Tier 2 — moderate, no new combat concepts.**
One-shot-per-mission systems (needs a spent-flag per unit per mission); the salvage unlock counters (new persisted campaign state, must survive save/load and permadeath) — *shipped with Tier 1 per §14 item 6*; Threat Ledger; the Runemaster salvage-Draw interaction — *also shipped with Tier 1*.

**Tier 3 — real new engine systems, each one its own project.**
Status effects — slow, stun, DoT, attack-debuff, knockback (the Mek Workshop doc's §5 already flagged every one of these); post-attack movement; aura systems; terrain mutation; **core systems and their UI — now in scope per §9's decision, but still the most expensive item in this doc and still the last thing to build.**

**A rule worth adopting from this split:** don't build a status effect for one system. Build the status-effect framework once, deliberately, as its own piece of work, and then a dozen systems and weapon branches all become data. Doing it the other way — one bespoke effect per item — is exactly the drifting-duplicate failure this project's build log already flags as a recurring pattern.

## 11. If you actually do want a heat axis later

I argued against it in §2, but there's a version that fits this game specifically, so it's on record rather than lost. The Bloom already have a **two-track health model** — Endurance and Vitality, the thing GDD §5.2 says is what makes them feel unlike fighting mechs. Player mechs have one track. Giving mechs a second track (call it Strain) would be *symmetry*, not imitation: both sides fight on two axes, for different reasons. Strain would rise from overdrawing your frame — deliberately equipping past your Draw ceiling in exchange for taking Strain damage as you use those systems.

That's a genuinely good idea and it is absolutely not a first pass. It touches every damage calculation, every health bar, the AI, and the sim harness. Recording it so it survives; not proposing it.

## 12. Scope — the part you asked me to always flag

**This is the largest single feature anyone has proposed for this game.** Bigger than the Hub, bigger than the campaign's engine work, bigger than everything in the Weapon Branch doc combined. Full build — all three tiers of §10 — is a multi-week project that touches the shop, the pre-mission screen, the damage pipeline, campaign state, the save format, the sim harness, and four locked doc sections.

**Tier 1 alone is not.** Tier 1 is a data file, a shop tab, an equip screen, and one extra additive term in a function that already has three. It is genuinely small, and it fixes the actual complaint — G→A stops being one slider. My recommendation is Tier 1, played for a while, then decide whether Tier 2 and 3 earn their cost from actual play rather than from this document.

**One more scope honesty:** there is still no economy sim harness. The Weapon Branch doc's §7 already said this and it's still true — there's nothing that plays out a whole campaign's earn-and-spend loop, so every Draw number, every cost, and every tier capacity in this doc is a guess with a shape, not a tuned value. Adding a fourth and fifth purchasable category without that harness means the economy is being balanced by feel across five interacting systems. **Decided 27 Aug 2026: the economy sim harness gets built first, before Tier 1.** Maxime took the boring answer, which is the right one — without it, five interacting purchase categories (tier, spare part, mek secondary, branch, system) would be balanced by feel. What that harness actually needs to do, sketched so it isn't a vague to-do: play a whole 36-mission campaign with a plausible spending policy, report per-pilot end-state (tier reached, branches owned, Draw spent, systems installed) and the company pool's own balance over time, and flag the two failure modes that matter — a player who can afford everything by Act III, and a player who can never afford a second mount. Same relationship to §5/§8's numbers that `combat_sim.py` already has to the damage tables: a number doesn't count until it's been through the harness.

**Built, 6 September 2026 — `npm run sim:economy` (`src/sim/runFrameSystemsEconomySim.ts` + `src/sim/frameSystemsEconomyParams.ts`).** Both failure modes named above show up against the harness's own placeholder numbers: a 25-company pass has the single best-earning pilot fully maxing (tier A + all branches + secondary + Refit) only 48% of the time by mission 36 (averaging mission 34 when it does — later than the 5 Sep personal-points retune's own "mission 25-30" target, which was sized against the pre-Frame-Systems purchase list), and a rarely-deployed "bench" pilot never reaching tier C — never affording the second mount — 94-100% of the time. Read as: the placeholder numbers picked for this harness are plausible but not yet tuned, and the real design tension (does a bench pilot getting locked out of a second mount forever matter, or is that acceptable the way permadeath already accepts uneven pilot outcomes) is now a concrete, numbers-backed question rather than a hypothetical one. Full findings and the harness's own honest limitations: `Bloom_Wars_Build_Log_Addendum_FrameSystemsEconomySimHarness_06Sep2026.md`.

**Then, same day:** Maxime picked "fix the earn rate first" over accepting that shape — `KILL_BONUS`/`SURVIVAL_BONUS`/`OBJECTIVE_BONUS` 15/15/30 → 18/26/46, tuned against the harness (anchor now maxes 100% at avg mission 25.8; bench reaches C 52-54%). `Bloom_Wars_Build_Log_Addendum_EarnRateRetune_FrameSystems_06Sep2026.md`. **And then Tier 1 itself shipped** — the harness now imports its cost and capacity constants from the shipped `data/frameSystems.ts` so the two can't drift, though its salvage timing model is still a flat placeholder simpler than the per-archetype gates that actually shipped. The "played for a while, then decide" recommendation above is now the live state: nobody has played it yet.

## 13. Docs that need updating if this goes ahead

Per the standing rule about chat decisions drifting away from what's written. *Now actually due as of 6 Sep 2026 — Tier 1 exists. The `.docx` items are Maxime's own hand; the markdown items Claude can do on request. Exact wording for each is in the Tier 1 addendum's last section.*

- **GDD §4.4** — the tier table gains Mounts and Draw columns. Also resolve the orphaned "first ability slot / second ability slot" notes (§1b) — cash them or cut them.
- **GDD §6.4** — "Points buy exactly three things" is already becoming four under the Weapon Branch doc. Under this it's five (tier, spare part, mek secondary, branch, system) plus two one-time purchases (refit, core). That line needs rewriting, not patching, and its "deliberately few" framing needs a deliberate decision to abandon.
- **GDD §4.3** — the chassis layer should probably note that some systems interact with chassis penalties (Redundant Actuators).
- **Data Pack §5.1** — the order of application gains a `systemBonuses` term on each of the five stat lines. This is the single most important doc edit here, because §5.1 exists specifically so balance testing stays reproducible.
- **Data Pack §12** — system costs, Draw values, refit costs, salvage unlock thresholds, once sim-verified.
- **Data Pack §6** — the six-vs-ten ability drift (§1b) should be fixed before anything writes a system that touches abilities.
- **`Bloom_Wars_Weapon_Branch_Point_System_v1.md` §3** — the second mount at C tier amends the one-equipped-at-a-time rule.
- **`Bloom_Wars_Mek_Workshop_And_Weapon_Progression_v1.md` §4** — **and this one is a real collision, not a footnote.** That doc's "modules" (company pool, bought per charge, consumed on use) and this doc's "systems" (personal pool, permanent, Draw-budgeted) are two different systems that would sit next to each other in the same shop doing similar-sounding things. They need to be either merged or made unmistakably distinct. My recommendation: keep both but rename so nothing is ambiguous — **consumables** are the company-pool one-use items (the grenade shelf), **systems** are the permanent personal installs. Don't ship two things both called equipment. *("Systems" is now taken, as of Tier 1.)*

## 14. Open questions — what's decided, and what's still yours

**Decided 27 Aug 2026:**

1. ✅ **Core systems: option A** — built, deliberately small, with the never-breaks-the-cap / never-hits-a-friendly rule (§9a) as the line that keeps Severance categorically bigger. Four cores specced in §9b.
2. ✅ **Salvage supply line: in**, treated as the point of the layer rather than an optional extra (§7). Kill-counter should start recording early and silently.
3. ✅ **Economy sim harness gets built before Tier 1** (§12). **Built 6 Sep 2026 — `npm run sim:economy`.**

**Decided 6 September 2026** (same chat pass that authorized the harness above):

4. ✅ **The core system is granted free at B tier**, not purchased with personal points (§9b). Reads as "your frame comes online," and the personal pool stays meaningful anyway via branches/systems/salvage/Refit.
5. ✅ **The A-tier Refit stands alone as the capstone purchase. Meeps and Tank are not forced into a symmetric 4th weapon branch** to match Munti's new Combat Medic (§8). Munti's three original branches were flat number tweaks needing a real flagship; Meeps/Tank's three each already include one (Shock Claws, Grinder Claw).
6. ✅ **Tier 1 and salvage ship together, not staggered** (§7). The kill-counter-starts-silently-early recommendation stands regardless. **Shipped that way, 6 Sep 2026.**
7. ✅ **An Heirloom holder still climbs the ordinary G→A ladder normally** — Requiem/Gjallar sits on top as a separate S-tier weapon, not a replacement for tier progression.
8. ✅ **But Requiem takes that pilot's core slot** (§9). Whoever holds Gjallar doesn't also get their path's B-tier core — no Bulwark Dome for Bosk while he carries it. Since the core is free either way (item 4), this has no personal-points economy effect; it only matters for the core system itself.

**Decided by the Tier 1 build itself, 6 Sep 2026 — Claude's calls, each one line to reverse, listed so they don't pass as settled:**

9. **The second mount stacks** — both branches fully live, passives add, on-hit lists union, range is the widest window. The doc never said; the alternative (primary + reduced offhand) is a second mechanic. Not sim-tested.
10. **Shredder Rounds and Rail Lance are additive** against a Tank (50%, capped 90%).
11. **S tier reads as A's capacity row.** The §3 table has no S row.
12. **Low-Profile Gait needs a 2+ star tile** — plain ground has 1 star in this engine.

**Still open — your calls, not mine:**

13. **"Draw" as the budget word**, and every system/refit/core name in here. Placeholders throughout, as always — Claude's own recommendation (keep "Draw") was given in chat 6 Sep 2026 but never put to a formal decision. Now live in the UI, so the rename gets dearer the longer it sits.
14. **Every specific Draw number, system/refit personal-point cost, and salvage kill threshold in §5/§7/§8 is still a placeholder** — shipped as 60 points per Draw, 350 per refit, 1 kill per salvage gate. `npm run sim:economy` covers the cost side. Nothing yet covers the combat side of a stacked loadout; that's a `combat_sim.py` job when wanted.
15. ✅ **Heartwood Graft — re-sourced to Gallcyst**, 6 Sep 2026 (Maxime's call: "Re-source to Gallcyst").
16. ✅ **Stabilizer Struts built; Crash Foam Lining cut**, 6 Sep 2026 — the Fieldwright stationary heal it needed was wired (it had been dead data), and Crash Foam's premise (the Fabricator mid-mission redeploy) was ruled out for good: "its the beacon job to give in battle restock." Spare parts feed Beacon Control now.
17. ✅ **Runemaster burrow detection wired as documented**, 6 Sep 2026 — anywhere in the pilot's vision, primary only. §5c's non-redundancy rule holds again (Seismic Tap is the weaker sensor). Maxime chose "as documented — measure it" knowing Rourke herself is Runemaster-primary; the before/after batch numbers are in the addendum above.
