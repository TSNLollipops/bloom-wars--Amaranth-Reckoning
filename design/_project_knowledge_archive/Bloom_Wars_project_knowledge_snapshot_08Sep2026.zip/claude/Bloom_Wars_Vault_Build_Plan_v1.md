# Bloom Wars — The Vault: Build Plan and Implementation Order (v1, 2 Sep 2026)

*Written after reading the live code rather than the docs' claims about it: `engine/heirlooms.ts` (30,609 b), `data/heirlooms.ts` (33,751 b), `engine/houseStanding.ts` (4,770 b), `scenes/Hub.ts` (431,163 b), `engine/campaignEconomy.ts`, all as they sit on `lorian-pc` at the timestamps from this morning's three Heirloom passes. Where this plan disagrees with a design doc, the code is what it's disagreeing with — see §8.*

---

## 0. Why this is the next thing

Three build passes on 2 Sep shipped the entire Heirloom system: recruitment, aristocrat minting, S-tier pilots, the returned-home rule, house standing and grievance, the recall hot topic. 1,536 tests. Every one of those passes closed with the same sentence in its own "still open" section:

> **No Vault room, no shortlist cards, no recruit button. A player cannot recruit an Heirloom today.**

That's a fully built second floor with no staircase. Nothing in the system is reachable in play — not the recruitment, not the aristocrat, not the houses, not the grievance system that was built with "full teeth" this afternoon. The Vault is the staircase, and it's the only thing standing between "the system is real" and "a player can use it."

`Bloom_Wars_First_Game_Dev_Feature_Gap_Report_1Sep2026.md` §F already put the Vault in EA weeks 1–2. Today is week 1 of that plan. Launch is 26 Oct.

---

## 1. The Vault is four jobs, not one — and they are very different sizes

This is the single most useful thing to establish before writing any code, because "build the Vault" sounds like one task and is actually four, three of which are cheap and one of which is a new system.

| # | Job | What the player does | Engine support today | Size |
|---|---|---|---|---|
| **A** | **The counter** | Look at a shortlist of house candidates, pick one, pay company points, gain an S-tier aristocrat pilot | `rollHeirloomShortlist`, `recruitHeirloom`, `aristocracyStanding`, `heirloomRecruitCost` — **all built, all tested** | Medium |
| **B** | **The shelf** | See what the company holds, choose which single Heirloom is carried, buy ability ranks | `fieldHeirloom`, `unfieldHeirloom`, `fieldedHeirloom`, `purchaseAbilityRank`, `abilityRank` — **all built, all tested** | Small |
| **C** | **The wall** | See which houses are angry and why, see what's been taken back, see who died carrying what | `heirloomHouseVerdicts`, `returnedHeirlooms`, `isReturnedHome`, `aristocracyStanding` — **all built** | Small |
| **D** | **The dedication** | The Mission 12 scene — Gjallar passes from Bosk to whoever held the gate | **Nothing.** No aberration acquisition function exists. No scene-trigger system exists. | Large |

**A, B and C are UI over finished engine.** Every function they need already exists, is unit-tested, and refuses cleanly with a player-readable sentence when it should. That is genuinely unusual and it means those three are mostly layout work, not design work.

**D is a new system wearing the same room's name.** `recruitHeirloom` explicitly refuses aberrations — *"isn't recruited — it comes from its own story beat"* — and that story beat has no code behind it at all. Planning D alongside A/B/C is how a two-week job becomes a five-week one.

**Recommendation: build A, C, then D, and hold B until §4 decision 2 is answered.** The reasoning for that odd order is in §4 and §6, and it's the most important argument in this document.

---

## 2. Where it lives — copy the pattern, don't invent one

### Plain-language note on the two options

A **scene** in Phaser is a whole screen that replaces what you're looking at — `MapSelect`, `Debrief`, `Hangar` are scenes. An **overlay** is a panel drawn on top of the scene you're already in, which you dismiss to get back. The Hub is a scene; everything the player opens *inside* the Hub is an overlay.

The Vault should be an overlay, for one concrete reason beyond effort: the whole point of the walkable Hub is that you go somewhere to do a thing. Swapping to a full screen at the plinth throws away the room you just walked across.

### The pattern already exists twice, in this exact file

`Hub.ts` already does precisely this in two places, and both shipped and work:

| | Hangar Deck | Workshop |
|---|---|---|
| Station point | `HANGAR_SHOP_POINT = { x: 690, y: 200 }` | `WORKSHOP_BENCH_POINT = { x: 340, y: 230 }`, radius 60 |
| Floor marker | `drawHangarShopPoint()` | `drawWorkshopBenchPoint()` |
| Proximity test | `isAtHangarShop()` | `isAtWorkshopBench()` |
| Prompt | `"E — roster & gear"` | `"E — carrier modules"` |
| Open | `openHangarShop()` | `openWorkshop()` |
| Built in `create()` | `buildHangarShopOverlay()` | (module list) |

So the Vault's shape is already decided by precedent, not by me:

```
VAULT_PLINTH_POINT = { x: ?, y: ? }   // inside ROOM_ZONE_BOUNDS.vault
VAULT_PLINTH_RADIUS = 60
drawVaultPlinthPoint()                 // dashed marker + "THE\nVAULT" label
isAtVaultPlinth()                      // currentRoomId === "vault" && within radius
interactPrompt → "E — the vault"
openVault() / closeVault()             // Esc closes, same as every other overlay
buildVaultOverlay()                    // called once from create(), setVisible(false)
```

`ROOM_ZONE_BOUNDS.vault` is `{ left: ZONE_SPLIT_X, right: ROOM_BOUNDS.right, top: ROOM_BOUNDS.top, bottom: ZONE_SPLIT_Y }` — the upper-right quadrant of the upper deck (`ROOM_DECK.vault === "upper"`). Pick the plinth point at that zone's own midpoint and check it clears `DOORS` by more than `VAULT_PLINTH_RADIUS + DOOR_RADIUS`, the same arithmetic `WORKSHOP_BENCH_POINT`'s own comment records having done.

**One line to delete on day one:** `ROOM_NOTES.vault` currently reads *"Heirloom dedications belong here eventually. Nothing built yet."* That string is the room telling the player the truth right now, and it stops being true the moment Phase 1 lands.

---

## 3. The one architectural decision that isn't cosmetic: the shortlist has to be stored

`rollHeirloomShortlist(state, rng, size)` is a **pure function** — same inputs, same output, no memory, no side effects. That's exactly right for the engine and exactly wrong for the UI if you call it naively.

If `openVault()` rolls a fresh shortlist every time it opens, the player closes and reopens the panel until the name they want appears. That's not a shortlist, it's a slot machine, and it silently deletes the scarcity the entire 3-of-8 budget exists to create.

So the roll has to be **stored**. That looks like a violation of this repo's strongest habit — *derive, never store* — and it isn't, for the reason `Bloom_Wars_Build_Log_Addendum_HouseStanding_02Sep2026.md` §1 already wrote down this morning:

> Derive when the source of truth outlives the question. Store when the event that answers it is the thing that destroys its own source.

A shortlist roll destroys its own source: the `rng` draw is gone the instant it returns. Nothing can reconstruct it later. So it's the same case as `PermanentLossRecord`, and it gets the same treatment.

**Proposed shape** — additive, optional, no migration needed, matching `builtBays` / `builtModules` / `heirlooms` themselves:

```ts
// in HeirloomCampaignState
/**
 * The standing offer. Stored rather than re-rolled per open, because
 * rollHeirloomShortlist is pure: rolling on open lets a player reopen the
 * panel until a name they want appears, which deletes the scarcity the
 * 3-pick budget exists to create.
 */
shortlist?: {
  ids: HeirloomId[];
  /** What the offer was rolled against, so a stale one can be spotted. */
  rolledAtRank: CampaignState["rourkeRank"];
  rolledAfterMissions: number;
};
```

The "no migration needed" phrase is worth unpacking since it comes up constantly in this repo: because the field is optional and every reader does `?? something`, an old save that predates the field just reads as "no offer rolled yet," which is exactly what it means. No conversion code, no version number, no risk of corrupting an in-progress campaign.

**When it refreshes is a real design decision, not an implementation detail** — see §4, decision 1. The data shape above supports all three candidate answers, which is why it's proposed before the decision is made.

---

## 4. Four decisions that block the build

### Decision 1 — Shortlist cadence — **LOCKED 2 Sep 2026: option A, roll once and hold**

`Bloom_Wars_Build_Log_Addendum_AristocratMinting_HeirloomNaming_02Sep2026.md` §6 lists "the shortlist cadence within Acts II–III" as an open placeholder. It has to close before Phase 1 ships, because it's what the stored field means.

| Option | Feel | Cost |
|---|---|---|
| **A. Roll once when Act II opens; the same three names stand until you take one, then reroll** | The houses made an offer and are waiting on you. Scarce, calm, easy to reason about. | Cheapest. One roll on unlock, one on each pick. |
| **B. Reroll every N missions whether or not you picked** | The market moves. Creates a real "take this one or gamble on next month" tension. | Needs a mission counter on the stored record and a rule for what happens to a name you were saving. |
| **C. Reroll on each Debrief** | Maximum churn, maximum FOMO. | Cheap to code, and it makes each individual offer worthless — you'd never take one early. |

**Locked: A.** It matches how the rest of this campaign's economy behaves (nothing else in the game expires on a timer), it's the only one where a player can deliberately save up for a specific pick, and B can be added on top of A later without changing the data shape. C actively fights the escalating cost ladder.

**What that means concretely for Phase 1:** `currentShortlist(state)` rolls and stores on first ask, returns the stored list on every ask after, and is cleared by `recruitHeirloom` succeeding — so the next open rolls a fresh three. `rolledAtRank` / `rolledAfterMissions` are still worth storing even though nothing reads them yet: they're what makes a stale offer diagnosable from a save file rather than a mystery.

### Decision 2 — Ability ranks are priced past what the campaign can pay — **LOCKED 2 Sep 2026: option B, the house sends them with money**

This is the finding I'd most want you to see, and it came out of arithmetic rather than reading.

Ability ranks are bought with **personal** points. Personal points come from `computeMissionEarnings`: `KILL_BONUS = 5` per kill, an assist priced as a fraction of the same 5, `SURVIVAL_BONUS = 5` for not being downed, `OBJECTIVE_BONUS = 10` for a win. A good mission for one pilot is therefore roughly **25–40 personal points**.

Rank costs are `250 / 400 / 600 / 850` — **2,100 to take one ability from rank 1 to rank 5, 6,300 to max all three.**

Now the campaign arithmetic. Heirlooms unlock at Act II (`heirloomsUnlocked` reads `rourkeRank !== "2nd_lt"`, so Mission 12 at the earliest). An aristocrat recruited the moment that opens has at most 24 missions left, deploys on all of them, survives all of them:

- **Lifetime personal points, best case: ~600–950.**
- That buys **rank 2 (250) and rank 3 (400)** on one single ability, with change.
- **Rank 5 is unreachable. Maxing all three is unreachable by about 7×.**
- The **third** recruitment — which by design happens late and costs 600 company points — joins with maybe six missions left, earns ~200 personal points, and **can never afford a single rank on anything.**

That last line is the one that decides whether the shelf is worth building. Right now the ability-rank UI would be a screen showing a player four locked buttons they will never unlock, on a weapon whose abilities don't fire in combat yet (§7).

Three ways out, all yours to pick:

| Option | What it does | Note |
|---|---|---|
| **A. Cut the ladder to ~a third** (`80 / 130 / 200 / 280`) | Rank 5 on one ability becomes a real campaign-long goal; two abilities to rank 3 is achievable | Keeps the economy shape, changes only four numbers in `data/heirlooms.ts` |
| **B. The house sends them with money** — mint the aristocrat with a signing pool (say 400–600 personal points) | Thematically excellent: an aristocrat arrives already better equipped than a recruit, which is the whole premise. Fixes the third-pick problem specifically. | ~4 lines in `mintAristocrat`, one new constant |
| **C. Leave it, and treat rank 5 as deliberately mythical** | Defensible — you're an XCOM purist and unreachable ceilings are a genre convention | Then the shelf ships read-only for EA and the buy buttons wait |

**Locked: B**, with A held in reserve if it still reads tight after a playtest. B is a smaller change than A, it fixes the sharpest case (the third pick), and it's a *story* answer to an economy problem, which is generally the kind this project has had the most luck with.

**Proposed value, and the argument for it — `ARISTOCRAT_SIGNING_POOL = 650`.** Not a round number picked for feeling round: 650 is exactly rank 2 plus rank 3 on one ability (250 + 400). So a freshly recruited aristocrat can immediately take their signature to rank 3 and nothing else, which is a legible, teachable meaning rather than an arbitrary balance — *the house paid for the weapon to be worth carrying, and everything past that you earn.* Their own mission earnings then carry them toward rank 4 over the rest of the campaign, and the third pick, joining late, still arrives useful instead of arriving broke.

Flagged as a placeholder in exactly the same sense the 250/400/600 ladder is: argued, not simulated. It lives as a named constant in `data/heirlooms.ts` next to the rank costs so a retune is one line.

**One consequence worth knowing before it surprises you:** personal points are zeroed when a pilot is permanently lost (`applyPermadeathCheck`). So an aristocrat who dies before spending the signing pool takes it with them — which is consistent with the returned-home rule and, honestly, sharpens it.

### Decision 3 — The dedication scene — **LOCKED 2 Sep 2026: option A, one-shot check for EA**

`Bloom_Wars_Antfarm_Carrier_Hub_v1.md` §7 designs a general `HubScene` record — a data-driven trigger/beat structure — and §8 lists **eleven** scene placements across the 36 missions. Grepping the repo: **`HubScene` does not exist anywhere in `src/`.** Zero code.

But the Hub already has a cheaper pattern that does the same job for a *single* beat: the one-shot check. `checkMekRetirement()`, `checkHeirloomRecall()`, `checkMuntiLoss()`, `checkMissionEcho()` all follow it — scan on Hub load, gate on a per-pilot `...Announced` flag so it fires exactly once, ever.

| Option | Cost | When it's right |
|---|---|---|
| **A. `checkVaultDedication()`, one-shot, hand-authored** | Small. Mirrors `checkHeirloomRecall()` almost line for line. | EA ships Warden Company alone and needs **one** scene: Mission 12. |
| **B. Build the general `HubScene` system now** | Large. New data type, trigger matching, a beat player, participant resolution, save-state for "seen." | Right the moment there are three or more scenes. Which is House Amaranth's problem, and House Amaranth is deferred past EA. |

**Locked: A for EA.** The header comment on `checkVaultDedication()` should name `HubScene` explicitly and say what a generalisation would have to hoist out, so B stays a refactor rather than a rewrite. This is the biggest single scope saving available in this whole plan — roughly the difference between the Vault landing in week 2 and landing in week 5.

Cost accepted, stated plainly: the other ten placements in `Bloom_Wars_Antfarm_Carrier_Hub_v1.md` §8 stay unbuilt, and each one added afterward is another hand-written check. The break-even is around three, and the trigger to revisit is the third one — most likely when House Amaranth gets its own Hub, post-EA.

### Decision 4 — Is the Vault gated, or open and empty?

The four buildable bays gate on `rourkeRank`. The Vault could do the same, or it could be walkable from Mission 1 and simply say why it's empty.

**Recommendation: open, empty, with a reason.** `heirloomsUnlocked` already returns a player-readable refusal — *"No house is offering yet — Heirloom candidates appear from Act II onward"* — and a room that tells you what it will eventually be worth is better foreshadowing than a locked door. It also means the Mission 12 dedication doesn't have to fight a gate to happen.

---

## 5. The phases

### Phase 1 — The Staircase *(the EA must-have)*

**Ships:** a walkable plinth in the Vault, and a panel that turns `recruitHeirloom` into something a player can actually do.

- `VAULT_PLINTH_POINT` / `_RADIUS`, `drawVaultPlinthPoint()`, `isAtVaultPlinth()`, prompt wiring at both of `Hub.ts`'s prompt sites (line ~7488 and the interact handler at ~2242 / ~6123 — there are two, and the Workshop bench is wired into both; miss one and the key works but the prompt doesn't, or vice versa).
- `buildVaultOverlay()` in `create()`, `openVault()` / `closeVault()`, Esc handling, backdrop interactive so clicks don't fall through (the Rec Room help panel's own note records why that matters in Phaser).
- **Shortlist cards, three of them.** Per card: the Heirloom's `displayName` and `epithet`, the aristocrat's `displayName`, `house` and one-line `hook`, `path` (or a path picker on the two `path: null` ones), and the signature ability's `displayName` + `rank1` text.
- **Recruit button** per card, showing the live cost from `heirloomRecruitCost(recruited.length + aristocracyStanding().costSteps)` against `state.points`.
- **Every refusal displayed as its sentence.** `recruitHeirloom` already returns real prose for all six refusal paths, including *"No house will put a name forward to Warden Company now."* Print `result.reason` — do not write a second set of error strings in the scene.
- Persist immediately after a successful recruit, matching `openHangarShop`'s own save-on-every-purchase convention.
- Shortlist stored per §3, rolled per Decision 1.

**Files:** `scenes/Hub.ts`, `engine/heirlooms.ts` (the stored-shortlist field + a `currentShortlist(state)` reader that rolls-and-stores on first ask), `data/heirlooms.ts` (only if Decision 2 lands as A or B).

**Tests:** the roll-once-then-stable rule is the one that actually matters — call `currentShortlist` twenty times, assert one answer; assert a pick reroll produces a list excluding the pick; assert an estranged-house penalty narrows the offer but never below `HEIRLOOM_SHORTLIST_MIN`.

**Done means:** a player walks to the Vault in Act II, sees three names, spends 250 company points, and an S-tier aristocrat is standing in the Hub with their own name on the Transporter Pad the next time they deploy. Every one of those downstream steps was verified working this morning.

---

### Phase 2 — The Shelf *(hold pending Decision 2 — see §6)*

**Ships:** which Heirloom is carried, and the ability shelf.

- The company's holdings, from `heirloomsWithCompany(state)`.
- **FIELD / UNFIELD**, one at a time (`HEIRLOOM_FIELD_LIMIT = 1`), reading `fieldedHeirloom(state)` — the *derived* reader, not the stored `fielded` field, because the stored one deliberately survives its wielder's death and the derived one doesn't. Getting this backwards would let a player field a dead aristocrat's weapon.
- The three abilities per Heirloom, current rank, `rank1` and `rank5` text, cost to advance, buy button calling `purchaseAbilityRank(state, id, abilityId, holderPilotId)`.
- `heirloomForPilot` gives you the holder; `assignedPilotId` is the map behind it.

**Files:** `scenes/Hub.ts` only, if Decision 2 lands as C.

---

### Phase 3 — The Wall *(cheap, high story value)*

**Ships:** the room's memory.

- **Returned home.** `returnedHeirlooms(state)` plus each one's `heirloomHouseVerdict` — the house, the aristocrat's name, the verdict, and `HOUSE_VERDICT_CLAUSES` text. An empty plinth with a name plate under it is one of the cheapest genuinely affecting things this game can do.
- **Standing.** `aristocracyStanding(state)` — how many cost steps the houses have added, how many names they've withdrawn. Right now this is invisible; a player whose recruitment price silently went from 400 to 600 has no way to learn why.
- **Memorial.** The feature gap report's B3, slotted for week 5, belongs on this wall: `statsStore.ts` already carries memorial queries with no screen behind them.

**Why this is worth doing before Phase 2:** this morning's House Standing pass built a whole grievance system with "full teeth" and every consequence of it is currently unobservable. A player can lose the campaign's remaining Heirloom content and never be told it happened. The wall is what makes that system *exist* for the player, and it's maybe a day's work.

---

### Phase 4 — The Dedication *(the load-bearing beat)*

`Bloom_Wars_Antfarm_Carrier_Hub_v1.md` §8 marks this **"Load-bearing, not skippable"** — the one moment the hub isn't allowed to be quiet. It's the scene where *"the friend-or-foe rule reads as grief rather than as game design."*

**Needs a new engine function first.** `recruitHeirloom` refuses aberrations by design, so Gjallar has no acquisition path at all:

```ts
/**
 * Assign an aberration to a pilot from its own story beat. Not a
 * recruitment: no company points, no shortlist, no pick spent against
 * HEIRLOOM_RECRUIT_BUDGET — the budget is the three houses' offers, and
 * Gjallar was never a house's to offer.
 */
export function acquireAberration(
  state: CampaignState,
  heirloomId: HeirloomId,
  pilotId: string,
): HeirloomRecruitResult
```

Refuses on: not an aberration, already assigned, unknown or non-active pilot. Writes `recruited` and `assignedPilotId` and nothing else — no minting, because the holder is an existing pilot.

**Then the scene.** Per `Bloom_Wars_Walkable_Hub_Build_Plan_v1.md`'s locked 25 Aug rule: the substitution *selector* is `findClosestBond` (already live in `data/npcBonds.ts`, used twice in `Hub.ts`), but this scene specifically stays **hand-authored with named slots** — who died, who's stepping up, what they meant to Rourke — rather than procedural, because a generic version of the campaign's most important beat is worse than no version.

Trigger: `checkVaultDedication()`, one-shot, gated on a new `CampaignState` flag, fired on Hub load after Mission 12 resolves. Contingency built in from the start, per campaign doc §6a: **Bosk may already be dead.** The scene needs a version that names whoever actually held the gate — that's the selector's job, and it must be written before the scene rather than patched in after.

---

## 6. Recommended EA cut line

**Weeks 1–2:** Phase 1 + Phase 3. Both are UI over engine that is already finished and tested. Together they make the entire Heirloom system — recruitment, aristocrats, houses, grievance, recall — reachable and observable for the first time.

**Week 3–4:** Phase 4, if Decision 3 lands on the one-shot check. This is the campaign's most important story beat and it currently doesn't exist.

**Phase 2 last, and deliberately.** Not because it's hard — it's the smallest of the four — but because **the Heirloom abilities do nothing in combat.** That's §7's first flag and it's unchanged since this morning. Shipping a shop that sells ranks of an ability that has no effect, at prices the campaign can't pay, is the one part of the Vault that would make the game feel *less* finished rather than more.

If Phase 2 has to ship for EA, ship it **read-only** — show the abilities, show what rank 5 would do, no buy button — and say so in the panel. A locked door with a reason behind it reads as content. A buy button that takes real points for nothing reads as a bug.

---

## 7. Scope flags — things I would not build in this pass

**The ~30 combat abilities.** Flagged in both of this morning's addenda and unchanged. Several need genuinely new engine mechanics. This is a bigger job than the entire Vault and it's the real prerequisite for Phase 2 mattering. Worth its own plan; not folded in here.

**`TIERS.S` is an unvalidated placeholder** (149/140/140, move 2, never run through `combat_sim.py`). Phase 1 puts a real S-tier unit on the board for the first time, which makes this pass more urgent, not less. One `combat_sim.py` run, half a day, and it should happen *alongside* Phase 1 rather than after — otherwise the first thing a player does with the new room is field an unbalanced unit.

**House Amaranth's coupling.** House Standing §5 flags it precisely: Thessaly Amaranth's house going estranged is currently worth the same as any other house's, when it could plausibly change Mission 28. It couples a death to a scripted beat. Real scope, genuinely interesting, explicitly not this.

**The general `HubScene` system.** Decision 3. Revisit at three scenes.

**Salvaged Heirlooms / the Runic Integration Line.** See §8 — this may no longer exist as a design, and shouldn't be built until you say whether it does.

---

## 8. Doc drift found while planning

Per the standing rule about not letting the docs quietly diverge from the code — five items, none of them fixed by this document:

1. **`Hub.ts` line 686**, `ROOM_NOTES.vault`: *"Heirloom dedications belong here eventually. Nothing built yet."* True today. Must be rewritten in Phase 1.
2. **`Bloom_Wars_Antfarm_Carrier_Hub_v1.md` §4 describes a "20-name Heirloom pool."** The shipped pool is **10** — 2 aberrations plus 8 recruitable (`RECRUITABLE_HEIRLOOM_IDS`). Either the pool shrank deliberately or the doc never caught up.
3. **Same section names "The Debutante's Answer," tagged *salvaged, not issued*, sitting uncalibrated in the Vault until the Workshop's Runic Integration Line is bought.** No Heirloom in `data/heirlooms.ts` carries that name, a `salvaged` tag, or any Workshop dependency, and no `CarrierModuleId` matches the Runic Integration Line. **This is a design that either got dropped in the naming pass or never got built. Your call which — it's a nice mechanic and it's the only thing linking two Hub rooms together.**
4. **Same section's open question — "whether a permanently lost pilot's Heirloom is retired, orphaned, or memorialized" — was answered this afternoon** (returned home to the house, pick not refunded). The doc still presents it as open.
5. **`Bloom_Wars_Master_Index.md`** still needs the House Standing entry that this morning's addendum §6 asked for, and its Heirloom section understates what the recall now does. Also worth adding a Vault pointer once Phase 1 lands.

---

## 9. Verification, and one honest gap

The project's own bar, unchanged: `npx tsc --noEmit`, `npx eslint src/`, `npx vitest run` against the 1,536-test baseline captured *before* editing, `npm run build`, `npm run sim`, `npm run sim:social`, `npm run sim:gate`, then a device commit with fresh mtime guards and a directory listing afterward to confirm real new sizes rather than trusting the tool's success.

**The gap this project has had all along applies here more than usual: the Vault is almost entirely UI, and UI is the one thing that can pass every check above and still be wrong on screen.** Overlapping labels, a card that runs off the panel, a plinth marker sitting under a door prompt — none of that fails a test. Your own click-test is the real verification step for this feature, the same way it was for the egg hull, where you caught things no script would have.

**Naming-lock lint, still vacuous.** `tools/lint-spoiler.mjs` reads `BW_RESERVED_TERM` from a `.env.local` that does not exist on the machine, so it prints "skipping" and exits 0 — and it runs as `pretest`/`prebuild`, meaning every recent build passed that gate without checking anything. The Vault adds a lot of new player-facing strings (house names, aristocrat names, refusal prose). **Setting that variable once, before Phase 1 ships, is a five-minute job that would put the lock back on duty for exactly the pass that most needs it.**

---

## 10. Decision status

**Closed 2 Sep 2026, same conversation this plan was written in — all three blocking decisions:**

1. **Shortlist cadence** — roll once when Act II opens, hold until a pick is made, then reroll. §4 decision 1.
2. **Ability-rank affordability** — the house sends each aristocrat with a signing pool of personal points; proposed at 650, the exact price of rank 2 + rank 3 on one ability. §4 decision 2.
3. **Dedication scene** — one-shot `checkVaultDedication()` for EA, written so the general `HubScene` system is a later refactor rather than a rewrite. §4 decision 3.

Decision 4 (open vs gated Vault) stands at the recommendation — open and empty with a reason — as the low-risk default; say so if you want a rank gate instead.

**Still open, not blocking:**

- **Does the salvaged-Heirloom / Runic Integration Line design still exist?** §8 item 3. If it's alive it belongs in Phase 3; if it died in the naming pass, the Antfarm doc should say so rather than leave a mechanic on the books that has no code and no name.
- **`TIERS.S` validation** — §7. Wants a `combat_sim.py` pass alongside Phase 1, not after it.
- **`BW_RESERVED_TERM` in `.env.local`** — §9. Five minutes, and it puts the naming lock back on duty for the pass that adds the most new player-facing strings in months.


---

## 11. Status update — 3 Sep 2026: Phase 2 shipped

All four phases are now built. Recap of what actually shipped, since three of the four landed in a different order than §6 recommended:

- **Phase 1 (the counter) — shipped 2 Sep 2026.** Recruit shortlist, cost ladder, refusal prose. Matches this plan's Phase 1 spec.
- **Phase 3 (the wall) — shipped 2 Sep 2026.** Returned-home display, house standing.
- **Phase 4 (the dedication) — shipped 2 Sep 2026.** `checkVaultDedication()`, one-shot, per Decision 3.
- **Phase 2 (the shelf) — shipped in two slices, not held to last as §6 recommended, because §6's own blocking condition changed underneath it.**
  - **Slice 1 (2 Sep 2026):** wired exactly 5 of the ~28 combat abilities into real effects — `oath_iron_word`, `lastword_field_triage`, `farsight_signature`, `salt_root_salt`, `ledger_overextended`. See `Bloom_Wars_Build_Log_Addendum_VaultPhase2Slice1_02Sep2026.md`.
  - **Slice 2 (3 Sep 2026):** built the shelf UI — field/unfield toggle, per-ability rank shop — landing in the middle ground §6 itself named as the fallback: not the full read-only version (buy buttons DO appear, for the 5 live abilities), and not the all-abilities version this plan's §6 correctly warned against (the other 23 show "not implemented in combat yet," no buy button, no lie). `HEIRLOOM_ABILITIES_LIVE_IN_COMBAT` (`data/heirlooms.ts`) is the single source of truth gating which abilities get a buy button, read directly by the shop rather than re-derived. See `Bloom_Wars_Build_Log_Addendum_VaultPhase2Slice2_03Sep2026.md` for the full build/verification writeup, including a live-browser Playwright click-test of the actual field and rank-up buttons — the UI-can-pass-every-check-and-still-be-wrong-on-screen gap §9 flagged.

Decision 2's locked number (`ARISTOCRAT_SIGNING_POOL = 650`) shipped as specified in §4 alongside Slice 1/Phase 1 — a fresh recruit can immediately push their signature ability to rank 3.

**Still genuinely open from §7/§8/§9, unchanged by this update:** the other 23 combat abilities remain unwired (each future slice repeats Slice 1's pattern); the salvaged-Heirloom / Runic Integration Line question (§8 item 3); `TIERS.S` combat_sim.py validation (§7, §9); `BW_RESERVED_TERM` still unset in `.env.local`, so the naming-lock lint is still vacuous on every build (§9) — worth the five minutes given how many new player-facing strings the Vault as a whole has added since this plan was written.
