# THE BLOOM WARS — Praise / Insult / Apology: System Proposal v1

**Design pass only — zero code, zero content lines written yet.** Written 1 September 2026. Grew out of `Bloom_Wars_Chat_Keyword_Categories_Plan_v1.md`'s own #7 ("Insults directed at a specific NPC — flagged, not proposed for now... a judgment call, not a sizing problem"), which explicitly asked for a real conversation before anything got written. This is that conversation, written up. Maxime's own framing, worth keeping visible rather than softened: the crew should be able to react like people, including to being treated badly, "even tho it would be more realistic... if it make npc more human. we should do it on principle."

**Status, 2 September 2026: BUILT.** See the new §7 at the bottom of this doc for exactly how §3a was actually resolved (not either of the two options this doc offered below) and the full build/verification account. `claude/Bloom_Wars_Build_Log_Addendum_CrewInteractionsBrainstorm_02Sep2026.md` is the authoritative build record.

**Worth saying plainly, since Maxime raised it himself: this isn't actually a risky or edgy addition.** Letting a player be cruel to their own crew and having it cost something is standard, well-established design — reputation/disposition systems have done this for decades. The reason it's new here isn't caution, it's that the game already lets NPCs be cold, rival, and openly clash with *each other* (Anger Blowup, rival-bond friction, catalyst clashes) but never let the player be the source of that toward an NPC. This closes that gap rather than opening a new kind of one.

**Three confirmed decisions, from Maxime directly, that shape everything below:**
1. Repeated insults should escalate past a simple Favorability hit into a real story consequence, not stay contained to a number.
2. There should be an Apology verb, and forgiveness should be catalyst-gated (some pilots forgive easily, some don't).
3. Insult should hit Favorability harder than Praise heals it — words that cut linger more than compliments repair.

## 1. The three verbs

**Praise** — a positive, catalyst-flavored Favorability bump. Smaller than Insult's hit, matching decision #3.

**Insult** — a negative, catalyst-flavored Favorability hit, bigger than Praise's bump. Also increments a new persisted counter (§3) that Apology does NOT reset — the fact that it happened doesn't un-happen, only the standing damage is repairable.

**Apology** — repairs some Favorability, magnitude scaled by catalyst (§4). Does not erase the lifetime insult count, but does matter for whether the worst consequence tier ever actually fires (§3) — genuine repair changes the outcome, it just doesn't rewrite history.

All three reuse the existing Favorability field and the existing catalyst-reaction-line machinery every other verb already uses — no new persisted architecture beyond the one counter below.

## 2. Why a counter, not just a Favorability threshold

The obvious cheap version — "escalate whenever Favorability drops below X" — has a real problem: Insult and Apology can move Favorability back and forth freely, so a threshold-only design lets a player insult, apologize back up, insult again, apologize again, and never actually face the consequence Maxime asked for. So this needs one small piece of state beyond Favorability: **`insultsGiven`**, a simple per-pilot lifetime integer, same shape as other simple counters already in this codebase (`turnsWithoutContact` is the closest precedent). It only ever goes up. Everything in §3 keys off *both* this count and the pilot's *current* Favorability together — so a player who insults once, then spends real effort apologizing and rebuilding trust, reads differently than one who racks up the same count and never repairs anything, even though the raw count is identical for both.

## 3. The escalation ladder — three tiers, placeholder numbers throughout

Explicitly placeholder, same discipline as every other new number this project ships with (Antfarm bay costs, the Wellroot's original attackPower) — these need playtesting, not a sim script, since there's no `combat_sim.py`-equivalent for social pacing.

- **Tier 1 — Sting, every single Insult.** Ordinary Favorability hit, catalyst-scaled (§4), plus an immediate catalyst-flavored reaction line (hurt/defensive/dismissive/amused, varies by catalyst — this is the actual content-writing pass, not done yet, waiting on this doc locking first).
- **Tier 2 — Reputation, at `insultsGiven` ≥ 3 for that pilot.** Registers a real hot topic through the *already-built* `hotTopics.ts` engine — no new plumbing needed, just a new topic kind — so another NPC has a real chance to bring it up unprompted ("heard you tore into [pilot] again"). If the Stress/Morale trigger system (`Bloom_Wars_Stress_Morale_Trigger_Proposal_v1.md`, still unlocked) ships before or alongside this, Tier 2 is also the natural first real trigger for it — a genuine Stress bump on the insulted pilot. If Stress isn't wired yet when this ships, this tier ships without the Stress half and picks it up automatically once that system lands, same "derive off state that already exists" discipline this project uses everywhere else.
- **Tier 3 — Breaking point, at `insultsGiven` ≥ 6 AND that pilot's current Favorability still below a real low bar** (meaning no real amends have landed — a player who's been apologizing and rebuilding trust doesn't get blindsided here even at a high lifetime count). **This is the one genuine open call in this whole doc — see §3a below before this gets built.**

### 3a. What Tier 3 actually does — a call worth confirming, not assumed

Two real options, and I'd default to the first one if not told otherwise, but this is squarely a "say so before building" moment given how much weight it carries:

- **Recoverable-but-real (my default):** the pilot formally refuses to deploy alongside Rourke specifically — a genuine mechanical lock, not just flavor, showing up right where TransporterPad already assembles a squad — until Favorability is rebuilt past a real recovery threshold through real Apology use. The CO calls it out directly next time he's talked to (a natural extension of `Bloom_Wars_CO_Bespoke_Dialogue_Bank_v1.md`'s own advice register — a new, distinct "call-out" bank, not the stress-relief one), and it's a guaranteed hot topic, not just a chance-based one. Recoverable, but genuinely costs the player something (a pilot they can't field) until they actually do the work to repair it.
- **Permanent departure** — the pilot requests reassignment for good, a real roster loss with no recovery path. This is closer to what "real consequence" could mean taken furthest, but it sits uncomfortably close to the permadeath/Munti system's own territory — that's this game's actual central stakes mechanic, and a second, unrelated way to permanently lose a pilot (over social behavior rather than combat) risks diluting what permadeath means rather than complementing it, and risks feeling punishing in a way that fights the reason this system exists (letting the crew feel human, not punishing the player for exploring it once).

I went with the first as the default in the rest of this doc. Flag if that's wrong and the second is actually the read wanted — it's a real fork, not a wording choice.

**Resolved, 2 September 2026 — neither option above is what actually shipped. See §7.**

## 4. Catalyst variance — the shape, not the lines yet

Insult sting, Apology generosity, and reaction flavor should all differ by catalyst rather than reusing one flat formula nine times — same "no caricatures, real internal logic" standard the ambient content already holds to. Rough shape, to be turned into actual reaction lines once this doc locks:

| Catalyst | Insult stings... | Forgives... | Flavor |
| --- | --- | --- | --- |
| Wolf (teamwork) | Moderately | On the team's behalf, not just their own | Disappointed more than angry — "not just about me" |
| Dog (loyalty) | Hard | Easily, if the apology feels genuine | Hurt, not hostile |
| Cat (selfishness) | Barely | Barely — doesn't need to, doesn't much care | Dismissive, unbothered either way |
| Crow (indulgence) | Moderately, but deflects | If you make it fun again | Hurt masked as a joke |
| Raven (instruction) | Hard — a real affront | Slowly, wants real acknowledgment | Lectures you on why it landed wrong |
| Bear (isolation) | Hard, internally | Rarely, quietly | Withdraws further, says little |
| Fox (trickery) | Lightly, turns it into banter | Easily — rarely holds a real grudge | Deflects, but a genuine apology actually lands |
| Rabbit (nurturing) | Very hard | Generously, almost too readily | Visibly hurt, still hopes you meant well |
| Shark (ambition) | Barely | Doesn't need to | Doesn't slow down for it either way |

## 5. What this doesn't do yet

**Superseded, 2 September 2026 — all of it is done now. See §7.** Left below unedited as the historical record of the original remaining-work estimate.

No code, no content lines. Needs, in order: §3a confirmed (or overridden), then this doc treated the same way `Bloom_Wars_Stress_Morale_Trigger_Proposal_v1.md` was — locked as real design intent — then the actual Insult/Praise/Apology reaction-line content written per catalyst (27 lines × 3 verbs, following the same sizing as the four banks already shipped), then the CO's own new "call-out" bank for Tier 3, then all of it wired into code once device access is back. Nothing here touches Agreement/Disagreement (Keyword Categories #6), which is a separate, still-open judgment call.

## 6. Naming-lock safety check

No proper nouns invented. Nothing here approaches "The Synker Wars" or the absolute reserved term.

## 7. Built, 2 September 2026 — how §3a actually resolved, and the full build record

**Neither of §3a's two offered options is what shipped.** Maxime's actual answer, verbatim: **"wont fly with you, player will have to ask co to remove them from ship."** Read closely, this is a genuine third shape, not a pick between the two options above: it's recoverable in the sense that the pilot doesn't just vanish automatically (unlike "Permanent departure"), but the recovery path isn't Apology rebuilding Favorability back past a threshold either (unlike "Recoverable-but-real," this doc's own default) — it's a real standoff that only ends when the player takes one specific, deliberate action: explicitly asking the CO to remove the refusing pilot from the ship. Apology can still repair Favorability at any point (and matters for whether Tier 3 fires at all, per §2/§3's own logic — a Favorability-ceiling condition is still part of the trigger), but once the standoff exists, Apology alone can never resolve it. Only the CO-mediated removal can, and that removal is permanent once chosen — closer in spirit to "Permanent departure" in its finality, but arrived at only by the player's own explicit choice rather than automatically, which is what keeps it from colliding with the permadeath/Munti system's own territory the way this doc originally worried the second option might: the player is never blindsided by an automatic loss, they have to ask for it.

**What actually shipped, matching decisions #1–#3 above exactly:** all three verbs (Praise/Insult/Apology), the `insultsGiven` counter, the three-tier ladder (Tier 2 at 3 insults registering a real `"insulted"` HotTopic; Tier 3 at 6 insults AND Favorability still below a real ceiling, flipping a new `refusesDeployment` flag), a real CO call-out bank (a new, distinct bespoke line, exactly as this doc's own §3a default anticipated it would need to be), and the CO-mediated removal itself (a new `"reassigned"` `PilotStatus`, reachable only through an explicit chat request to the CO). Per-catalyst Insult sting and Apology generosity (§4's table) are both real, differentiated `Record<Catalyst, number>` deltas, not one flat formula. All of it was live-verified end-to-end in a real running browser, including the full six-insult escalation from Tier 1 through the CO call-out through the actual removal — not just unit-tested in isolation.

Full build record, every file touched, the verification methodology (including a real production bug found via live-browser testing — a named-targeting rank-token false-match, unrelated to this system's own logic but found while verifying it), and what's honestly still open (every numeric constant here remains a placeholder, not yet playtested or sim-validated — same caveat this doc's own §3 already carried): **`claude/Bloom_Wars_Build_Log_Addendum_CrewInteractionsBrainstorm_02Sep2026.md`.**
