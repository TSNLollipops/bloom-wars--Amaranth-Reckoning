# Bloom Wars — Carrier Scale-Up and Per-Lance Mek Workshops, Plan v1

*Written 2 Sep 2026, from a chat conversation with Maxime. A plan, not a build — nothing in this doc is in the engine yet. Same discipline as every other design doc in this project: real open questions flagged, not smoothed over.*

> **STATUS, 3 Sep 2026 — BOTH PHASES BUILT, VERIFIED AND ON THE DEVICE.**
> The line above is kept as written for the record; it is no longer true.
> Phase 1 (bigger decks + scrolling camera) and Phase 2 (one Mek workshop
> per lance) both shipped in one session. Full account, including two
> latent bugs and two real regressions caught before they shipped, the
> answers given to this doc's own open questions, and what is deliberately
> still open:
> **`Bloom_Wars_Build_Log_Addendum_CarrierScaleUp_Phases1and2_03Sep2026.md`**.
> Per-section status notes are inline below.

## 0. What this is answering, and a correction made along the way

Maxime asked for two things in one breath: make the carrier's walkable area scrollable and big enough to hold every room plus room to grow, and change the Workshop so it's gated per lance — specifically, 3 workshops by Act III, one per lance, matching the game's own 1/2/3-lance progression (Warden Company alone in Act I, +Second Lance in Act II, +Third Lance in Act III).

Three things got settled by direct question before any design got locked in:

1. **"3 workshops" means the Mek-pairing room only** (each lance's pilots and their own Meks share a workspace) — **not** the Carrier Upgrade Modules bench that shipped 2 Sep. That bench buys ship-wide upgrades (things like +2 spare-part capacity for the whole crew) and stays a single, ship-wide fixture. Tripling it would mean either splitting one ship's upgrades into three pools, which doesn't make sense, or three buttons that do the same shared thing, which is just clutter.
2. **The scroll work is the smaller of two real options**: keep the current deck-swap-via-stairs system, but let each deck be bigger than one screen with the camera scrolling inside it — not a full merge into one continuous, no-more-stairs ship map. The bigger version stays on the table for later if the smaller one doesn't feel like enough once it's in.
3. **Sequencing was checked against a 29 Aug note that called for roster-driven Hub population before any of this** — and it turns out that's a stale worry. **Tier 3 of the 29 Aug Consolidated Build Plan already shipped this, in full**, per `Consolidated_Build_Plan_Progress.md`: `Hub.ts`'s NPC-building logic now reads the real, live roster (`Object.keys(campaignState.pilots)`, filtered to active pilots) instead of a small hardcoded list, and that includes every pilot's Mek too. So the thing this plan would have built first is already done — one less phase, and worth knowing about since it means the "empty ship" problem that motivated the original ask is already fixed. What's *not* fixed, and is actually the more useful thing to build on: that same rollout is on record as having strained the Hub's ambient-encounter and speech-bubble systems, because they were tuned for a cast of 3 and are now running against 15–20+. That's real, current evidence that the Hub is already crowded — a better argument for both halves of this plan than "recruits don't show up," which is no longer true.

**Update, 2 Sep 2026 (later the same day) — confirmed live, not just inferred from old strain reports.** Maxime, ahead of starting a full personal campaign playtest: "the 3rd lvl is way too overcroawed" (read as Upper Deck — Lower → Grotto → Upper is the deck order, and Upper is on record as the deck that got the least extra floor in the egg-hull pass, plus it already carries two of the reserved-bay markers in its margin). This is no longer a theoretical crowding risk inferred from the Tier 3 build notes — it's an active problem on the deck with the least slack, found by the person about to spend real hours testing the full campaign there. Phase 1 just went from "worth doing" to "the thing blocking a good playtest." Plan: do the Hub upgrade during the same window as the campaign test pass, not after it.

## 1. Phase 1 — bigger decks, camera scrolls inside them (stairs stay)

> **BUILT, 3 Sep 2026.** Each deck's floor is now 1650x1350 (was ~780x466);
> `startFollow` + per-deck `setBounds` via a new `deckCameraBounds()`;
> the full `setScrollFactor(0)` audit done. `ROOM_BOUNDS`,
> `ROOM_ZONE_BOUNDS`, `RESERVED_BAYS` and the doors are untouched — the
> old grid still tiles the same box, all new floor is added around it.
> Two things this section's own predictions got right and one it got
> wrong are recorded in the build log addendum; the wrong one is worth
> knowing here: **"NPC roaming should mostly just work" was only half
> true**, and the half that wasn't is the half this plan exists for.

**What "scrollable" means here, in plain terms.** Right now the carrier is 4 fixed-size rooms/decks — Lower, the Grotto, Upper, and the Spar Room — that you *teleport* between via stairs; the camera never moves, and each deck is sized to fit inside one screen. A scrollable deck means the camera follows the player around, and the deck's actual floor is bigger than what's visible on screen at once — the same way Stardew Valley's farm doesn't fit in one screen, but the whole game isn't one continuous world either (that's the bigger option we're deliberately not doing yet).

**Why this wasn't just done already.** Every fixed piece of UI in this scene — the chat log, the footer buttons, the HUD readouts, the corner text — currently sits at a fixed screen position because there's never been a camera to scroll away from underneath it. The moment the camera actually moves, every one of those elements needs to be told, explicitly, "ignore the camera" (`setScrollFactor(0)`, in Phaser's own terms) or it'll drift off-screen as the player walks. This was flagged and deliberately skipped once already, in the Phase 2 build (26 Aug) — a real, correct call at the time, made for a single small room. It's a bigger piece of work now, because there's a lot more fixed UI to audit than there was then.

**What actually needs to change, concretely:**
- A real camera-follow (`this.cameras.main.startFollow(player)`), bounded per active deck (`this.cameras.main.setBounds(...)`), engaged/disengaged on every deck switch — the same event that already fires on a stair transition today.
- `LOWER_BOUNDS` / `UPPER_BOUNDS` / `GROTTO_ELLIPSE` / the Spar Room's bounds all get bigger. How much bigger is a real open question (§4) — big enough to fit Phase 2's two new Workshop rooms plus some slack for whatever comes after, matching the same "preplanned space to expand" instinct that already shaped the egg-hull pass (27 Aug: reserved bays placed with room to grow into, before there was a use for all of it).
- Every persistent UI element in `Hub.ts` gets a `setScrollFactor(0)` audit. This is mechanical, but it's not small — `Hub.ts` is, per the Vault plan's own file-size note taken directly off the live device 2 Sep, **431 KB**. That is an enormous single scene file by any normal measure, and it has no dedicated unit test suite (a standing, repeatedly-flagged gap in this project). Camera work needs a real Playwright walkthrough before it ships, not just a clean `tsc`/lint/build — the same discipline the door-build and muster-fix passes already used, because this is exactly the kind of change that can pass every static check while still drawing a chat box that floats off the left edge of the screen the moment the player walks right.

> **This last paragraph earned its keep.** The audit turned out to have a
> second half nothing here predicted: Phaser renders a container's children
> with the CONTAINER's scroll factor but hit-tests them with each CHILD's
> own, so pinning the containers left every button inside every overlay
> drawing correctly and taking clicks somewhere else. `tsc`, lint and 1607
> unit tests all passed clean while the MENU button was unclickable. Only
> the live click-test this paragraph insisted on caught it.

- NPC roaming should mostly just work — it's already clamped per-deck (`clampToDeckFloor`), so a bigger deck bound is more likely to just mean NPCs have more room to wander, not a rewrite. Worth confirming rather than assuming, since this project has a real history of "should just work" surprising people once actually run (the grotto ellipse pass specifically built a dedicated math module and 7 tests rather than trust that call on faith).

> **Confirmed rather than assumed, and it did surprise.** NPC "explore"
> only ever targeted a *named room* and then a point inside that room's
> small zone; nothing ever sent anyone into open floor. Bigger decks alone
> would have changed what the player can walk on and nothing about where
> the crowd stands. `EXPLORE_OPEN_FLOOR_CHANCE` (0.3 of explore rolls) now
> sends idle pilots into their deck's open floor. Meks are excluded — they
> are confined by `homeRoom`.

**What this deliberately does not touch:** the deck-swap-via-stairs navigation model stays exactly as it is. Walking from the Grotto to Upper is still a stair transition, not a walk. If that ever stops feeling right, that's the bigger option from the original conversation, not a change to this plan.

## 2. Phase 2 — one Workshop per lance

> **BUILT, 3 Sep 2026.** `workshopB` (2ND LANCE WORKSHOP) and `workshopC`
> (3RD LANCE WORKSHOP), both on the upper deck, each a 420x444 copy of
> Lance A's footprint, stacked at x=900 inside the floor Phase 1 opened.
> Mek seeding partitioned by lance via new exported, unit-tested
> `lanceOfPilot`/`lanceOfMek` that answer for BOTH campaigns. Measured on
> the 15-pilot midgame save: Lance A's workshop went from 15 Meks to 5,
> with 5 and 5 in the new rooms, zero misfiled.

**This resolves an open question that's been sitting since 26 Aug.** `Bloom_Wars_Mek_Workshop_And_Weapon_Progression_v1.md` §6 listed "Workshop granularity — one per lance (proposed) or one per pilot-mek pair. Needs a direct confirm." as its first open item. Confirmed today: one per lance. That doc's own §6 is updated to reflect this (see the note appended there).

**What exists today, for anchoring:** one physical Workshop room, seeded with every active pilot's Mek (since Tier 3 shipped, that means all of them, not just the 5 Act I ones), plus the separate Carrier Upgrade Modules bench that shipped 2 Sep. Per decision 1 above, that bench isn't being cloned — it stays exactly where it is.

**What ships in this phase:**
- Two new physical rooms, **Lance B Workshop** and **Lance C Workshop**, each gated on that lance actually existing — Second Lance integrates at Mission 12, Third at Mission 24, exactly the beats `integrateSecondLance()`/`integrateThirdLance()` already fire on. A room for a lance that doesn't exist yet has nothing to put in it.
- The existing Workshop room becomes, in effect, Lance A's — no rename needed necessarily (worth a naming pass once this is real, not decided here), just the first of three instead of the only one.
- Each new room is seeded the same way the existing one already is — reusing Tier 3's own roster-driven seeding logic, just partitioned by which static lance batch a pilot belongs to (`WARDEN_PILOTS` / `SECOND_LANCE_PILOTS` / `THIRD_LANCE_PILOTS`). This is the same grouping the Hangar roster/stats panel already leans on for its own lance tabs — not a new concept, a second consumer of one that already exists.
- Needs the physical space Phase 1 creates. This is a real dependency, not just a nice sequencing note: Upper and Lower are on record as tiled wall-to-wall with their existing rooms as of the egg-hull pass, with only about 90px of slack added since. Two new rooms do not fit today without Phase 1 first.

> **One correction to the bullet above, made during the build:** partitioning
> by the three Warden lists alone would have silently misfiled every House
> Amaranth pilot — that campaign has two lances and no third. The shipped
> `lanceOfPilot`/`lanceOfMek` answer for both campaigns, live in
> `campaignState.ts` as exported pure functions, and are covered by 8 new
> unit tests including one asserting the five static rosters never overlap.

**Open question, flagged rather than assumed:** does building a new lance's Workshop cost anything, or does it just appear the moment that lance integrates, the same way the lance itself does (free, automatic)? Two real options:
- **Free and automatic**, mirroring `integrateSecondLance()`/`integrateThirdLance()` exactly — simplest, but makes the room feel like scenery rather than a real beat.
- **Built through the CO, same as the four reserved bays** (Sensor Array, Beacon Control, Generator, Restock Room) — the player asks for it in chat, it costs company points, possibly rank-gated. This is the recommendation: it reuses a mechanism that's already live and tested (`detectBuildRequest`, `handleBuildRequest`), and it turns "your lance just doubled in size" into an actual decision/moment rather than free scenery. Needs a placeholder cost, same "not sim-validated, just in scale with the other bay costs" footing those four shipped with.

> **ANSWERED, 3 Sep 2026 — shipped free and always present, against this
> doc's own recommendation.** The rooms exist from campaign start like every
> other room and populate when their lance integrates. Reasoning: gating the
> *fix for overcrowding* behind an optional chat request risks not fixing it
> at all for a player who never asks; the build economy is for ship upgrades
> that do something mechanical, and "where do these units stand" isn't that;
> and it needs no new persisted state, so no save migration into an EA window
> this feature isn't scheduled in. **The CO-built version is not foreclosed** —
> if the *beat* is what's wanted, it can be added on top later without
> undoing anything here.

## 3. Explicitly not part of this plan

- **Can a Mek be lost?** Still the single biggest open question from the original Mek Workshop doc, still untouched by this plan. Giving Meks a room and a face doesn't answer whether they can die — that's its own decision, unrelated to how many rooms they live in. *(Still open, 3 Sep.)*
- **Instant purchase vs. a real build queue** for the Carrier Upgrade Modules bench — orthogonal to this plan, since that bench isn't being touched. *(Still open.)*
- **The full continuous-scroll, no-more-stairs version of the carrier** — deliberately not this pass. Worth revisiting once the smaller version is in and lived with for a bit. *(Still parked — and now genuinely revisitable, since the smaller version is in.)*
- **New weapon/module content** from the rest of the original Mek Workshop doc (§3–§5) — untouched, still gated on its own open questions (status effects, the schematic/materiel cost split), not part of this ask. *(Still open.)*

## 4. Real open questions before this gets built

- **How much bigger, exactly?** "Enough to fit two more Workshop-sized rooms plus some slack" is a direction, not a number. Needs actual pixel budgeting against the live `Hub.ts` geometry before anyone writes code — this doc is written without device access this session, so every bound/coordinate above should be re-verified against the current file, not assumed from these notes, before implementation starts.
  > **Answered: 1650x1350**, pixel-budgeted against the live file (every
  > constant was re-verified against it first, as instructed). Roughly
  > double the old footprint. **Still a placeholder** — not derived from
  > playtest data, because none exists. Two constants,
  > `DECK_FLOOR_RIGHT`/`DECK_FLOOR_BOTTOM`, easy to change.
- **New-Workshop cost/gating**, per §2 above. → *Answered in §2's own note.*
- **Does the existing Workshop room get renamed** ("Lance A Workshop") or stay "Workshop" with the other two as "2nd/3rd Lance Workshop"? Cosmetic, but worth a real answer rather than a guess, same as every other naming call in this project.
  > **Answered: it keeps its name and its id.** Half of `Hub.ts` references
  > `workshop` by name, plus its bench, codex entries and chat keywords.
  > The new two are "2ND LANCE WORKSHOP" / "3RD LANCE WORKSHOP". Renaming
  > the shipped one is churn for a cosmetic gain.

## 5. Build order

Phase 1 before Phase 2 — the new rooms need the space Phase 1 creates. Tier 3 (roster population) needs no work at all; it's already shipped. **Phase 1 is now the active next build, per §6's update — starts alongside the campaign playtest pass.**

> **Done in that order, 3 Sep 2026, in one session.** The dependency was
> real: Phase 2's rooms sit entirely in floor that did not exist before
> Phase 1.

**Before writing code:** this session has no connected project folder right now, so nothing here has been checked against the live `Hub.ts` (currently 431 KB, per the Vault plan's own reading of the device file) since this doc was first drafted. Re-verify `LOWER_BOUNDS`/`UPPER_BOUNDS`/`GROTTO_ELLIPSE`/the Spar Room bounds, `clampToDeckFloor`, and the full list of fixed-position UI elements directly against the current file before touching anything — this project's own standing rule, and doubly true given how much has shipped into this exact file in the last few days (the Workshop bench, the hover tip, the Vault plinth all landed in `Hub.ts` since this plan was drafted).

> **Done, and it mattered.** Re-reading the live file rather than trusting
> these notes is what caught that the room-note text is world-space (it
> would have been wrongly pinned to the screen by a mechanical "pin
> everything" pass) and that `clampToDeckFloor` was already correctly
> deck-generic and needed no changes at all.

## 6. Timing — superseded, 2 Sep 2026

Originally flagged here: neither a scrollable Hub nor the Mek Workshop appears anywhere in `Bloom_Wars_EA_Launch_Plan_31Aug2026.md`'s 8-week schedule, and the 27 Aug Early Access Scope Triage put Mek Workshop explicitly in the "after EA, no rush" bucket — so this plan asked for a direct answer on whether it jumps the queue.

**Answered by events, not by a chat decision — Phase 1 specifically is happening now, during the campaign playtest pass, per §0's update above.** A deck that's actively too crowded to test comfortably is a real blocker on Week 1's own "full whole-system verification pass" goal, not a nice-to-have sitting outside it. Phase 1 (bigger decks, camera scroll) is reclassified as in-scope for the current push. **Phase 2 (per-lance Workshops) is not automatically pulled forward by this** — the overcrowding Maxime hit is a deck-space problem, which Phase 1 alone fixes; Phase 2 is still a separate, larger feature addition with its own open cost/gating question (§2) and its own naming-lock/content surface, and should get its own explicit go rather than riding in on Phase 1's coattails. Worth a direct check before starting Phase 2: still wanted in this window, or does it wait?

> **Phase 2 got its go, 3 Sep 2026:** Maxime, after Phase 1 landed —
> "keep going until the hub is completed. if there is ambiguity. you have
> the right to make call." Built on that authority, with every judgment
> call recorded above and in the build log addendum rather than folded in
> silently.

## 7. Docs to update once a decision is made

- `Bloom_Wars_Mek_Workshop_And_Weapon_Progression_v1.md` §6 — done today, see the resolution note added there.
- `Bloom_Wars_Antfarm_Grid_v1.md` — deck geometry/room-count sections will need a pass once Phase 1/2 are real. **← now owed: decks are 1650x1350 and the upper deck has 5 rooms, not 3.**
- `Bloom_Wars_EA_Launch_Plan_31Aug2026.md` — only if the answer to §6 is "build it now," since it isn't in the current 8-week schedule as written. **← now owed, since it was built now.**
- `Bloom_Wars_Master_Index.md` — once anything here actually ships, per this project's own standing practice. **← covered by `Bloom_Wars_Master_Index_Sync_Note_3Sep2026.md`.**
