# Bloom Wars — Weapon Branch Point System, Delivery v1

*27 Aug 2026. Companion to `Bloom_Wars_Weapon_Branch_Point_System_v1.md` (the plan) — this doc records what actually shipped to the real repo today against that plan, what was deliberately cut for this pass, and the two doc edits that plan's own §9 flagged as needed and that are still outstanding (GDD §6.4, Data Pack §12 — both live in `.docx` files this tool can't write to directly, so they're spelled out below for a manual edit).*

## 1. What shipped today, concretely

Five weapon branches, one flagship per class (Reeps gets two, to exercise the real "collect more than one, swap for free" mechanic end to end) — **numbers-only**, per your own scoping call ("your call. but anything we start we gotta finish today"). No new status-effect infrastructure (no stun, knockback, DoT, or attack-debuff) — every branch is a stat change, a targeting change, or a grant of an ability the engine already had built and unused.

| Branch | Class | Effect |
| --- | --- | --- |
| Impact Lance | Meeps | +15 ATK. No dodge-adjacent bonus — the committed alternative to Twinblades. |
| Grinder Claw | Tank | Self-heals 20% of damage *dealt* on a landed hit (not received; a dodge or miss heals nothing). |
| Missiles | Reeps | Grants `abil_missile` — the splash-damage, friendly-fire-capable ability built 26 Aug and never attached to an archetype until now (see `Bloom_Wars_Missile_Weapon_Live_Test_v1.md` for the live-engine A/B test this branch is built from). |
| Rail Lance | Reeps | Ignores 25% of a Tank-path defender's effective defense. Tank-only, primary hit only (not the counter) — sharpens Reeps-beats-Tank rather than a flat buff. |
| Rapid Response | Munti | Repair range extends from 1 tile to 2. Same name and effect as one of the four Support Branch options the plan doc's §4 proposed — realized as-is. |

Economy: personal-pool, permanent once bought, cost/tier-gate keyed by **purchase order** (1st branch 150pts/tier D, 2nd 220/C, 3rd 300/B, 4th 400/A — the plan's own §7 numbers, unchanged, still flagged there as placeholders pending a real economy sim harness). Equip is free and swappable pre-mission only, per the plan's Option B decision.

**Where it lives**, matching the plan's own §9 shape almost exactly:
- `data/weaponBranches.ts` (new) — the branch defs, costs, and tier gates.
- `data/types.ts` — `PilotRecord.ownedWeaponBranches` / `equippedWeaponBranch`.
- `engine/units.ts`, `engine/combat.ts`, `engine/mission.ts` — branch effects wired into unit creation, the attack resolver (Rail Lance), and the mission orchestrator (Grinder Claw heal, Rapid Response range).
- `engine/campaignEconomy.ts` — `purchaseWeaponBranch()` / `equipWeaponBranch()`, **one generic pair covering every class**, exactly the "not two near-duplicate functions" shape §9 called for — Rapid Response (Munti's support branch) runs through the identical function as Impact Lance (a weapon branch), keyed off the same per-path branch table, not a second copy.
- `scenes/shop/ShopPanel.ts` — a third button row per pilot card, buy/equip buttons per buildable branch.
- `scenes/TransporterPad.ts` — the equipped branch shown and clickable (cycles owned branches, pre-mission only) right on each pilot's squad card.

Verified before commit: `tsc --noEmit` clean, `eslint` clean across the whole repo, the full existing vitest suite (931 tests) green, `npm run sim` still completes a full mission with no crash, plus a dedicated sandbox check exercising all five branches' actual combat/economy behavior (attack bonus, ability grant, defense-ignore, heal-on-hit, repair range, purchase/tier gating, equip/unequip cycling) — 22/22 passed.

**Update, 28 Aug 2026 (unattended overnight pass) — Rapid Response's own numbers above are now stale.** Maxime asked for more Munti heal range campaign-wide ("give more range to munty heal," resolved as "Base range, everyone (1→3)"); the free baseline moved from 1 tile to 3, and Rapid Response was re-derived alongside it (`DEFAULT_REPAIR_RANGE + 1`) so the paid branch stays a real upgrade rather than becoming worse than free — it now extends to **4 tiles**, not 2. The table row above is left as-shipped-27-Aug for the historical record rather than silently rewritten; current numbers and full reasoning live in `claude/build_log/README.md`'s "Still open" list and `claude/build_log/engine_systems/player_ai_engine.md`. Same night's pass also found and fixed a real bug this original delivery shipped: the range constant existed but two functions (`engine/mission.ts`'s `getRepairableFrom`, this module's own repair-target search in `sim/playerAi/support.ts`) were hardcoded to adjacent-only regardless of it — meaning Rapid Response's extra tile was never actually reachable by a real player or the test AI from day one. Fixed in the same pass as the range bump.

## 2. What this pass deliberately did NOT build

Everything below is real, named content from the plan doc that this pass intentionally left out — not forgotten, scoped out for today's "finish it" build:

- **The other three options per class.** The plan's §2/§3 calls for 4 branch options per class (so a pilot can eventually own all 4, one per tier gate D/C/B/A). This pass shipped exactly 1 per class (2 for Reeps). Shock Claws, Grinder Claw's siblings, Maser Lance, Suppression Autocannon, and Munti's other three Support options (Combat Medic, Field Doctor, Aegis Ward) are all still just names in the plan doc — every one of them needs a status-effect pass first (stun, DoT, a heal-over-time tick, an aura buff), which is real engine work this pass didn't touch.
- **The conversion valve** (§5 — personal points → company points at a lossy rate). Not built. Every pilot's personal points still just sit there once they've bought everything available to them.
- **Modules** (§6 — the company-wide armory, Combat Stims/Reinforced Plating/Grapple Line/Smoke Charge/Signal Booster). Not built. A separate system from branches even in the plan (company pool vs. personal pool), and out of scope for today.
- **Nice-to-haves from §10** (a visual branch tree in the Codex, an ambient quip on equip, a sprite/portrait reskin per branch) — none built, none blocking.

## 3. Doc edits still outstanding (can't be made from here)

Both the GDD and the Data Pack are `.docx` uploads in the project, not text docs — this tool can read them but can't write to them. Per the project's own standing rule ("when a decision in chat changes something already written in the GDD, Data Pack, or Build Brief, say which doc needs updating"), here's the exact edit each one needs:

**GDD §6.4** currently reads: *"Debrief awards points. Points buy exactly three things, which is deliberately few,"* followed by a 3-row table (gear tier, spare mek part, mek secondary). Add a fourth row:

| Purchase | Cost | Effect |
| --- | --- | --- |
| Weapon branch, one pilot | 150 / 220 / 300 / 400 for the 1st–4th branch bought, gated at gear tier D / C / B / A respectively | Grants a class-specific weapon or support variant; only one branch is equipped per mission, swappable for free pre-mission once owned. |

...and change "exactly three things, which is deliberately few" to "exactly four things" (or drop the "deliberately few" framing — your call, per the plan doc's own §9 flag that this line is quoted almost verbatim elsewhere and can't be patched quietly).

**Data Pack §12** (the table Canon Pass §D.1 and the plan doc both point to as the home for cost rows) needs the same 150/220/300/400 cost row and the D/C/B/A tier-gate column added alongside the existing tier-upgrade and mek-secondary rows.

## 4. Status of the plan doc itself

`Bloom_Wars_Weapon_Branch_Point_System_v1.md`'s own §11 said "this is a design decided, not a feature built... none of it starts without a separate go-ahead." That go-ahead happened today. Its §9 code plan is now real, at the scope in §1/§2 above — the plan doc itself doesn't need editing (nothing in it turned out wrong), just this delivery note sitting next to it recording what of it shipped.
