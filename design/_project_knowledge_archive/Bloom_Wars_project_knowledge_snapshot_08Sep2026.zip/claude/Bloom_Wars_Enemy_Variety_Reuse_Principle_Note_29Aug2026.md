# Design note — reuse shown-once Bloom archetypes for variety instead of just raising spawn counts, 29 Aug 2026

**Not investigated further, not built. Tally only, per this session's standing instruction.**

Maxime, refining the "missions are too easy" thread rather than just repeating the double-the-spawn-count fix: "one thing i think we can add is more undertow in mission 4-9. reusing enemy we showed off once is good. any bloom shown should be reused. so maybe instead of making more same spwn. add variety."

**The general principle, worth keeping distinct from any one mission's fix:** once a Bloom archetype has been introduced to the player, it should keep showing up in later missions rather than being a one-off setpiece — variety (mixing in an enemy type the player's seen before but forgotten) as the harder-fix lever, instead of just more of whatever's already in the mission.

**Undertow.** Debuts Mission 4 (3 burrowed Undertow + 4 Crawlmass), reused Mission 19 (3 burrowed Undertow + 5 Crawlmass), Mission 21 (Heartwood + Undertow reinforcements), Mission 26 (Undertow ambush). Not actually a one-off at the whole-campaign level — just absent specifically across Missions 5-9, which is what Maxime's own ask was scoped to.

**Sporethrower.** Debuts Mission 7 (3 Sporethrower + 2 Crawlmass), reused once more at Mission 17 (1 Sporethrower, minor presence). Nothing confirmed after 17.

**Sirenmaw (the flying one).** Debuts and, as far as every search run this session found, appears exactly once — Mission 12 only (Act I's finale wave: "4 waves, Crawlmass→Sirenmaw"). No second appearance found anywhere in Act II or Act III's build logs. The Choir (Mission 8's mid-boss) is Sirenmaw-descended and shares its flight_membrane movement type, but it's a named boss encounter, not the same kind of reusable trash enemy.

**Gallcyst.** Reused three times as a fixed-turret set-piece — Mission 9 (2 fixed Gallcyst), Mission 14 (2 fixed Gallcyst pair), Mission 30 (2 fixed Gallcyst planted on road/spine intersections). Always the same "sessile strongpoint" role each time rather than a mobile threat — recurs in count, but arguably reads as one-note regardless.

**A genuinely useful find, surfaced by search rather than assumed: this exact concern was already raised once before, and only partly acted on.** The batch-2 build addendum (`Bloom_Wars_Amaranth_Act1_Build_Log_v1.md`) explicitly promised "I'll actively pull Undertow/Sporethrower back into rotation starting with batch 2" — then batch 2 shipped without doing it, was called out for that directly in the batch-3 addendum ("that was a promise made and not kept"), and batch 3 actually delivered on it: Sporethrower's Mission 17 return and Undertow's Mission 19 return are both explicitly framed as making good on that broken promise. What didn't happen: the same discipline was never extended to Sirenmaw, and wasn't kept up as an ongoing rule for every batch after — it reads as a one-time correction rather than a standing practice, which is exactly the gap Maxime's own principle ("any bloom shown should be reused") would close for good if it's actually adopted as a rule going forward rather than a one-off fix.

**Direct answer to "any other one only show up once?", as best as this session's own searches can confirm:** Sirenmaw is the clearest case — one appearance, Mission 12, nothing since. Sporethrower is close behind — two appearances total, nothing confirmed past Mission 17. Undertow and Gallcyst both get reused multiple times, just unevenly. **Caveat, stated plainly:** several Act II/III missions' enemy comps weren't individually confirmed this pass (some build-log entries just say "5-wave siege" or "staggered ambush waves" without naming archetypes) — this is the best answer available from what's actually been surfaced and searched today, not a guaranteed-complete campaign-wide audit. A real one would mean reading every one of the 36 individual mission build-log files directly, not just the three act-overview tables and a couple of targeted searches.

**How this relates to the earlier Mission 4/Mission 6 "double the spawn count" proposals:** not a contradiction, a refinement — this reads as Maxime preferring the variety approach over the blunt more-of-the-same approach as the better lever going forward, once he's had time to think past the first instinct. Worth weighing both together whenever mission balance actually gets revisited, rather than defaulting to whichever was said first.

## Planned next step — the real audit, not yet run

Maxime: "add plan to audit in the log." Recorded here as the concrete next action, not done yet:

1. Read all 36 individual mission build-log files directly (`build_log/act1/mission01_*.md` through `build_log/act3/mission36_*.md`), not just the three act-overview tables — those tables truncate several Act II/III entries down to wave counts with no archetype names, which is exactly the gap that made today's answer incomplete.
2. Build one real table, all 36 missions × every Bloom archetype (Crawlmass, Splitfang, Undertow, Sporethrower, Gallcyst, Sirenmaw, plus the named bosses Choir/Heartwood/Wellroot/Unnamed/Cradle kept in their own separate category rather than mixed in as "reusable trash," since they're a different design category from the six regular archetypes) — a real per-archetype appearance count and gap list, not spot-checked one archetype at a time as Maxime happens to ask.
3. Cross-check House Amaranth-only missions (6, 16, 20, 23, 24, 28, and others once confirmed) separately, since those have no Bloom presence at all by design and shouldn't be counted as "gaps" the way a Bloom-only mission's missing archetype would be.
4. Bring the finished table back before making any actual spawn-list edits — this is audit-then-decide, not audit-and-build-in-the-same-pass, consistent with this session's standing "tally only" rule.
