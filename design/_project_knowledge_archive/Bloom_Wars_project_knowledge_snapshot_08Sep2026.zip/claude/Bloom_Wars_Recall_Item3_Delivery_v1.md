# THE BLOOM WARS — Recall Item 3, expanded curated recall, shipped 28 Aug 2026

**Delivery note, same standalone-now/fold-in-later convention as the other same-day deliveries — not yet folded into `Bloom_Wars_Social_Sim_Roadmap_v1.md` #17/#18, `Antfarm_Realisation_Full_Scope_Plan_v1.md` §3, or `claude_Bloom_Wars_Master_Index.md`.**

**Update, same day:** all three slot types are now live — see "STAGE_MOMENT, closed" below. This doc originally shipped with STAGE_MOMENT held back; folding the follow-up in here rather than as a separate doc, since it's the direct continuation of the same spec.

## What shipped — all 3 pieces of the spec, in the end

Source: your `claude_Bloom_Wars_Recall_Item3_Decision_v1.md`. Section 2's decision (generative recall off the Phase 1 gate, into the Réalisation harness as a Phase 2 prototype) is a decision, not a build — nothing to construct there, just recorded as agreed. Section 3's "expanded curated recall" is the actual build.

**`{RIVAL}` and `{LOST}`, both real, both wired into the existing resolver.** `crewBanterSlots.ts`'s `SlotType`/`SlotContext`/`resolveSlotText` — the exact machinery from Roadmap #17 — now also handles these two. `{RIVAL}` mirrors Hub.ts's own `npcRivalLabel` exactly: `findWorstRival` plus the same `RIVAL_THRESHOLD` gate that function already uses, so a line only fires once a real rivalry exists (bond at or below -20) — deliberately no "just pick somebody" fallback the way `{SQUADMATE}` has one, since a friendly bond isn't a rival. `{LOST}` reads a fallen Munti's name straight off `CampaignState.pilots` (`status: "permanently_lost"` + path `"munti"`) — the same check `checkMuntiLoss()` already runs, so the roster itself is the tally, no new state needed.

**Two-fact lines, the mechanism, fully built and tested.** `SlottedLine` gained an optional `slotType2` — every one of the 39 existing entries leaves it unset and behaves exactly as before. When it's set, `resolveSlotText` fills both tokens and only returns something if BOTH resolve; either one missing falls back to the flat line, same all-or-nothing contract a single-slot miss already has.

**`{STAGE_MOMENT}`, closed — you picked option 3.** "highlight reel should date itself with calandar. down to the sec." That's a real, new persisted fact, not a display tweak, so here's exactly what it touches:

- `HubPilotSocialState` gets a new field, `stagePromotedAt?: Partial<Record<Stage, number>>` — epoch ms, keyed by the Stage reached, at most two entries ever (`blooded`, `command`; nothing promotes into green).
- It's written at the REAL event, not backfilled later — `campaignEconomy.ts`'s `purchaseTierUpgrade` now checks whether a purchase crosses a Stage boundary and stamps `Date.now()` the instant it does, once per Stage, never overwritten by a later purchase.
- The Highlights reel itself changed, not just its data: `renderHighlights` now merges the existing "First X" verb milestones with the new Stage-promotion milestones (`highlights.ts`'s new `buildStagePromotionMilestones`) into one chronological list, and that whole list now renders with a real calendar date/time down to the second (`calendarTimeLabel`, new) instead of the vague "3d ago" it used before. Scoped to the Highlights reel specifically — the separate History panel's own relative-time display is untouched, since that's not the panel you named.
- `{STAGE_MOMENT}` itself resolves to a short display name ("Blooded" or "Command," preferring the more recent if both are on record) for use in a spoken-dialogue template like "since I made {STAGE_MOMENT}" — the calendar precision lives in the reel's own display, not embedded in what an NPC says out loud, since "since I made Blooded on August 27th at 3:42:17 PM" doesn't read as a sentence a person would say.
- Only fires off a REAL recorded promotion — a pilot who started the campaign already at Blooded has nothing to recall here, since no live promotion event ever happened for them. This was worth getting right: the honest alternative (resolving off current Stage alone) would have silently claimed history that never occurred.

15 new tests across the three pieces (5 for the timestamp write itself — including that a same-Stage purchase writes nothing, and that two separate crossings both land without clobbering each other — plus coverage for `buildStagePromotionMilestones` and the `STAGE_MOMENT` resolver).

## What's still open

**No new flavor-text content — RIVAL/LOST/STAGE_MOMENT/two-fact still have nothing to fire on.** Same honest gap as CLASS/ROOM after Roadmap #17 shipped: the mechanism works end to end (unit-tested with synthetic lines), but `SLOTTED_LINES` itself is untouched — still 39 entries, none using the new slot types or `slotType2`. Every prior content batch (the original 39, and CLASS/ROOM's own "I'll have a batch done" follow-up) came from you, not from me deciding what a pilot should say — didn't want to guess at that here either. Whenever you've got lines, they drop straight into `SLOTTED_LINES`'s existing shape, `slotType2` added for a two-fact entry — no resolver changes needed either way.

## Verification

`tsc --noEmit`, `eslint .` + spoiler lint (skipped, no `BW_RESERVED_TERM` in this sandbox, same as every prior pass), `npx vitest run` (51 files / 1072 tests, up from 1046 across both passes — 20 for RIVAL/LOST/two-fact, 15 for the STAGE_MOMENT follow-up), `npm run build`, `npm run sim`, `npm run sim:social` — all clean at each stage. Committed to your device, zero conflicts across both passes: `data/crewBanterSlots.ts`, `data/__tests__/crewBanterSlots.test.ts`, `data/highlights.ts`, `data/__tests__/highlights.test.ts`, `engine/campaignEconomy.ts`, `engine/__tests__/campaignEconomy.test.ts`, `engine/campaignState.ts`, `scenes/Hub.ts`.

## Open, for you

1. Want RIVAL/LOST/STAGE_MOMENT/two-fact content written by you (same pattern as the original 39 and the CLASS/ROOM wishlist), or should I draft a first batch for your review?
2. Section 2's Phase 2 harness placement (generative recall prototyping) — anything to build there now, or just noting the decision for whenever that harness gets picked back up?
3. Worth a quick look at the Highlights reel in-game — the calendar format is `YYYY-MM-DD HH:MM:SS`, plain and locale-independent rather than a prettier "Aug 27, 2026" style. Fine as-is, or want it dressed up?
