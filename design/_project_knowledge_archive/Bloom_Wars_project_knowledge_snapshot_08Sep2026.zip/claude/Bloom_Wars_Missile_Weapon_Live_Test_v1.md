# Bloom Wars — abil_missile Live-Engine Test, v1

*Test run 27 Aug 2026, in a cloud sandbox copy of the repo — nothing was written back to the real project folder, per instruction. Not touching combat_sim.py, which Maxime is updating separately.*

## What this actually tested

Not the Weapon Branch Point System or Frame Systems Layer docs — those are still pure design, unimplemented, and (per Maxime's own decision the same day) waiting on an economy sim harness before any of it gets built. This tested **abil_missile**, a real, already-shipped mechanic that turned out to be sitting in the engine unused: full targeting, splash damage, friendly-fire capability, per-unit charges, all implemented in `engine/mission.ts` on 26 Aug — but attached to zero archetypes or pilots. Its own code comment describes it in Maxime's own words as "a weapon path... like alternative g-a rank weapon upgrade," explicitly deferred: "we gonna build the upgrade path later." Nobody ever came back and gave it to anyone. Same shape as the Rourke rank bug this project already caught once — designed, built, never wired.

## Method

A sandbox-only test harness (not synced to the repo) that grants `abil_missile` to all three Reeps archetypes and runs the current 36-mission Amaranth campaign through the existing headless sim (`npm run sim`'s own engine, same player-AI bot, same hostile AI), with one addition: a Reeps with a charge left fires a splash shot only when it's guaranteed to hit 2+ hostiles and zero friendlies. That's deliberately conservative — it tests the weapon's combat value, not the bot's judgment. A separate forced test confirmed the friendly-fire path itself works: aimed a shot at an ally on purpose and it took 41 real damage, exactly as the code's own comments describe.

10 trials per mission per condition, 360 runs each (baseline vs. missile-enabled).

## Results

| | Baseline | Missile-enabled |
|---|---|---|
| Win rate | 200/360 (55.6%) | 223/360 (61.9%) |
| Losses | 14 | 9 |
| Commander-down | 146 | 126 |
| Permanent pilot losses (all runs) | 97 | 55 |
| Avg turns/mission | 10.44 | 12.76 |

1,134 missile shots fired across the run, 3,217 total hits, 397 kills, **zero friendly-fire incidents** (expected — the heuristic never chooses one).

## The honest part

Aggregate improvement is real and fairly large — permanent pilot losses roughly halved. But it's not uniform: about a third of missions showed a *lower* win rate with missile access than without, most consistently **Mission 24 (Two Fires)** and **Mission 32 (Hold at the Spire)** — both showed the same direction at two different trial counts (5 and 10), so this isn't just noise. Both are turn-limited missions (`eliminate_all` turnLimit 16, `protect_asset`). The likely mechanism, read from the code rather than guessed: `missileStrike` "costs this unit's entire remaining action budget" — a Reeps that fires loses its normal move-then-shoot kiting for that turn. On a mission where position and pace matter more than burst damage, that trade seems to cost more than it gives.

One more caveat worth stating plainly: the sim's own player-AI is a heuristic stand-in, not a real tactician — same caveat the Act I build log already gives Taunt. A human player choosing when to fire would very likely avoid exactly the situations where the bot's blanket "fire when safe" rule loses time it needed. Per-mission deltas at only 10 trials are noisy on their own (a 5-trial pass on Mission 26 showed 5/5→0/5; at 10 trials that same mission was a much smaller 9/10→7/10) — the pooled 360-run aggregate is the number worth trusting, not any single mission's row.

## What this means, not more than this

The mechanic itself is sound and correctly implemented — splash, charges, no-dodge-on-splash, friendly-fire-capable-but-counter-suppressed, all work exactly as designed. Giving it to Reeps is a real net positive across the current campaign on average, with a real, specific cost on a couple of turn/position-sensitive missions that's worth knowing about before anyone flips the switch for real. This doesn't validate or invalidate the Weapon Branch Point System or Frame Systems Layer docs — those are a different, much bigger, still-undecided ask.

## Not done in this pass

- Not wired into the real repo — sandbox only.
- No tier-gating tested (the actual doc's own plan gates a first weapon branch behind D-tier; this test ran it at G-tier baseline for everyone, which is a stricter/harder test, not the intended play state).
- No look at whether the bot could be taught to skip missile on turn-tight missions specifically — a real, buildable follow-up if this gets picked up for real.
