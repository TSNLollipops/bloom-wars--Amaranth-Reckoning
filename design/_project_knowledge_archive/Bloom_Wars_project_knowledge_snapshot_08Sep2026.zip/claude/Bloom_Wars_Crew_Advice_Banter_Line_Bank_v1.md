# THE BLOOM WARS — Crew Advice & Banter Line Bank v1

**Content pass only — zero code, when written.** Written 1 September 2026, continuing straight on from `Bloom_Wars_Crew_Greeting_Farewell_Line_Bank_v1.md` — Maxime asked if there were more of the same kind to knock out. There are: `Bloom_Wars_Chat_Keyword_Categories_Plan_v1.md`'s own recommended build order names **#4 Advice** and **#5 Banter/joke request** as the natural next batch after Greeting/Farewell, "similar in size to what farewell alone would need." Same catalyst-only scope call as the greeting/farewell bank — see that doc's own §0 for the reasoning, unchanged here.

**Update, 1 Sep 2026 (later the same day): wired into the real code and live-verified for routing correctness.** See §4 below — this bank is no longer content-only.

**Not touched, on purpose:** the same plan doc's #6 (Agreement/disagreement) and #7 (Insults toward a specific NPC) are both explicitly flagged there as needing their own design conversation before anything gets written — "a judgment call, not a sizing problem." Writing content for either without that conversation first would be exactly the kind of scope call this project's own rules ask to be flagged rather than made solo. Held, not built.

**Advice here is peer-to-peer crew advice, not the CO's.** `Bloom_Wars_CO_Bespoke_Dialogue_Bank_v1.md`'s Advice/Stress-relief section is a specific mentor-register response to elevated Stress, from one fixed character. This is different: any crew NPC's catalyst-flavored answer to an ordinary "got any advice?" ask, casual peer register, not gated on a Stress read. The two don't compete for the same trigger.

## 1. Advice — 4 lines per catalyst

**Wolf (teamwork):**
1. "Best advice I've got — don't try to do this alone. None of us do."
2. "Lean on the squad. That's what we're here for."
3. "Whatever it is, it's lighter split between more people."
4. "Ask for help before you need it, not after."

**Dog (loyalty):**
1. "Stick with the people who've already proven they've got you."
2. "Loyalty's not blind — it's just choosing who's earned it and staying with them."
3. "Whatever you decide, decide it for the people who'd do the same for you."
4. "Don't burn a bridge over a bad day. Bad days pass, bridges don't rebuild themselves."

**Cat (selfishness):**
1. "Look out for yourself first. Nobody else is going to do it for you."
2. "Ask what's actually in it for you before you say yes to anything."
3. "You don't owe everyone an explanation."
4. "Take care of your own business. Everyone else is taking care of theirs."

**Crow (indulgence):**
1. "Whatever's stressing you out, go do something that isn't that for a while."
2. "You're allowed to have fun even when things are bad. Especially then."
3. "Don't let this place turn you into someone who forgot how to enjoy anything."
4. "Go blow off some steam. The problem will still be there after."

**Raven (instruction):**
1. "Learn the lesson the first time so you don't have to learn it twice."
2. "Slow down and think it through before you act on it."
3. "Ask yourself what you'd tell someone else in your position."
4. "Every mistake's a lesson if you actually pay attention to it."

**Bear (isolation):**
1. "Sometimes the answer is just — don't. Walk away from it."
2. "You don't have to solve it today."
3. "Not everything needs company to get through."
4. "Give yourself space before you decide anything."

**Fox (trickery):**
1. "There's always more than one way through a problem. Find the sneaky one."
2. "Don't take the straight path if a clever one gets you there faster."
3. "The rules bend more than people think. Use that."
4. "If it's not working head-on, come at it sideways."

**Rabbit (nurturing):**
1. "Be gentle with yourself. You're doing better than you think."
2. "Make sure you're actually taking care of yourself, not just everyone else."
3. "It's okay to ask for help. That's not weakness."
4. "Whatever it is, you don't have to carry it alone."

**Shark (ambition):**
1. "Stop overthinking it and just move. Momentum solves more than planning does."
2. "Figure out what you actually want, then go get it."
3. "Don't wait for the perfect moment. It's not coming."
4. "Every setback's just a detour if you keep pushing."

## 2. Banter / joke request — 4 lines per catalyst

Per the plan doc's own note: strongest thematic fit is crow (indulgence — literally built around needing distraction), but every catalyst gets a real answer, not just a "not my thing" default, since a flat refusal from 8 of 9 catalysts would make this feel like it only half-shipped.

**Wolf (teamwork):**
1. "Why'd the squad cross the minefield? Because none of us wanted to go alone."
2. "You know what's funny? Two people trying to squeeze through one doorway at the same time. Every time."
3. "Best joke I know is 'solo mission.' Like that's a real thing that happens here."
4. "Does a group hug count as tactical positioning? Asking for a friend."

**Dog (loyalty):**
1. "I'd tell you a joke, but I already told it to you twice and you laughed both times, so I know it's good."
2. "Nothing's funnier than watching someone realize I remembered their birthday."
3. "Knock knock. ...You're supposed to say 'who's there.' See, this is why I like you — you never play along either."
4. "Funniest thing I've seen all week was you thinking you could sneak past me."

**Cat (selfishness):**
1. "You want a joke? Fine — you, thinking I have free jokes to give away."
2. "Here's one that's funny to me and probably not to you."
3. "I laugh at plenty of things. Most of them are other people's problems."
4. "Sure, I've got a joke. It's gonna cost you, though."

**Crow (indulgence):**
1. "Why did the Munti bring a toolkit to a party? Because every party's an emergency if you look hard enough."
2. "You ever laugh so hard at your own joke nobody else even needs to?"
3. "I've got about six jokes queued up and zero shame about any of them."
4. "Life's too short for bad jokes. Luckily, I only tell great ones. Allegedly."

**Raven (instruction):**
1. "Here's a joke with a lesson buried in it — see if you catch it."
2. "The funniest thing is watching someone learn the hard way what I already told them."
3. "I'll tell you a joke if you promise to remember the point of it."
4. "Humor's just a lesson that doesn't feel like one yet."

**Bear (isolation):**
1. "...I don't really do jokes."
2. "Fine. Two guys walk into a bar. I stayed home. The end."
3. "I laughed once. It was a good day."
4. "You want funny, go find Crow. I've got nothing."

**Fox (trickery):**
1. "Here's a joke — but I might be lying about the punchline."
2. "I'd tell you one, but I'd rather just let you walk into it."
3. "The best joke's the one you don't see coming. Watch yourself."
4. "Ask me for a joke and you might end up the punchline."

**Rabbit (nurturing):**
1. "Why did the little Bloom cross the road? Nobody knows, but I hope it made it safe."
2. "I mostly just like seeing you smile, joke or not."
3. "Here's a silly one, just for you."
4. "I'm not the funniest, but I'll always try if it means you laugh."

**Shark (ambition):**
1. "Fastest joke I've got — ready? Go."
2. "I don't really do jokes. I do results. But fine, here's one."
3. "You want funny? Watch me close this next objective."
4. "One joke, then back to work. Ready?"

## 3. Naming-lock safety check

No proper nouns invented anywhere in this bank — no places, no factions, no new characters. "Bloom" in Rabbit's joke is existing, already-shipped in-game vocabulary, not new. Nothing here echoes or abbreviates "The Synker Wars," and there's no new vocabulary to check against the absolute reserved term.

## 4. What this doesn't do — updated 1 Sep 2026, now wired and partially live-verified

**This bank is no longer content-only.** The same day it was written, `src/data/chatIntent.ts` gained a real `detectSmallTalk()` recognizer covering "any advice"/"tell me a joke" and the other trigger phrases from `Bloom_Wars_Chat_Keyword_Categories_Plan_v1.md`'s #4/#5, and `src/data/smallTalk.ts` (new) transcribed all 72 lines here verbatim, wired into `src/scenes/Hub.ts`'s `submitChat()`.

**Verified two ways, honestly reported.** Type-checked and syntax-checked clean before committing. Live-verified in Maxime's own running game that the *routing* works correctly: typing "any advice"/"tell me a joke" with nobody in single-target range correctly produced the existing "Nobody's close enough to talk to" broadcast fallback rather than a crash or mis-route — confirming the recognizer and the proximity-gating logic both fire as intended. **What wasn't reached in that same pass: the actual Advice/Banter line content itself**, since the crew NPC available at the time had wandered just out of single-target range before these two categories got tested (Greeting/Farewell were tested moments earlier, while she was still in range, and matched this bank's — well, the companion Greeting/Farewell bank's — text exactly). Trying this again with a crew NPC actually in range is the one thing still owed a direct check from Maxime's own play. Full account: `claude/Bloom_Wars_Master_Index.md`'s "Chat small-talk wiring" section.

Agreement/disagreement (#6) and rudeness-toward-a-specific-NPC (#7) are deliberately not touched here — both need a real scoping conversation with Maxime before any content gets written, not just implementation time.
