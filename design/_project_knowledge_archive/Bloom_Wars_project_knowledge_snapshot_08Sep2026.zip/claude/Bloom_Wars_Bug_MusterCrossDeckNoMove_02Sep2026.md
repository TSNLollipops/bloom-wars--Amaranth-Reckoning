# Bug report — muster doesn't complete a cross-deck move, found in live testing, 2 Sep 2026

**Reported by Maxime, in chat, during pre-full-campaign-playtest poking around:** "tried to use muster to make my ant move from the 3rd deck stack to the 1st lvl hangar. they replied, but didnt move." ("3rd deck" read as Upper — Lower → Grotto → Upper is the deck order — moving toward wherever the bay/muster point sits on Lower deck.)

## Why this isn't a total surprise

`Consolidated_Build_Plan_Progress.md`'s Tier 1 entry marks "muster not routing cross-deck" as fixed (**CODE-COMPLETE**, 31 Aug 2026, alongside three other Hub movement/door bugs), but that same entry says plainly: *"Still owed per the plan's own explicit call-out: a real Playwright walkthrough (Hub.ts has no unit test suite) — not yet done."* As far as this project's own records show, nobody has actually watched a cross-deck muster complete since that fix landed. This report may be the first real-world test of it, and it looks like it's still broken, or has regressed since.

## Symptom, as reported

- Player mustered an NPC currently on the Upper deck.
- The NPC acknowledged (replied) — the message/propagation half of muster is working.
- The NPC did not move — the pathing/movement half did not complete.

## Working hypothesis, not confirmed (no device access this session to check the actual code)

Muster's acknowledgment and its movement are two separate steps. A same-deck muster is a single walk to the bay; a cross-deck one (Upper → Lower) needs two stair hops (Upper → Grotto → Lower), reusing the same multi-hop door-chaining logic (`nextHopDoor` / `completeDoorHop`) the ordinary NPC-roaming "explore" system already needed real debugging to get right (see `Bloom_Wars_Walkable_Hub_Build_Plan_v1.md`'s own Bug A/B/C history on that same mechanism, for roaming rather than muster specifically). Most likely candidates for where this actually breaks, in rough order of suspicion:

1. The multi-hop route for a *mustered* NPC never resolves to a first-hop stair target at all (acknowledgment fires unconditionally on receiving the message, independent of whether a route exists) — would explain zero movement, not even a first step.
2. The `mustered` flag from the 27 Aug "stay at bay" fix (which deliberately stops `updateNpcRoaming` from re-targeting a mustered NPC once they arrive) is too broad and is also suppressing the *initial* walk-to-target logic for a mustered NPC, not just re-targeting after arrival.
3. The route resolves and the NPC takes the first hop correctly, but stalls at the first stair (fails to trigger the hop-to-next-deck completion) — would show partial movement rather than none.

## What actually happened — none of the above

Confirmed against the real code and fixed 2 Sep 2026. Full writeup: `Bloom_Wars_Build_Log_Addendum_MusterMekCoAckFix_02Sep2026.md`. Short version, since all three hypotheses above turned out wrong: the cross-deck hop-chaining logic was never broken — an independent simulation of `nextHopDoor` across all 64 room-pair combinations found zero failures. The NPC Maxime mustered was a Mek ("ant" in the Workshop, an Upper-deck room), and Meks have no `campaignState.pilots` entry, so `sendToMuster()` has silently no-op'd for them since the 31 Aug fix — correctly, that fix was real and Meks genuinely never get pulled into muster movement. What that fix missed: `broadcastMessage()`/`propagate()` still showed Meks (and the CO) the "aye, heading out" acknowledgment bubble unconditionally, before ever checking whether `sendToMuster` would do anything. Reply, then nothing, forever — exactly the reported symptom, and it reproduces on any deck, not just cross-deck. The Upper-deck detail was incidental to where that Mek happened to be standing.

Fix: `broadcastMessage()`/`propagate()` never call `sendToMuster` or relay for Meks/CO. Same-day follow-up, confirmed by Maxime: instead of the resulting dead silence, Meks/CO now get a real in-voice decline line (a Mek stays at the bench, the CO redirects with rank) — reacting without ever deploying.

## Status

**Fixed, committed, and verified live, 2 Sep 2026 — fully closed, no open items.** `tsc`, `eslint`, `vitest` (1599/1599), and `npm run build` all clean on both the original fix and the decline-line follow-up; mtime-drift checked before every commit. This one also got the real Playwright click-test the Tier 1 entry admitted it never had: `tools/verify/checkMusterMekAck.mjs` booted the actual game in a real headless browser, teleported the player next to a live Mek NPC, called the real `callMuster()`, and confirmed (after the follow-up) the Mek shows a real decline bubble ("Not my post, boss — my war's fought at the bench.") while its movement target stays byte-identical before/after and `mustered` stays `false` — while a real pilot in the same test gets the ordinary bubble, the `mustered` flag, and a genuine walk to the bay. Full account and numbers in the addendum doc above.

Relevant given the current EA Launch Plan is in Week 1 ("full whole-system verification pass") — this is exactly the kind of finding that pass is for, surfaced by real play rather than a scripted test.
