# THE BLOOM WARS — PvP Concept Note: Two-Front Attrition (SotS-structured)

**Brainstorm capture, 2 September 2026. Not a design, not a spec, not approved for build.** Written down from a live back-and-forth so the shape survives the conversation. Maxime flagged mid-explanation that he wasn't sure it was landing (*"unsure if it land correctly"*), so §1 is an explicit restatement for him to correct rather than a claim about what he meant. Everything in §3 onward is analysis and suggestion from this session, clearly separated from his own idea, and none of it should be read as settled.

**Read §5 before treating this as the whole picture.** This session initially treated the two-board SotS structure as new material from this week's conversation. It is not — `claude/Bloom_Wars_Spitball_Ideas.md` already has the same concept, in more developed form on some points (fleet scale, the SotS combat model itself, an existing mechs-damage-ships coupling), dated 25 and 28 Aug 2026. §5 reconciles the two. Read this note for the newer turn-mechanic decisions (simultaneous commit, the 3-turn retreat) and the Spitball doc for fleet-scale and combat-model context — neither document supersedes the other.

PvP is the **paid** tier and several releases out — see `claude/Bloom_Wars_Release_Ladder_And_Monetization_Note_02Sep2026.md`. Nothing here should be built before the 26 Oct EA launch, or before House Amaranth and the calendar teeth ship in the first free update.

## 1. The concept, as understood

Maxime's own fragments, in order, so the original phrasing is preserved:

> "i think a strategic battle like in sword of the stars would work best with what wr got for now."
>
> "sots structure. pvp is going to have two simultaneous battle. the ship fight and the mech fight. each player take turn moving one or the other while the other player turn one or the other in turn. unsure if it land correctly. ie. one on mech one on ships. then vs versa. after x number of turn. regroup and retry"
>
> "with loss compounding as the battle rage on"

Restated:

- **Two boards run at once** — a ship fight and a mech fight.
- **On your turn you act on one board only.** Your opponent independently acts on one board. Sometimes you meet on the same board and it's a contested exchange; sometimes you're on mechs while they're on ships and you each get a beat of unopposed progress.
- **After X turns the engagement breaks off** — survivors disengage, regroup, and the fight can resume. Directly SotS's own rule (verified: SotS runs 4-minute real-time combat rounds, and if no victor emerges the survivors pull back and a new strategic turn begins, so a battle can legitimately span several strategic turns).
- **Losses compound as the engagement drags on.** Each successive round of the fight is fought with what survived the last one.

## 2. Why the core mechanic is strong

The real subject of this design is **attention**. One commander, two fronts, and it is impossible to be in both places. Every turn is a question about where to spend the only action available.

Compounding attrition is what gives that question teeth, and it does so without any additional rule. The front you ignore is not merely failing to advance — it is bleeding, and bleeding worse the longer you look away. That is a much cleaner coupling than an explicitly authored cross-board effect (this session had suggested things like "lose the ships and your mechs lose restock and evac," which is still available and still thematically apt, but is no longer load-bearing).

## 3. Analysis and open problems — this session's, not Maxime's

### 3a. Compounding loss needs a real withdrawal option, and it is structural

Compounding loss is a positive feedback loop: fewer units, weaker position, heavier losses, weaker still. In PvP that shape produces the worst state a match can occupy — decided early but not yet *over*, so the losing player grinds through an outcome they can already see.

**The structure already contains its own exit valve, and that is the point of using SotS's shape.** Losing an engagement is not losing the war. A player pulls back, preserves what survived, and re-forms somewhere stronger. Compounding attrition then stops being a death spiral and becomes the central decision: *commit to another round and try to break them, or cut losses now and keep a force in being.* That is operational-warfare thinking and it is the good version of this idea.

The condition: **retreat must be genuinely viable and must not read as conceding.** If a player can be pinned into a fight they cannot leave, compounding loss removes agency rather than testing judgment. The retreat mechanic therefore wants designing at the same time as the attrition rules, not bolted on afterwards.

### 3a-i. Retreat costs three turns under fire — DECIDED 2 Sep 2026

Maxime: **"it take 3 turn to retreat. so player have to defend themself."**

Withdrawal is not instant. Committing to leave means three turns of holding on while disengaging — the fighting retreat, made a rule rather than a cutscene. This answers the §3a condition without defanging the attrition: retreat stays available, but choosing it is itself a gamble rather than an escape hatch.

**Three consequences follow that nobody had to author, which is generally the sign of a ruleset that works:**

- **Retreating on one board costs you the other board.** Three turns of defending a withdrawal on the mech front means three turns of attention not spent on the ships, which are compounding losses the whole time. A player cannot withdraw from both fronts at once without being defenceless on both. This is a tighter coupling between the two boards than any of the explicitly-authored options this session had proposed (orbital support, restock cutoff), and it arrives free.
- **The opponent gets a decision the moment a retreat is visible:** pile onto that board and punish the withdrawal, or ignore it and press the front that has just been abandoned. Both are correct in different situations, so spotting a retreat feeds the same central attention question rather than short-circuiting it.
- **"When do I break off" acquires a real cost curve.** Because losses compound, a late retreat is far more expensive than an early one — three turns of casualties at the end of a grind rather than near the start. Leave early and preserve a force while conceding ground; leave late and there may be no force left to preserve.

**Tuning note: 3 is only meaningful relative to X**, the engagement length before automatic disengagement (§1). At X=10 a retreat costs 30% of the fight; at X=5 the retreat *is* the fight. The ratio is the real number, and neither value is set.

**Open underneath this, and it bears directly on §3e:** a three-turn withdrawal implies a **rearguard** — someone covers it, and plausibly does not get out. If PvP ran on campaign pilots, choosing who holds the line while the rest withdraw would be among the most affecting decisions this game could ask a player to make, and among the most brutal. That single interaction is the strongest argument available for *either* answer to the pilots-vs-PvP-units question, depending on which way Maxime wants it to cut. Whether a partial retreat (pull some units, leave a rearguard) is even legal is itself undecided.

### 3b. The ship fight probably should not be a new combat system

There is no ship combat anywhere in this codebase. The carrier exists as fiction only (the Antfarm hub; the Carrier Upgrade Modules are still unbuilt, per `Debrief.ts`'s own header).

Suggested rather than assumed: build the ship fight as **the same grid engine with different unit archetypes and terrain**. `UNIT_ARCHETYPES` already exists; ships become another set of entries with their own movement, range and armor profile. "Two simultaneous battles" then means two instances of the existing battle engine with a thin coordinator above them routing each player's action to a board.

Two reasons beyond cost: it keeps both fronts speaking one rules language, which players have to learn only once; and it means every improvement to the tactical engine improves both boards at no extra cost.

### 3c. Simultaneous blind commit — DECIDED 2 Sep 2026

Maxime weighed two options and picked:

> "simultaneous. or turn based lock. you roll. and the game chose which side you start on. but I think simultaneous is good."

**Simultaneous blind commit it is.** Both players secretly choose a board, both reveal, both resolve.

The rejected alternative is worth recording along with why it was the weaker option, since the reasoning generalizes: if the game assigns each player's front by roll, the attention economy — the entire distinctive mechanic in §2 — disappears. There is no longer a decision about where to spend the only available action, just two boards taking turns. Blind commit keeps the decision and adds a bluff layer on top of it: you are guessing where your opponent is spending attention, and reading it correctly is the good feeling the mode would be built around.

Blind commit is also the *more* async-friendly of the two, since both players submit independently and the game resolves without either waiting on the other.

### 3c-i. The resolution-order problem, and where the roll actually belongs

Simultaneous commit creates one genuine problem that needs answering: **when both players commit to the same board, whose actions resolve first?** This is the classic simultaneous-turn trap — both fire, both would die, do both? Games built around true simultaneous resolution (Frozen Synapse and its lineage) construct the entire engine around plan-then-execute timing.

**This codebase is not built that way.** `engine/mission.ts` runs a single `this.turn` counter with strictly sequential resolution — the shape a PvE game with an alternating AI opponent needs. Retrofitting genuine simultaneous resolution into it would be a rework of the core battle loop, not an addition to it.

**Proposed resolution, and it costs almost nothing: make the CHOICE simultaneous, not the COMBAT.**

1. Both players secretly commit to a board.
2. Reveal.
3. Each board then resolves with normal sequential turns, exactly as the existing engine already does.
4. **When both players committed to the same board, roll for initiative** — who acts first.

This preserves the blind commit and the bluff (the part actually wanted), leaves `Battle.ts` and the turn structure untouched (the part that makes it buildable), and gives Maxime's own roll idea a home where randomness genuinely belongs — breaking a collision — rather than where it would have consumed the central decision.

It also produces a good dramatic beat: committing to the same board as your opponent becomes a gamble. You have both decided this is the front that matters, and initiative decides who lands first.

*Status: proposed this session, following directly from Maxime's decision above. Not separately confirmed by him.*

### 3d. Race or duel?

If both players consistently choose different boards, each is making unopposed progress and the match is a race to break through first. If they contest the same board, it is a duel. The design should know which it wants as its default texture, because it changes what winning feels like. Compounding attrition pushes toward duel (neglect is expensive), which is likely the right instinct, but it is worth being deliberate.

### 3e. Campaign pilots and permadeath — still unanswered

Raised twice in conversation, not yet resolved. Compounding attrition, plus permadeath, plus a human opponent actively working to bleed you, is savage. Entirely fine if intended and if PvP runs on its own units; very different if a bad match costs real people from a campaign roster. This is a story decision far more than a technical one — it determines whether losing a PvP match costs you someone you know.

### 3f. Balance tooling does not exist for this

Restating the standing gap from the release-ladder note, because this concept makes it sharper: `combat_sim.py` models AI-vs-AI on asymmetric PvE scenarios. It cannot validate two-board, two-human, compounding-attrition balance in its present form. This project's own rule is that a number or map counts only once it has run through the script and passed — purpose-built PvP maps do not remove that requirement. A PvP-capable sim mode is real, unbuilt work.

### 3g. Match length

SotS-shaped matches are long: many strategic turns, several containing battles, now with attrition carrying across them. Async turns that into weeks per match. Fine if the intent is a campaign fought against a person over time; wrong if the intent is a match finished in an evening. Local hotseat (the agreed first step, see the release-ladder note) will validate the *loop* cheaply but will say nothing about how a multi-week match actually feels.

## 4. What would need answering before any build

1. ~~Alternating or blind commit~~ — **decided: simultaneous blind commit** (§3c). Follow-on proposal for resolution order in §3c-i, not yet separately confirmed.
2. Campaign pilots and permadeath, or PvP-only units (§3e). **The largest remaining question, and a story call more than a technical one.**
3. ~~What withdrawal costs and how it works~~ — **decided: three turns under fire** (§3a-i). Still open underneath it: whether a partial retreat with a rearguard is legal, and the value of X that makes 3 meaningful.
4. Intended match length, which follows from 2-3 (§3g).

## 5. Reconciling with the older Spitball material — 2 Sep 2026

**This whole concept was already on record before tonight's conversation**, and this session initially missed it — Maxime caught the gap: *"this info should be in the folder somewhere. i talked about pvp once a week sgo i think."* Checked, and he was right. `claude/Bloom_Wars_Spitball_Ideas.md` already has, 25 Aug 2026, verbatim:

> "carrier co, legion co, company co. as rank, then sword of the stars style space battle with 3 carrier and escort and mech fighting, 2 layer the mech micro and the ship micro. gladriator during the war fight and gladiator after the war fight. expanded point system, heavy mech customisation. allow mech to hurt ships via landing on them if the mech reach a ship in time. stuff like that."

And, 28 Aug 2026, on fleet size specifically:

> "when we get to do pvp player will have up to 5 carrier."

So the two-board SotS structure, the ship/mech split, and the multi-carrier "company" framing are not new ideas from this week's conversation — they are the same standing concept, being returned to and refined. This session's own contribution this week is the specific turn mechanic on top of that standing shape: simultaneous blind board commit, compounding attrition, and the 3-turn contested retreat (§3a-i, §3c/§3c-i). Recorded here so the two documents don't drift apart from each other.

**What the older material adds that this week's conversation didn't have:**

- **"Up to 5 carriers," not a fixed 5.** Reads as a progression ceiling for the "company" a player builds, not a fixed match loadout — closer to "how big can your company get" than "every match is 5v5." Confirmed today, 2 Sep: *"player will make 'company' and fight each other over their carreer and gain up to 5 carrier under their command."* PvP is explicitly framed as a career/company mode now, not a one-off match type.
- **A real, still-unresolved collision with the strategic campaign's own rank ladder.** `Bloom_Wars_Rank_And_Command_v1.md` and the Spitball doc's own command-echelon ladder tops out at Carrier CO (1 carrier) → Legion CO (2 carriers, 10 lances, 8 escorts) → Company CO (many legions, open-ended). Five carriers is bigger than Legion but nowhere near "many legions" — it does not land on an existing rung. The standing (unconfirmed) read from 28 Aug: PvP fleet scale is probably independent of strategic-campaign rank, a match-balance number rather than a campaign milestone. Still not confirmed, and now more load-bearing than when it was first flagged, since PvP's own progression ("gain up to 5 carriers") makes this a second ladder that needs to either map onto the first or be explicitly declared separate.
- **SotS's real combat model is order-based, not direct unit control** — already checked against the source once (25 Aug): ships take facing orders (broadside/face-target/directional) and movement orders (close/pursue/stand off/retreat), armor is modeled as "bricks" that must be breached before hull damage lands, and critical hits disable specific systems or kill crew rather than draining a shared health bar. This is a materially different, and plausibly better-fitting, answer to the "how does the ship board actually work" question than this week's §3b suggestion (reuse the grid engine with ship-flavored `UNIT_ARCHETYPES`). It is also already justified in-fiction: the player is the Seal-holder, "the backseat commander half a galaxy away" (`Bloom_Wars_Independent_Campaign_The_Amaranth_Reckoning.md`), not a hands-on pilot — orders-not-micromanagement is the natural expression of who the player's character actually is at this scale, not just an engineering shortcut. §3b should be read as superseded by this, not as the settled answer.
- **A second cross-board coupling, already on record and not invented this week:** mechs can damage ships by physically reaching and landing on them in time. Flagged in the 25 Aug entry as "the sharpest new idea in that batch — the first real answer to how the ship layer and the mech layer actually interact mechanically rather than just running in parallel." This sits alongside compounding attrition (§2) as a second, complementary way the two boards affect each other, and is likely worth combining with it rather than choosing between them.
- **The existing turn-scale concern is still open and this week's mechanic doesn't resolve it.** The 25 Aug entry flags that a full company fight (up to ~20 pilots by Act III scale) risks tipping into RTS territory the moment both sides field that many units simultaneously — "a genuinely different engine problem... rather than a reskin of the existing one-party-vs-AI mission flow." The order-based SotS model is the entry's own proposed answer to this, which is a second reason to weight it over §3b's direct-control suggestion.

**Practical note for future sessions:** `Bloom_Wars_Spitball_Ideas.md` is the older, larger record of this concept and should be read alongside this note, not instead of it — this note has the newer turn-mechanic decisions (simultaneous commit, retreat cost) that the Spitball doc does not yet have, and the Spitball doc has fleet-scale and combat-model context this note did not originally have. Neither supersedes the other; they cover different halves of the same idea.

## 6. Naming-lock safety check

No proper nouns invented. Nothing here approaches the reserved book-series terms.
