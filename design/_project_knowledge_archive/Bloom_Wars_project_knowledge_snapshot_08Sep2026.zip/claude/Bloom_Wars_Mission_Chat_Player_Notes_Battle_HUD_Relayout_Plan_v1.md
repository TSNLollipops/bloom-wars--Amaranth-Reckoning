The Bloom Wars — Mission Chat, Player Notes, and the Battle HUD Relayout (Plan v1)

Written 4 September 2026. Plan only. Nothing here is built. Handoff target is Claude Code, which has the live repository; this document was written against the project docs, not against `Battle.ts` itself, and says so wherever that matters.

> **Verification note — added by Claude Code, 4 Sep 2026, same day, working directly against the live repo.** Facts 1a, 1b, and 1c below (§1) are answered. Short version, full detail in `Bloom_Wars_UI_Improvement_Plan_v1.md` Track 4:
>
> - **1a.** The plan's "assumed 45px tile" is wrong for the shipped game. `Battle.ts` (line 664) computes tile size per-mission: `tileSize = max(16, min(floor(700/mapWidth), floor(560/mapHeight)))`, board origin `(16, 60)`. No real map renders at 45px — the biggest maps already sit at 19–21px today, before any relayout.
> - **1b.** Checked all 72 live maps (`mapsAmaranth.ts`, `mapsHouseAmaranth.ts`) directly. Max width: **36 tiles** (`map_amaranth_falling_back_to_meridian`). Max height: **19 tiles** (`map_amaranth_tunnel_rats`). Different maps — §3c's own instruction to loop over real map definitions rather than hand-pick a worst case was the right call.
> - **1c.** No new data-layer flag needed. `data/types.ts` already defines `BloomArchetype` and `HostileMechArchetype` as two separate interfaces with different fields (perception/intelligence/movementType vs. path/tier) — a mission-chat router can gate on which archetype pool a hostile resolves against, rather than hardcoding a Bloom id list. Still worth confirming at implementation time that the *live* `Unit` instance on the board (not just the static archetype table) carries something that lets code tell the two pools apart at runtime — that's a five-minute check, not a design question.
>
> **One correction to §4a's own math, flagged because it changes the risk picture.** "684px for the board... roughly 34px tiles, down from 45" assumed the wrong current tile size. Recomputed against the real formula: Falling Back to Meridian renders at 19px under the *current* 700px-wide viewport and stays at 19px under the *proposed* 684px-wide one — the relayout's own width cut barely moves the number. Good news for feasibility (nothing in the game crosses the 16px `MIN_TILE` floor under the proposed layout, confirmed across all 72 maps). But it also means the six largest maps are already this small on the shipped build, independent of this plan entirely — worth Maxime's own eyes on those six maps before assuming the relayout is what would make them hard to read. Full table in the UI Improvement Plan, Track 1.

Maxime's ask, verbatim: "Allow player to add to their codex. Takes notes by typing :notes in the chat. Allow player to chat with their npc and the enemy npc during missions. Put the chat box to the roght of the map. Incrase size of the char box to fill the space available. Copy the chap box of the hub to the mission. Move briefing and mission log to the left side of the map."

Four asks. They are not the same size and they are not independent, so this document splits them into four workstreams in a build order where each one is shippable and verifiable on its own.

## 0. Decisions already locked, 4 Sep 2026

Asked directly in chat before this document was written:

1. Mission chat feeds the social sim. Stress, morale and favor move as a result of what the player types during a mission. Not flavor-only. Maxime explicitly declined a per-mission cap.
2. The Bloom never speak, and get no chat channel at all. Enemy chat is human-crewed hostiles only. In Warden Company that means House Amaranth mechs; in the House Amaranth campaign it means Warden Company.
3. Player notes are global, tagged with the save. They survive permadeath and campaign loss, because they are the player's knowledge, not the commander's. Each note carries which campaign, mission, day and turn it was written in.

### 0.1 Correction, 4 Sep 2026 (later the same day) — the Praise/Insult/Apology system was already built

The first draft of this document, and the chat message alongside it, told Maxime the Praise/Insult/Apology system was stalled on an open design fork and recommended shipping mission chat without favor until that fork got resolved. That was wrong. The system shipped on 2 September 2026, live-verified — `claude_Bloom_Wars_Build_Log_Addendum_CrewInteractionsBrainstorm_02Sep2026.md`. Doc drift on this session's part, not caught before the first draft went out.

What actually shipped resolves §3a as a third shape, neither of the proposal doc's own two options: Insults 1 and 2 are ordinary Favorability damage, repairable by Apology at any point. Insult 6, if Favorability is still below a real floor when it lands, flips a permanent standoff (`refusesDeployment`) that Apology can no longer touch — the only way out is asking the CO, in person, to remove that pilot from the ship for good. Recoverable early, forced-permanent once the standoff exists, always the player's own explicit choice rather than an automatic loss.

Asked to confirm the fork, Maxime's answer was "Both." That's exactly what's already built — not a pick between recoverable and permanent, a design where both are true depending on how far it's let go. There is nothing left to decide here. §5c below is rewritten against the real system instead of inventing a second one next to it.

## 1. Three facts Claude Code must confirm before writing a single coordinate

This is the honest blocker. This plan cannot specify exact rects without these, and guessing at them is how the action-bar harness lost an hour on 3 Sep by assuming a 960px canvas.

**1a. The current Battle map viewport rect and tile size.** Whatever constant `Battle.ts` uses for tile pixel size, and the rect the board is currently drawn into. Every number in Section 4 below is derived from an assumed 45px tile and must be recomputed against the real one. → **ANSWERED, see verification note above.**

**1b. The largest map in the game, both campaigns.** `maps.py`'s own validation output shows the four base maps at 18x12 and 20x12. `maps_amaranth.py` covers 36 more and its output was not available when this was written. The layout module in Section 3 needs the true maximum width and height, because that is what decides whether the shrunk viewport can still show a whole board or has to scroll. → **ANSWERED, see verification note above.**

**1c. Whether hostile units carry anything that distinguishes human-crewed from Bloom.** Decision 2 above needs a real field to test against. If hostiles are only distinguishable by archetype id, add an explicit flag at the data layer rather than hardcoding a list of Bloom ids in the chat router. Hardcoding it means the next Bloom archetype ever added silently gains a chat channel. → **ANSWERED, see verification note above.**

Do not start Workstream 2 until 1a and 1b are answered. Workstream 1 is unaffected and can start immediately. **Both are now answered — Workstream 2 is unblocked.**

## 2. Workstream 1 — the colon command namespace, and `:notes`

Ships first because it is independent, cheap, and Workstream 4 depends on the namespace existing.

### 2a. Why a colon namespace, and not another keyword bucket

`data/chatIntent.ts` currently detects intent by keyword across roughly five buckets with a hand-ordered precedence chain. That chain already has two documented real collisions that had to be resolved by hand: the word "mission" appearing inside a worry check-in phrase, and "worried" appearing inside a fear-bucket phrase. Every natural-language feature added makes the next collision more likely and harder to see coming.

A colon prefix is an escape hatch from that entire problem. A message beginning with `:` is a command, is parsed first, and never touches keyword matching.

```
:notes <text>       write a note, tagged with current context
:notes              open the Codex on the Field Notes tab
:help               list available commands
:t <name> <text>    targeted talk (Workstream 4 uses this)
```

An unknown command must return a clear error and stop. It must never fall through into keyword matching. A typo like `:notse hold the line` silently becoming small talk to the nearest pilot is the kind of bug that is infuriating and almost impossible to report.

`detectCommand()` goes in `chatIntent.ts`, checked before every existing bucket. It is pure and takes a string, so it is directly unit-testable, which none of the scene-level chat handling is.

### 2b. Storage

New module `src/data/playerNotes.ts`. Phaser-free and DOM-guarded, same discipline as `engine/displayScale.ts`, whose guards were proven real by the test suite rather than assumed (vitest's environment has no `document` or `localStorage`, so a missing guard fails the suite outright).

```ts
interface PlayerNote {
  id: string;              // creation timestamp plus a counter
  text: string;
  createdAt: number;       // epoch ms
  scene: "hub" | "battle";
  campaignId?: string;     // which save this was written in
  campaignLabel?: string;  // e.g. "Warden Company, Day 14"
  missionId?: string;
  missionName?: string;
  turn?: number;           // battle only
}
```

localStorage key: `bloomwars_notes_v1`. Deliberately not in `CampaignState`, per decision 3. Notes outlive the save that produced them.

`campaignId` probably does not exist yet. Check `CampaignState` for a stable identifier. If there isn't one, add `campaignId: string` set once at campaign creation. That is a save-schema addition, so it must load clean when absent from an older save. That pattern is already established twice in this project (`activeMissionAttempt`, `hasCheckedInWithCo`); follow it, and add the old-save test alongside.

### 2c. Caps, and why they are not optional

This is the first time the game stores arbitrary player-authored text, and it is worth being blunt about the failure mode.

localStorage is typically a 5MB quota shared across the entire origin, and the three manual save slots live in that same budget. A player who pastes a wall of text into `:notes` repeatedly is not just bloating their notebook, they are eating the space their own saves need, and a save that fails to write is a far worse bug than a note that fails to write.

- `MAX_NOTE_CHARS = 280`
- `MAX_NOTES = 200`
- A total-bytes guard checked before every write.

On hitting a cap, refuse the write and say so plainly. Do not silently evict the oldest note. Silent data loss on a feature whose entire purpose is remembering things is the worst possible behavior here.

Also cap the DOM input's own `maxlength` so the refusal is rare rather than routine.

### 2d. The Codex tab

`src/scenes/Codex.ts` gains a sixteenth category, Field Notes, showing notes newest first with their context tag, and grouped by campaign so a Warden save's notes and a House Amaranth save's notes do not interleave into nonsense.

It needs a delete. A note written with a typo, or written by a cat walking on a keyboard, is otherwise permanent. Delete-per-note, with confirmation.

Re-verify the category list at sixteen entries. `drawCategoryList()` was made to size its row spacing to the real category count on 4 Sep, capped at the original 50px, precisely because going from 9 to 15 categories pushed rows 11 to 14 off the bottom of the 640px canvas and made them genuinely unclickable. That fix should hold at 16. Confirm it with an actual click on the sixteenth row rather than by reading the code, because that bug was found by clicking and was invisible to review.

Naming lock note, checked and cleared. `:notes` lets a player type arbitrary text which is then stored and re-rendered. `lint-spoiler.mjs` checks source files, not runtime input, and that is correct: a player typing anything into their own notebook is not a content leak and nothing here ships that text. No new exposure. Recorded so nobody rediscovers the question later and panics.

### 2e. One idea worth stealing later, not built here

Once notes are save-tagged and queryable, the mission briefing panel can surface the player's own note from the last time they fought a given Bloom archetype, right there in the brief. That is close to free once this exists, and it turns a notebook into a real tactical tool. Filed as a follow-up, not scoped here.

## 3. Workstream 2 — `battleLayout.ts`

Foundation for Workstream 3. Nothing visible ships from this on its own, which is exactly why it is worth doing separately: it is the only part of the relayout that can be tested without a browser.

### 3a. The problem it solves

The canvas is a fixed 1074x640 logical coordinate space, and every scene places UI at hardcoded absolute positions. `Battle.ts` is roughly 122KB of hand-placed coordinates. The Display Size option shipped on 2 Sep scales the whole finished canvas like a projector; it does not give any scene more room.

So the layout is zero-sum. There is no "space available" for the chat box to fill. Every pixel it gains comes out of the board or out of another panel, and a hand-edited relayout of a file that size will produce collisions that only show up in a screenshot.

### 3b. Shape

New module `src/engine/battleLayout.ts`. Phaser-free and pure, following the precedent set by `engine/hubGeometry.ts` and `engine/hoverTipLayout.ts`, both of which were split out for the same stated reason: scene files import Phaser at module scope, which throws outside a browser, so anything living in a scene cannot be unit-tested.

```ts
interface BattleLayoutInput {
  canvasW: number; canvasH: number;
  mapW: number; mapH: number;      // in tiles
  leftOpen: boolean; rightOpen: boolean;
}

interface BattleLayoutResult {
  topHud: Rect;
  leftColumn: Rect | null;
  mapViewport: Rect;
  rightColumn: Rect | null;
  actionBar: Rect;
  tileSize: number;
  mapScrolls: boolean;   // true if the board cannot fit even at MIN_TILE
}
```

`tileSize = floor(min(viewportW / mapW, viewportH / mapH))`, clamped to `[MIN_TILE, MAX_TILE]`. If the clamp binds at `MIN_TILE`, `mapScrolls` comes back true and `Battle.ts` handles it the same way the Hub handles its own camera scroll.

### 3c. Tests, which are the whole point of the split

- Known map sizes produce known rects, asserted exactly.
- The map viewport never overflows the canvas at any combination of open and closed columns.
- Collapsing both columns returns `tileSize` to its full-board value.
- Column rects never overlap the map viewport or each other.
- `mapScrolls` is false for every real map in the game at the default open-column layout. This is the test that makes fact 1b load-bearing, so write it as a loop over the actual map definitions rather than over hand-picked sizes. **Confirmed by hand this session against all 72 maps: true at the proposed 684×560 open-column viewport, `MIN_TILE` never binds. Still write the test — this was checked once by hand, not proven as an invariant.**

## 4. Workstream 3 — the Battle HUD relayout

Blocked on facts 1a and 1b. ~~The numbers below are illustrative and derived from an assumed 45px current tile; recompute against the real constant.~~ **Facts confirmed; recompute this section's illustrative numbers against the real formula before implementation — see the verification note at the top of this document. The overall shape (left column / map / right column / action bar) is unaffected; only the specific pixel and tile-size figures below need redoing.**

### 4a. Target arrangement

```
+--------------------------------------------------------------+
|  top HUD: turn, sortie clock, objective, hold-zone status     |
+------------+-------------------------------------+-----------+
|  selected  |                                     |  chat log |
|  unit  OR  |            map viewport             |           |
|  briefing  |                                     |           |
|            |                                     |           |
|  mission   |                                     +-----------+
|  log       |                                     |  input    |
+------------+-------------------------------------+-----------+
|  action bar  1..6, paged                                      |
+--------------------------------------------------------------+
```

Illustrative budget: 160px left, 230px right, leaving 684px for the board. On a 20-wide map that is roughly 34px tiles, down from roughly 45px. A board about a quarter smaller in each dimension. **Superseded — see verification note. A 20-wide map (e.g. `map_amaranth_muster`, 20×12) is currently 35px under the shipped 700px-wide viewport, not 45px, and becomes 34px under this proposed 684px one — essentially unchanged, not a quarter smaller. The real, larger effect is on the biggest maps, which were already tight before this plan existed (see Track 1 of the UI Improvement Plan).**

230px on the right is chosen so it genuinely is a copy of the Hub's chat box, whose log sits from x=846 to the 1074 edge. Same width means the same font size and line-fitting behavior transfers rather than needing retuning.

What the player gains for the shrink: the Hub's chat log is 6 visible lines at 9px, described in its own build log as a tight fit chosen to avoid overflow rather than a design choice. A full-height 230px column gives roughly 25 lines at 12px. The mission chat box ends up substantially better than the Hub's, which is worth doing the Hub's own version over later.

### 4b. Where the selected-unit panel goes

Currently the right-hand HUD panel shows selected-unit info, and shows the mission briefing when nothing is selected. That is already a shared block doing double duty, so moving it wholesale into the left column's top block is a straight relocation, not a redesign. Keep the same either-or behavior.

The cursor-following hover tip built on 2 Sep is unaffected and stays where it is. Do not reintroduce a hover block into any panel; that duplication was deliberately removed and the `fitLines` contention it caused went with it.

### 4c. Collapsible columns

`[` toggles the left column, `]` toggles the right. `Battle.ts` recomputes from `battleLayout.ts` and redraws. Both closed gives the full-size board back for reading the whole field, which is the honest answer to wanting both a chat box and a tactical view.

Verify `[` and `]` are actually free before committing to them. `1` through `6`, `tab` and `esc` are taken.

### 4d. Screenshots are a required deliverable, not a nicety

The UI sweep's own general lesson, stated after `6LAST RITES` shipped and rendered as "BAST RITES" through 1965 passing tests: a whole class of bug in this game is only visible in a picture.

Required screenshots before commit:

- Fresh 5-pilot roster, smallest map.
- Full 16-pilot three-lance roster, largest map. This is the case that broke the Transporter Pad, and it broke only after the player had earned two more lances, which is the worst possible time to find out. **Use `map_amaranth_falling_back_to_meridian` (36×14) or `map_amaranth_tunnel_rats` (30×19) — confirmed the two real dimension-extremes this session.**
- Both columns collapsed.
- A chat log full to overflow with real-length lines, not placeholder short strings.

Run `sweepUi.mjs` and `auditUiText.mjs` over the Battle scene afterwards. Note honestly that both are text-geometry lints and say nothing about whether the screen is good.

## 5. Workstream 4 — mission chat

### 5a. Routing

Hub chat routes by `nearestNpcInRange`. Battle has no walkable proximity, so it needs a different rule:

- Default addressee is the currently selected friendly unit. This is the natural analogue and requires no new interaction.
- Nothing selected means a squad broadcast.
- `:t <name> <text>` targets by display name or callsign, friendly or hostile.

Reuse, don't rebuild. `extractNamedTarget(raw, candidates)` already exists in `chatIntent.ts` and solves exactly this matching problem for Hub's six verbs — case-insensitive, word-boundary-anchored, and rank-token-safe (a real bug shipped and got fixed here on 2 Sep: a bare rank fragment like "Spec." was matching before the fix filtered non-name tokens out entirely). Battle's `:t <name> <text>` should call this same function against the mission roster and visible hostiles, not reimplement name matching from scratch. `detectAddressee()` as a name does not exist in the repo and is not needed — what's actually missing is the selection-default and fog-of-war gating wrapped around the existing matcher, since Hub has no equivalent of either concept.

Fog of war applies to chat. A hostile can only be addressed if it is currently visible. Every AI tier except `LEGACY` was given honest fog of war on 1 Sep specifically because the old bot could shoot burrowed and concealed units no human can click. Letting the player taunt something they cannot see would reintroduce that same inconsistency from the other direction, and the restriction is free tension besides.

### 5b. Enemy chat, humans only

Per decision 2. Gate on the real data-layer flag from fact 1c, never on a hardcoded list of Bloom archetype ids. **`BloomArchetype` vs. `HostileMechArchetype` — see verification note.**

The Bloom get no channel at all. Not an eerie non-response, not a described behavior line. If a player targets a Bloom, the command fails with a plain message.

Effects on hostiles: none mechanically. There is no morale system on the enemy side and inventing one here would be a whole separate system. What is worth doing, and is cheap because the infrastructure exists, is logging what was said to which named human hostile and surfacing it post-mission as a hot topic. That connects mission chat to the gossip system and is the most interesting thread in this whole request. Flagged as a follow-up, not scoped here.

### 5c. Social sim effects — reuse the real system, don't build a second one

Per decision 1 and the correction in §0.1, mission chat routes through the existing six verbs — Gift, Praise, Insult, Apology, Congratulate, Send-Off. All of it already exists: `src/data/socialActions.ts` holds every constant and per-catalyst delta table, `src/data/verbs.ts` and `chatIntent.ts` hold the verb definitions and keyword buckets, and the full Tier 1/2/3 Insult ladder (`insultsGiven`, the `"insulted"` HotTopic, `refusesDeployment`, the CO call-out, CO-mediated removal) is live and tested. Favor moves, same as stress and morale. There is no fork left to work around.

The real work is architectural, not designed. The verb-resolution logic — `resolveChatTarget`, `extractNamedTarget`, and the six `handle*Request` methods — currently lives as private methods on `Hub.ts`. Battle needs the same logic and cannot import a scene file, for the same reason `hubGeometry.ts` and `hoverTipLayout.ts` exist as separate modules: scene files import Phaser at module scope, which throws outside a browser. This is the project's own reuse over rebuild principle applied directly: extract the verb-resolution core out of `Hub.ts` into a scene-agnostic module (`src/engine/socialVerbResolution.ts` or similar) that takes a `CampaignState`, a target NPC id, and a verb, and returns the mutated state plus the reaction line. `Hub.ts` and `Battle.ts` both call it; neither duplicates it.

Two pieces stay Hub-only on purpose — Battle should not try to reproduce them:

- The CO call-out fires the next time the CO is Talked to after a standoff begins. Battle has no CO to talk to mid-mission. A pilot who hits Tier 3 during a mission simply gets `refusesDeployment: true` right away, and the callout waits for the next Hub visit, exactly as it already does today.
- CO-mediated removal is explicitly a Hub, in-person, CO-proximity action per how it shipped. No Battle-side removal path. A refusing pilot already deployed finishes the mission they're in; the lock only affects future deployment.

One real mid-mission case worth naming for the content pass: if a Tier 3 standoff begins during a mission the refusing pilot is deployed in, that's a distinct beat — a squadmate who has, mechanically, decided they're done with the player, still standing next to them on the board for the rest of the fight. Worth its own colder, non-cooperative reaction line rather than reusing the ordinary Tier-1 insult line. This is a content note for §5f, not a code change — the mechanic already handles the state correctly.

Genuinely new, not reused: the built system has zero hostile-facing content — all six verbs are crew verbs. Decision 2 (no Bloom channel; human-crewed hostiles get one) is real new work regardless of any of the above: either new verbs or a new addressee class for the existing ones, new per-faction content, and a decision about what a hostile insult or taunt actually does mechanically, since there is no morale system on the enemy side to move. §5b's original scoping — no mechanical effect on a hostile, logged and surfaced later as a hot topic — still stands unchanged.

One addition beyond what was asked, flagged as such so it can be vetoed. Maxime explicitly declined a per-mission cap on chat, and this respects that: there is no limit on how much a player may type. But repeating the same intent at the same NPC in the same mission should be worth half the previous instance each time, floored at zero. That is not a cap on talking, it is a cap on repeating yourself, and without it "type the same compliment eleven times" is the dominant morale strategy in the game. Diminishing returns on repetition, uncapped conversation.

### 5d. The key-capture bug, which will happen if it is not handled deliberately

The Hub already hit this exact bug and its fix is on record. The scene's key-capture list was written out as three separate string literals in `create()`, `openChat()` and `closeChat()`, and they had already drifted. Adding `H` and `L` would have meant `create()` captured them, `openChat()` never released them, and both letters would have been `preventDefault`'d out of the chat input. Typing "hello" would have produced "ello".

Battle binds more keys than Hub did: `1` through `6`, `tab`, `esc`, plus whatever `[` and `]` become. Write one `battleCaptureKeys()` helper called from all three sites, exactly as `hubCaptureKeys()` did. There must be no way for the release list to disagree with the capture list.

Second, separate check: the Hub's chat input is a DOM element overlaid on the canvas, and the Display Size cap shipped after it. Confirm the Hub input still positions correctly at 100% and at Fill before copying the approach, rather than copying a bug into a second scene.

### 5e. Pacing

Chat must not block. The player types during their own turn or during the enemy turn without gating anything, and the enemy AI keeps animating. The 12-hour sortie clock is real-world time and is not a factor here.

### 5f. Content

This build wires the plumbing. It does not write most of the lines, but the crew side needs far less new content than the first draft of this doc assumed.

Already exists, reused as-is: Gift/Praise/Insult/Apology/Congratulate/Send-Off reaction lines, nine catalysts each, from `socialActions.ts`. Nothing new to write there.

New content needed: the Tier-3-mid-mission reaction line noted in §5c (nine catalysts, one line each, colder register — small); human-enemy taunt and reply banks for both campaigns' opposing casts (the real content job, unchanged from the first draft). Per the standing brief-before-writing pattern, a scoping brief comes first and lines are written only once direction is confirmed. Ship the plumbing against a small placeholder hostile bank so the system is verifiable, and treat the real hostile content as its own job.

## 6. Build order

1. Workstream 1 (colon namespace, `:notes`, Codex tab). Independent, shippable alone, and puts the namespace in place that Workstream 4 needs.
2. Workstream 2 (`battleLayout.ts`). ~~Blocked on facts 1a and 1b.~~ **Unblocked — see verification note.** No visible change.
3. Workstream 3 (the relayout). Screenshots required.
4. Workstream 4 (mission chat). Needs the right column from 3 and the namespace from 1.

Each step is verifiable without the steps after it existing, per the Build Brief's own §3 discipline.

## 7. Verification gate, every workstream

`tsc --noEmit`, `eslint`, `lint-cast-collision`, `vitest`, `vite build`, all clean.

`lint-spoiler.mjs` cannot run in a sandbox because it needs `BW_RESERVED_TERM` from the git-ignored `.env.local`. Run `npm run lint` locally once before this is considered done.

Workstream 3 additionally requires the four screenshots in §4d plus a Playwright pass. The harness already has a Battle-scene entry point in `checkActionBarPaging.mjs`, which boots a mission with `scene.start("Battle", {…})`, the same call `TransporterPad.ts` makes on BEAM DOWN. Reuse that path.

The trap already written into the harness README, restated because it will bite again: the logical coordinate space is 1074x640, not 960x600. Scaling a scene coordinate by `box.width / 960` puts a click roughly 110px off target, and because a miss on the canvas is a legal board click rather than an error, the script fails with a confusing "the button did nothing."

Commit with fresh mtime-drift checks on every pre-existing file. This project has documented cross-session collision history on the shared device repo.

## 8. Docs that need updating when this ships

- `Bloom_Wars_GDD_v0_2.docx` §3, the core gameplay loop. The battle HUD arrangement changes and a new player verb (talking during a mission) is added. Blocked on the same raw-`.docx`-access limitation as every other pending GDD edit, so it goes on the existing pending-edits list rather than being silently skipped.
- `Bloom_Wars_Data_Pack_v0_1.docx`, if the chat effect magnitudes in §5c end up as tunable numbers. Confirm the right section number against the live file rather than trusting this line.
- `claude_Bloom_Wars_Codex_Rebuild_And_Live_Briefing_Plan_v1.md` §8, which currently records the Codex as six lore categories plus the manual. Field Notes is a seventh kind and is player-authored, which nothing in that plan anticipated.
- `claude_Bloom_Wars_Forgotten_Plans_Audit_1Sep2026.md` — its Praise/Insult/Apology entry, if it still lists any part of that system as open; check it against the real build log rather than this doc's own first-draft error.
- `claude_Bloom_Wars_Master_Index.md`, a new section, and the READ THIS FIRST block if the relayout lands before Early Access.

## 9. Honestly still open

- ~~Facts 1a, 1b and 1c are unanswered. Sections 3 and 4 are unbuildable until 1a and 1b are.~~ **Resolved 4 Sep 2026, same day — see verification note at the top of this document. Section 4's illustrative numbers still need a pass to reflect the real formula, but nothing is blocked.**
- Whether 34px tiles actually read well is a question for Maxime's own eyes on his own monitor, not something to settle from arithmetic. The collapsible columns in §4c exist partly as insurance against the answer being no. **Reframed: the real question is whether 19–21px tiles on the game's six biggest maps read well — that's true today, independent of this plan. See the UI Improvement Plan, Track 1.**
- Whether the built social verbs currently allow targeting the CO himself, or are crew-only in practice — not stated either way in the 2 Sep build log. Confirm during the §5c extraction rather than assuming.
- The post-mission gossip hook in §5b is the most interesting idea in this document and is deliberately not scoped.
- No hostile-facing content exists. §5f is a real content job that has not been briefed. Crew-facing content is already done and reused.
