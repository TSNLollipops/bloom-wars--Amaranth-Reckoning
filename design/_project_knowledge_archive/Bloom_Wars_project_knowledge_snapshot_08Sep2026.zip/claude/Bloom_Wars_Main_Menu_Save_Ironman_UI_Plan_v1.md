# THE BLOOM WARS — Main Menu, Save Architecture, and Ironman Mode: Plan v1

**Status: planning pass only — zero code touched.** Checked against the actual repo before writing any of this (not memory, not the design docs alone) — `Boot.ts`, `MapSelect.ts`, `main.ts`, `data/allCampaigns.ts`, and the save-related section of `engine/campaignState.ts` were all read fresh from Maxime's machine first. Everything below is grounded in what's actually there today, flagged where it's a proposal versus something already decided.

**Why this is its own doc, not folded into the House Amaranth Mission Plan.** This touches the whole game, Warden Company included — the greeting screen, the save system, and Ironman mode all live below the campaign layer, not inside it. The House Amaranth Mission Plan's §3d (save architecture) and §8 (mission-select wiring) both point here rather than duplicating this content.

## 1. What's actually there today — verified against the live repo

- **There is no title screen.** `main.ts` boots straight into `Boot`, which either shows a "RECALLED" notice (a mission timed out) or starts `MapSelect` directly. `MapSelect` is the first thing a player ever sees, and its own header ("engine test pass — pick a mission") is the scene's own code comment admitting it's a placeholder: *"a cheap, honest stand-in for 'pick which mission to test' — there's no campaign/shop layer wired up yet."* The screenshot is exactly what the code says it is.
- **One save, continuously overwritten.** `engine/campaignState.ts`: a single hardcoded key, `STORAGE_KEY = "bloomwars_campaign_state_v1"`. `saveCampaignState`/`loadCampaignState`/`clearCampaignState` all read/write that one key. No slots, no metadata, no "New Game" button wired to anything — `clearCampaignState()` exists as a function but nothing in any scene calls it. This already matches the Ironman shape almost exactly; it just isn't presented as a choice anywhere, because there's no screen to present it on.
- **No `ironman` field exists on `CampaignState` at all.** Nothing gates save/load behavior today because there's only one behavior.
- **`MapSelect` already has a dormant multi-campaign tab switcher, built on purpose for this moment.** Its own comment: the tab row "activates the moment `CAMPAIGNS.length > 1`... built and defused for exactly this future, not exercised until now." Today `CAMPAIGNS` holds three entries — Warden's own Act I/II/III — so the switcher is already live for act-to-act navigation. This is good news for House Amaranth: the *act-level* switcher pattern is proven and reusable. It is not, on its own, the right place for a Warden-vs-House-Amaranth choice — see §5.
- **No mission-order gating exists anywhere.** Every mission in the active campaign/act is selectable from a fresh save, by design, per `MapSelect`'s own comment ("nothing else in this campaign enforces mission order either"). Out of scope for this plan unless you want it added — flagging it because it's adjacent, not proposing to build it.

## 2. Proposed navigation flow

```
Boot (unchanged — still catches a timed-out mission on load)
  └─▶ MainMenu (NEW)
        ├─ CONTINUE ──────────▶ MapSelect (resumes the live save; hidden/greyed if none exists)
        ├─ NEW CAMPAIGN ─────▶ CampaignSetup (NEW) ─▶ MapSelect (fresh state, side + Ironman locked in)
        ├─ LOAD GAME ────────▶ LoadGame (NEW; only shows slots when the live campaign is non-Ironman)
        └─ OPTIONS ──────────▶ stub for now — see §7

MapSelect / Hangar / Hub / Debrief
  └─ a small "MENU" corner control (NEW, shared) opens a light overlay:
        SAVE  (only when the live campaign is non-Ironman — "Save As..." into a slot)
        OPTIONS
        RETURN TO MAIN MENU
```

Nothing about `Boot`'s recall-timeout job changes — it still runs first, still falls through to whatever comes next (now `MainMenu` instead of `MapSelect` directly).

## 3. `MainMenu.ts` — the actual greeting screen

**Visual direction — polished within the locked art constraint, not a new one.** Worth being explicit about this rather than let "like XCOM, polished" imply something this project has already ruled out: `Boot.ts`'s own comment states the rule plainly — *"No art pipeline for the placeholder pass (GDD §12.2) — everything is drawn with Phaser Graphics primitives."* That's still true here. "Polished" is achievable inside that constraint through composition, typography, and motion rather than illustrated art: a large, well-kerned title treatment (the existing monospace family every other scene already uses, just given real hierarchy and breathing room instead of a debug-sized header), a dark atmospheric backdrop built from Phaser Graphics primitives (a slow procedural motif — a faint hex-grid, drifting Bloom-tendril lines, or a subtle scanline sweep — all cheap, all vector, none of it sprite art), and confident button states (hover/press feedback, consistent with the hover states `MapSelect`'s own mission cards already have). If what's actually wanted is real illustrated art — a logo, a painted background — that's a different, bigger ask (an actual art pipeline decision) and worth naming as its own separate scope call rather than assumed into "polished."

**Buttons:**
- **CONTINUE** — calls `loadCampaignState()`; if it returns a state, goes to `MapSelect`. If null (first launch, or after a full reset), this button is hidden or greyed rather than shown as a dead click.
- **NEW CAMPAIGN** — goes to `CampaignSetup` (§4). If a live save already exists, this needs a real "this will start fresh — your current campaign stays saved unless you overwrite it" framing, not a silent overwrite; exact confirmation-dialog wording is a small detail worth getting right rather than guessing here.
- **LOAD GAME** — goes to `LoadGame` (§6). Hidden/greyed if the live campaign is Ironman (nothing to load — see §5) or if no manual slots exist yet.
- **OPTIONS** — stub. See §7 for why this is intentionally thin right now.

## 4. `CampaignSetup.ts` — the New Campaign screen, and where Ironman actually lives

This is the screen the Ironman decision already locked a location for, three days before this plan existed (`Bloom_Wars_Spitball_Ideas.md`, 25 Aug 2026): *"Ironman is a checkbox on the New Game/campaign-creation screen itself, presented once, locked in for that campaign — not something flipped later from a settings menu, not changeable mid-run."* This plan just gives that decision an actual screen to live on.

**Contents:**
- **Side select** — once House Amaranth exists, this is where "Warden Company" vs. "House Amaranth" gets chosen (see §5). Today, with only Warden Company built, this control either doesn't render at all or renders pre-selected with nothing to choose — cheap to leave the slot for it in the layout now rather than retrofit later.
- **Ironman checkbox** — **checked by default**, matching the already-locked framing that Ironman is the base/default experience, not an opt-in extra. Unchecking it is what turns on manual saves.
- **A one-line explanation of what the checkbox actually does**, in-fiction-adjacent but honest: something like *"IRONMAN: one save, no going back. Losses are permanent and so is everything that leads to them."* Worth writing for real once this gets built rather than placeholder copy — it's doing real expectation-setting work.
- **BEGIN CAMPAIGN** — creates a fresh `CampaignState` via the existing `createWardenCampaignState()` (or its House Amaranth equivalent, once it exists), sets the new `ironman` field from the checkbox, saves it under the live key, and starts `MapSelect`.

**The one thing worth saying plainly rather than overselling: this is an honor-system Ironman, the same as XCOM's own PC version is.** `CampaignState` lives in browser `localStorage` — a player who really wants to can open devtools, copy the JSON out before a bad mission and paste it back in after. Nothing about a browser game can prevent that the way a console's managed save system can. XCOM PC has exactly the same limitation and calls it Ironman anyway; the value is in making save-scumming inconvenient and against the stated rules of the mode, not in making it impossible. Worth having said once, here, rather than implying a guarantee the architecture can't actually make.

## 5. Where House Amaranth fits into this flow

The Mission Plan doc (§3d) already proposed a separate save-state module per campaign side, for the same "don't risk what's shipped" reasoning as the separate Hub scene. That decision and this plan's flow agree cleanly: **side selection happens once, on `CampaignSetup`, before Ironman and before anything else** — pick Warden Company or House Amaranth, then the rest of that screen (Ironman checkbox, BEGIN CAMPAIGN) applies to whichever side was picked, reading/writing that side's own state module and storage key. `MapSelect`'s existing act-tab switcher stays exactly as it is *within* a side (Warden's three acts, and eventually House Amaranth's three), rather than being stretched to also cover the side choice itself — those are two different axes (which war are you playing vs. which act of that war are you on) and conflating them into one tab row would make both harder to read.

Practically: a player can have a live Warden Company save and a live House Amaranth save at the same time, each with its own Ironman choice, neither able to touch the other's storage key. `MainMenu`'s CONTINUE button needs a small decision here too, once both sides exist — continue whichever was played most recently, or ask which side to continue. Flagging rather than picking; either is cheap once the underlying state is already separated by side.

## 6. Save-slot architecture — the technical shape

**Ironman campaigns: unchanged from today, exactly.** One continuously-overwriting key, autosaved at the same three points already in place (`TransporterPad`'s BEAM DOWN, `Debrief`, the Hangar shop on purchase). No manual save UI ever shown. `MainMenu`'s CONTINUE is the only way back in — there is no "load an earlier point," by design.

**Non-Ironman campaigns: the live key plus named manual slots.** Proposed shape, extending what's already there rather than replacing it:
- The existing `STORAGE_KEY` becomes the *live/continuing* state for that side — autosave keeps writing to it exactly as today, Ironman or not.
- A new, small set of manual slot keys (`bloomwars_manual_save_<n>_v1`, a handful — 3–5 is a reasonable start, easy to raise later) hold player-triggered snapshots: a straight copy of the live state's JSON, frozen at the moment "Save As..." is pressed, plus a little metadata (timestamp, current mission/act, maybe roster size) so `LoadGame` can show something more useful than a bare slot number.
- **Loading a slot overwrites the live key with that slot's contents** and returns to `MapSelect` — the natural "rewind" semantics a player expects from Load Game, not a branch/fork.
- `saveCampaignState`/`loadCampaignState`/`clearCampaignState` already take an optional injected storage for testing — the same shape extends cleanly to an optional *key* override for slot support, without needing to touch their existing call sites at the three autosave points at all. Small, additive, matches this codebase's own stated discipline (`campaignState.test.ts`'s existing "an old save missing a field loads clean" coverage) rather than a rework.

**Where "Save As..." actually appears in play.** Proposed: alongside the existing autosave points — a new button on the Hangar/shop screen and on Debrief, reusing the existing `makeShopButton`-style control rather than inventing a new button system. Deliberately **not** a mid-mission/mid-battle save — that's a materially harder problem (freezing and restoring live turn state, not just `CampaignState`) and this game's own permadeath/commander-down design doesn't really need it: a mission attempt already either resolves or gets voided (recalled/commander-down), so "save mid-fight" doesn't answer a real player need the way "save between missions" does. Flagging this as an explicit scope boundary for this pass rather than a silent omission.

**`CampaignState.ironman: boolean`** — new field, set once at `CampaignSetup`, read everywhere that needs to decide whether to show Save/Load UI at all. An old save from before this field existed needs a sane default on load — proposed: **treat a missing field as `true` (Ironman)**, since that's the actual behavior every existing save has had until now (one continuously-overwriting key, no alternative) — this keeps a pre-existing save's real behavior unchanged rather than quietly granting it a feature (manual saves) it was never actually built with.

## 7. `LoadGame.ts` and Options — brief, since both are mostly straightforward once §6 exists

**`LoadGame.ts`** — lists the manual slots for the currently-selected side (empty state: "no manual saves yet" rather than a blank screen), each showing whatever metadata `Save As...` captured. Selecting one loads it per §6's semantics and goes to `MapSelect`. Only reachable at all when the live campaign for that side is non-Ironman.

**Options — deliberately thin in this pass.** Checked what there'd actually be to put on it: no audio system exists anywhere in this codebase (Phaser Graphics primitives only, no sound files, nothing in the build log ever mentions one), so an audio-volume slider would be decorative. A real, useful first Options screen is closer to: a "reset tutorial hints" toggle (there's already a real, isolated flag for this — `hasSeenTutorial`/`markTutorialSeen()`, deliberately outside `CampaignState` per its own header comment) and maybe a text-size/UI-scale option if that's ever wanted. Proposing to build the *menu entry point* now (so `MainMenu` isn't missing an obviously-expected button) with genuinely minimal content inside it, rather than either skipping it or over-building settings nobody's asked for yet.

## 8. New content and tooling this plan implies

- **`src/scenes/MainMenu.ts`** — new scene, inserted into `main.ts`'s scene array and as `Boot`'s fall-through target instead of `MapSelect`.
- **`src/scenes/CampaignSetup.ts`** — new scene, the New Campaign / Ironman screen.
- **`src/scenes/LoadGame.ts`** — new scene, the manual-slot picker (non-Ironman only).
- **A shared "menu overlay" component** — the small in-play corner control (§2) reused across `MapSelect`/`Hangar`/`Hub`/`Debrief`, following this project's own "extract before duplicating" discipline (the same reasoning that produced `ShopPanel.ts` as a shared class instead of copy-pasted shop code across `Debrief.ts` and `Hangar.ts`).
- **`engine/campaignState.ts` changes** — a new `ironman: boolean` field on `CampaignState` (with the missing-field-defaults-to-`true` rule from §6), and a key-override parameter threaded through `saveCampaignState`/`loadCampaignState`/`clearCampaignState` for slot support.
- **No new engine/mission-side systems required** — this is entirely a menu/persistence-layer addition; nothing about `Battle.ts`, `mission.ts`, or any mission content changes.

## 9. Proposed batch order

1. **`CampaignState.ironman` field + the key-override plumbing in `campaignState.ts`.** Foundation everything else reads from; cheapest to get right first, same "before the blob gets bigger" reasoning the Spitball doc already flagged for this exact feature three days ago.
2. **`MainMenu.ts`**, wired as `Boot`'s new fall-through target. Buttons can go in before their destinations fully exist (CONTINUE and NEW CAMPAIGN can target a not-yet-built `CampaignSetup` stub briefly, or this step and the next can land together).
3. **`CampaignSetup.ts`** — side-select slot left in place but inert until House Amaranth exists (§5), Ironman checkbox wired live.
4. **`LoadGame.ts` + the manual "Save As..." buttons** on Hangar/Debrief.
5. **The shared in-play menu overlay** (§2/§8) across the four scenes that need it.
6. **Options**, minimal per §7.
7. **Full verification** — `tsc`/lint/`npm run test` (this touches shared save-load code, so the existing `campaignState.test.ts` coverage needs new cases for the ironman field's default and the slot key-override, not just a "still passes" check), `npm run build`, and — if a live-browser check is available that session — an actual click-through of the new flow, the way earlier UI passes in this project have verified themselves.

## 10. Open items — need Maxime's call before or during the build

- **Manual save-slot count** — proposed 3–5 to start. Easy to raise later; the key-override architecture doesn't care how many there are.
- **"Save As..." naming/metadata** — auto-named ("Slot 1", timestamped) or player-nameable? Proposed auto-named for a first pass, nameable is a cheap follow-on.
- **`MainMenu`'s CONTINUE once both campaign sides exist** (§5) — most-recently-played, or ask which side.
- **Exact Ironman explanation copy** on `CampaignSetup` — the line in §4 is a placeholder for the real thing.
- **Options screen scope** — confirmed thin (tutorial-hint reset, maybe UI scale) unless there's something specific wanted here.
- **The overwrite-confirmation wording** on NEW CAMPAIGN when a live save already exists.
