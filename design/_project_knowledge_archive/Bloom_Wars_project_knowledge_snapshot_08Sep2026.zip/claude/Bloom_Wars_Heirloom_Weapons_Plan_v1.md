# Bloom Wars — Heirloom Weapons Plan v1

*Written 28 Aug 2026, at Maxime's own request in chat — a fresh design pass on the Heirloom pool. Substantially revised 28-29 Aug 2026, same request thread, once Maxime corrected the whole premise of who actually wields a Heirloom (see §1 below) and then designed the recruitment system that follows from that correction, back-and-forth, over several rounds — ending with his own words, "no im done iterating," which is read here as: stop asking, write it all up. A proposal, not a lock, same status as the Frame Systems Layer doc: nothing here is built, nothing here has touched `combat_sim.py`, and none of it is PvP-balanced — that's explicitly deferred, per Maxime's own words ("they dont have to be pvp balanced, thats for later. just cool bullshit tech").*

**This doc directly answers, and settles for the first time, the open question `Bloom_Wars_Independent_Campaign_The_Amaranth_Reckoning.md` §9 has been carrying since 25 Aug 2026** — whether the Heirloom pool should be a 15-entry table (matching the corrected 3-lance roster) or stay a deliberately oversized 20-entry pool. Maxime's own answer, this session: neither — **10 total.** See §4 for what that does to the old table.

## 0. Scope flag, up front, per this project's own rule

This is a **bigger structural change than the existing Heirloom design**, not just new flavor text on the same shape, and it's worth being direct about that before the rest of this doc reads like it's already settled — twice over now, once for the original per-pilot-ability redesign, and a second time for the recruitment system layered on top of it this session:

- **Every Heirloom pilot now gets a named, unique signature mech**, not just a special attack bolted onto their ordinary frame. That's a new content type — ten named units with their own identity, distinct from the four path-based mechs and from the Frame Refits the Frame Systems Layer doc already proposed. No new art is needed to *start* (this project's whole art direction is still placeholder geometric shapes), but it's still ten new named things a player is meant to recognize and get attached to, which is real design and content weight even before a single pixel is drawn.
- **Each Heirloom now carries three independently-leveled abilities on individual recharge timers**, replacing the single shared 0–100 charge-meter model Severance/Requiem currently uses. That's a genuinely different resource model, not a bigger version of the old one — it needs its own UI (three ability icons with their own cooldown readouts, not one meter), its own per-pilot save state, and its own purchase flow in the shop screen.
- **This sits in real, acknowledged tension with the Frame Systems Layer proposal's own §9 "core systems,"** which Maxime already decided (27 Aug 2026) should stay deliberately small specifically *so it never gets confused with Severance*. §5 below proposes how the two fit together rather than collide.
- **New this session: eight of the ten Heirlooms now come with a named aristocrat pilot attached, recruited through a dedicated shortlist system that draws on a whole separate points economy (company points, not personal).** That's not a bigger version of the ability-rank system above — it's a third new content type on top of the first two: eight named characters with houses, personalities, and a hook each, plus a real recruitment UI (shortlist cards, a pick-3-of-8 campaign-long budget), plus a new S-tier sitting above the existing gear-tier ladder. Flagging this as its own real scope addition, not folded quietly into the two bullets above.

None of this needs to be decided before reading the rest of the doc — it's a planning pass, and it can sit as design content only for as long as the original 20-entry table did. Flagging it here so the size of the ask is visible before the details bury it.

## 1. The shared framework — two tracks, not one

**The premise this session corrected, first — worth stating plainly since it reshapes everything below.** The original framing of this doc treated all ten Heirlooms as the same kind of thing: reach A tier, survive a story beat, the weapon is yours, whichever of your own pilots happened to earn it. Maxime corrected that directly: *"in canon heirloom are specialised mech with specialised high class pilot. the are the aristorcrat mech."* A Heirloom, canonically, isn't a loose weapon any competent veteran can pick up — it comes bundled with its own owner, a specific high-class pilot the weapon was built for, and that pilot is themselves part of what the Heirloom is. That's a real, structural change to how the whole pool works, not a flavor note on top of the existing design.

That correction splits the ten Heirlooms into two tracks, not one:

**Track A — Aberrations (2 of 10): Requiem and The Stolen Seal.** Both of these are, on their own terms, *not* proper aristocrat-piloted Heirlooms — they're the exceptions that prove the rule, and Maxime confirmed both explicitly:
- **Requiem** — Bosk didn't inherit this weapon through any noble line, he stole or misused it (*"requiem is an aberation, its stealing the weapon of trav, no?"* — see §2a's own separate finding on the design-rationale citation this surfaced), and Bosk himself is explicitly **not** an aristocrat (*"borsk isnt aristocrat"*). Requiem needs no pilot content, no recruitment, no house — it's already, correctly, Bosk's-then-Rourke's, exactly as shipped.
- **The Stolen Seal** — captured goods, not issued gear. Warden Company's own meks spoof House Amaranth's command seal imperfectly rather than legitimately wielding it (§2 below). There's no proper pilot for it either, by the same logic — it's a weapon nobody in Warden Company actually has the bloodline or standing to hold, which is the entire point of its kit's own unreliability.

Neither of these two needs any of the recruitment machinery below. They stay exactly as originally designed in §2 and §3 — available through their own story beats (Requiem: Mission 12 onward, already shipped; The Stolen Seal: Mission 28, "Marrow's Reckoning"), no shortlist, no company-points cost, no aristocrat pilot to write.

**Track B — Proper Heirlooms (8 of 10): a matched aristocrat pilot for each.** The remaining eight — Widow's Ledger, The Iron Oath, Deadfall, The Last Word, Salt the Root, The Cutting Room, Cinder Line, Farsight's Reckoning — are the real thing: each one comes with a specialized, high-class pilot who is, in Maxime's own framing, **"the rich kid slumming it with the military to get familial honor."** Not a grunt who earned a prize through merit alone — a noble who needs Warden Company's uniform (and, implicitly, whatever glory or redemption the war offers) more than Warden Company needs them, at least at first. Every one of the eight below carries that same DNA, with its own specific spin on why this particular scion is out here at all. See §3 for the full eight, kit and pilot together.

### 1a. S-tier — a new rung above the gear-tier ladder

Maxime's own words, settling this directly: *"and herloom are s ranked."* Every proper Heirloom (and, narratively, the two aberrations too, even without recruitment content) sits at a new **S tier**, above the existing G→F→E→D→C→B→A ladder every other pilot climbs through gear progression. This is a real content/engineering flag, not just a label: **every doc and every source file this session actually checked only shows tiers up to A** — the GDD's own tier table, the Data Pack's cost curves, and everywhere else "A-tier" gets cited as the top of the ladder (including this doc's own original §1, before this revision). Nothing has been grepped against the live `src/` code yet to confirm there's no lingering "S" reference already half-built somewhere, or conversely to confirm nothing in the tier-gating logic would choke on a rank past A. **Worth a real check before this becomes code** — not a blocker for the design itself, which is settled, but a genuine "verify before you build" flag per this project's own standing discipline.

### 1b. Recruitment — the shortlist system

This is the new mechanism that actually gets a player one of the eight proper Heirlooms, replacing this doc's original "unlock condition: reach A tier, survive a beat, granted to whichever pilot wins it" framing for the eight (Requiem and The Stolen Seal keep their own separate story-beat unlocks, per §1 above).

**Cost: company points, not personal points.** This is a deliberate, explicit split from how weapon branches and gear tiers work — those spend from each pilot's own personal point pool. Recruiting an aristocrat spends from the shared, institutional company-points pool instead, the same bucket that funds Antfarm bay construction. Maxime's own words: *"company, for heirloom."* Mechanically, this reads as: a Heirloom pilot isn't something one veteran grinds toward individually, it's an investment Warden Company itself makes — recruiting nobility costs the whole outfit something, not just one pilot's own record.

**A pool of 8, a budget of 3.** The player can recruit **up to 3 total** aristocrat pilots across a full campaign playthrough, no matter how many of the eight get offered along the way — *"the mc only get to pick up to 3 heirloom pilot during campaign and field one at a time no matter what. so its less a population and more a pool."* This is deliberately scarce: 3 of 8 means most of a given playthrough's roster of aristocrats never gets picked up at all, which is the point — a real, felt choice between very different kits and hooks, not a checklist to complete.

**One Heirloom-class item fielded at a time, no matter what.** Same "one meter" rule Requiem's own kit has always carried, now stated as the umbrella rule for the whole pool: whichever single item is active — Requiem, The Stolen Seal, or whichever one of the player's own recruited aristocrats is currently fielded — that's the only Heirloom-grade thing on the field at once. This reading (that the single-slot rule covers all three sources uniformly, not just the eight aristocrats against each other) was proposed in chat as the natural unification of Requiem's already-shipped rule and the new pick-3 pool, and wasn't separately challenged — flagged here as the working assumption rather than a word-for-word confirmed line, worth a quick nod from Maxime the next time this doc comes up rather than treated as silently locked.

**Mechanism: a shortlist, shown as Codex-style cards.** When a shortlist event fires, the player sees a set of candidate aristocrats presented as cards — name plus weapon/kit specialty, in the same visual language `Bloom_Wars_Codex_Design_v1.md`'s already-planned "Personnel" category uses — and picks one. Maxime's own words: *"shortlist with specialty, you are given a codex info with anme and weapons and you pick one. you can pick up to 3 with points."* This gives the Personnel category a second real reason to exist beyond flavor browsing — it's now load-bearing UI for an actual gameplay decision, not just lore.

**Declined candidates aren't gone — they can resurface.** If a shortlist offer passes without the player picking that candidate, they aren't permanently lost; a later shortlist event can offer them again. Confirmed directly via a popup question, answer: **"Can resurface later."** This matters for how scarce the choice actually feels — passing on someone once isn't necessarily final, but nothing guarantees a second look either, since a resurfaced candidate is still competing against whoever else is on that later list, and by then the player may have already spent their 3 picks elsewhere.

**Shortlist offers begin at Act II and never before.** Confirmed directly, Maxime's own words: *"player can only get heirloom at act 2 and onward."* No aristocrat can be recruited during Act I under any circumstances — this keeps the early game clean of Heirloom-grade power and gives the aristocrats themselves a reason to only start showing up once Warden Company's own reputation is established enough to be worth a noble family's attention.

**Proposed pacing (not explicitly re-confirmed — flagged as the working spec, not a locked answer).** This doc's own already-existing story-beat machinery gives two obvious anchor points: `integrateSecondLance` (~Mission 13, the Act II threshold) and `integrateThirdLance` (~Mission 24-25, the Act III threshold) — the same two functions that already drive Rourke's own rank promotions (per `Bloom_Wars_Social_Sim_Roadmap_v1.md`'s #12 entry). The proposal on the table when this conversation ended was to tie shortlist windows to those two beats, possibly with a third, smaller check partway through Act III to give the player a real shot at all 3 picks before the campaign's final stretch. This was still being iterated on when Maxime said he was done — so it's written here as the current best-guess spec, explicitly flagged as the one piece of this whole design that never got a direct, final confirmation. Worth a quick "yes, that's right" or a correction the next time this doc comes up, rather than treated as equally locked to everything else in this section.

**What isn't decided: the actual company-points cost of a recruitment.** Everything above locks the *shape* of the mechanism; no number has been proposed for what a single recruitment actually costs in company points, or whether the three picks cost the same amount each or escalate. Left open — see the revised §6.

### 1c. What still applies once a pilot is recruited — the original ability-rank framework, carried forward

Once an aristocrat is actually recruited, the original per-Heirloom ability system this doc already specced (before this session's recruitment redesign) is the working assumption for how their kit grows — **this specific point was not re-discussed this session and should be treated as carried forward by default, not re-confirmed:**

**What recruitment itself grants:** the named signature frame and the first ability rank, free, the moment the aristocrat joins. The frame is flavor and identity, not a stat rewrite.

**Three ability slots, each independently rankable 1–5.** Rank 1 is free, granted at recruitment. Ranks 2 through 5 are bought with **personal points** — this is the one place the two point economies meet on the same Heirloom: company points get the pilot in the door, personal points grow their kit afterward, same pool gear tiers and weapon branches already draw from. Not every ability needs a dramatic rank 5 — "depend on what you pick" (Maxime's own phrase, from the original design pass) is read here as: some abilities are a clean, escalating numbers climb, and some gain a genuinely new clause only at rank 5. Both patterns are used in §3, called out per ability.

**Recharge, not a shared meter.** Each of the three abilities has its own cooldown, counted in turns, independent of the other two — closer to the shape Bloom Wars' own path abilities (Ambush, Interdict, Screen, Taunt) already use than to Severance's own single accruing meter.

**Cost economy for ability ranks — placeholder shape, unchanged from the original pass:**

| Rank | Cost | Cumulative |
|---|---|---|
| 1 | Free (unlock) | 0 |
| 2 | 250 | 250 |
| 3 | 400 | 650 |
| 4 | 600 | 1,250 |
| 5 | 850 | 2,100 |

Maxing all three abilities on one Heirloom: 6,300 personal points, on top of whatever company points it cost to recruit the pilot in the first place. **Not run through any sim.** Worth Maxime's own confirmation that this ability-rank layer is still meant to sit on top of recruitment exactly as before, since the recruitment redesign changes what "unlocking" a Heirloom even means.

### 1d. The hard rule, unchanged

Carried over, unchanged, from the Frame Systems Layer doc's own §9a:

> **No Heirloom ability besides Requiem's own signature line-attack may ignore the full-HP damage cap or hit friendlies unconditionally.** Both of those properties stay Requiem's alone.

This doc's own designs respect that throughout, aristocrats included. Several abilities in §3 are still dangerous to misuse — but none of them are *guaranteed* to hit an ally the way Requiem's line always does. That distinction stays deliberate: Requiem is the only thing in the game that doesn't ask your permission.

### 1e. Uniqueness

Unchanged in spirit, restated for the new structure: not one shared ultimate, ten distinct ones, and each Heirloom is a singular artifact. The real consequence of the pick-3-of-8 recruitment budget (§1b) replaces the old "not every A-tier veteran gets one" scarcity note — under the new system, scarcity comes from the campaign-long budget itself rather than from a race against other pilots reaching A tier. That's arguably a cleaner, more legible kind of scarcity: the player always knows exactly how many picks they have left and is choosing deliberately, rather than wondering whether they'll simply run out of eligible pilots.

## 2. The one Qiraki reuse — picked carefully, as asked, corrected 28 Aug 2026

**Corrected the same day this doc was written.** The first draft of this section treated Reqa's own Heirloom sword as an already-legitimate reuse — "already spent, so it's off the table here" — and built the rest of the doc on top of that assumption. Maxime caught it directly: *"we shouldnt be using reqa severance in this, its hers."* That's right, and it's a bigger finding than just this doc — see §2a below. **Reqa's sword is not being reused here at all, not even as a thing that already happened.** The one Qiraki reuse this doc actually spends is the one described below, and only that one.

Looking at what the Qiraki files specify at Heirloom-grade, one item stood out clearly: **the "Celestial Magi," Alina's family Heirloom (`Qiraki_Book7_Chapter_Outline_v40.md`)** — "bullshit even by Heirloom standards, upgraded across thousands of years to accumulate capability," restricted by blood to the main family line, and maintained (never operated) by someone outside that bloodline whose actual job is *archaeology* — working out what a given coupling or undocumented change was even for, before daring to touch it.

That's a genuinely different texture from Requiem's "one clean, terrible rule." It's a weapon nobody fully understands anymore, including the people who own it. That's the one being reused — not the name, not the family, just the shape of the idea — because it's the strongest available answer to "cool bullshit tech" that isn't just a bigger version of what Severance already does.

**The Bloom-Wars-native translation, no locked terms anywhere in it:** House Amaranth is already this campaign's own noble dynasty, already holds its own charter battlegroup, and Mission 28 ("Marrow's Reckoning") is already the exact beat where Colonel Marrow turns on Halcyon Amaranth mid-battle. That's a real, already-written mission with an empty hook in it for exactly this: **the Heirloom Warden Company captures there is House Amaranth's own command seal, weaponized generations ago and locked to Amaranth blood.** Warden Company's meks can't actually unlock it — they spoof it, imperfectly, which is why its kit (§3, below) is the one genuinely unpredictable entry in the pool rather than a clean, reliable kit like everything else, and why (per §1 above) it needs no proper pilot of its own — nobody in Warden Company actually has the standing to hold it legitimately. This also reuses "The Seal and the Sword," a concept this project's own docs already coined and already used once before to stand in for a redacted Qiraki term (`Bloom_Wars_Spitball_Ideas.md`) — so the naming is doubly safe, and doubly native.

### 2a. A real, pre-existing finding this correction surfaced — Severance's own design text quotes Reqa's sword directly

Checked rather than assumed once Maxime flagged the principle: **GDD §8.2 ("The Heirloom: Severance") already quotes Reqa's sword's own canon description almost verbatim** — "'Severs the bond of reality at the edge' reads mechanically as *ignore the buffer, go straight to the living thing*... it falls directly out of your own rune-tech derivation." This isn't something this session introduced — it's been sitting in the locked v0.1 GDD text since before this doc existed, and `Bloom_Wars_Canon_Pass_v1.docx`'s own cross-reference list explicitly names `Qiraki_Rune_Tech_Reference.md` as "the rune-tech reasoning behind Severance vs. Bloom Endurance," citing that same GDD §8 passage as standing, unchanged, canon-checked. So this is a two-document problem, not a one-line fix.

**What's actually being proposed here, and what isn't.** Severance's own numbers — the line shape, the 80 fixed damage, the friend-or-foe rule, ignoring the full-HP cap, the Collapse-check versus Bloom — are shipped, tested, sim-validated content, and nothing about Maxime's correction asks for those to change. A line-shaped ultimate that ignores defenses and ends a boss fight is a recognizable trope on its own footing (Advance Wars CO powers, XCOM's own late-game ultimates); it never actually needed Reqa's specific weapon to justify existing. What needs to go is the *sourcing* — the sentence that ties Severance's design reasoning to a real, named, story-load-bearing weapon belonging to a specific Qiraki character. That's a documentation-only fix, not a rebalance, and it's logged as a pending `.docx` edit in `claude/Bloom_Wars_Docx_Pending_Edits_Status_28Aug2026.md`, with replacement text ready to paste. **Worth Maxime's own confirmation, though, since it's a real fork:** is decoupling the *rationale* enough, or does he want Severance's actual mechanical identity reconsidered too, given how closely its battlefield rules (ignores armor/shields entirely, treats a "kill" as removing the target from the fight outright rather than a normal HP reduction) still track her weapon's own specified battlefield consequences even with the citation removed? That second option is a real rebalance — new numbers, a resim, updated tests — not a text edit, so it's flagged rather than assumed.

Also corrected: `claude/Bloom_Wars_Master_Index.md`'s own "Cross-project references" section listed "Rune Tech Reference" among the five Qiraki docs Bloom Wars draws from — removed, since the one design element it was ever cited for is exactly what's being retracted. See that doc's own changelog line for the dated note.

## 3. The ten Heirlooms

Eight proper, aristocrat-piloted Heirlooms (§1's Track B) plus two aberrations (Requiem, The Stolen Seal — §1's Track A, no pilot content needed for either). Best-fit distribution across the eight proper ones: Meeps 2, Tank 1, Reeps 2, Munti 1, flexible/"Any" 2 — worth a look before locking, see §6.

---

### 1. Requiem — Aberration, unchanged

*Founding — Bosk's, then Rourke's. Already built, already shipped, GDD §8 / Data Pack §11.5. Not an aristocrat-piloted Heirloom — see §1.*

Kept exactly as-is: the line attack, the shared 0–100 meter, friend-or-foe with no exception, ignores the full-HP cap, Collapse-checks the Bloom directly. This doc doesn't touch its mechanics. Whether it also gets retrofitted into the three-slot/rank shape later, or stays the one deliberate exception (the flagship *should* look different from the rest of the shelf), is an open question — see §6.

Frame flavor: the Anvil-line frame, after Bosk's own callsign.

---

### 2. The Stolen Seal — Aberration, the one Qiraki-inspired entry

*Captured, not issued. See §2 for the full derivation. Suggested unlock: Mission 28, "Marrow's Reckoning," on Marrow's own turn. Not an aristocrat-piloted Heirloom — see §1: nobody in Warden Company has the Amaranth bloodline or standing to hold this legitimately, which is the entire point.*

Frame flavor: an Amaranth command-frame, chassis unmistakably not Warden Company make, running a jury-rigged access spoof instead of a real key.

| Ability | Rank 1 | Escalation to Rank 5 | Recharge |
|---|---|---|---|
| **Borrowed Authority** | Next attack copies a random on-hit effect drawn from any Bloom archetype or House Amaranth unit fought this campaign. | Rank 5 lets the wielder reroll the draw once per use before committing. | Long (5 turns) |
| **Ledgerhall Static** | Jams one random enemy ability for 2 turns. | Rank 5: jams the target's *strongest available* ability specifically, no longer a pure random pick — the spoof has finally learned enough to be selective. | Medium (4 turns) |
| **Inherited Weight** | Passive — at mission start, roll a random DEF bonus (0 to +15) for the whole mission. | Rank 5 narrows the roll's floor (+8 to +15) — still random, never bad. | Passive, no recharge |

**The felt cost, as a kit:** every other Heirloom on this list is reliable. This one isn't, on purpose, and that's the whole point — a player who takes the Stolen Seal is choosing swing and spectacle over a dependable plan, which is a real, different kind of "cool bullshit tech" than a clean button.

---

### 3. Widow's Ledger — Meeps

*Kill-momentum. Concept carried forward from the existing 20-entry table.*

Frame flavor: stripped down, over-clocked, a frame built to spend itself fast.

**Pilot (draft): Corin Ashby-Voss, House Voss.** Obsessed with kill-count, literally — Corin measures worth in numbers, their own and everyone else's, a habit that reads as cold bookkeeping to squadmates who've never had to prove their value to a family that only counts wins. The rich-kid-slumming-it hook here is sharpest read straight: House Voss keeps score on everything, and Corin's own honor, at home, is a running tally. Warden Company is just the first place that tally has ever been life-or-death.

| Ability | Rank 1 | Escalation to Rank 5 | Recharge |
|---|---|---|---|
| **Ledger Entry** (signature) | Each kill this mission stacks +8% damage for the rest of the mission. | Rank 5: stacks cap raised, and the bonus also applies to move range past 3 stacks. | Passive, always on |
| **Closing Argument** | A guaranteed finishing strike against any target at or below 25% HP, any range within move. | Rank 5: threshold raised to 35%. | Medium (3 turns) |
| **Overextended** | Trade defense for one turn: 0 DEF, +40% ATK. | Rank 5: duration extended to 2 turns. | Short (2 turns) |

**The felt cost:** the frame runs hot by design — no passive downside bolted on, because the kit itself is already all-in. A Widow's Ledger pilot who doesn't keep killing is just a fragile Meeps.

---

### 4. The Iron Oath — Tank

*Bodyguard ultimate. Concept and name carried forward from the existing table.*

Frame flavor: the widest, slowest silhouette in the game — deliberately not fast, on purpose.

**Pilot (draft): Dame Perrine Castellan, House Castellan.** Raised from childhood specifically to shield her house's own name — the honor-guard-as-upbringing version of the rich-kid hook, where "slumming it" reads less like escape and more like the family's own doctrine finally getting a real target to stand in front of. The frame's own tankiest-in-the-game silhouette isn't incidental to her — it's the literal continuation of what she was built for.

| Ability | Rank 1 | Escalation to Rank 5 | Recharge |
|---|---|---|---|
| **Oathkeeper** (signature) | Cannot be reduced below 1 HP for 2 turns. All spared damage lands the instant it ends. | Rank 5: duration 3 turns; the deferred damage is halved on landing instead of full. | Long (5 turns) |
| **Iron Word** | Taunt in radius 2 — every hostile that can reach the wielder must target it this turn. | Rank 5: radius 3. | Medium (3 turns) |
| **Debt Paid** | Once triggered, redirect the next instance of ally damage within radius 1 onto the wielder instead. | Rank 5: radius 2. | Medium (4 turns) |

**The felt cost:** Oathkeeper doesn't erase damage, it postpones it — a player who doesn't plan for the bill is trading a bad turn now for a worse one later.

---

### 5. Deadfall — Reeps

*Assassin. Name and core idea carried forward from the existing table.*

Frame flavor: a long, low profile, built to never be found until it's already fired.

**Pilot (draft): Ilse Dunmoor, House Dunmoor.** Quiet by philosophy, not just by role — "unseen until the moment" is how House Dunmoor teaches every one of its own, and Ilse takes it further than most. The kit's own built-in downside (the reveal on use, never fully removed even at rank 5) mirrors something real about her family's own doctrine: it's a plan that works exactly until it doesn't, on a schedule nobody controls, which is a real, uncomfortable thing for a Dunmoor to have to sit with in the field rather than in theory.

| Ability | Rank 1 | Escalation to Rank 5 | Recharge |
|---|---|---|---|
| **Deadfall** (signature) | An unavoidable, uncounterable strike at ×2 damage, any range. Reveals the wielder's position to every enemy for the rest of the turn. | Rank 5: the reveal is delayed one full turn instead of immediate — one free shot at true stealth per use. | Long (5 turns) |
| **Vanish** | Removed from enemy targeting entirely for 1 turn. Cannot act while active. | Rank 5: duration 2 turns. | Medium (4 turns) |
| **Marked Round** | Next hit on this target grants all allies +15% damage against it for 2 turns. | Rank 5: +25%, duration 3 turns. | Short (2 turns) |

**The felt cost:** Deadfall's own reveal is real even at rank 5 — it's delayed, never removed. This pilot is always one bad turn away from being the most exposed unit on the board.

---

### 6. The Last Word — Munti

*Life and death. Name and core idea carried forward from the existing table.*

Frame flavor: visibly overbuilt on the repair bay, underbuilt everywhere else.

**Pilot (draft): Osric Ferrow, House Ferrow.** Self-sacrifice as performance — Osric grew up on House Ferrow's own branding (a house that markets itself on service, on giving everything for others) and believed it a little too literally, a little too young. The signature ability's own permanent, stacking cost (each use of The Last Word shortens his max HP for the rest of the campaign) reads as the literal price of taking his own family's slogan at face value, over and over, mission after mission.

| Ability | Rank 1 | Escalation to Rank 5 | Recharge |
|---|---|---|---|
| **The Last Word** (signature) | Fully restores one downed ally mid-mission, no spare part spent. Wielder's own max HP permanently reduced 10% for the rest of the campaign, each use. | Rank 5: the permanent cost drops to 5% per use — never removed entirely, only softened. | Long (once every 6 turns, campaign-wide max uses unbounded) |
| **Field Triage** | Repair two allies in radius 2 this turn instead of one. | Rank 5: radius 3. | Medium (3 turns) |
| **Last Rites** | A downed ally (not yet lost to permadeath) can act one final time this turn before resolving. | Rank 5: the ally also gets a full heal for that one action, then goes down again as normal. | Long (5 turns) |

**The felt cost:** the signature ability is the one place in this whole doc where a permanent, stacking, campaign-long cost survives untouched — using the biggest save in the game literally shortens this pilot's own life, a little, every time.

---

### 7. Salt the Root — Any, anti-Bloom specialist

*Concept carried forward from the existing table, expanded into a full kit.*

Frame flavor: matted, scarred, built from Bloom-derived salvage rather than clean Foundry parts — the campaign's own salvage-supply-line idea (Frame Systems Layer §7) made literal on one specific frame.

**Pilot (draft, revised this session): Thessaly Amaranth, House Amaranth — the House Amaranth black sheep.** A cousin of Halcyon Amaranth's, and the one aristocrat on this list whose own house is a real, load-bearing faction in the campaign rather than background flavor. Thessaly left home specifically to study the Bloom, a genuinely unglamorous, hands-dirty specialty by House Amaranth standards, and insists — often, maybe too often — that her house doesn't matter to her anymore. Mission 28 ("Marrow's Reckoning," the same beat that hands the player The Stolen Seal) is where Colonel Marrow turns on Halcyon Amaranth mid-battle — and it's the one moment in the whole campaign built to test that claim directly, whether or not the player has recruited her by then. (This replaces an earlier draft, "Thessaly Marchetti, House Marchetti" — reassigned to House Amaranth specifically so this hook could exist, confirmed via a direct popup question: **"Yes, assign it to one (Recommended)."**)

| Ability | Rank 1 | Escalation to Rank 5 | Recharge |
|---|---|---|---|
| **Root Salt** (signature) | ×1.6 damage against sessile/hive-type Bloom (Gallcyst-family, the Wellroot, the Unnamed). ×0.7 against everything else. | Rank 5: the penalty against non-sessile targets shrinks to ×0.85. | Passive, always on |
| **Scorched Ground** | Bloom mat under the target stops regrowing for 3 turns. | Rank 5: also stops spreading in radius 1 of the target. | Medium (4 turns) |
| **Vermin's Eye** | Reveals every Bloom unit on the map, burrowed or not, for 1 turn. | Rank 5: duration 2 turns. | Long (5 turns) |

**The felt cost:** a genuine glass cannon against exactly one category of enemy — this pilot is actively worse than baseline against House Amaranth or anything non-Bloom, not just situationally weaker. Worth noting the irony isn't lost, given who's piloting it: a Bloom specialist from the one house whose own soldiers she's mechanically worse against.

---

### 8. The Cutting Room — Meeps, Hiopi-flavored

*Concept and name carried forward from the existing table. Deliberately reuses the centauroid Charge signature trick, the same move the Frame Systems Layer doc's own "Ram Frame" refit already borrows for a Tank — here it's the genuine, native version.*

Frame flavor: built low and long for a centauroid gait, visibly wrong on a human pilot's frame if one ever tried to use it (worth a line of flavor text somewhere: this Heirloom doesn't transfer well outside Iyari's own chassis family).

**Pilot (draft): Vann Rethwick, House Rethwick, Hiopi.** Old Hiopi nobility — the one aristocrat on this list who isn't human, worth keeping deliberately, since it establishes on-screen that this campaign's aristocracy isn't a human-only institution. Vann genuinely resents "slumming it" with grunts, more openly than any of the other seven — not performed reluctance, real irritation — which paradoxically makes him the truest believer in the whole aristocrat-pilot system among the eight: he's not here despite the class gap, he's here because he still fundamentally believes it should matter, and is visibly annoyed that Warden Company mostly doesn't treat it like it does.

| Ability | Rank 1 | Escalation to Rank 5 | Recharge |
|---|---|---|---|
| **The Cutting Room** (signature) | Move through and strike every enemy in a straight line, ignoring terrain cost, ending adjacent to the last one hit. Full commitment — cannot be called off partway through. | Rank 5: damage no longer drops off against the 3rd+ target hit in the line (a real, un-flagged falloff exists at ranks 1–4, worth designing in explicitly so rank 5 has something real to remove). | Medium (4 turns) |
| **Momentum** | +2 move on the turn immediately following any Cutting Room use. | Rank 5: also grants +10% ATK that same turn. | Passive, triggered |
| **Sure Footing** | Immune to knockback and forced movement for 1 turn. | Rank 5: duration 2 turns. | Short (2 turns) |

**The felt cost:** the signature move is a full commitment with no abort — a misjudged line can charge this pilot straight into the middle of a fight it can't survive.

---

### 9. Cinder Line — Any, area denial

*Concept and name carried forward from the existing table.*

Frame flavor: built around a single oversized ordnance rack, everything else stripped to the minimum to carry it.

**Pilot (draft): Halden Kestrel, House Kestrel.** Willing to burn what his own house can't hold onto — a real, sharp-edged read on a family whose own grip on its holdings and standing is visibly slipping, and a son who's decided that if House Kestrel can't keep something, better it burns than passes to whoever's circling. That's a genuinely darker note than most of the other seven, worth holding onto rather than softening: Halden isn't slumming it for honor exactly, he's out here because scorched earth is a philosophy he's already applied to his own family's future once.

| Ability | Rank 1 | Escalation to Rank 5 | Recharge |
|---|---|---|---|
| **Cinder Line** (signature) | Sets a chosen line of tiles (up to 5) burning for 3 turns — 15 damage/turn to anything standing on it, hostile or friendly, no exception on the tiles themselves. | Rank 5: duration 4 turns, damage unchanged. | Long (5 turns) |
| **Firebreak** | Instantly extinguish one of the wielder's own active Cinder Lines. | Rank 5: extinguishing also deals the line's remaining total damage to every hostile currently standing on it, all at once. | Short (1 turn) |
| **Draft** | Allies moving through a friendly Cinder Line take no burn damage for 1 turn. | Rank 5: duration 2 turns. | Medium (3 turns) |

**Worth being precise about, given the hard rule in §1d:** the burning *tiles* don't check sides, same as bloom mat already doesn't — but this is an opt-in hazard the player places, not a guaranteed line through the whole squad the way Requiem's beam is. Firebreak and Draft both exist specifically to give the player tools to manage that risk, which Requiem deliberately offers none of. That's the real difference this kit is built around, not a loophole in the hard rule.

---

### 10. Farsight's Reckoning — Reeps, Osnian-flavored

*Name and core idea carried forward from the existing table, retargeted from a pure damage ultimate into a detection-and-precision kit — the natural second Reeps identity alongside Deadfall's assassin read, and a direct nod to Anand's own established role as "the squad's eyes against the Undertow."*

Frame flavor: sensor-heavy, visibly antenna-studded, the least armored silhouette in the pool.

**Pilot (draft): Reya Solenne, House Solenne, Osnian.** Quiet in a different register than Ilse Dunmoor's — Reya's version of honor runs on information rather than glory, watching and knowing rather than being seen doing something dramatic. That's a deliberately understated take on the "rich kid slumming it" hook: House Solenne's own idea of prestige was apparently never about the battlefield spectacle the other seven houses chase, which makes Reya's presence in Warden Company read as a quieter, more personal choice than most of the others' — nobody's expecting her to prove anything loudly, which may be exactly why she's here.

| Ability | Rank 1 | Escalation to Rank 5 | Recharge |
|---|---|---|---|
| **Farsight** (signature) | Reveals every hostile unit on the map, including burrowed, for 1 turn. | Rank 5: duration 2 turns. | Long (5 turns) |
| **Reckoning** | A guaranteed critical hit against any single currently-detected target, anywhere on the map, not just in range. Consumes the wielder's entire next turn. | Rank 5: the turn-consumption cost is waived if the target is a burrowed unit revealed this same mission. | Medium (4 turns) |
| **Standing Watch** | Allies within radius 3 gain +1 vision for 2 turns. | Rank 5: radius 4. | Short (2 turns) |

**The felt cost:** Farsight and Reckoning are built to chain (reveal, then snipe), but Reckoning's own turn-cost is real and only situationally waived — this pilot's biggest play often means everyone else carries the fight alone the following turn.

---

## 4. What happens to the old 20-entry table

`Independent_Campaign_The_Amaranth_Reckoning.md` §9's original table is superseded by this doc, not deleted — eight of its ten unused names and concepts are carried forward here nearly verbatim (Widow's Ledger, The Iron Oath, Deadfall, The Last Word, Salt the Root, The Cutting Room, Cinder Line, Farsight's Reckoning). The other names from the old table — **The Long Silence, The Hollow Choir, Groundfall, The Debt Collector, Stormbreak, Hush, The Debutante's Answer, Last Muster, The Quiet Part, Bloodprice** — aren't in this doc's ten, but nothing about their flavor is bad; several (Hush, The Quiet Part, The Debt Collector especially) are genuinely strong and worth keeping on a shortlist if the pool ever grows past 10, or as a bench for a future replacement if one of this doc's ten doesn't play well once built.

**Meridian's Vow is deliberately not carried into the 10.** It never fit this doc's own per-pilot shape — no owner-pilot, no mech, usable exactly once in the entire campaign, ever. Recommend keeping it exactly as originally specced: a scripted, battalion-wide Mission 36 finale event, not a mechanical "Heirloom" in this new sense at all. That's not a downgrade — it's arguably a cleaner fit for what it always was.

## 5. Reconciling this with the Frame Systems Layer's own "core systems"

Both docs now propose a signature, per-pilot special ability system, gated at a tier threshold. Worth being explicit about how they're meant to coexist rather than compete, since Maxime flagged exactly this kind of collision risk himself when reviewing the Frame doc (§13, "modules vs. systems"):

- **Core systems (Frame Systems Layer §9)** are granted at **B tier**, one per path, deliberately small, deliberately the same four for every pilot who reaches B. They're "your frame comes online" — universal, guaranteed, modest.
- **Heirlooms (this doc)** are earned at **S tier**, reached either through the aristocrat-recruitment shortlist (the 8 proper ones, Act II onward) or a dedicated story beat (Requiem, The Stolen Seal). They're "you've become a legend" — rare, competed-for, and the actual power ceiling, now literally a rank above everyone else's own ceiling rather than just narratively so.

Recommend keeping both, explicitly layered: a B-tier pilot has their path's core system; the same pilot, if they later reach S tier by recruiting or inheriting one of the ten Heirlooms, adds a second, much bigger toolkit on top. Nothing about the core-system's own hard rule (never ignores the cap, never hits a friendly) needs to change — this doc's own §1d hard rule is the same rule, just restated for Heirlooms rather than cores, so the two systems already agree on the one thing that actually protects Requiem's own specialness.

## 6. Open questions — Maxime's calls, not mine

Substantially shorter than the original five, now that the aristocrat-pilot recruitment system has answered most of what was open before. What's left:

1. **The exact shortlist cadence within Act II–III.** §1b's proposal (windows tied to `integrateSecondLance`/`integrateThirdLance`, possibly a third smaller check partway through Act III) was the last thing on the table before Maxime said he was done iterating — never explicitly confirmed as the final answer, just the last proposal standing. Worth a direct yes/no the next time this doc comes up, rather than treated as equally locked to everything else in §1b.
2. **The company-points cost of a single recruitment.** Locked: the currency (company points), the budget (3 picks), the mechanism (shortlist). Not locked: what a pick actually costs, or whether all three cost the same or escalate the way gear tiers do.
3. **Does Requiem stay exactly as-is (one meter, one ability), or does it eventually get retrofitted into three slots like everyone else?** Unchanged from the original doc — leaning toward "stays as-is," since the flagship *should* look mechanically different from the rest of the shelf, but that's still a real asymmetry worth confirming rather than assuming.
4. **Does the personal-points ability-rank system (§1c) still apply exactly as originally specced once a pilot is recruited, or does the new company-points recruitment cost replace some part of it (e.g., does recruitment itself buy more than just rank 1)?** Not re-discussed this session — flagged as the working assumption (carried forward unchanged) rather than a confirmed answer.
5. **The best-fit distribution among the 8 proper Heirlooms (Meeps 2, Tank 1, Reeps 2, Munti 1, Any 2) leans light on Tank and Munti.** Worth rebalancing, or is an intentionally uneven spread fine, since "Any" ones are still available to every path?
6. **Unlock/shortlist-eligibility triggers besides Mission 28 (The Stolen Seal) and the Act II/III cadence in §1b** — none of the eight proper Heirlooms currently has its own specific story-moment hook the way Salt the Root's pilot now does via Mission 28's House Amaranth beat. Worth giving any of the other seven a similar tie-in (a mission or character moment that makes recruiting them land harder), or is the generic shortlist-and-pick flow fine for the other seven?
