# THE BLOOM WARS — Player Telemetry & Performance Statistics Plan v1

**Written 1 Sep 2026, at Maxime's direction. Status: plan only, nothing built.** His ask: *"we will need a way to learn player statistic. to keep track of performance data to improve the game over time."*

**Scope flag, per this project's rule:** this is a new system (a persistent statistics store plus, optionally, an upload path), not a tweak. It's small in code but it touches the engine (`Mission`), Debrief, Battle's commander-down path, Options, and — if the upload half is built — something outside the game entirely (a tiny server). §5 separates the cheap local half from the expensive remote half so Maxime can take one without the other.

Companion: `claude/Bloom_Wars_Player_AI_Difficulty_Tiers_Plan_v1.md` — the two plans share one record shape on purpose (§2).

---

## 0. Glossary

- **Telemetry** — the game quietly writing down what happened (which mission, how many turns, who got hurt) so the numbers can be looked at later. Not a recording of the screen; a spreadsheet row per mission.
- **Local-first** — the data lives in the player's own browser/Electron storage. Nothing leaves the machine unless the player chooses.
- **Opt-in** — off until the player turns it on, with a plain sentence saying what gets sent.
- **PII** — personally identifiable information (name, email, IP). This plan collects none.
- **Schema** — the fixed list of fields in each record, so every row has the same shape and can be compared.

---

## 1. What exists today (read from the code)

There is real, useful per-mission data already computed — it's just thrown away the moment Debrief closes:

- `Mission.unitPerformance` — per deployed pilot: `damageDealt`, `kills`, `assistCredit`, `wasDowned`. Written live by the engine for human and bot alike.
- `Mission.outcome` (`win` / `loss` / `commander_down`), `turn` at resolution, `permanentLosses`, `rescueOutcome`, `clearBloomPatchOutcome`, `fireSupportChargesRemaining`, `deployedPilotIds`, and a human-readable `log: string[]` of every action.
- `engine/campaignEconomy.ts` — `computeMissionEarnings`, `computeMissionCompletionBonus` (turns-under-limit, no-pilot-downed, etc.) — all the "how clean was this run" signals, already calculated for points.
- `CampaignState.activeMissionAttempt = {missionId, startedAt}` — wall-clock start of the current attempt (used by the 12h recall clock); cleared at Debrief. So mission duration in real minutes is one subtraction away.
- `CampaignState.lastMissionEcho` — `{missionId, outcome}` for the Hub's ambient reactions. **Overwritten every mission; it is not a history.**

What doesn't exist: any per-mission history, damage *taken* per pilot, ability-use counts, hostile kills by archetype, attempt numbers (how many tries a mission took), or any record at all of a human's individual decisions. The Gladiator doc already noted the asymmetry: the bot leaves a reason-coded trail per decision, a human playing `Battle.ts` leaves nothing.

Storage convention to follow (`campaignState.ts`): keys named `bloomwars_<thing>_v1`, all access through a `CampaignStorage {getItem,setItem,removeItem}` interface with an injectable backend so tests run under Node. The tutorial flag already shows the pattern for data that should *survive New Game* — which statistics should, because they're about the player, not the save.

---

## 2. The one principle: bot runs and human runs write the same row

`MissionSummary` — one function, `summarizeMission(mission, meta)` in `src/engine/missionSummary.ts`, called by three places: the sim driver (bot), `Debrief.ts` (human win/loss), and `Battle.ts`'s COMMAND DOWN overlay (human commander-down — this path never reaches Debrief today, so it needs its own hook or the most interesting failures vanish).

Why it matters: the difficulty-tier plan's Easy/Moderate/Hard bots are only a *guess* at what real players look like until real players' rows sit next to bot rows in the same table. With a shared shape, "which bot does the tester cohort resemble on Act I" is a one-line comparison. Without it, it's two incompatible datasets and a week of reconciliation.

---

## 3. Schema v1 — the mission record

Kept deliberately flat and small (well under 2 KB per mission) so a whole campaign's history fits comfortably in localStorage alongside the save.

```ts
interface MissionSummary {
  v: 1;                              // schema version — bump when fields change
  gameVersion: string;               // from package.json at build time, e.g. "0.0.1+a1b2c3d"
  installId: string;                 // random UUID minted once per browser/install; no meaning outside this game
  campaignId: string;                // random UUID minted at New Campaign; ties rows to one playthrough
  source: "human" | "bot";
  botTier?: "easy" | "moderate" | "hard";
  seed?: number;                     // bot runs only

  missionId: string;
  attemptNumber: number;             // 1 on first try of this mission in this campaign, 2 on retry…
  outcome: "win" | "loss" | "commander_down" | "recalled";
  turns: number;
  turnLimit?: number;
  realSeconds?: number;              // human only: Date.now() - activeMissionAttempt.startedAt
  ironman: boolean;

  squad: Array<{                      // one per deployed pilot
    pilotId: string; path: string; tier: string;
    weaponBranch?: string; mekTrack?: string;
    damageDealt: number; damageTaken: number; kills: number; assists: number;
    downed: boolean; permanentlyLost: boolean;
    abilitiesUsed: Record<string, number>;   // {abil_ambush: 1, abil_repair: 3}
  }>;
  hostilesKilledByArchetype: Record<string, number>;
  fireSupportUsed: number;
  bonusObjective?: { kind: string; completed: boolean };
  pointsBefore: number; pointsAfter: number;
  rosterSizeBefore: number; rosterSizeAfter: number;
  finishedAt: string;                // ISO timestamp
}
```

Engine additions needed to fill it (small, all in `mission.ts`): `damageTaken` on `unitPerformance` (credit in `resolveAttack` alongside the existing `creditDamage`), an `abilitiesUsed` counter incremented inside each verb (`ambush`, `interdict`, `screenAllies`, `sensorSweep`, `taunt`, `fireSupport`, `missileStrike`, `repairUnit`, `clearBloom`, `enterOverwatch`), and a `hostileKills` tally by `archetypeId` in `resolveKill`. Each is one line at a site that already exists. Tests: one per counter, plus a `summarizeMission` snapshot test.

**What is deliberately NOT in v1:** anything that names the player, any free text, the full action log (too big per row; see v2), Hub social data (a separate concern — the social sim has its own `socialLog` already).

---

## 4. Where it lives and how it's kept small

`bloomwars_stats_v1` in localStorage: `{ installId, records: MissionSummary[] }`, append-only. Cap at 500 records (a full 36-mission campaign with retries is well under 100); when the cap is hit, drop the oldest non-win. Survives New Game and Load (it's keyed to the install, and each row carries its own `campaignId`). Cleared only by an explicit "Delete my statistics" button in Options.

Under Electron this is the same localStorage API, so the code doesn't change between the browser demo and the paid download.

---

## 5. Two halves: local (cheap, do it) and remote (real cost, decide)

### 5.1 Local half — ships for EA, no server, no policy questions

Everything in §3–4 plus the player-facing surfaces that come almost free once the rows exist (each of these is also in the feature-gap report as a "cheap and loved" item):

- **Richer Debrief**: a real stat block — MVP (most damage), kills per pilot, damage taken, turns vs par, "no one downed" badge — instead of only the points breakdown it shows today.
- **Pilot service record** (Hangar roster / Hub Berths): missions flown, kills, times downed, times saved by a Munti, abilities favored. Computed from rows, no new state.
- **Memorial**: every `permanentlyLost` pilot with the mission and turn they fell. Computed from rows.
- **Export statistics** button (Options): copies a JSON blob to the clipboard and offers a file download. This is how EA testers hand data to Maxime with zero infrastructure: "paste this in the itch thread." Also the backbone of a **Report a bug** button — same blob plus the last mission's `log` and the game version.

Effort: roughly one session for the engine counters + summary + storage + Debrief block, a second for service record / memorial / export. All local, all testable under Node.

### 5.2 Remote half — opt-in upload (decide separately)

The game has no backend and itch.io provides none. Options, cheapest first:

1. **Manual only** (5.1's export button + an itch community thread). Zero cost, zero maintenance, but data arrives only from testers who bother. For a 20-person EA cohort this is honestly fine.
2. **A tiny collector endpoint** — a Cloudflare Worker (free tier is far more than enough) that accepts a POST of one `MissionSummary` and appends it to a KV/D1 store; Maxime downloads a CSV when he wants. One evening to set up, needs a Cloudflare account, and someone (a Claude session) to write the ~60-line worker. The game side is a single `fetch()` guarded by the opt-in flag, with a retry queue in localStorage for offline play.
3. Anything heavier (Supabase, a real database, dashboards) — not for EA.

Recommendation: ship 5.1 for EA for sure; build option 2 only if Week 3 has slack after the Vault, since it's the only way to get *every* tester's data rather than the vocal ones'. Either way, the game code is written so the upload is one function behind one flag — adding it later costs nothing on the game side.

### 5.3 Privacy, said once and plainly

Collect nothing identifying: no name, no email, no IP logging on the worker (Cloudflare can be told not to keep it), no free text. `installId` is a random number, not a hardware fingerprint. Upload is **opt-in, default off**, with the toggle in Options next to a one-sentence description of what's sent and a "Delete my statistics" button. Never put any of it in a URL. Maxime lives in Québec, where a provincial privacy law (Law 25) governs collecting personal information — anonymous, consented gameplay statistics are the low-risk shape, but this is worth a five-minute read of the actual rules before the upload half ships, not something to take on this doc's word (not legal advice).

---

## 6. How the difficulty-tuning job uses it

Per mission, three columns from bot runs (Easy/Moderate/Hard win %) and one from humans (win % and median attempts). The rules of thumb the tuning job would work from:

- Human win rate far *below* Moderate bot → the mission relies on something the UI doesn't communicate (the 26 Aug playtest's "turn 16 mission failed, no unit died" is exactly this shape). Fix legibility, not numbers.
- Human win rate far *above* Hard bot → humans found an exploit the bot doesn't model (Mission 9's "never enter turret range" is the known example). Design question, not tuning.
- Human `attemptNumber` median ≥ 3 on a non-climax mission → spike; check `commander_down` share.
- `abilitiesUsed` near zero across humans for an ability the mission was built around (Interdict at a chokepoint) → the ability isn't discoverable; the difficulty is fine.

This is also the first real answer to the standing "most batch numbers were measured against a weaker bot" caveat: human rows are the ground truth the bots get re-calibrated against.

---

## 7. Schema v2 — per-action events (later, for Gladiator v2)

The Gladiator doc's "learn from the player" idea needs a decision-level trail, not a mission-level row: for each human action, `{turn, unitId, action: move|attack|ability|endTurn, from, to, targetId, abilityId, boardHash}`. It's the same trail the bot already emits as `PlayerAiReason` codes. It's bigger (hundreds of events per mission), so it lives in a separate `bloomwars_events_v1` ring buffer of the last N missions, never uploaded by default. Not needed for EA; noted so the v1 hooks are placed where v2 can attach (`Battle.ts`'s single `handleBoardClick`/`runActionSlot` funnel is the one place every human action passes through).

---

## 8. Sequencing

| Phase | What | Size |
|---|---|---|
| 1 | Engine counters, `summarizeMission`, `bloomwars_stats_v1` store, hooks in Debrief + COMMAND DOWN + sim driver, tests | 1 session |
| 2 | Debrief stat block, service record, memorial, export/bug-report button | 1 session |
| 3 | Opt-in toggle + Cloudflare collector (needs Maxime's account) | 1 session + his evening |
| 4 | Per-action events (v2) | post-EA |

Phase 1 should land *before* the difficulty-tier plan's Phase D re-baseline so the bot fingerprint table is produced in the final shape. Docs to update once built: `Bloom_Wars_Main_Menu_Save_Ironman_UI_Plan_v1.md` §7 (Options scope), `Bloom_Wars_Gladiator_Learned_Opponent_v1.md` §1.3 (the logging dependency), and the Master Index.

## 9. Open questions

1. Local half only for EA, or also the collector? (Recommendation above: local for sure, collector if Week 3 has room.)
2. Should the Debrief stat block show *everything* or keep some of it for the service record, so the Hub has a reason to be visited? (Taste call.)
3. Does Maxime want his own play flagged (`source: "human", tag: "dev"`) so it's separable from testers'? Trivial to add, easy to forget.
