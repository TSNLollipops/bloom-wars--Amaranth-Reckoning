# The Bloom Wars — Placeholder Session TODO

**Read this first if you are a fresh session with access to Maxime's computer.**

Maxime spins up three or four short "placeholder" conversations while he is at school so work can happen without him watching. He is not there to answer questions. This file is what he would have told you.

*Written 7 September 2026, end of the codex-rework session. If you finish something here, delete the item rather than annotating it, and add a line to `Bloom_Wars_Now_And_Next.md`.*

---

## Ground rules — these are not optional

**1. Do not write Maxime's voice work.** Character dialogue is his. If a task below says "content," it means he writes it. A previous session searched an entire repo for lines it thought were lost and shipped an empty skeleton with a warning rather than reconstruct them. That was the right call. Making up a character's lines and presenting them as a draft costs him more than doing nothing.

**2. Plan → mockup → questions in a popup → wait for "go."** His standing process for anything that touches game code. He is at school, so a popup will not be answered — which means **if a task is not already approved below, do not build it.** Everything in "Ready to build" has his go-ahead. Everything in "Needs Maxime" does not, and prep work is the most you should do.

**3. The gate, every time, before you commit anything:**
```
npm run typecheck && npm test && npm run lint && npx vite build
```
`npm run lint` includes `lint-spoiler.mjs`, which needs `BW_RESERVED_TERM` from his git-ignored `.env.local`. **In a sandbox that check silently skips** — it prints a "not set" line and passes. It only really runs on his machine. If you cannot run it, say so plainly in your handoff rather than reporting a clean lint.

**4. Every device write carries `expectedMtimeMs` from its own staging.** Stage the file, edit, commit with that mtime. A rejected write means **re-stage and merge — never force**. Two sessions once wrote older copies of `mission.ts`/`Battle.ts`/`Debrief.ts` over a day's work because this was skipped. He may be running other sessions in parallel with you right now.

**5. Verify against the actual current file, not against a plan doc or your own memory.** Several docs in this project are stale in ways nobody noticed for days. Grep the code. This is his own carried-over rule and it has caught something almost every session.

**6. After an edit, look at what sits immediately around it.** A correct fix that broke its neighbour has happened here more than once — including a `str.replace()` with no count limit that inserted the same furniture into four different decks.

**7. Tests verify state; screenshots verify what a player sees.** Three real bugs this session passed every assertion and were only visible on screen. For anything visual, take the screenshot.

**8. Never hand-edit `maps_generated.ts`.** Edit `maps.py` and regenerate. `combat_sim.py` and `maps.py` are the source of truth for balance and maps.

---

## Ready to build — approved, self-contained, no decision needed

### A. The Debrief check-in nudge names a room the Greathouse does not have

**This is a real player-facing bug with a fix that is already written.**

`scenes/Debrief.ts:767` renders, with **no facility branch** (there are only three `isHouseAmaranthMission` branches in that file and this is not one of them):

> "Report to the CO in the grotto before your next deployment."

The Greathouse has no grotto. Verinis sits in **THE CONTROL ROOM** (`controlRoom`, floor `ss2` — see `engine/facilityHouseAmaranth.ts`). So a House Amaranth player finishing their first mission is told to report to a room that does not exist in their building.

**The fix is Maxime's own already-written line**, from `Bloom_Wars_Verinis_Voice_Bank_v1.md` §10, Check-in nudge:

> "Report to me before you deploy again, Colonel."

It sidesteps the room name entirely, which is why it is the right fix and not just a patch. Branch on the facility, keep Warden's existing string, use Verinis's line on the House side. One branch, one string, one test.

Do **not** invent a Warden-side rewrite while you are in there. Arangement's bank does not exist yet and that is content.

### B. Retire `data/codex.ts`'s dead exports

`PERSONNEL`, `BESTIARY`, `WORLD`, `SYSTEMS`, `GLOSSARY` and their helpers are now read by nothing except `data/__tests__/codex.test.ts`. The Archive (`data/archive.ts`) replaced them on 7 Sep. Retiring them means retiring that test file with them.

Let the compiler drive it: delete the exports, and `noUnusedLocals` names whatever else just died. Run the suite before and after and confirm the count only drops by the retired tests. `RANKS` is still live — the Archive generated from it but `scenes/Codex.ts` no longer imports it, so check before assuming.

Low value, zero risk, good filler task. Do not do it in the same commit as anything else.

### C0. `Bloom_Wars_Now_And_Next.md` needs an eleventh pass — do this one first if you have fresh context

That file is the project's working state doc and it currently **does not know the codex rework happened**. Two things in it are actively wrong:

- It says Verinis has *"six of nine slots have real content."* All nine slots except slot 9 (item D below) were completed 7 Sep.
- It says nothing about the Archive, `data/archive.ts`, `scenes/Archive.ts`, HOW TO PLAY, or `npcSocialStates` — the largest feature shipped this week.

It follows an established pattern: dated "Nth pass" paragraphs at the top, newest last. Add an eleventh.

**Why the session that shipped all this did not do it:** `project_write` replaces a doc whole, and that file is ~30KB. Rewriting it means reproducing every one of those bytes from context, and a single slip silently destroys work — which is the exact failure its own opening paragraphs describe happening twice already. Doing that at the end of a long session, tired, is how you lose a week of build log. A fresh session with the whole doc newly in context and nothing else competing for attention is the right one to do it. Read it, apply the change as an exact-match replacement in a script, write it back, then **read it back out of the project and confirm the insertion landed** — the doc's own third pass describes doing precisely that, and it is the standard here.

---

## Needs Maxime — do not act, prep only

### C. Bray's callsign collides with an Heirloom title

Verified, real, low severity, and it is a naming call, not a code one.

- `data/heirlooms.ts:662` — the `deadfall` Heirloom has `epithet: "Deadfall"`
- `scenes/Hub.ts:4486` renders `` `${displayName}, ${epithet}` `` → the Vault shows **"Ichigeki, Deadfall"**
- `deadfall` is `track: "proper"`, so it is in `RECRUITABLE_HEIRLOOM_IDS` and any campaign can be offered it
- `data/campaignHouseAmaranth.ts:79` — `S.Sgt. Callum Bray — "Deadfall"`

A House player can have a pilot callsigned Deadfall and that Heirloom in the same save. They never appear in the same panel.

Costs if he picks one: renaming **Bray** is two strings (`campaignHouseAmaranth.ts:79`, `data/archive.ts:1270`). Renaming the **epithet** is one, but "Ichigeki" (一撃, *a single blow*) paired with an English epithet is clearly deliberate. **Leaving it is defensible** — a callsign and a weapon epithet are different registers.

### D. Verinis voice bank slot 9 — Debrief / Campaign Shop callouts

**Content. His to write.** `Bloom_Wars_Verinis_Voice_Bank_v1.md` §10 has the empty slot and the reasoning.

The screen is `scenes/Debrief.ts`. Every callout on it currently speaks in flat UI narrator voice. Seven events would take a Verinis line:

| Event | Method | Current narrator text |
|---|---|---|
| CO check-in due | `drawCoCheckinNudge` | see item A above |
| Second Lance granted | `drawSecondLanceCallout` | "…recruit it at the Campaign Shop / five berths, empty." |
| Third Lance granted | `drawThirdLanceCallout` | same |
| Callsign earned | `drawCallsignCallout` | "THE CREW HAS A NAME FOR THEM NOW" |
| Munti replacement | `drawMuntiCallout` | "EMERGENCY REPLACEMENT — [name] assigned, Munti-class, G-tier" |
| Bonus objective met | `drawBonusObjectiveCallout` | rescue_pilot / clear_bloom_patch succeeded |
| A pilot lost | `drawGriefCallout` | "GRIEF — HOW THEY'RE TAKING IT ([name])" |
| Campaign finale | `drawCampaignFinaleCallout` | the day-count stat |

The three worth the most in his register: the **lance grants** (he hands over five empty berths and an implied bill), the **Munti replacement** (a stranger arrives because someone did not come back), and the **grief callout** — a CO who is "an asshole, plain and simple" saying something about a dead pilot is the highest-value line on that screen.

**You may do the plumbing** — the facility-keyed bank lookup — once the lines exist. Not before. There is nothing to key.

### E. Arangement of Content has no voice bank at all

Maxime, 7 Sep: *"ill do arrangement bank another day."* Same rule as D. Do not draft it.

### F. Content flags still awaiting a yes

All in `Bloom_Wars_Codex_Rework_Plan_v1.md` §7. In the Archive as drafts, none blocking:

- `hist_gladiator`'s optional Hiopi aside (the sport was inspired by watching a Hiopi city-fight — book-side texture, deliberately not written in)
- "Warden Holdings" as a new proper noun (`company_registry`)
- The Osnian "bad omen" line — lands hard on Anand specifically
- The Screaming paper's invented plating resonance
- Whether "spreading form" / "sessile" are player-facing vocabulary

---

## State as of 7 Sep 2026, 23:59

The **codex rework shipped in full**. `data/archive.ts` (140 entries), `engine/archiveDossier.ts` (the live dossier block), `scenes/Archive.ts` (three-pane reader, launch-and-pause), reached from the **tactical table in the CIC** (Warden) and the **reading table in Records** (House Amaranth). `npcSocialStates` added so the CO and Meks persist. The Field Manual rewritten against the actual files. The old Codex reduced to **HOW TO PLAY** — out-of-fiction help only, nine sections, no save needed.

**Gate at last commit: typecheck clean, eslint clean, cast-collision lint clean, 105 files / 2569 tests passing, `vite build` succeeds.** `lint-spoiler` has never run against this content — it skips in the sandbox.

Six real bugs were found and fixed during the build. Three of them (the Archive rendering *underneath* the paused Hub, Rourke's rank disagreeing between two panes on the same screen, an inflated shelf count) passed every assertion and were only findable by looking at a screenshot. The worst was **the Archive being permanently locked on every House Amaranth save** — `highestWardenMissionIndexReached` returns -1 for every House mission id, which reads as "nothing resolved" forever. Fixed with `highestMissionIndexReached(facility, echo)`.

Full record, newest first:
- `Bloom_Wars_Build_Log_Addendum_HouseGateFixAndCleanup_07Sep2026.md`
- `Bloom_Wars_Build_Log_Addendum_ArchiveCloseout_07Sep2026.md`
- `Bloom_Wars_Build_Log_Addendum_ArchiveConsole_07Sep2026.md`
- `Bloom_Wars_Build_Log_Addendum_ArchiveDataLayer_07Sep2026.md`
- `Bloom_Wars_Codex_Rework_Plan_v1.md` — the decisions (Q1–Q14) and the Field Manual audit in §8
- `Bloom_Wars_Verinis_Voice_Bank_v1.md` — his 63 lines, the register split, and §12d

---

## Things a cold session gets wrong here

- **`campaignId` is a minted random id, not a campaign identifier.** It looks like one. Use `baseSceneKeyFor(state)` to tell Warden from House Amaranth. A function got this wrong this session and its own test caught it.
- **A paused Phaser scene still renders.** `pause()` stops `update()`, not drawing. Scenes draw in the order `main.ts` lists them. `scene.launch` + `scene.pause` needs an explicit `bringToTop` or the new screen is invisible underneath the old one.
- **A helper with a scope in its name is telling you what it will not do.** `highestWardenMissionIndexReached` had the word right there and got reused on a two-campaign feature anyway.
- **`src/data/**` must never import from `src/engine/**`.** Zero violations across 47 files — the rule is real. Data is what things are; engine is what is happening in this save.
- **Content that outgrows its renderer is a layout bug.** `renderObjectives` drew three cards across one row because there were exactly three objectives. There are seven now.
