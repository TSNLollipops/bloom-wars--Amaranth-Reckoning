# THE BLOOM WARS — Calendar Teeth: Direction Note (carrier-defense sorties)

**Direction, not a spec. 2 September 2026.** Recorded the same day the calendar economy shipped, because `Bloom_Wars_Calendar_System_v1.md` and the calendar build-log addendum both currently say "whether teeth ever gets built is still open" — that is now answered in *direction*, and leaving those docs saying otherwise is exactly the drift this project's own rules exist to catch. Nothing here is built, and none of it should be built without its own design pass first.

Maxime's own words, in full:

> "teet are gona be like ftl. sortie to defend the carrier. happening once a month randomly"

## 1. What this resolves for free

The calendar shipped with one honestly-flagged weakness: **a player who idles with the tab focused burns days for nothing**, harmless only because nothing reacts to the number. Both the v2 proposal and the corrected v1 doc name it as the first thing needing rethinking if teeth ever arrived.

This direction resolves it without a penalty mechanic. Idle time produces days, days produce raids, raids cost something real. The consequence is structural rather than punitive — the game never tells the player off for walking away, it just lets the war keep moving, which is the premise the calendar was built on in the first place.

It also retroactively earns the calendar's most important design call. The clock ticking in Battle as well as the Hub means a raid taxes *all* time, not just social time: grinding missions costs the same days as socializing, it just pays mission rewards for them instead of relationships. That is the genuine opportunity cost the original 25 Aug framing was reaching for — "time u do social u aint fighting" — and it only works because both scenes feed one clock.

## 2. The numbers problem, surfaced immediately

**At the shipped rate (1 day per 6 real minutes), a 30-day month is 3 real hours of play.** A ~30-hour campaign therefore contains roughly **ten** carrier-defense sorties.

Whether that is right depends entirely on what these are:

- **Big authored set-pieces** — ten across a campaign is reasonable, maybe even generous.
- **FTL's actual feel** — nowhere near enough. FTL puts a decision in front of the player every couple of minutes; its pressure is continuous, not decadal.

Three dials can absorb the difference, and they should be chosen together rather than one at a time: the base day rate (`MS_PER_CALENDAR_DAY`), the length of a "month," and the once-per-month frequency. Flagged now because building a raid system around an implied cadence and *then* discovering the calendar disagrees is the expensive order to find this out in.

## 3. Open questions that want answering before any build

**A "month" doesn't exist yet.** `calendarDay` is a bare float; there is no month or week structure anywhere in the codebase. Small to add, but it forks the design:

- **Exactly once per month, on a random day within it** — guaranteed pacing. Never two back to back, never a long drought. Authored tension.
- **A per-day probability averaging one a month** — real chaos, including the occasional brutal double and the occasional quiet stretch. Closer to how FTL actually feels.

These play very differently and the choice is much cheaper made now than swapped later.

**The FTL comparison argues against pure randomness.** Worth being precise about what FTL actually does, because the mechanism matters more than the vibe: FTL's pressure is a **rebel fleet the player can watch advancing on the sector map**. The tension is entirely in seeing it and choosing anyway — one more scrap run, or jump now? A raid that fires from a hidden timer doesn't produce that decision. It produces an interruption. And a surprise raid landing on top of this game's permadeath/Munti stakes is where players start reloading saves rather than living with outcomes.

**Recommendation, offered not assumed: make the pressure visible and building.** A gauge that fills as days pass, sitting beside the day readout already in the Hub HUD. That turns the calendar from a decorative number into a decision surface — "two days of slack left, one more poker night or launch now?" — which is the actual FTL loop. Randomness survives in *when exactly* it fires inside the window, so it still surprises without feeling arbitrary.

## 3a. Raids pay out — and the trap that creates

Maxime, immediately after approving the visible-pressure idea: **"raid also give militsry point obviously."** (Terminology note: no "military points" concept exists in the codebase — this reads as `CampaignState.points`, the company pool, the standard mission-reward currency. Worth confirming rather than assuming, since `CampaignPilotEntry.personalPoints` is a separate thing.)

Narratively this is right, and it gives the raid a good register: *you didn't ask for this fight, but you got paid for it.*

**The trap, worth naming before anything is built.** The teeth premise is "spending time costs you something." A raid that pays points makes time *earn* you something. Left unchecked, that inverts the whole mechanic: idle in the Hub → days pass → raids arrive → points accumulate. The pressure system becomes a slow grind faucet, and a player optimizing the game correctly would deliberately dawdle. That is the exact opposite of the intent.

This is not an argument against the payout. It's an argument that the payout needs one balance rule holding it in place:

> **Points per elapsed day from raids must sit clearly below points per elapsed day from flying real missions.**

Because the calendar taxes all time at one rate, that comparison is clean and directly checkable against `campaignEconomy.ts`'s existing numbers (`OBJECTIVE_BONUS`, `KILL_BONUS`, `SURVIVAL_BONUS`, `CO_BONUS_BY_RANK`, the completion bonus). Hold that rule and raids read as consolation rather than strategy — you're always better off launching than loitering, and the points you get from a raid soften a bad outcome without rewarding the behavior that caused it.

**The stronger lever, and the more FTL one: escalation.** Rather than only tuning the payout down, let each raid make the next one *worse* — harder, or sooner, or both. This does three things at once:

- **Caps farming automatically.** Dawdle long enough and the raids outpace what you can profitably fight, so the strategy defeats itself without needing a hard cap or a lecture.
- **Reproduces FTL's actual pressure.** FTL's rebel fleet doesn't just arrive, it closes. Escalation is what makes lingering feel dangerous rather than merely eventful.
- **Gives the visible gauge something real to show.** Not just "a raid is coming" but "a raid is coming and it will be worse than the last one." That is a far more interesting readout than a countdown, and it makes the Hub's day counter genuinely load-bearing.

Combined, the shape holds together: **visible building pressure + escalating difficulty + a real but deliberately sub-mission payout.** Each piece covers a weakness in the others.

**Unanswered mechanics, each a real design question:**

- ~~What does a defense sortie *cost* if it goes badly?~~ **Answered 2 Sep 2026 — carrier damage.** Maxime: *"carrier damage is good."* This is a better failure state than pilot loss for two reasons worth keeping visible. It's a real cost that doesn't collide with the permadeath/Munti system's own territory, so the two stakes mechanics complement rather than dilute each other — the same concern that made the Insult proposal reject an automatic permanent-departure tier. And it finally gives the Antfarm doc's Carrier Upgrade Modules (Auxiliary Berths, Forward Battery, the rest — still unbuilt, per `Debrief.ts`'s own header calling them Tier 2) an obvious reason to exist: a Forward Battery means nothing on a ground mission and a great deal when the thing being shot at is your own carrier. Still open underneath it: what carrier damage actually *does* mechanically, and whether pilot loss remains possible alongside it or is taken off the table entirely.
- Can it be declined, or is it forced?
- Does it interrupt the Hub directly, or fire as a gate the next time the player tries to launch?
- Does it use the existing 12-hour mission real-time clock, or sit outside it?
- New maps: `maps.py` and `combat_sim.py` remain the source of truth, so any defense map has to be generated and sim-validated through them, never hand-authored into `maps_generated.ts`.

## 4. Scope, and when this ships — decided 2 Sep 2026

Per the project's standing rule on saying so before building: this is **a new content type, not a feature**. It implies a new mission kind, new maps (through the sim pipeline), a trigger/scheduling system, a month structure on the calendar, probably a new UI element, and a decision about how it interacts with permadeath. That is comparable in size to the calendar economy itself, plausibly larger.

**Scheduled: the first post-launch content update, alongside House Amaranth.** Maxime: *"the teeth going to have to wait for post ea launch same time as house amaranth."*

This is consistent with what is already locked rather than a new fork — `Bloom_Wars_EA_Launch_Plan_31Aug2026.md` already ships **Warden Company alone** for Early Access (itch.io, Electron-packaged, target 26 Oct 2026), with House Amaranth explicitly deferred as the first post-launch update. Teeth now rides in that same release.

Two things follow, worth stating so a future session doesn't have to re-derive them:

- **Nothing in this note should be built before EA launch.** The EA schedule (Vault next, then docs/tech-debt, packaging, the itch.io page, playtesting, final regression) is unchanged and unaffected.
- **The calendar shipping without teeth is now the intended state, not an interim compromise.** That was already the case, but it now has a date attached: the calendar spends roughly two months live and cosmetic before anything reacts to it. That is a genuine advantage rather than a delay — the base rate (1 day per 6 real minutes) is an unplaytested guess, and having real players feel the clock for weeks *before* raid pacing is designed around it means the raid cadence gets built on a tuned number instead of a guessed one. The §2 numbers problem essentially resolves itself if the rate is fixed first.

## 5. Docs this makes stale

- `claude/Bloom_Wars_Calendar_System_v1.md` — its §3 and its "Not decided here" list both say whether teeth gets built is open. Direction now exists; the shape does not.
- `claude/Bloom_Wars_Build_Log_Addendum_CalendarEconomy_02Sep2026.md` — its §5 "idle case" entry can now point here for the resolution.

Both left uncorrected for now, deliberately: this is a direction, not a locked design, and rewriting those docs as though teeth were settled would overstate what has actually been decided.

## 6. Naming-lock safety check

No proper nouns invented. Nothing here approaches the reserved book-series terms.
