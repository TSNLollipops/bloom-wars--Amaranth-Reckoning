---
title: Undertow "hold until spotted" — scoping note
date: 2 Sep 2026
status: BUILT 3-4 Sep 2026 AND SHIPPED OFF — one flag from live, awaiting Maxime's call
---

> ## STATUS — BUILT, VERIFIED, SHIPPED OFF (3–4 Sep 2026)
>
> The diagnosis below is exactly right and the recommended fix was built
> exactly as specified. It ships with `ENABLE_UNDERTOW_AMBUSH_HOLD` set to
> `false` in `engine/ai.ts` — flip one word to turn it on; the data flag,
> both call sites and four tests already exist and pass.
>
> **Why off: the verification plan in "Why this still needs real
> verification" below was run in full, seeded A/B, and it says the change
> does not do what it was scoped to do while doing several things it was
> not.**
>
> - **Mission 22 — the mission this was for — n=500 per tier: 0% / 0% / 2%
>   both with and without. Completely unmoved.**
> - Full 76-mission sweep at n=25: aggregate 48% → 50%, nine missions moved.
> - The five biggest movers re-measured at n=200 (signal, not noise):
>   `mission_amaranth_4` 27% → **0%** with 122/200 TIMEOUT from zero;
>   `mission_amaranth_26` 100% → 82%; `mission_amaranth_29` 61% → 33%;
>   `mission_house_amaranth_15` 0% → 53%; `mission_house_amaranth_21` 5% → 95%.
>
> `mission_amaranth_4` is what decides it: timing out 61% of runs, from zero,
> is precisely the failure this doc warns about by name — enemies holding
> position on a map whose premise is that they come to you. Rebalancing five
> missions, one into a timeout, is not a call to make unattended.
>
> Proof the shipped default is untouched: the full sweep at the same seed
> after the flag was added returns 909/1900 (48%), byte-identical to the
> pre-change baseline.
>
> Full account:
> `claude/Bloom_Wars_Build_Log_Addendum_UndertowAmbushHold_ShippedOff_04Sep2026.md`.

# Where this came from

Mission 22 tuning tonight (2 Sep 2026). Maxime asked for "1 undertow that
will hit the 1st enemy that it see if not seen itself" as part of a wave
restructure. I flagged that this exact idea was already tried on this exact
mission and always lost — see `AMARANTH_MISSION_22`'s own comment in
`campaignAmaranth.ts` ("UNDERTOW 'BEHIND THE LINE' — INVESTIGATED, NOT
ADDED"): every placement came back a deterministic 0/150, because a
burrowed Undertow with nothing visible doesn't wait, it walks straight to
the dock and starts ticking `PROTECT_ASSET_TICK_DAMAGE` every turn it
sits there. Maxime's answer: "scope it out. it might be useful" — this is
that scoping, not an implementation. Nothing below has been built or
shipped.

# This is not a new idea — it's a named, already-acknowledged regression

This is the important framing. It isn't "invent ambush behavior from
scratch" — `engine/ai.ts`'s own header comment (the `ENABLE_ENEMY_ROAM_FALLBACK`
block, ~line 331) already says, in Maxime's own words from 25 Aug 2026,
that a burrowed Undertow "used to stay put until spotted" and that a later
change made it "beeline toward the player's deploy zone unconditionally" —
on `mission_amaranth_26` (Cut the Root / extraction), not Mission 22. That
mission's fix was `BattleUnit.isExtractionTarget`: a flag that makes a
hostile never consider one specific *friendly* unit attackable at all, so
the stranded extraction target can't be rushed and killed. That's a real,
shipped precedent for "carve out an exception to the roam fallback" — but
it solves a different shape of problem (protect one target) than the one
here (make one *attacker* wait instead of camping). It was never applied to
Undertow's own idle behavior, so the regression the comment names is still
live today, on at least two missions (26 worked around it; 22 just doesn't
use Undertow at all because of it).

# The actual mechanism, read from the code, not guessed

`idleRoamTarget` (`engine/ai.ts`, ~line 383) is what a reflexive/pack unit
falls back to when it has nothing visible:

```
function idleRoamTarget(map: MapDefinition): Coord[] | undefined {
  if (map.defendZone?.length) return map.defendZone;
  if (ENABLE_ENEMY_ROAM_FALLBACK && map.deployZones.player.length) return map.deployZones.player;
  return undefined;
}
```

`defendZone` is checked first and unconditionally — every `protect_asset`
map (Mission 22 included) has one, so on those maps this function *never*
returns `undefined`, meaning "hold position" is not reachable there at all.
Every reflexive/pack hostile with nothing visible marches to camp the
asset and starts ticking it, whether that's the intended behavior for that
archetype or not. That's the whole bug, in one function.

The good news: everything else "ambush" needs already exists and already
works correctly today — I checked each piece against the actual code
rather than assuming:

- **Stays unseen while burrowed**: `isVisibleTo` (`engine/ai.ts` ~line 126)
  returns `false` for `target.burrowed` unconditionally, both directions
  (this file is symmetric — player-side fog of war and hostile-side
  targeting share the same function). A burrowed Undertow is invisible to
  the player regardless of distance, today, already.
- **Sees and reacts to the first thing in range**: burrowed doesn't blind
  the unit *as an observer* — only `target.burrowed` is checked, not
  `observer.burrowed` — so a burrowed Undertow's own vision (3, seismic)
  still finds enemies normally. The moment something's in range,
  `reflexiveDecision` does exactly what every other reflexive unit does:
  nearest visible target, move into range, attack. No special "first
  enemy" logic needed — that's just what this tier already does.
- **Surfaces on the strike, with a bonus**: `engine/mission.ts` (~line
  1422) already sets `surfaced = !!attacker.burrowed` and clears the flag
  the moment a burrowed unit attacks, and `UNDERTOW_SURFACE_DAMAGE_MULT`
  (1.5x, `combatTables.ts`) already rewards that first strike.

So the gap isn't "build ambush AI." It's one function's priority order
denying the unit the chance to ever reach the "wait" branch it would
otherwise correctly use. Worth saying plainly: this makes the fix smaller
and lower-risk than the original ask sounded like it would need.

# Proposed fix (recommended)

Add an opt-in flag, e.g. `holdWhenIdle?: boolean`, to `BloomArchetype`
(`data/types.ts`, next to the other optional fields ~line 138). Set it
`true` only on `bloom_undertow` (`data/bloom.ts`). In `ai.ts`'s
`reflexiveDecision` and `packDecision`, check it *before* calling
`idleRoamTarget` — same pattern already used three other places in this
file for the `flight_membrane` lookup (`BLOOM[unit.archetypeId]?.movementType
=== "flight_membrane"`):

```
if (unit.kind === "bloom" && BLOOM[unit.archetypeId]?.holdWhenIdle) return {};
```

That's the entire behavior change. Every other archetype, on every other
mission, is byte-for-byte unaffected — `idleRoamTarget` still runs exactly
as it does today for everything that doesn't carry the new flag. Undertow
is the only thing that changes anywhere in the campaign.

Estimated size: two small diffs (`types.ts`, `bloom.ts`) plus a ~3-line
change in `ai.ts`, touched in two functions. Small change, in shared code.

> **BUILT AS SPECIFIED, 3 Sep 2026.** One deviation worth naming: the check
> is wrapped in a `holdsWhenIdle(unit)` helper gated by
> `ENABLE_UNDERTOW_AMBUSH_HOLD`, so both call sites read the same one line
> and the whole thing has a killswitch — the same shape
> `ENABLE_ENEMY_ROAM_FALLBACK` directly above it already uses. The
> prediction in this section held exactly: with the flag off, the full
> 76-mission sweep is byte-identical to the pre-change baseline.

# Fuller version (not recommended yet)

What Maxime described could also be read as a real detection-radius
ambush — surfaces specifically when something gets *close*, independent of
normal vision/perception rules, closer to "seismic" as its own sense. That
would need a new radius check decoupled from `vision`, decisions about
whether it fires on any proximity or only within LOS, and interacts with
the already-flagged-as-unbuilt `burrowDetection: true` field sitting unread
on the Runemaster mek track (`data/meks.ts` — `ai.ts`'s own comment already
lists this as "still not covered"). More faithful to the flavor, meaningfully
more surface area, and it'd make sense to design it once, for both this and
the Runemaster hook, rather than twice. Worth a separate pass if the small
fix above doesn't feel like a real ambush once it's actually played — not
worth building blind.

# Why this still needs real verification before it ships anywhere

Small and scoped doesn't mean risk-free — it's still a change to shared
`ai.ts` code, and this exact class of change already burned the project
once: the original roam-fallback rollout dropped the full 40-mission
aggregate from 71% to 54% at n=25/mission and silently broke
`mission_amaranth_26`'s premise, and that only got caught because Maxime's
own process required a full campaign sweep before shipping, not just the
one target mission. Same discipline applies here, scaled to how much
smaller this change is:

- Full campaign batch sweep (all missions, `npm run sim:batch`) at a light
  sample (n=25, matching the precedent) specifically looking for anything
  that currently spawns Undertow and *relies* on today's camp-the-objective
  behavior — if nothing else in the campaign spawns Undertow outside
  Mission 26, this should be a formality, but the precedent is exactly "it
  wasn't a formality last time," so it gets checked, not assumed.
- Mission 22 and Mission 26 specifically at n≥500 per tier, per Maxime's
  own standing rule (`Bloom_Wars_Player_AI_Difficulty_Tiers_Plan_v1.md`
  §3.5, 2 Sep 2026) — Mission 26 because this fix changes an already-live
  mission's behavior even though it wasn't the one asked for tonight, and a
  change nobody re-tests there is exactly the kind of doc drift the
  project's own process notes warn about.
- If the sweep turns up nothing new to worry about, `BattleUnit.isExtractionTarget`
  on Mission 26 is worth leaving in place regardless (defense in depth,
  costs nothing) rather than removing it as part of this change.

> **RAN, 3–4 Sep 2026 — and this section is why the feature is off.** Every
> bullet above was executed. The sweep was NOT a formality: it moved nine
> missions. `isExtractionTarget` on Mission 26 was left in place, as advised.
> This doc's own instinct — that the last change of this class looked safe
> and wasn't — was correct a second time.

# Recommendation

Build the small version (flag + 3-line check), scoped to Undertow only,
verify per the plan above, then retry the actual Mission 22 wave with it.
Hold the fuller detection-radius version until we know whether the small
one already delivers the feel Maxime's after.

> **OUTCOME, 3–4 Sep 2026.** Built and verified per the above. The retry on
> Mission 22 is the part that settles it: 0% / 0% / 2% at n=500 per tier,
> identical with the fix on and off. The small version does not change
> Mission 22 at all, so the question this doc opened — "does the small fix
> deliver the feel Maxime's after" — cannot be answered on that mission.
> It would have to be answered on Missions 4, 26, 29 and House Amaranth
> 15/21, which is a different and larger conversation than the one this
> note was scoped for. Maxime's call.
