# THE BLOOM WARS — Arangement of Content: CO Bespoke Dialogue Bank v1

**Content pass only when written — see §4/§6 below for the code that has since shipped.** Written 1 September 2026, at Maxime's direct request, off the back of a flag that's been sitting open since the grotto first shipped a walkable CO (27 Aug 2026): *"he has no bespoke dialogue content (advice, Stress-relief conversation) — Talk just draws from the generic per-animal ambient pool, same as any other NPC, not the CO-specific voice the design docs eventually call for"* (`Bloom_Wars_Antfarm_Carrier_Hub_v1.md` §11.3, and `Bloom_Wars_Master_Index.md`'s own Antfarm Grid v0 section). Maxime's own instruction: write the CO's lines, and add greeting and goodbye to the list too — so this covers three banks, not one.

## 0. What this is, and what it isn't

Arangement of Content is one fixed, named character, not one of the nine catalyst archetypes every other NPC draws from — the whole point of "bespoke" here is that he shouldn't sound like a Wolf or a Bear reading from the shared pool, he should sound like himself. So unlike the Munti Respect bank or the ambient catalyst pool, this isn't crossed against nine catalysts — it's one voice, written once, with enough internal variety (three banks, several lines each) to not repeat on a player fast.

**Voice, established from what's already on record, not invented fresh here:** Carabil (confirmed species, `Bloom_Wars_Antfarm_Carrier_Hub_v1.md` §11.3's own 27 Aug update), grown into the ship rather than piloting a separate body (per the Carabil canon pulled into `Bloom_Wars_Carabil_Playable_Species_Proposal_v1.md`) — someone who's been sitting in this specific seat, on this specific ship, for a long time. His job is explicitly named twice on record: a mentor/counselor managing a pilot's Stress, "closer to a support NPC than a romance option" (`Bloom_Wars_Spitball_Ideas.md`), and a register distinct from CIC's war-plot briefing tone, "closer to Berths' 'the people rather than the war'" (`Bloom_Wars_Antfarm_Carrier_Hub_v1.md` §11.3). So: steady, direct, dry rather than warm-and-fuzzy, cares without performing it, doesn't do speeches. **Deliberately, absolutely not romantic or flirtatious anywhere in this bank** — he's locked non-romanceable specifically so "can I date my CO" never becomes the answer to "does my CO help me cope" (§11.3's own stated reasoning), and every line below was checked against that line.

No lines here reference Rourke by name or by rank, and none assume a specific catalyst, Stage, or rank on the visiting pilot's side — that's deliberate, so this bank works for whoever the trigger logic eventually sends through it (the player, or, if this ever extends past the player, any pilot), rather than needing a rewrite the moment the trigger shape gets decided for real.

## 1. Greeting — 8 lines

For an ordinary Talk, not a hot-topic/mission-echo reaction (those already have their own content elsewhere) — just the CO acknowledging someone's walked up.

1. "Grotto's yours as long as you need it. What's on your mind?"
2. "You made it down here in one piece. That's a start."
3. "No line today. Come on in."
4. "I was starting to think you'd forgotten where I sit."
5. "Door's always open. Doesn't mean the news is always good — just that it's open."
6. "Sit if you want. I don't stand on ceremony down here."
7. "Whatever you're carrying topside, you can set it down for a minute first."
8. "Talk first, business after. That's the order down here."

## 2. Advice / Stress-relief — 10 lines, split by the pilot's read

Matches the ≥70-panicking Stress threshold already established in `pilot_creator.html`'s own prototype (cited in `Bloom_Wars_Stress_Morale_Trigger_Proposal_v1.md`) — five lines for an ordinary, low-Stress visit, five for a visibly wound-tight one. Whichever trigger design actually ships can route on that same read; nothing here assumes a different threshold.

**Calm / low-Stress context:**

1. "You're not required to have it all figured out by the time you leave this room."
2. "Everyone topside's got an opinion on how you should be handling it. I've got exactly one — however you're actually managing to."
3. "The ones who never ask for a minute are the ones I keep an eye on. You asking is the healthy part."
4. "You did the job. Let that be enough for tonight."
5. "This outfit doesn't run on people who never need to stop. It runs on people who know when to."

**Elevated-Stress context:**

6. "You're wound tight enough I can hear it from the doorway. Sit down before you say anything."
7. "Whatever's chewing on you doesn't get solved standing at attention. Sit."
8. "I've watched good pilots run themselves into the ground insisting they were fine. I'd rather you weren't one of them."
9. "You don't have to tell me what it is. You do have to stop carrying it alone for five minutes."
10. "This isn't the room where you have to be squared away. Save that for topside."

## 3. Farewell / Goodbye — 8 lines

For ending a conversation / walking away, matching the same low-key register as the greetings — no big send-offs, no false cheer.

1. "Go on. I'll be here."
2. "Get some rest if you can find it."
3. "Come back down when you need to. I'm not going anywhere."
4. "Head up. Watch the deck plates near the hatch, they've been sticking."
5. "That's enough for today. Go."
6. "Door's open behind you too, for what it's worth."
7. "Don't make me come find you next time."
8. "Topside's waiting. So am I, whenever you're back."

## 4. Trigger shape — shipped, 1 September 2026 (later the same day), and it's simpler than the proposal below

**Update: this is no longer a proposal.** The three-hook design originally sketched here (a one-shot-per-visit Greeting reveal, an event-driven Farewell, a live-Stress-keyed Advice pull) didn't end up being how this actually shipped — the simpler, more general mechanism that was already being built for the *crew's* own Greeting/Farewell/Advice (see `Bloom_Wars_Crew_Greeting_Farewell_Line_Bank_v1.md` and `Bloom_Wars_Crew_Advice_Banter_Line_Bank_v1.md`) turned out to cover the CO too, with one small branch, rather than needing its own separate hooks. What actually shipped: the same typed-chat `detectSmallTalk()` recognizer the crew banks use (a player typing "hey," "bye," "any advice," etc.) routes to the CO's own bank instead of the shared catalyst pool whenever the nearest NPC in range is him specifically (`pilotId === CO_PILOT_ID`), with Advice keyed off his real live Stress value against `STRESS_PANIC_THRESHOLD` exactly as this section originally proposed. Greeting and Farewell are **not** one-shot-per-visit as originally sketched — they fire every time the trigger phrase is typed, same as the crew's own banks, a simplification made for consistency across the whole small-talk system rather than giving the CO a bespoke gating rule the crew banks don't have. Banter has no CO-specific content (this bank never covered it) and falls back to his own catalyst's crew banter as a deliberate stand-in, flagged in code.

**Live-verified for two of three via automation, and now confirmed for the third by Maxime directly, 1 Sep 2026.** Typing "hey"/"bye" to a crew NPC confirmed the underlying recognizer and routing machinery work correctly end to end (see the Master Index's "Chat small-talk wiring" section for the exact verbatim lines produced). The browser-automation session verifying this work couldn't get the player character within range of the CO in the grotto (a standing movement-automation limitation, unrelated to this feature) — but Maxime checked him directly in his own play that same day and confirmed he's working ("the guy in the grotto is okay"). That closes out the gap this section used to flag.

The original three-hook proposal text is preserved below for the historical record of what was considered before the simpler shape shipped:

- **Greeting** fires on the first Talk with the CO in a given Hub visit (mirroring how the existing rank-deference "Hello, Sir" reveal and the Stage "graduation" reveal are both one-shot-per-visit-or-per-event, not per-click).
- **Advice/Stress-relief** replaces the ordinary generic-ambient-pool line specifically when the player Talks to the CO — read the visiting pilot's own live Stress value the same way the Favorability/Stage badge already reads live campaign state, and pick from the calm or elevated half of the bank accordingly.
- **Farewell** fires on whatever "end conversation with the CO" event already exists for closing a Talk bubble (or, if none does yet, on walking a set distance away after a Talk — same shape `updateNpcRoaming`'s proximity checks already use elsewhere in Hub.ts).

## 5. Naming-lock safety check

No proper nouns invented in this bank at all — no place names, no faction names, no new characters. Checked against both known constraints: nothing here echoes or abbreviates "The Synker Wars," and nothing approaches the absolute reserved term, since there's no new vocabulary here to check in the first place — just dialogue in an already-established voice.

## 6. What this doesn't do — updated 1 Sep 2026, now wired

**Superseded: code has been touched.** `Hub.ts` no longer routes CO Talk through the generic catalyst ambient pool for Greeting/Farewell/Advice specifically — those three now use this bank via the mechanism in §4 above. He still falls back to the generic pool for the ordinary E-key Talk interaction and for anything outside these three chat-triggered categories (Banter, Worry-checkin), which this bank never covered. `Bloom_Wars_Antfarm_Carrier_Hub_v1.md` §11.3's own "no bespoke dialogue content" line and the Master Index's Antfarm Grid v0 section, both flagged as stale here previously, have now been corrected at the source to point to this bank and to the Master Index's own "Chat small-talk wiring" section.
