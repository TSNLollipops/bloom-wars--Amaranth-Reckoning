# THE BLOOM WARS — Character Visual Identity, concept pass v1

*Written 23 August 2026. Concept pass, not code — Maxime's own call, since the portrait half of this has nowhere to render yet (no hub screen exists). Scoped down from a much bigger ask (room navigation, a 50-character roster, a player-facing character creator) to just this: how a character reads visually, on the unit icon today and on a portrait eventually, using the same underlying markers.*

## 0. What this is actually answering

Two things got tangled together and are being pulled apart here:

1. **The near-term, concrete complaint:** "hiopi arent as different as other unit" — the species-outline system built earlier today (GDD §12's chassis encoding) doesn't make Hiopi read as visually distinct the way it makes Osnius read distinct. That's fixable now, cheaply, without new art.
2. **The long-term, explicitly-parked wish:** upgrading the whole visual engine toward a Red Alert: Aftermath-style look. Noted below in §4, not designed here — it's a different scope of project entirely and Maxime's own framing ("if possible") already treats it as aspirational, not a commitment.

The shared thread between the two questions in the scope check: whatever markers distinguish a species/chassis on the battle-map icon today are the same markers that would eventually distinguish that character's portrait once the hub exists — one identity system, two render contexts, not two separate things to design.

## 1. What's already built (GDD §12, implemented in `Battle.ts` this session)

Every unit's chassis gets one extra decorative pass on top of its base path-shape (blob/meeps/tank/reeps/munti) and faction fill:

| Chassis | Species (canon mapping) | Current treatment |
| --- | --- | --- |
| `bipedal` | Human | Nothing extra — plain silhouette outline only |
| `centauroid` | Hiopi | A second, wider outline ring traced ~2.5px outside the first |
| `bipedal_vibrissal` | Osnius | Two short tick-mark lines angled up and out from the top, reading as whiskers/antennae |

**Why the complaint is accurate:** whiskers are a *shape* addition — they change the silhouette's outline, something new and specific to look at. A wider ring is a *weight* addition — same silhouette, just traced twice. At tile scale (a few pixels of radius), a second ring reads as "slightly bolder line," not "different creature." Osnius got a real visual tell; Hiopi got a rendering nuance. That gap is real, not a perception issue.

## 2. The proposal — give Hiopi actual feet

Hiopi are canonically quadruped/centaur-built (Qiraki_Concept.md, locked: digitigrade legs, torso and forearms). The current wider-ring treatment doesn't reference that at all. Legs would.

**Construction, mirroring the whisker treatment structurally** (same grammar the vibrissal tick-marks already use, moved to a different anchor point):

```
// sketch only — not wired into Battle.ts, illustrative
} else if (unit.chassis === "centauroid") {
  const legLen = r * 0.5;
  const baseY = cy + r * 0.85;
  const spread = r * 0.35;
  g.lineStyle(1.5, 0xffffff, 0.85);
  // four short downward strokes, suggesting a quadruped stance
  [-1.5, -0.5, 0.5, 1.5].forEach(i => {
    const x = cx + i * spread;
    g.lineBetween(x, baseY, x + i * 2, baseY + legLen);
  });
}
```

Four short strokes fanning down and slightly outward from the base of the shape, same weight and confidence as the existing whisker ticks. At a glance: whiskers point up from Osnius, legs point down from Hiopi. Two species, two silhouette-breaking marks, same visual vocabulary, opposite anchor.

**Open call: replace the ring, or keep both?**

- **Replace** — legs are the whole treatment, ring goes away. Cleanest, matches the "one extra mark per chassis" pattern bipedal_vibrissal already set. Recommended.
- **Keep both** — legs plus the existing wider ring. Busier, and the ring wasn't doing much on its own, so it's unlikely to add real legibility now that legs exist. Worth trying only if legs alone read as too sparse once actually rendered.

## 3. Bipedal (human) — worth a look, not urgent

Human is currently the one chassis with *no* extra mark at all — plain silhouette, nothing added. That's arguably correct (human is the "baseline," everyone else deviates from it) rather than a gap, but it's worth naming as a deliberate choice rather than an oversight, since it wasn't stated as one anywhere in GDD §12. Not proposing to add anything here — flagging that "human gets nothing" should be a decision on record, not silence.

## 4. Red Alert: Aftermath — parked, not designed here

Maxime: *"i want to one day upgrade the vidual engine to look better. more like red alert affermath."* Worth being honest about what that actually implies before it becomes a line item anywhere: GDD §12.2's placeholder-geometric lock ("art is placeholder geometric shapes, not sprites," decided precisely because there's no art budget or artist) is the whole reason primitive-drawn silhouettes exist at all. A Red Alert: Aftermath-era look — actual sprite art, isometric-ish unit art, a real tileset — isn't a bigger version of today's system, it's a different system replacing it entirely: an art pipeline, actual assets (hand-drawn, generated, or licensed), and a rendering approach Phaser Graphics primitives were never meant to produce. That's the same scale of lift as the sprite/decor work this session was deliberately scoped *below* (see the Gemini prompt-kit conversation earlier — that was terrain/mood art, explicitly kept separate from the code-drawn unit-encoding system for the same reason).

Not saying no — saying this is its own future project, not a tweak to file alongside "give Hiopi feet." Worth its own scope conversation whenever it's actually time, same as everything else flagged this way in this project.

## 5. The portrait half — genuinely nothing to design yet

Confirmed in the scope check: portraits have nowhere to render into, since the hub screen doesn't exist in code. The only thing worth writing down now is the *principle*, not a spec: whatever markers end up meaning "this is a Hiopi" on the tile icon (legs, once built) should be the same markers a portrait uses later, scaled up, rather than a second, separately-invented visual language for the same species. That's a one-line rule to keep in mind when the hub actually gets built, not a design to finish today.

## 6. Open questions — your call

- **Replace the ring with legs, or keep both?** Recommended: replace. §2.
- **Human gets nothing — deliberate baseline, or does it deserve its own small mark too?** Leaning toward "deliberate baseline is fine," but flagging rather than deciding.
- **Leg count/spread/angle** — the sketch above is a starting guess (4 strokes, fanned), not tuned against how it actually looks at tile scale. Needs the same kind of visual check (synthetic preview harness, like the tier-pip/species-outline pass) once it's actually built.
- **Red Alert: Aftermath** — not a question to answer now, just flagging it's sitting there as a real future ask whenever the placeholder-geometric era is ready to end.

## 7. Build cost, honestly

This is small. If the "replace the ring with legs" call gets made, it's a same-shape change to `drawSpeciesOutline`'s existing `else if (unit.chassis === "centauroid")` branch in `Battle.ts` — no new files, no schema change, same sandbox-first / typecheck / test / screenshot-verify workflow already used for tier pips and defense stars this session. Cheap whenever you want it built.
