# The Bloom Wars — Foundation (the rules that don't change)

**What this is.** The settled ground for the game project: what's locked, what the reserved terms are, how balance is judged, where trust sits when two things disagree, and the process disciplines this project earned by breaking things. One of three levels — `Bloom_Wars_History.md` holds what's been built, `Bloom_Wars_Now_And_Next.md` holds current state and open work, and `Bloom_Wars_Master_Index.md` routes between them.

**Read this first, and read it whole.** It's short on purpose. If you're picking this project up cold, this file plus `Bloom_Wars_Now_And_Next.md` is enough to start working; History is reference, not onboarding.

**What belongs here.** A rule, a locked decision, a convention, a hard-won process discipline. Something that would still be true after another month of building. **What doesn't:** anything dated, anything in progress, any number still being tuned. If an entry here needs a "as of" qualifier, it probably belongs in one of the other two files.

**When a rule here changes,** change it here rather than adding a newer contradicting note somewhere else — that's the failure mode this whole split exists to fix. The old master index carried three different balance rules simultaneously, two of them retired, none of them marked as such in the places people actually read.

## Scope — two projects, one workspace

This project folder holds two entirely separate things: **The Bloom Wars**, a browser tactics game, and **Qiraki**, a book series. They share no canon obligations except the reserved names below and a handful of deliberate one-way lore borrows.

**This file covers the game only.** Everything else in the workspace — all `Qiraki_*` files, `Rune_Patterning_Primer.md`, `Cross_Project_Writer_Note.md` — is book material, indexed separately under `Qiraki_Master_Index.md`, and carries its own separate style guide and craft rules that are **not** meant to agree with the game's. Don't cross-apply them. Figure out which project a conversation is about and stay there.

The one genuinely shared rule is the naming lock, below. The one deliberate bridge is the cross-project borrowing policy, also below.

## Naming — one rename that trips people up

**"The Amaranth Reckoning" and "Warden Company" are the same 36-mission campaign.** It was renamed on 31 August 2026. Every doc dated 31 Aug or later says Warden Company; historical build-log entries from 25–29 Aug say The Amaranth Reckoning throughout, and those are deliberately *not* rewritten, because they're dated records of what was true and named at the time. Read them as the same thing wherever either name appears.

**House Amaranth is a different campaign entirely** — a separate, later, second 36-mission campaign that happens to share the word "Amaranth." It is not a rename of anything. When a doc says "Amaranth," check which of the three it means.

## The real current-state sources, in order of trust

When two things disagree, the higher-numbered one loses. This ordering is a rule, not a suggestion — it exists because this project has repeatedly caught docs claiming things the code contradicts.

1. **`src/data/campaignAmaranth.ts`** (in the repo) — the actual shipped mission data. This is ground truth; nothing else can contradict it. The same applies file-for-file elsewhere: the code is always above any doc describing it.
2. **`claude/build_log/README.md`** — the build history, split by act/mission/engine-system for navigability (see that file's own index). This is the doc to read for "what's actually done and how it was tuned," mission by mission or system by system. The original single-file running log, `claude/Bloom_Wars_Amaranth_Act1_Build_Log_v1.md`, is preserved unedited as the full chronological narrative archive (through Batch 7 / campaign complete) — the split structure is a synthesized index into it, not a replacement of its content; read the archive when you want the exact blow-by-blow, playtest quotes, and every intermediate tuning attempt.
3. **`claude/Bloom_Wars_Independent_Campaign_The_Amaranth_Reckoning.md`** — the campaign's own design doc: the full 36-mission outline, roster, rival, the Bloom's three new named threats (The Choir, The Wellroot, The Unnamed), the Heirloom pool, permadeath/Munti rules (§6a/§6b). Read this for *why* a mission is shaped the way it is.
4. **`claude/Bloom_Wars_Consolidated_Build_Plan_Progress.md`** — carries the Player AI round-4 / Playwright-verification work and the whole House Amaranth build history, for the 29 Aug – 1 Sep window the old index barely covered.
5. **A dated build-log addendum** (`claude/Bloom_Wars_Build_Log_Addendum_*.md`) — for the specific build it covers, the addendum is the authority over anything in the History doc, which is a synthesized index into these.

The 8 documents below (GDD, Data Pack, Build Brief, Canon Pass) are **not wrong** — the core engine rules they define (the class triangle, chassis layer, meks, Collapse rule, the Bloom Bestiary category system, Severance) are all still in force and reused by the Amaranth campaign per that doc's own §1. What's stale about them is the *campaign content*: the 4-mission Team One slice, its roster, and its Mission 3 wipe are archived, not current. Read the 8 documents for shared systems and mechanics; read the three sources above for what mission content actually exists today.

## The 8 documents (original vertical-slice handoff — mechanics still live, campaign content archived)

| Doc | What it is |
| --- | --- |
| **Bloom_Wars_GDD_v0.2.docx** | The Game Design Document. Vision and scope, the class triangle, the chassis layer, the Meks system, the Heirloom (Severance), mission objective types, the *original* 4-mission vertical-slice campaign (archived), art direction, the scenario-editor plan, and a decision log. Still the right read for how the shared systems work. |
| **Bloom_Wars_Data_Pack_v0.1.docx** | Companion to GDD §14. Every number: type schema, unit archetypes, the original Team One roster and meks (archived), mek track effects, abilities, combat/damage tables, the 7 pre-rolled Bloom archetypes, hostile mechs, the original 4 maps/missions (archived), the points economy, and the balance simulation output. |
| **Bloom_Wars_Build_Brief_v0.1.docx** | The handoff / build instructions. Four non-negotiable rules (the spoiler lock is still absolute and still enforced by `tools/lint-spoiler.mjs`), a 12-step build order, the test plan, naming/file-layout conventions. |
| **Bloom_Wars_Canon_Pass_v1.docx** | Resolves open items in the three docs above against the Qiraki source files — the original Team One roster corrections, real gear-tier names, real Bloom colour families. The colour-family *system* (Canon Pass §E) is reused for the Amaranth campaign's own new Bloom threats; the roster-specific content is archived with Team One. |
| **README.md** | Explains the three Python scripts (`combat_sim.py`, `maps.py`, `maps_amaranth.py`) used to validate the game's numbers and maps. All three of this README's own claims — two scripts plus the README itself — had gone missing from the actual repo at one point or another; all are restored now (see the History doc's "Design tooling" section). Both map scripts are superseded in practice by the live `npm run sim` harness (`src/sim/run.ts`) for actual gameplay balance testing. |
| **maps_generated.ts** | Auto-generated TypeScript for the original 4 validated Team One maps (archived). Regenerated on demand by `design/maps.py`; deliberately not committed to the repo, since a checked-in copy of a generated file that duplicates `maps.ts` is exactly the drift README.md warns about. |
| **sim_output.txt** | Console output of `combat_sim.py` — Data Pack §13 (archived numbers). |
| **maps_output.txt** | Console output of `maps.py` — the Team One map validation table. The 21 Aug 2026 original is frozen in the repo as `design/maps_output_reference_21Aug2026.txt`, which the rebuilt script byte-diffs itself against on every run. `design/maps_amaranth_output.txt` is the equivalent for all 36 Amaranth maps, from `maps_amaranth.py`. |

*Reading order for the shared systems: GDD → Data Pack → Canon Pass → Build Brief. For current campaign content: the Independent Campaign doc → `claude/build_log/README.md` → `campaignAmaranth.ts` itself.*

## Locked decisions

Still true for both the archived Team One slice and every live campaign. These are settled — reopen one deliberately, in conversation, not by drifting past it in a build.

- **Web-first**: TypeScript + Vite + Phaser 3. Steam port later, Electron-packaged Windows download for Early Access.
- **Meks are Option B** — passive, one per pilot, never on the board.
- **Class triangle**: Meeps > Reeps > Tank > Meeps.
- **Full-HP damage cap of 90.** Severance is the sole exception.
- **Art is placeholder geometric shapes, not sprites** (GDD §12.2). "Polished" means composition and motion, never illustrated art, until that constraint is deliberately lifted.
- **Silhouette encoding is meaning-bearing**: a player unit's combat path determines its shape (GDD §12.1), and a Bloom unit's `movementType` determines its silhouette family (swarm/burrow/sessile/flight/limbless). Colours and shapes here are a language, not decoration — don't reassign one casually.
- **Permadeath is live, not scripted.** Mission 3's scripted extraction-failure wipe is a Team One-specific, archived beat. Every live campaign uses the real rule instead (Independent Campaign doc §6a): a living Munti anywhere on the field means a downed pilot restocks; no living Munti means the loss is permanent. Rourke is the single documented exemption.
- **Ironman is the default** on a new campaign — one save, no rewinding — with manual slots available only if the player unchecks it at creation.

## Balance philosophy — corrected 4 September 2026, read this before citing any win-rate number

This has been revised three times and the older versions are still quoted in older docs. This is the live version.

**The AI is not supposed to win. The batch sim exists to catch cheese, not to hit a difficulty target.** Maxime, 4 Sep 2026, verbatim: *"Ai arent really suposed to win the mission btw. Ai test are to see if mission is cheesable."* The bot is a hand-written heuristic stack standing in for a tester, not a yardstick a mission's difficulty should be tuned against. A mission the AI loses 0/100 at every tier including Hard is not automatically broken — it means the bot couldn't find a way through, fair or unfair, which is not evidence of anything on its own. What a batch run is genuinely for is spotting a win that came from something that doesn't look like real play: a chokepoint the AI can stack, a spawn pattern it can bait, a positional trick that trivialises a fight meant to be real.

**Retired, do not cite as the working rule:** the per-mission target-band table in `Bloom_Wars_Player_AI_Difficulty_Tiers_Plan_v1.md` §6 (Openers 80-95% on Moderate, and so on). It was informally run on from 2 Sep and was built on the wrong premise; that doc's §6 now carries its own correction note.

**Still standing, with a caveat:** the ≤15% ceiling (31 Aug — "if ai win more than 15% of the time, the map is too easy") is an *upper bound*, which stays consistent with "the AI isn't supposed to win." It was calibrated against the old `LEGACY` bot and has never been re-anchored to the tiered bots, so whether it's still the live numeric check is genuinely open — worth asking only if it comes up naturally.

**The real difficulty target is human-facing, not a win rate at all.** Maxime, 4 Sep 2026: *"i should genuinely feel like im about to wipe at any moment or im not hitting the same itch as xcom."* In numbers: late game, if the player isn't losing more than 5 units a mission it's too easy; early game, the player should be forced into at least one restock per mission. The named lever is more spawns campaign-wide, deliberately, once EA's other work is further along. Full note, including the two terms that still need pinning down ("lose" = downed or permanently lost; "restock" = Beacon Control specifically or any Munti save): `claude/Bloom_Wars_Difficulty_Feel_Target_WipeTension_04Sep2026.md`.

**Warden Act I tuning is Maxime's, not Claude's.** Missions 1, 7, 12 and 21 read as unwinnable or near it at every AI tier. That is off the build queue by his own explicit call — *"Missions issue are mine to deal with. I will personally tune each of them but later."* Not an open Claude task, not a launch risk to keep re-raising. Helping when he starts is a normal ask at that point; it starts from him.

**The house rule that outranks all of the above:** a balance number or a map only counts once it has been run through `design/combat_sim.py`, `design/maps.py`, or `design/maps_amaranth.py` and passed. Never hand-edit `maps_generated.ts` — edit the source and regenerate.

## Naming lock (shared with the book project — the only real coupling)

One reserved term (defined in the Build Brief, deliberately not written in any of these docs — enforced by a build-failing lint rule, `tools/lint-spoiler.mjs`, not by convention) must never appear anywhere in the game's code, comments, filenames, or UI strings. A second term — the book series' own military-arc name — is separately reserved and also must not surface as a game-facing string.

**This applies to every campaign, not just the archived Team One slice, and it has no partial form.** A shortened or informal version of a reserved term is still the reserved term — that exact reasoning ("dropping part of the name makes it clear of the lock") produced a real slip on 29 Aug 2026, caught in code comments and a plan doc before it reached any player-facing string. The only permitted appearance is a comment that names a term while explaining the lock policy itself, which is describing the rule rather than using the term as game vocabulary.

## Cross-project references

The GDD and Data Pack pull one-way inspiration/verification from a few Qiraki documents (checked as of the 21 Aug canon pass — see that document for the full list: Military Era Outline, Bestiary, Bioterror Bank, Points Shop Catalog, Rune Tech Reference). They are **not** Bloom Wars files and remain indexed under `Qiraki_Master_Index.md`. The Amaranth campaign reuses the same Bestiary/Bioterror Bank systems (see the Independent Campaign doc §1, §8) rather than re-deriving them.

**Policy, set 26 Aug 2026 — this is deliberate shared-universe borrowing, not accidental overlap, and it's the standing default rather than a per-case exception.** Species (Hiopi, Osnius, Carabil) and their established biology/culture have been fair one-way inspiration since the 21 Aug Canon Pass. Maxime extended that on purpose, verbatim: "we are already using the species name... this is gonna be canon at some points. so might as well have fun on it. im afterall really gonna share the book. and the game. for my own sense of completeness." Both properties are meant to connect as canon eventually and are both going to be shared publicly, so leaning into real Qiraki texture on purpose — for a concrete functional system like the in-fiction calendar, not just flavor lines — beats keeping the game artificially generic. **The one condition that doesn't change, his own words: "I want both clearly not conflicting."**

**What this doesn't touch.** The naming lock above is unaffected — both reserved terms stay hard-blocked, lint-enforced, and unrestated in any doc.

**How to apply it going forward.** Verify any specific Qiraki fact against the actual file before using it, not memory. When something reads close to a locked term but isn't confirmed as it, flag it and substitute a Bloom Wars-native equivalent rather than guess — the Gladiator rank-ladder entry in `Bloom_Wars_Spitball_Ideas.md` already did exactly this once, redacting a Qiraki-side command term mid-conversation and using the game's own "Seal and the Sword" concept in its place. And keep consistency in view both ways: a fact pulled from Qiraki into Bloom Wars should still read true if a reader ever holds both properties side by side.

## Working rules — the process disciplines this project earned the hard way

Each of these exists because something actually broke. They're listed here rather than re-derived every session.

- **Verify against the actual current file, never memory or an older plan.** Carried over from `Cross_Project_Writer_Note.md`. This has caught real doc drift repeatedly — a roadmap's own entries marked "Not built" for features that had shipped, a build-log win rate stale by 17 points, a "missing" colour palette that was already in the code.
- **After an edit, check what's sitting immediately around it.** Fixes break neighbours more often than expected, even when the fix itself was correct.
- **A clean test run is not proof the build matches its spec.** On 28 Aug 2026 a batch shipped, tested clean, and still diverged from its own written spec in five load-bearing ways — caught only by deliberately re-reading the spec against the shipped code afterwards. Reading a spec and applying it are two separate steps.
- **Re-read a file fresh immediately before editing it, and drift-check before committing.** This repo has documented cross-session collision risk: an `index.ts` overwrite, a mid-session edit to a plan doc's own file, a silently reverted `Battle.ts` batch. All caught, none silent — because of this rule.
- **Pulling a fresh on-device copy of a file this session has already edited overwrites the edit.** `device_stage_files` into the same sandbox path is a replace, not a metadata refresh.
- **A session's connected folders are bound at conversation start.** A folder added mid-conversation is invisible to that conversation no matter how correctly it was added — which looks exactly like the add failing. Start a new conversation before judging whether it took.
- **Flag scope growth before building it.** A new system, a new content type, a structural rework — say so, name the tradeoff, let Maxime decide. Placeholder numbers get labelled as placeholders in the code itself, not silently shipped as settled.
- **Say which doc a chat decision makes stale.** When something decided in conversation contradicts the GDD, Data Pack, or Build Brief, name the doc.
- **Design decisions made on Claude's own judgment get attributed as Claude's, not Maxime's** — in code comments and in the History doc both, so a future session can tell an approved decision from a reasonable guess.

## Repo layout

Unchanged — see GDD §2.1 / README "Where they go". The live campaign's own mission/map data lives in `src/data/campaignAmaranth.ts` and `src/data/mapsAmaranth.ts`, parallel to (not replacing) `src/data/campaign.ts`/`src/data/maps.ts`, which hold the archived Team One slice.

**On-device path.** The repo lives at `F:\The Bloom wars. Code project\bloom-wars\bloom-wars` on Maxime's machine (`lorian-pc`). The folder connected to a session is the grandparent, `F:\The Bloom wars. Code project` — so **a session's connected root is not the repo root; append `\bloom-wars\bloom-wars`.**

**Verification gate before any commit:** `npx tsc --noEmit`, `node tools/lint-spoiler.mjs`, `node tools/lint-cast-collision.mjs`, `npx eslint .`, `npx vitest run`, `npx vite build`. Plus `npm run sim` / `sim:social` / `sim:gate` where the change touches those systems.

## Build log structure

The build history is split for navigability: `claude/build_log/README.md` is the index, with `act1/`, `act2/`, `act3/` (one file per mission) and `engine_systems/` (one file per cross-cutting mechanic — Player AI, permadeath/commander-down, the mission clock, bonus objectives, civilian extraction, Taunt/Fire Support, ability depth/targeting AI, walking animation, squad/deploy structure, house rules). Each split file is a concise synthesis with a pointer back to the archive's own section for full narrative detail. The original single-file log, `claude/Bloom_Wars_Amaranth_Act1_Build_Log_v1.md`, stays in place unedited as the permanent archive — kept specifically for archival purposes even though it won't ship with the game.

**Per-build records** go in a dated `claude/Bloom_Wars_Build_Log_Addendum_<Thing>_<DDMonYYYY>.md`. That addendum is the authority for its own build; `Bloom_Wars_History.md` carries a synthesized entry pointing at it.
