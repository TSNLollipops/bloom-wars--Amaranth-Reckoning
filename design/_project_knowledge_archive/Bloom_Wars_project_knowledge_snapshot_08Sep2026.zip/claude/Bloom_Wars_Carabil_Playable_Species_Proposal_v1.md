# THE BLOOM WARS — Carabil as a Player-Makeable Species: Proposal, Not Decided

**Design pass only, zero code — same status `Bloom_Wars_Stress_Morale_Trigger_Proposal_v1.md` and `Bloom_Wars_Bloom_Silhouette_Doctrine_Proposal_v1.md` carried before Maxime's own sign-off.**

*27 Aug 2026, same session as the Antfarm Grid v0 stress test and the grotto's Carrier CO (Arangement of Content) shipping. Maxime, immediately after: "gonna have to let player make carabil too. in the characters editor. look up canon info about carabil. see what you can do."*

---

## 1. Canon, pulled straight from the Qiraki files

Read fresh against `Qiraki_Bible_Skeleton.md`, `Qiraki_Character_Sheets_v5.md`, `Qiraki_Concept_v4.md`, `Qiraki_Physical_Description_Bank.md`, and `Qiraki_Military_Era_Outline_v3.md` — not from memory. Species-level facts only below; Coherence of Process's own personal backstory and the COE's political/accession history are deliberately left out (see §2).

**Physiology.** Lithoid — crystal/mineral physiology, semi-transparent, glittering internally. No two Carabil look alike; color is personal aesthetic choice (not biology-fixed), ranging the full visible spectrum, and can shift over a long timescale "the way a person redecorates." No face, nothing that reads as an expression in any human sense — "tone" lives entirely in how the internal glitter moves (slow constellations, denser and faster during a crisis, near-still when calm) and in voice cadence, which carries a resonance "like it's arriving from slightly inside a large empty room even in open air."

**The ship-bond — the single most load-bearing fact.** Carabil are grown INTO a ship from the start, not merely piloting a separate body the way a mek pilot pilots a mech. Their connection to the ship is immersive and constant, felt as an extension of their own nervous system, spread across a much larger structure. They don't feel pain from ship damage, but they do feel *lesser and weaker* — a real, felt diminishment. When a Carabil releases their full mech complement, they feel a rush of emptiness first, then their senses expand outward to include what each deployed mech's sensors are feeding back.

**Cognition.** "Longsight" is the species' own term for their long-horizon strategic cognition, tied to a collective/networked mind. Ship-piloting specifically requires deliberate separation from that collective — trained for years, voluntary, most often chosen by young "sprouts" (the species' term for juveniles) seeking a bounded, tethered solitude: "alone yet not."

**Naming convention.** Abstract process/concept phrases rather than personal or family names — "Coherence of Process" is the founding example. Reflects the species' whole cognitive orientation: identity expressed as a function within a system, not a self set apart from one. This is the one piece already live in Bloom Wars (Arangement of Content's name follows it).

**Communication.** Carabil use an AI-assisted translator to bridge the real conceptual gap between "instant" and "now" when talking with species that don't share their time-perception.

## 2. Deliberately left out of game material

The COE accession/political history (negotiated joining, "no FTL of their own," civil-stabilizer origin scaling into carrier-command), the open author-lane question of whether Carabil's "true history" is suppressed knowledge in-world, and Coherence of Process's own specific personal description and mentor arc with Trav — none of that is generic species texture, all of it is Qiraki's own plot/political material. Reusing the *species mechanics* above already has precedent (Hiopi's centauroid chassis and reproductive culture already inform Bloom Wars; the naming-lock's own reserved term is unrelated to any species name — confirmed earlier this project). Reusing the *political history* would be pulling actual book lore into game material with no doc flagging it as a deliberate cross-reference, which the project's shared rule exists to prevent.

## 3. The real fork this creates

Take the ship-bond fact at face value and "let the player make a Carabil pilot" doesn't have an obvious answer — canon Carabil don't have a separate, individually mobile body to put in a mek at all. They *are* the ship, the same underlying idea Arangement of Content already represents in the grotto right now. Three honest directions, none picked here:

**A — Reskin.** Carabil becomes a selectable species in the character editor with a new lithoid/crystal chassis, mechanically identical to any other pilot — same four paths, same archetype stats, just a different look and a naming-convention hint in the generator. Cheapest by far: one new chassis, some UI, no new game systems. The explicit tradeoff: a Carabil pilot climbing into a mek and getting shot at is a real, visible departure from "grown into a ship, no separate body" — worth naming as a deliberate simplification, not slipping past unlabeled.

**B — Canon-faithful, not a roster pilot at all.** A player-made Carabil isn't deployable — the character editor instead lets the player design their *own* ship's bonded commander, a second Arangement-of-Content-style figure, structurally a Hub character rather than a combat one. Truest to the source material, but it answers a different question than "let player make Carabil too" seems to be asking — it's a new content type (a custom-CO creator), not a new roster option.

**C — A real ship-bond path.** Carabil become a genuinely different fifth path/archetype family — reframed at a smaller scale (bonded to a single mech or a small drone swarm rather than a full carrier) so they can deploy without literally contradicting "grown into a ship," carrying real canon flavor (lithoid, faceless, Longsight-flavored abilities) into actual combat stats and a new ability kit. Most faithful of the two deployable options and the most game-interesting, but the biggest lift: a new path needs its own chassis, ability set, balance pass against the existing class triangle, and sprite/visual treatment (same category of work Hiopi's own bespoke centauroid chassis already needed, per `Qiraki_Visual_Reference_Bank.md`).

**My honest lean, not a recommendation to just proceed on:** A is cheap and gets "you can pick Carabil" into the editor fast, but it's a real, worth-naming step away from what makes Carabil interesting. C is the version that actually earns "let player make Carabil" as new content rather than a new paint job, at real engineering cost (new path, new abilities, new balance pass, new chassis art). B is the most book-faithful but doesn't really deliver what the request sounds like it's asking for.

## 4. Explicitly not decided here

Which of A/B/C (or a fourth option not listed) Maxime actually wants; if C, what the ship-bond path's kit/stats should be; how the character editor's own naming generator would produce abstract-process-phrase names on demand; whether a player-made Carabil is automatically non-romanceable the same way Arangement of Content is (Antfarm §13: "anything but Hiopi/Carabil"); and whether this touches the Character Editor doc (`Bloom_Wars_Character_Editor_v1.md`) directly or stays proposal-only until a direction is picked.

## 5. Decided, 27 Aug 2026 — B, with a path to C

Maxime, verbatim: *"b. with path opening to c so player can swap co role with other character as needed in the editor."*

Read plainly: build toward B — the character editor's "make a Carabil" flow produces a ship-bonded CO character, not a deployable roster pilot — but the CO post itself isn't permanently fixed to one hardcoded instance the way Arangement of Content is today. Whoever holds the Carrier's CO post should be swappable: build a Carabil in the editor, install them into the CO slot "as needed." "Path opening to C" means this shouldn't be built in a way that forecloses a later ship-bond archetype that can actually deploy — the same character record should be able to grow a combat kit later without a rebuild.

**The concrete mechanism this implies — my own proposal for how, not yet confirmed in detail:**

- **A CO is data, not a hardcoded object.** Today Arangement of Content is a single hand-built `HubNpc`, assembled inline inside `buildNpcs()` — fine for a fixed cast of one, wrong the moment more than one Carabil could hold the post. This wants its own small record type — call it `CarabilCoRecord` for now, separate from both `PilotRecord` (roster pilots) and the ad hoc object Arangement of Content currently is: `{id, displayName, visualSeed (glitter-color token, not portrait art — matches "no two individuals look alike, color is aesthetic choice"), createdAt, isNamed (true only for Arangement of Content himself)}`. Bare-minimum today; also the exact seam Option C would extend later with real stats and an ability kit, without touching how the CO's Hub presence works.
- **One post, one occupant, tracked in campaign state.** A single pointer — e.g. `campaignState.carrierCoId` — names whichever `CarabilCoRecord` currently holds the post. Defaults to Arangement of Content's id at campaign start, so nothing changes for a player who never touches this system. `Hub.ts`'s `buildNpcs()` looks up whoever that pointer currently names and seats them in the grotto, instead of hand-building Arangement of Content specifically — the CO's Hub behavior (walk-up-and-talk, stationary, non-roaming, generic ambient pool) becomes generic over "whichever Carabil is currently CO," not one-off code.
- **The swap is a Hub action, not just an editor toggle** — installing a player-built Carabil as CO happens from inside the grotto itself, a real in-fiction moment (relieving/replacing the ship's bonded commander), which flips `carrierCoId` and re-seats the single CO slot.

**Open, worth a quick answer before this gets scoped for real:**

- Does swapping remove Arangement of Content, or park him — gone for good (retired/reassigned off-screen), or benched and re-installable later? Decides whether `CarabilCoRecord`s need a real roster (plural, parked) or just an active/inactive pair.
- Any cost or gate on swapping, or free and instant whenever the player wants? "Relieving your ship's bonded commander" feels like it might want to mean something — a Favorability/Stress consequence, a one-time story beat — rather than a free menu toggle, but that's a real call, not assumed here.
- Exactly one CO post, ever — matches "the Carrier," singular — or could there be more than one active at a time? This proposal assumes one; a player building a second Carabil would be building a future candidate for the post, not a second simultaneous CO. Worth confirming before the data model locks around that.

**Status: still design only, no code.** The Character Editor itself isn't built yet either — `pilot_creator.html` is a disconnected sandbox prototype and `Bloom_Wars_Character_Editor_v1.md` is design-only — so none of this is close to buildable in isolation. This section exists to get the CO-swap decision on record now, ahead of that editor work, not because it's next in the build queue.
