# THE BLOOM WARS — Canon Verification Pass v1

*Resolves the open items flagged in GDD v0.2, Data Pack v0.1, and the Build Brief v0.1, now that the Qiraki source files are attached to this project. A formatted .docx of this same content was delivered to Maxime directly — this is the project-durable text version for future sessions.*

| Field | Value |
| --- | --- |
| Version | v1 |
| Date | 21 August 2026 (§E addendum added 28 Aug 2026 — see note at end of that section) |
| Companion to | Bloom_Wars_GDD_v0.2.docx · Bloom_Wars_Data_Pack_v0.1.docx · Bloom_Wars_Build_Brief_v0.1.docx |
| Sources cross-checked | Qiraki_Military_Era_Outline_v3.md · Qiraki_Session_Locks_Addendum.md · Qiraki_Character_Sheets_v5.md · Qiraki_Bible_Skeleton.md · Qiraki_Defect_Queue_v2.md · Qiraki_Concept_v4.md · Qiraki_Points_Shop_Catalog.md · Qiraki_Weapons_And_Progression.md · Qiraki_Bioterror_Bank_v2.md · Qiraki_Bestiary.md · Qiraki_Technobabble_Glossary_v2.md |
| Status | 10 of 10 porting-checklist items resolved with a cited source or a direct decision from Maxime. Nothing left open. |

**How to use this document.** Each section below targets a specific section of an existing Bloom Wars doc (cited at the top of the section) and gives replacement text/tables/TypeScript ready to drop in, per this project's own "merge new canon into existing documents, don't append" rule.

---

## A. Team One roster — species and chassis

**Targets:** Data Pack §4 (table + §4.2 TypeScript) · GDD §10 roster references · Build Brief §7 row 2

**RESOLVED.** Four of the five pilots were already right by coincidence. One is wrong: Fracrals Thyns is Hiopi, not human.

### A.1 What the source actually says

Qiraki_Military_Era_Outline_v3.md's "PART B — ROSTERS, CORRECTED" (confirmed in Qiraki_Session_Locks_Addendum.md and Qiraki_Character_Sheets_v5.md):

| Pilot | Species | Path | Note |
| --- | --- | --- | --- |
| Fracrals Thyns | Hiopi, male | Tank (squad boss/CO) | Quadruped, centaur-built. Tachyon beam, overshield generator. |
| Derek Barasj | Human, dwarf, cybernetic arms | Munti | Loyal, energetic. |
| Hiro Nagori | Human | Meeps | Conspiracy-theorist flavor. |
| Yren Tourignie | Human, female | Reeps | Joins mid-Mission 1 as reinforcement, stays on. |
| Trav (Trav Calder) | Human | Meeps | Player-facing lead. |

### A.2 The one real fix

Qiraki_Bible_Skeleton.md: Hiopi = "quadruped, centaur-built, frog/lizard hybrid" → the game's centauroid chassis.

- archetypeId: `arch_tank_bipedal` → `arch_tank_centauroid`
- species: `human` → `hiopi`
- Stat delta: HP 105 → 100, gains the "charge" ability alongside overshield, picks up the centauroid rubble/structure/ridge movement penalty (§7.3). Thyns' Tank archetype moves exactly 3 tiles — exactly the charge ability's ≥3-tile threshold, so the squad boss can now trigger a ×1.25 charge hit on a clean approach. Worth a look in playtesting.

### A.3 Is anyone Osnian?

No. Team One is 4 human, 1 Hiopi, 0 Osnian. The vibrissal-chassis sensor is never available to this roster; burrow detection depends entirely on the Runemaster mek track (Nagori + Tourignie), exactly as Data Pack §4.1 already reasoned. No rebalancing needed.

### A.4 Corrected TypeScript (Data Pack §4.2)

```
export const PILOTS: PilotRecord[] = [
  { id: "pilot_thyns",     displayName: "Fracrals Thyns",
    archetypeId: "arch_tank_centauroid", mekId: "mek_thyns",     tier: "G" },
  { id: "pilot_barasj",    displayName: "Derek Barasj",
    archetypeId: "arch_munti_bipedal",   mekId: "mek_barasj",    tier: "G" },
  { id: "pilot_nagori",    displayName: "Hiro Nagori",
    archetypeId: "arch_meeps_bipedal",   mekId: "mek_nagori",    tier: "G" },
  { id: "pilot_tourignie", displayName: "Yren Tourignie",
    archetypeId: "arch_reeps_bipedal",   mekId: "mek_tourignie", tier: "G" },
  { id: "pilot_trav",      displayName: "Trav",
    archetypeId: "arch_meeps_bipedal",   mekId: "mek_trav",      tier: "G" },
];
// All five confirmed against Qiraki_Military_Era_Outline_v3.md Part B,
// Qiraki_Session_Locks_Addendum.md, and Qiraki_Character_Sheets_v5.md.
```

---

## B. Mek names

**Targets:** Data Pack §4.2 MEKS record · GDD §6 · open item #2/#3 in the Build Brief and Master Index

**RESOLVED — but not the way the open item expected.** There's no source to "fill in": canon has no individual mech names at all. A "Mek" is the mechanic (the person — what Reqa does for Trav); mechs (machines) aren't individually named. Qiraki_Technobabble_Glossary_v2.md locks this: "'Mek' is the mechanic role, the person... 'Mech' is the machine itself... Never interchange them." Named mechanics exist (Reqa, Denna Ashworth, Alina Firemoss); named mechs don't.

So the possessive placeholder style ("Thyns' Mek," "Barasj' Mek") is already the in-fiction-accurate form. Recommend closing as final, dropping the "placeholder" comment in Data Pack §4.2.

### B.1 A naming collision worth flagging, not fixing

The game's MekArchetype uses "mek" for the piloted support system (the machine's loadout) — the opposite of canon's locked Mek=person/Mech=machine rule. Not a bug: GDD §6.1 quotes Maxime's own design decision verbatim. Flagging so it's a conscious choice, not silent drift. If ever worth aligning: rename the game's system to "Loadout"/"Support" and reserve "Mek" for a possible future feature (Reqa or an equivalent named mechanic appearing in dialogue/debrief text). Not changed in this pass.

---

## C. Mission 3 — who is lost to extraction failure

**Targets:** Data Pack §11.4 (the one real blocker) · GDD §10.4 · Build Brief §7 row 1

**RESOLVED — this is the one that actually blocked step 12.** Trav is the sole survivor. Thyns, Barasj, Nagori, Tourignie are lost to extraction failure.

### C.1 The source, verbatim

- Qiraki_Concept_v4.md: "Trav is the sole survivor specifically because he felt the sessile organism's presence before walking into its range, unlike his teammates, who didn't notice."
- Qiraki_Defect_Queue_v2.md DEC-18/DEC-19 (RULED): "Team One's wipe at the sessile tomb is caused by extraction failure, the one condition the locked battlefield-medicine rule allows to actually kill someone." The sessile-tomb and volcanic-grotto missions are the same event, merged.
- Qiraki_Military_Era_Outline_v3.md, "C3. Mission 3 — the sessile tomb, and the end of Team One": "Team One ends here, to extraction failure... The squad's last transmission: 'Data sent.' Trav gets one week of rest and grief before he is issued another team."

### C.2 Corrected TypeScript (Data Pack §11.4)

```
{
  id: "ev_extraction_failure",
  trigger: { type: "objective_complete" },
  action: { type: "remove_from_roster",
            unitIds: ["pilot_thyns", "pilot_barasj",
                      "pilot_nagori", "pilot_tourignie"] },
  once: true,
}
// pilot_trav is deliberately absent — he is the sole survivor.
// Source: Qiraki_Concept_v4.md, Qiraki_Military_Era_Outline_v3.md §C3,
// Qiraki_Defect_Queue_v2.md DEC-18/DEC-19.
```

### C.3 The downstream decision this unlocks — RESOLVED, Maxime's call

**Decision (21 Aug 2026): points invested in a pilot are lost with that pilot. No carry-forward, no debrief refund.**

Maxime's framing: gear-tier spend is per-pilot investment, same shape as XCOM's soldier ranks/upgrades — it belongs to the individual, not a shared pool, and losing the individual costs the investment along with them. This is a deliberate difficulty choice: the game is meant to be "just as demanding" as that comparison implies. It also matches Data Pack §12.3's existing incentive (bonus points for "no pilot downed"), so this was already the direction the scoring was leaning.

Practical effect on Data Pack §11.4 / the debrief screen: no special-case logic needed to bank points back. `remove_from_roster` simply drops the pilot (and their PilotRecord, including its `tier`) from the active roster; whatever was spent getting that pilot from G to their current tier is gone with them. The debrief should say so plainly (something like "gear invested in a lost pilot is not recovered") rather than staying silent — silence is what would make it read as a bug per GDD §10.4's original concern, not the loss itself.

**Status: closed.** GDD §10.4 and Data Pack §12.3 can drop the "open — needs your call" framing; §12.3's bonus row is now doing double duty (rewards caution, and stakes the tier investment on it).

---

## D. Gear-tier display names, per path

**Targets:** GDD §4.4 (new subsection) · Data Pack §12.1

**RESOLVED.** Qiraki_Points_Shop_Catalog.md names every tier of every path, G through A. Display strings only — they attach flavor to the existing universal G–A stat ladder, no new stats or slots.

| Tier | Meeps | Tank | Reeps | Munti |
| --- | --- | --- | --- | --- |
| G | Stocklance | Blockshield | Popgun | Quickfix kit |
| F | Heavylance | Wallpanel | Burstrifle | Longarm |
| E | Twinlance | Skinshield | Twinburst | Farfix |
| D | Pairblade | Groupshield | Longeye | Lifebox |
| C | Arcblade | Maserline | Farmark | Quickbox |
| B | Flareblade | Tachlance | Twinmark | Widefix |
| A | Stormblade | Bastion | Skyline | Overcharge |

(Meeps column follows Trav's own blade-branch; a lance-branch fork exists in the source too as an alternate Meeps flavor set.)

### D.1 Points-shop costs — recommend keeping the game's own numbers

Real catalogue cost bands (a 7-year academy-to-military career economy): G 150–300, F 400–800, E 1,200–2,500, D 3,000–6,000, C 12,000–20,000, B 40,000–70,000, A 150,000–250,000.

**Recommendation, not a fix:** don't convert directly — different currency for a different story length. Each real-world grade costs ~2.5–3.6× the one before; the game's own ladder is deliberately flat (~×1.5/step, an already-simulated design choice, per GDD §4.4). Keep the flat curve. Treat the real bands as lore-flavor context only.

---

## E. Bloom colour families

**Target:** Data Pack §8.4 colorPalette values

**RESOLVED, with a caveat.** Qiraki_Bioterror_Bank_v2.md has no fixed lookup table — it's generative (roll/pick 1–2 palette families, 2–3 colors, deliberately mismatch color against role). What follows is a real first application of that system, freely re-rollable.

| Creature | Palette (hex) | Families used | Why |
| --- | --- | --- | --- |
| Crawlmass | #B7B4AE, #DCD9D2, #7A2430 | Ashen/bleached + Wet viscera outlier | Swarm chaff reading half-drained, one old-wound fleck. |
| Splitfang | #3DDCFF, #F2E63D, #8A4A2A | Bioluminescent wrongness + Chitin outlier | Pack-hive glow instead of expected claw-brown. |
| Undertow | #1A1A24, #3A2E4A, #A97C4F | Deep-void iridescence + Chitin outlier | Reserved "expensive" palette spent on the burrow ambusher. |
| Sporethrower | #8A867E, #DCD9D2, #C24D63 | Ashen/bleached + Wet viscera outlier | Drained chassis around one wet launch gland. |
| Gallcyst | #6B4358, #4A2E3A, #B4FF3D | Necrotic bloom + Bioluminescent outlier | Necrotic fits the Bank's sessile pairing; glowing acid gland as "don't touch" cue. |
| Sirenmaw | #D9CBB0, #A97C4F, #3DDCFF | Chitin/mineral + Bioluminescent outlier | Dry matte flier, glowing throat-sac (sound organ). |
| The Heartwood | #1A1A24, #5C4A78, #6B4358 | Deep-void iridescence + Necrotic outlier | Named boss earns the Bank's reserved high-tier palette. |

Implementation note: the Bank wants swarm-type creatures (Crawlmass, Splitfang) to vary color per unit/cluster, not be uniform. Current schema has one static palette per archetype — a nice-to-have for the renderer (2–3 variants rolled at spawn, or a jitter function), not required for the placeholder pass.

### E.1 Addendum, 28 Aug 2026 — the three Independent Campaign archetypes, added after this pass originally shipped

The table above covers only the Data Pack's original seven. Three more Bloom archetypes were added later, for the 36-mission Amaranth Reckoning campaign (`Bloom_Wars_Independent_Campaign_The_Amaranth_Reckoning.md`) — Choir (Act I), Wellroot (Act II boss), and the Unnamed (Act III final boss) — and this section was never updated to record their palettes, which is why the Bloom Silhouette Doctrine proposal (`Bloom_Wars_Bloom_Silhouette_Doctrine_Proposal_v1.md`, §5/§6) flagged "no locked colour palette" for all three as of 27 Aug 2026 as still-open.

**That flag is now stale — the palettes exist and shipped in code, they just were never written up here.** `src/data/bloom.ts` (checked directly tonight, 28 Aug 2026, against the live device repo) has real, non-placeholder `colorPalette` values on all three, each with its own derivation comment in the source rather than a fresh Bioterror Bank roll — recorded here for the first time so this section stays the complete reference, not just the original seven:

| Creature | Palette (hex) | Lineage / derivation |
| --- | --- | --- |
| The Choir | #D9CBB0, #6B4A8A, #3DDCFF | Descends from Sirenmaw (Chitin/mineral + Bioluminescent outlier) — keeps Sirenmaw's dry base tone (#D9CBB0) but swaps the earth accent for a violet one, reading as the same family made audible/coordinated rather than solitary. |
| The Wellroot | #2A1F14, #5C6B2E, #9ACD32 | Deliberately Gallcyst's lineage (acid weaponType/onHit), not Heartwood's, despite reusing Heartwood's escalation-curve stat shape — a new dark-soil-and-toxic-green palette distinct from Gallcyst's own necrotic-bloom family, fitting "a sessile hive-node rooted into House Amaranth's terraces." |
| The Unnamed | #0D0D14, #7A3AA0, #8B1E3F | Descends from Heartwood (Deep-void iridescence + Necrotic outlier) — darker void base (#0D0D14 vs. Heartwood's #1A1A24) with a purple/crimson accent pair, reading as an escalated, more corrupted version of the same lineage rather than a new family. |

Not a fresh application of the Bioterror Bank's generative system the way the original seven were (no re-roll happened) — these were designed directly against their lineage archetype's existing palette, which is a reasonable and consistent approach but worth being honest is a different provenance than the table above. All three are already wired into the live renderer per the Silhouette Doctrine doc's own §7/§8 (shape families apply mechanically via `movementType`; only the palette was the missing piece, and it isn't missing anymore).

**Still genuinely open:** the render-size/tile-footprint rule (Silhouette Doctrine §5) and swarm cluster color variation (§3 of this same section, above) — neither touched by this addendum.

---

## F. Bestiary vocabulary — already correct

**Target:** Data Pack §2 BloomArchetype type · GDD §5.1, §7

**CONFIRMED, no change needed.** The BloomArchetype enums (weaponType, movementType, perception, intelligence) match Qiraki_Bestiary.md's own category lists exactly. Verified, not open.

Note: the Endurance/Vitality numeric values on the 7 archetypes were never meant to come from the Bestiary — both Qiraki_Bestiary.md and Qiraki_Bioterror_Bank_v2.md say "no numeric ranges exist yet." Those numbers are the game's own validated design.

---

## G. The Collapse rule (Endurance vs. Vitality)

**Target:** GDD §0.2c / §5.2

**Supportive evidence found — still a confirmation, not a resolution.** No numeric canon spec exists, but Qiraki_Bioterror_Bank_v2.md's descriptive Endurance/Vitality section maps closely onto the game's Collapse rule: "high endurance, low vitality — wears down slowly, dies fast once breached" (matches Gallcyst's 5-hit shape), "low endurance, high vitality — visibly damaged early, still lethal and moving long after it should've stopped" (matches Sporethrower). Recommend confirming as correct — Maxime's call.

---

## H. Expanded roster — Team Two & bench

New material, added at Maxime's invitation ("add population to the mech folder with as many as you want"). Six more named, military-era, path-confirmed pilots exist in the source and aren't in any Bloom Wars data file yet. Scoped to the MeltaDread military era (same as Team One), deliberately excluding the academy-era cast per GDD §1's "entirely military era" lock. Not wired into the 4-mission slice's playerPilotIds — roster depth for Act 1's back half.

### H.1 Team Two, MeltaDread

Source: Qiraki_Military_Era_Outline_v3.md Part B, Qiraki_Session_Locks_Addendum.md, Qiraki_Defect_Queue_v2.md DEC-22.

| Pilot | Species | Path | Note |
| --- | --- | --- | --- |
| Bram Solvig | Osnian, male | Munti (CO) | All brown. Family-oriented. |
| Frida Green | Human, female | Munti | Orphan, hardass, no humour. |
| Trahsin Hyrs | Hiopi, female | Tank | Massive gunlance; short movement bursts between shield deployments. |
| Elodie Dufours | Human, female | Reeps | Daughter of a MeltaDread dreadnought crew. Preppy, company trivia. |

Source ambiguity, not resolved here: the outline lists Trav on both Team One and Team Two ("Four women and Trav"). No duplicate pilot_trav record added — worth a line to the author next time the outline gets a pass.

### H.2 Bench replacements

Source: Qiraki_Military_Era_Outline_v3.md Part B, Qiraki_Defect_Queue_v2.md DEC-16.

| Pilot | Species | Path | Note |
| --- | --- | --- | --- |
| Naomi Castell | Human | Reeps | Extreme long range, fusion lance "the Bloom Eraser." Stays where the enemy can't reach. |
| Suki Arnesen | Human | Reeps | Close-range beam pistol, rapid-evasion float unit. Never stops moving. |

Castell/Arnesen are a deliberate same-path, opposite-philosophy pair in the source, mirroring the academy-era Ilyen/Talia device.

### H.3 Mek assignments — new design choices, not sourced

| Pilot | Archetype | Mek | Primary | Secondary | Reasoning |
| --- | --- | --- | --- | --- | --- |
| Bram Solvig | arch_munti_vibrissal | mek_solvig | Fieldwright | Quartermaster | Protective/family fits repair track; CO gets economy secondary. |
| Frida Green | arch_munti_bipedal | mek_green | Fabricator | Armorer | Self-reliant orphan. |
| Trahsin Hyrs | arch_tank_centauroid | mek_hyrs | Armorer | Fieldwright | Gunlance pairs with Armorer; "short bursts between shield deployments" ≈ Fieldwright's stationary bonus. |
| Elodie Dufours | arch_reeps_bipedal | mek_dufours | Runemaster | — | Sharp, always has intel. |
| Naomi Castell | arch_reeps_bipedal | mek_castell | Runemaster | Fieldwright | Stays still sniping — both tracks reward stillness. |
| Suki Arnesen | arch_reeps_bipedal | mek_arnesen | Armorer | — | Never stops moving — needs survivability, not a stationary bonus. |

### H.4 TypeScript — append to Data Pack §4.2

```
export const ROSTER_DEPTH_PILOTS: PilotRecord[] = [
  { id: "pilot_solvig",  displayName: "Bram Solvig",
    archetypeId: "arch_munti_vibrissal", mekId: "mek_solvig",  tier: "G" },
  { id: "pilot_green",   displayName: "Frida Green",
    archetypeId: "arch_munti_bipedal",   mekId: "mek_green",   tier: "G" },
  { id: "pilot_hyrs",    displayName: "Trahsin Hyrs",
    archetypeId: "arch_tank_centauroid", mekId: "mek_hyrs",    tier: "G" },
  { id: "pilot_dufours", displayName: "Elodie Dufours",
    archetypeId: "arch_reeps_bipedal",   mekId: "mek_dufours", tier: "G" },
  { id: "pilot_castell", displayName: "Naomi Castell",
    archetypeId: "arch_reeps_bipedal",   mekId: "mek_castell", tier: "G" },
  { id: "pilot_arnesen", displayName: "Suki Arnesen",
    archetypeId: "arch_reeps_bipedal",   mekId: "mek_arnesen", tier: "G" },
];

export const ROSTER_DEPTH_MEKS: Record<string, MekArchetype> = {
  mek_solvig:  { id: "mek_solvig",  displayName: "Solvig's Mek",
                 primary: "fieldwright", secondary: "quartermaster", spareParts: 0 },
  mek_green:   { id: "mek_green",   displayName: "Green's Mek",
                 primary: "fabricator",  secondary: "armorer",      spareParts: 2 },
  mek_hyrs:    { id: "mek_hyrs",    displayName: "Hyrs' Mek",
                 primary: "armorer",     secondary: "fieldwright",  spareParts: 0 },
  mek_dufours: { id: "mek_dufours", displayName: "Dufours' Mek",
                 primary: "runemaster",  secondary: null,           spareParts: 0 },
  mek_castell: { id: "mek_castell", displayName: "Castell's Mek",
                 primary: "runemaster",  secondary: "fieldwright",  spareParts: 0 },
  mek_arnesen: { id: "mek_arnesen", displayName: "Arnesen's Mek",
                 primary: "armorer",     secondary: null,           spareParts: 0 },
};
```

---

## I. Updated open-items roll-up

Supersedes the "Open items carried across the docs" section of Bloom_Wars_Master_Index.docx (also updated separately, see `claude/Bloom_Wars_Master_Index.md`).

| # | Item | Status |
| --- | --- | --- |
| 1 | Who dies in the Mission 3 wipe | Resolved — §C, including §C.3. Points invested in a lost pilot are NOT carried forward (XCOM-style individual investment, decided 21 Aug 2026). |
| 2 | Team One species/chassis | Resolved — §A. One fix: Thyns is Hiopi/centauroid. |
| 3 | Mek names | Resolved — §B. No individual mech names exist in canon. |
| 4 | Points-shop values | Resolved — §D.1. Keep the game's own validated cost curve. |
| 5 | Bioterror Bank colour families | Resolved — §E, extended §E.1 (28 Aug 2026) to cover the three later Independent Campaign archetypes. |
| 6 | Gear-tier names per path | Resolved — §D. Full 4×7 table. |
| 7 | Bestiary enum vocabulary | Confirmed correct, no change — §F. |
| 8 | Collapse rule intent | Supportive canon evidence found — §G. Still needs confirmation. |
| 9 | Mek/Mech terminology | New — flagged, not fixed. §B.1. |
| 10 | Reserved-term spoiler lock | Unaffected by this pass — automated per Build Brief §2.1. |

## J. Build-status note (added 21 Aug 2026, post-canon-pass)

This vertical slice (missions 1a/1b/2/3 as specified in the Data Pack) is being built first as an **engine/mechanics test pass**, not as final campaign content. Maxime will devise the real campaign missions separately once the engine is proven; the existing 4-mission slice exists to validate that movement, combat, terrain, the event system, meks, and Severance all actually work end to end. Treat the current mission data as a functional harness, not as content to polish narratively.

*End of Canon Verification Pass v1 (§E.1 addendum, 28 Aug 2026, appended below the original unchanged text above).*
