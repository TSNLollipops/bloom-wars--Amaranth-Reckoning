# The Bloom Wars — Requiem Early-Equip & Extra Tank Weapon Branches, note (4 Sep 2026)

Maxime, verbatim: *"ship extra tank module, ship ability to allow bosk to equip requiem as soon as mission 2."* Then: *"heirloom are not an upgrade you buy but one u can use from start."* Then, on which system the tank item belongs to: *"the tank wespon branch."* Then, told both remaining Tank branches were wanted: *"All of them built. They where usposed to be done. So much thing got forgotten somewhere I want a full audit."*

**CORRECTION, same evening.** This doc originally reported that Gjallar/Requiem's combat ability didn't exist despite a code comment claiming it shipped 3 Sep. That was wrong, and it was wrong because of a mistake in how the check was done, not because the game's code is actually in that state — see §1a below for the full correction and what still holds up after re-checking properly.

## 1a. The correction — Gjallar/Requiem IS real. Here's what actually happened.

The first pass searched only a hand-picked handful of files copied off Maxime's machine for inspection, not the actual repository, and reported "not found anywhere" as if it had checked everything. It hadn't — `scenes/Battle.ts`, `engine/ai.ts`, and the test file itself were never even copied over before that claim was made.

Re-checked properly this time: got a full recursive file listing of the actual `src/` tree first (not assumed), then pulled every file that could plausibly touch this — `engine/mission.ts`, `engine/combat.ts`, `engine/ai.ts`, `scenes/Battle.ts`, `engine/units.ts`, and the test file directly. Result:

- `engine/__tests__/gjallarRequiem.test.ts` **exists** — 24KB, real tests against the real `Mission` class, timestamped one second apart from `data/heirlooms.ts`'s own last save (i.e., saved in the same pass, exactly as the comment describes).
- `engine/mission.ts` has real, wired functions: `canRequiemSeverance`, `getRequiemDirectionTargets`, `previewRequiemSeverance`, `requiemSeverance`, `accrueRequiemCharge`, `getRequiemCharge` — a real 0–100 charge meter tied to combat.
- `engine/combat.ts` has `applyRequiemBloomDamage`, the dedicated choke point for the Bloom Collapse-check bypass, imported and used from `mission.ts`.
- `scenes/Battle.ts` has a real **GJALLAR** action-bar button, direction-targeting, a hover-tip explaining the attack, and a charge-meter HUD line.

**So: the ability is genuinely built, tested, and playable.** The "Vault Phase 2 slice 7, 3 Sep 2026" comment in `data/heirlooms.ts` was telling the truth. The lesson worth keeping (this project already has a standing rule about exactly this): a search across a partial local copy is not a repo-wide search, and reporting it as one is worse than not checking at all, because it sounds more certain than it is.

## 1b. What still holds up, re-checked against the full file set this time

Even with the broader, correct file set — now also including `engine/campaignState.ts`, `scenes/CampaignSetup.ts`, `scenes/Debrief.ts`, `scenes/TransporterPad.ts`, and `scenes/Hub.ts` — one part of the original finding is still true:

**`acquireAberration()` — the only function that ever assigns Gjallar to a pilot — is called exactly once anywhere in the codebase**, in the Mission-12 Vault dedication scene (`resolveVaultDedication`, wired into `scenes/Hub.ts`'s `checkVaultDedication()`), and only hands Gjallar to Rourke if Bosk specifically falls at Mission 12. Nothing anywhere assigns it to Bosk. If he survives, it stays "uncased, unclaimed" per that function's own comment — real ability, nobody actually holding it.

**This changes the size of the ask a lot, and in the good direction.** Since the combat ability already exists and works, "Bosk equips Requiem by Mission 2" is NOT a first build anymore — it's genuinely small:

1. Add one call, `acquireAberration(state, "requiem", "pilot_bosk")`, somewhere at or before Mission 2 start.
2. Decide what the GDD's own Mission 2 row (`Bloom_Wars_GDD_v0.2.docx` §10.3 — *"Heirloom: Meter becomes visible, charge rate halved so it cannot fill. Introduced, not detonated."*) should now say, since your "usable from the start" framing suggests you want that throttle gone, not just the assignment moved earlier.
3. Confirm the locked rule #4 in `engine/heirlooms.ts` (*"player can only get heirloom at act 2 and onward"*) is still meant to govern only the 8 *proper*, recruited Heirlooms — Gjallar/Simulacrum already read as the deliberate exception in the code, this would just make that exception actually reachable in play.

**Docs to touch once built:** GDD §10.3 (Mission 2 row), Data Pack §11.5 (still says `SEVERANCE`/`abil_severance`, already a pending docx edit in `Bloom_Wars_Docx_Pending_Edits_Status_28Aug2026.md`).

## 2. Extra Tank weapon branches — both wanted, both confirmed genuinely unbuilt

Confirmed system: **weapon branches** (`src/data/weaponBranches.ts`), not Frame Systems Layer modules. Re-checked with the full file set (including `engine/mission.ts`, `combat.ts`, `ai.ts`, `Battle.ts`, `units.ts`, `turnManager.ts`) rather than the earlier partial one — this part of the original finding holds up:

`weaponBranches.ts`'s `tank:` list contains exactly one buyable branch, `tank_grinder_claw`. Of the original four-branch Tank design, two are still genuinely absent anywhere in the repo — no partial version, no stub, nothing:

- **Riot Drum** — melee plus a knockback/pin on hit, echoing Interdict's own flavor. The engine already has real knockback math (`turnManager.ts`'s `knockbackDestination()`, `isKnockbackImmune()`) and a real pin mechanic (`abil_interdict`'s `triggerInterdiction()`) — both currently only fire in the Bloom-hits-mech direction. Riot Drum would be the first mech-attack-triggers-knockback/pin effect, reusing the math, adding new wiring for "my own hit does this."
- **Maser Lance** — a big, committed cone AoE, designed as Tank's late-game payoff (source doc proposes gating behind D-tier+). Confirmed: no cone-shaped targeting exists anywhere in this codebase — every existing AoE-ish thing is a single target, one fixed 8-tile line (Gjallar), a couple of small fixed-shape hazards, or a 50%-damage cleave to one adjacent enemy. This is a first for the game, not a variation on something that exists.

**Maxime wants both built** (*"All of them built"*). Riot Drum is the cheaper of the two (reuses existing math); Maser Lance is genuinely new targeting work (new UI, new shape logic, new tests) — worth knowing which one to tackle first if this gets picked up as two separate passes rather than one.

## 3. The "full audit" ask

Triggered directly by the Gjallar mistake above — which turned out to be a real code discrepancy in exactly zero cases once checked properly, not the pattern of forgotten/fake work it looked like at first. Worth being straight about scope before committing to anything called a "full audit": this project has ~300 docs and 90+ test files, and checking every "shipped" claim in every one against current code is a multi-hour undertaking, not a quick pass. Discussed with Maxime directly rather than assumed — see chat for what got agreed (a bounded first pass on the Heirloom-abilities + Weapon-branches claim set specifically, vs. a wider sweep, vs. skipping it and just building the three confirmed items above).

## Filed, not built (as of this doc)

Logged in `Bloom_Wars_Now_And_Next.md`'s "Needs Maxime's call" list. Nothing in the engine, sim, or docs has been changed yet — everything above is a verification pass and a note.
