Bloom Wars — Player AI: Ability & Objective Awareness Plan (v1)

*25 Aug 2026. Maxime: "plan everything the bot wont be able to finish mission 12-36 if he cant use ability at least at kids lvl of success." This is that plan — not built yet, nothing in this doc is code. Companion to `claude/Bloom_Wars_Amaranth_Act1_Build_Log_v1.md` (today's Taunt addendum is the thing that triggered this ask) and `claude/Bloom_Wars_Independent_Campaign_The_Amaranth_Reckoning.md` (the 36-mission source this plan is scoped against).*

## 0. The honest scoping correction, up front

The literal ask is right — the bot genuinely can't test what it can't do. But "ability at kids level of success" is only part of what's actually blocking missions 12-36, and I want to say the other part plainly rather than let the plan imply ability-teaching alone gets you there.

Only missions 1-8 are built. Mission 9 needs a new engine objective type (Survive N Turns) that doesn't exist yet, for anyone — Maxime included; nobody can play mission 9 until it's built regardless of what the bot knows. Missions 13-36 (all of Act II and III) need several more systems that don't exist yet either: a squad composition choice (10 pilots, deploy 5-8), an off-board ship fire-support call-in, two more new objective types (Contested Landing, Protect Asset), a capital-ship escort mechanic, bigger deploy caps. None of that is an AI problem. It's content and engine work, and it has to happen before there's anything for an AI to be smart or dumb about.

So this plan is honestly two different things bundled under one ask:

- **What's real and plannable today:** teaching the bot the six abilities and the objective types that already exist in the engine, covering missions 1-8 fully and most of what 9-12 will need once mission 9's objective type exists. This is where the actual detail below lives.
- **What's correctly flagged but can't be pre-specified:** AI behavior for systems that don't exist yet (Act II/III's new mechanics). Section 7 names them and says how they'll get picked up — each gets its own small AI follow-on once its real mechanics are built and specced, the same way Taunt's AI hook got built right after Taunt itself this session, not months in advance of it.

I'd rather hand you a plan that's honest about that split than one that pretends to spec AI behavior for a ship-support ability nobody has designed the numbers for yet.

## 1. The architecture change — do this once, first, before any individual ability or objective

`decidePlayerAiAction(map, unit, allUnits, turn)` — that's the entire current input. Checked directly before writing this plan: it has never seen the `Mission` object. It doesn't know the objective type, doesn't know where a hold zone or exit tile is, can't call Screen or Taunt or Interdict, because it has no reference to anything that could call them. `run.ts` is the only thing touching the real `Mission`; it takes back a `{path?, attackTargetId?}` and translates that into one `moveUnit`/`attack` call.

Every section below needs this fixed first, so it's Phase 1, not folded into whichever ability happens to be built first:

- **Input:** pass the live `Mission` reference (or a narrow read-only wrapper around it) into `decidePlayerAiAction`, alongside what it already gets. `Mission` already exposes exactly the query surface the bot needs as pure, side-effect-free methods — `canScreen`/`canAmbush`/`canInterdict`/`canSensorSweep`/`canClearBloom`/`canTaunt`/`canRepair`/`canRescue`, `sensorSweepChargesRemaining`, `mission.objective`, `mission.objectiveParams`, `mission.bonusObjective` plus its live outcome fields. No new engine surface required — the UI in `Battle.ts` already calls every one of these to decide what to grey out. The bot asking the identical questions is not a new capability, just a new caller.
- **Output:** extend `PlayerAiDecision` from move+attack-only to a named `action` field (`"screen" | "ambush" | "interdict" | "sensor_sweep" | "clear_bloom" | "taunt" | "repair" | "rescue"`, optional, alongside the existing `path`/`attackTargetId`). `run.ts` grows a small dispatch translating whichever `action` came back into the matching `Mission` verb call. `run.ts` stays the only thing that mutates `Mission` — the decision function stays a pure function of read-only state, which is the property that makes this engine "reusable in the sense that matters today" per its own header. Don't blur that for the sake of one ability.

This shape is what absorbs every future system for free: a new objective type is a new field on the context object and a new `if` in the objective-awareness logic; a new ability is a new possible `action` value. Nothing about this needs re-architecting per feature once it's built once.

## 2. Objective awareness — the higher-leverage half, do it before ability polish

Right now the bot's only goal, ever, is "find something to kill or someone to heal." That's why Missions 2, 3, 5 (hold_zone, clear_bloom, extract_unit + rescue_pilot) are essentially untested today regardless of how well the bot fights — it doesn't know those missions have a goal beyond combat at all.

| Objective | Kid-level heuristic | Priority relative to combat |
|---|---|---|
| `eliminate_all` | No change — this is what the bot already does. | — |
| `hold_zone` | Once any player unit is inside the zone (or the hold window is close), treat the zone's own tiles as a second cohesion anchor alongside `nearestLivingAlly` — units converge toward the zone rather than chasing kills across the map, and prefer not leaving it once there if reasonably safe. | Above `seek_fight`, below self-preservation (retreat/regroup) — a unit that's about to die doesn't hold a tile it can't defend from. |
| `extract_unit` | The named unit gets a standing override once turn count is in a reasonable window: path to the nearest exit tile outranks `seek_fight`. Escorts screen it rather than wander off — same cohesion anchor idea as `hold_zone`, anchored on the extract target instead of a tile. | Above `seek_fight`. Below `killNow` (a free kill is still a free kill) and below the extract unit's own self-preservation. |
| `clear_bloom` | The Munti prefers clearing over attacking whenever a clearable tile exists and it isn't in immediate danger — this is the mission's actual job, not a discretionary pick. | Above `focus_weak` for the Munti specifically. Doesn't touch non-Munti units' priorities at all. |
| `rescue_pilot` (bonus) | Nearest reasonably-safe unit prioritizes reaching and picking up the downed NPC, then routes to an exit while carrying (the engine already refuses an attack while `carryingRescueId` is set, so this just needs the bot to choose the path). | A genuine bonus, not the mission — never outranks the real objective or `killNow`. |
| `clear_bloom_patch` (bonus) | Same logic as `clear_bloom`, scoped to the bonus's own `patchTiles` instead of the whole map. | Same as above. |

## 3. Ability usage — staged by risk, not by how interesting each one is

The real risk isn't "the bot uses an ability badly," it's "the bot burns something that can't be undone this mission for nothing." Ambush and Interdict cost a turn if used badly — recoverable, next turn is still fine. Screen, Sensor Sweep, and Taunt are once-or-capped per mission — a bad automated call there quietly wrecks that mission's whole balance read, which is a worse outcome than the bot never touching the ability at all. Stage accordingly.

**Low-risk (build these first):**

- **`abil_ambush` (Meeps).** Use as an alternative to a low-value `seek_fight` move: nothing worth attacking this turn, not already adjacent to a hostile (the ability refuses adjacent anyway), and going unseen looks achievable from the reachable tiles this turn. Worst case if the heuristic is wrong: a wasted turn, same as a bad `seek_fight` move already can be today.
- **`abil_interdict` (Tank).** Brace instead of moving when there's no good attack available this turn AND at least one visible hostile looks likely to close within `INTERDICT_RADIUS` next turn. Worst case: a turn spent bracing nothing, no different in cost from any other wasted turn.

**Medium/high-risk (build after the low-risk pair is proven, and stress-tested separately):**

- **`abil_screen` (Munti, once/mission).** Reserve for a real "here it comes" moment — kid-level trigger: only fire if it would conceal 2+ units and at least one of them is already hurt, not just "available and nothing better to do." Under-using this is a much safer failure mode than over-using it.
- **`abil_sensor_sweep` (Reeps, 2 charges/mission).** Only worth real value on Undertow-bearing maps; everywhere else it's a wasted charge no matter how the bot times it. Kid-level: use once, early, if charges remain and nothing better is available — accept this one may never be "optimal," that's fine at this bar.
- **`abil_taunt` (Meeps, mission 8+, once/mission).** The one I'd actually recommend NOT automating yet. Today's own forced-scenario test showed the real downside: a Meeps taunting a full adjacent pack point-blank with no defensive mitigation can go down in one hostile phase. A kid-level heuristic here risks teaching the bot to do exactly that, which would make Mission 8's sim numbers actively misleading rather than just incomplete. If you want it in anyway, the conservative version is: only taunt when the Munti is genuinely endangered AND the taunting unit itself isn't already about to eat the same fire it's trying to pull — but I'd rather flag this as "leave it out, ship without it, revisit once Ambush/Interdict/Screen are proven" than build a wrong heuristic and have to catch it the way today's terrain/focus-fire pass had to catch three separate regressions.

`abil_clear_bloom` and `abil_repair`/rescue are covered under objective awareness above — they're not discretionary-timing abilities in the same sense, they're obligatory to that objective type's progress.

## 4. Sequencing

1. **Architecture change** (Section 1) — foundational, blocks everything else.
2. **Objective + bonus-objective awareness** (Section 2) — highest leverage: unlocks meaningful testing for Missions 2, 3, 5 (and 4's rescue bonus) essentially for free once Phase 1 lands.
3. **Ambush + Interdict** (low-risk abilities).
4. **Screen + Sensor Sweep** (capped abilities, conservative thresholds, own stress-test pass).
5. **Taunt** — recommend deferring per Section 3's own case; your call.
6. **Survive N Turns AI heuristic** — write this once Mission 9 and the engine objective type it needs actually exist, not before.
7. **Everything Act II/III needs** (Section 7) — one small AI follow-on per system, attached to that system's own build pass.

Each phase gets the full gate (typecheck/lint/test/build) plus a real stress-test batch at n=20+ watching for `ONGOING` and turn-count outliers, the same discipline this session's terrain/focus-fire pass needed the hard way — new conditional branches in this decision chain are exactly what caused three separate regressions there. A/B against the pre-phase baseline where the change is subtle enough that a single before/after run could mislead.

## 5. Explicitly out of scope for this plan

- **Squad composition** (which pilots to bring — Act II's 5-8-of-10 choice). A pre-mission decision, not an in-mission one; `run.ts` has no hook for it at all today. Separate problem, not folded in here.
- **Heirloom/ultimate usage.** None of the twenty are implemented as a usable engine verb yet — `abil_severance` is still pure data (Data Pack §11.5's own framing: "introduced, not detonated"). Nothing for the bot to use until one exists.
- **Any Act II/III mechanic that isn't built** — ship/capital fire-support call-ins, Contested Landing, Protect Asset, capital-ship escort. Named here so they're not forgotten, not specced here, because they can't be specced honestly before their own mechanics exist.

## 6. A live design implication, added mid-draft — Maxime: "i plan to make mission really need you to use yoour skills, not just smash and go. the social aspect is gonna be complex so the tactical aspect will be too"

This raises the stakes on the whole plan above, and it's worth naming the actual implication rather than just nodding at it. If future missions are *designed* to require a specific tool at a specific moment — not just reward using one — then "kid-level" can't mean "generally competent," it has to mean "reliably recognizes the moment the mission is actually signaling." A bot that's too conservative with, say, Interdict or Screen won't just play those missions worse, it'll read them as unwinnable when a human using the intended tool would find them very doable — a false negative, not an honest data point.

The good news: this mostly falls out of the generic, board-state-driven heuristics in Section 3 rather than needing bespoke per-mission logic, *as long as* a mission's own design telegraphs the intended tool through the board state itself — the exact pattern Taunt's own Mission 8 briefing already uses ("if it's really a swarm, the ones who scatter thinnest are the ones it converges on first" — a hint in the fiction, not a popup). A chokepoint built for Interdict reads as "hostiles about to close on a Tank with nothing better to do" regardless of whether a human or the bot is looking at it — the generic heuristic fires because the board genuinely calls for it, not because it was special-cased for that mission.

That cuts both ways, and the second direction is worth having on record: if the bot — tuned only with the generic, board-state heuristics in this plan, nothing mission-specific — can't figure out when to use a tool a mission is built around, that's a real signal the mission isn't legible enough yet, not just a gap in the AI. Worth treating a stuck bot on a "you need to use X here" mission as a design smoke test before assuming it's an AI problem to go fix.

Practical effect on Section 3's own staging: Taunt's "maybe don't automate yet" recommendation should be revisited the moment a mission 9+ is actually being designed around it specifically, rather than staying deferred indefinitely — that's the trigger to loosen the threshold and re-verify, the same "build it when the content that needs it exists" call already made for the `socialHook` stub field.

## 7. What this buys, concretely

Missions 1, 2, 3, 4, 5, 6, 7, 8 all become meaningfully sim-testable for the first time — today, only 1/2/4/6/7/8 get real combat-only signal, and 3/5 get essentially nothing because the bot can't attempt their actual objective. Every future mission built from here on inherits objective-awareness automatically for any objective type that already exists (a fifth `hold_zone` mission, say, needs zero new AI work). Ability usage catches a different class of defect than objective awareness does — whether a mission is winnable *without* using its intended tools versus whether it's winnable at all — and losing that distinction is exactly how "the bot lost" stops meaning anything specific.
