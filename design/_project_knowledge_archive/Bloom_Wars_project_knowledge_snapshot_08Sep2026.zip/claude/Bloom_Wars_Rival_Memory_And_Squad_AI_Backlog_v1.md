# Rival Memory + Squad AI — Backlog (captured 6 Sep 2026, tagged post-EA)

Two pieces of Maxime's larger "both campaigns fight each other's full named roster" request that are deliberately **not built yet**, written down here so the ideas don't get lost between now and whenever they're picked back up. Neither is started in code. See `Bloom_Wars_Build_Log_Addendum_HouseAmaranthThirdLance_06Sep2026.md` for what *has* shipped from that same request (House Amaranth's own Third Lance).

## 1. "They remember you" — rival persistence

Maxime's call when asked how deep this should go: flavor now, full mechanic later, after EA ships.

**Now (once the mirrored hostile-mech rosters and their missions exist):** a line of dialogue or briefing text acknowledging a past fight with a named rival — no change to stats, tactics, or mission outcome. Cheapest version: a briefing-text variant keyed on "has this rival been fought before, and what happened," reusing whatever mission-briefing variant system already exists (`data/missionBriefing.ts`) rather than building new plumbing.

**Later (post-EA):** an actual escalation mechanic — a rival's stats, gear, or tactics shift on a rematch based on history with them. Genuinely a new system: needs persistent per-rival state on `CampaignState` (win/loss count against them, maybe which of their pilots specifically fought and survived), and a rule for what "escalation" actually changes (tougher tier, a new ability, a different `path`/tactic). Not scoped further than that — worth its own design pass when it's actually next, not guessed at now.

## 2. Squad AI for named rivals — the "act as a team" idea

Maxime's own proposal, checked against the actual code before agreeing: give the named rival squads (not every hostile in the game) coordinated, focus-fire behavior instead of today's one-at-a-time, uncoordinated targeting.

**What's already there, confirmed by reading `engine/ai.ts` directly:** a `pack` intelligence tier already exists and is fully built and tested — shared vision across nearby allies, and every pack member independently pathing/attacking the same shared "weakest target" pick (`sharedPackTarget`, lowest HP × effective defense). It's currently used by exactly one Bloom monster archetype and is hard-gated off for every mech (`intelligenceOf`: `if (unit.kind !== "bloom") return "reflexive"`). It is **not** the `sim/playerAi/hard.ts` "Hard AI" Maxime referenced by name — that module plays the player's own squad in offline balance sims and has never been wired into a real mission; reusing it for real hostiles would be a much larger, separate undertaking touching every mission's existing balance tuning, and isn't the plan here.

**The plan, not yet built:** open that gate specifically for named rival mechs (the ones with real names and hostile-mech twins, not generic troopers), so a full rival-squad encounter reads as a coordinated unit instead of five mechs picking targets independently. Degrades safely by construction — `packDecision` falls back to solo `reflexive` behavior whenever fewer than two pack-tier units are within `SPLITFANG_PACK_RADIUS` of each other, so it cannot change anything about the two existing solo rival duels (Marrow's and Rourke's own Mission 20/28 fights), only affects a mission where multiple named rivals are on the field together at once — which doesn't happen anywhere in the game yet, since those missions haven't been built.

**Why it's not built yet:** it depends on the mirrored hostile-mech rosters (item above in the main addendum) and the mission-placement decisions still to be made together — there's nothing to coordinate until more than one named rival can appear in the same fight.
