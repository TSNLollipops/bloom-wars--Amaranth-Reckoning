# THE BLOOM WARS — Release Ladder & Monetization Note

**Recorded 2 September 2026.** Roadmap capture, not a plan or a spec. None of this existed in any project doc before today; `Bloom_Wars_EA_Launch_Plan_31Aug2026.md` covers the EA launch itself and stops there, saying nothing about what happens after or how any of it is priced.

## What Maxime said

> "the teeth going to have to wait for post ea lunch same time as house amaranth. im not charging for any update untilbthe pvp one. the pvp one is gonna be huge and ill chsrge for it."

## The release ladder as it now stands

1. **Early Access — Warden Company alone.** itch.io, Electron-packaged Windows download, target **26 Oct 2026**. Locked in the EA Launch Plan. Includes the calendar economy (shipped 2 Sep), cosmetic and without teeth.
2. **First post-launch update — free.** House Amaranth's 36-mission campaign (built, sim-tuned, not yet committed to the device) plus the calendar's teeth: carrier-defense raids, FTL-style escalating pressure, carrier damage as the failure state. See `claude/Bloom_Wars_Calendar_Teeth_Direction_Note_02Sep2026.md`.
3. **Further updates — free.** No boundary set on how many or what they contain.
4. **PvP — paid.** The first and so far only thing Maxime intends to charge for. His own sizing: "gonna be huge."

## Why PvP is the one paid thing — confirmed 2 Sep 2026

Maxime, after this week's PvP design conversation surfaced how much genuinely new infrastructure it needs (see `claude/Bloom_Wars_PvP_Concept_Note_TwoFrontAttrition_02Sep2026.md`): **"see basically en entire new game. thats why the gladiator upgrade is gonna be its own paid thing and not one of my free upgrade which ill do a lot of."**

Worth recording the reasoning, not just the conclusion, since it's the actual dividing line between what's free and what's paid on this roadmap — a future session or a "why isn't X free" question should be able to check anything against this test rather than the pricing looking arbitrary. House Amaranth (the first free update) needs none of the things below: same engine, same maps pipeline, same combat model, same balance tooling, more missions. PvP needs all of them:

- **A real backend** — accounts, matchmaking, persistence. Nothing this project has ever needed before (§ below, "first thing that needs a backend").
- **A different combat model**, not an extension of the existing one — SotS-style order-based ship combat is a different genre of interaction than the tactics grid, per this week's own research.
- **Balance tooling `combat_sim.py` cannot currently do** — human-vs-human, not AI-vs-AI (§ below, "existing maps and balance work do not transfer").
- **Purpose-built maps**, confirmed separately by Maxime the same week (*"pvp is gonn havr its own map"*).
- **A command/progression ladder** that doesn't cleanly nest inside the existing Carrier CO → Legion CO → Company CO ladder (still unresolved — see the PvP concept note).

That is a second product sharing a setting, carriers, and pilots with the first — not a content pack, which is the real test for "does this get charged for" going forward: **new infrastructure the base game never needed is the paid tier; more of what the base game already does is a free update.**

## PvP — three things worth flagging now, while it's cheap to

Nothing about PvP is designed and none of this is a proposal. But it is the paid tier, which makes it the highest-stakes item on the ladder, and three facts about it are true today and worth writing down before anyone starts.

**1. It is the first thing this project has ever wanted that needs a backend.** The Bloom Wars is a pure-browser game: `localStorage` only, no accounts, no server, no network calls anywhere. `Bloom_Wars_Calendar_System_v1.md` ran into exactly this when it wanted cross-player comparison and defaulted to a shareable end screen rather than a leaderboard, "since nothing else in this project has a server-side component and building one would be a large, separate piece of scope on its own." PvP doesn't get to make that same dodge. Accounts, matchmaking, persistence, and anti-cheat are a different *category* of work from everything built so far, not a bigger amount of the same work.

**2. Async vs. realtime is the fork that sets the price.** For a turn-based tactics game, asynchronous play (submit a turn, opponent plays later) is the natural fit and dramatically cheaper — no live netcode, no rollback, no latency handling, tolerant of a player closing the tab mid-match. Realtime PvP is a substantially larger and more fragile build for a genre that doesn't especially need it. Worth deciding early, because nearly every other technical choice follows from it.

**3. The existing maps and balance work do not transfer — confirmed by Maxime, who was already planning for it.** His own words, 2 Sep 2026: *"pvp is gonn havr its own map. its going to br a whole thing."* So the map half of this flag is answered: PvP gets purpose-built, presumably symmetric maps rather than reused campaign ones. The balance-tooling half is still open and is the part that remains easy to underestimate. Every map and unit in this game has been sim-tuned through `combat_sim.py`/`maps.py` against an **AI opponent**, to win-rate targets, on deliberately **asymmetric** scenarios — one side attacks a defended position, one side extracts under pressure. Human-versus-human balance is a different discipline: mirror matchups, first-turn advantage, map symmetry, army selection, and the fact that a human opponent exploits what an AI never notices. `combat_sim.py` currently models AI-vs-AI, so **it cannot validate PvP balance in its present form** — and this project's own standing rule is that a number or map only counts once it has run through the script and passed. Purpose-built PvP maps don't remove that requirement, they just mean the maps are new too. A PvP-capable sim mode is real, unbuilt work that no existing asset covers.

## Sequencing — hotseat first, approved as direction 2 Sep 2026

Build the PvP *ruleset* first as **local hotseat**: two players, one machine, no backend whatsoever. Comparatively cheap, needs none of the infrastructure above, and can ship free during the EA period as a genuine feature. It buys the thing that actually de-risks the paid expansion — real play data on two-human balance, symmetric maps, and turn structure, on a ruleset proven before a line of netcode exists. The paid tier then becomes the networking, matchmaking and ranking layer on top of rules that already work, instead of rules and infrastructure being invented at the same time where each hides the other's flaws.

Maxime approved this as direction ("your sugestion sound good to me"), with the honest caveat that he was explicit about evaluating it as a storyteller rather than a developer: *"im not a dev im a storyteller."*

**The one cost of this order that is a judgment call rather than a technical one, and therefore Maxime's to make:** local hotseat shipping under the word "PvP" will disappoint players who read that as online. The fix is naming, not engineering — call it **local versus** or **hotseat** in every player-facing string and store listing, and keep "PvP" reserved for the paid online release. Cheap to get right up front, awkward to walk back after players have formed an expectation.

**Still entirely undecided:** async vs. realtime (see point 2 — this reads as technical but is really a feel question: correspondence-chess pacing versus a live tense duel, which is a design call, not an engineering one), ranking/matchmaking design, army selection and drafting rules, and whether PvP shares the campaign's pilot roster and permadeath stakes at all or runs on its own separate units.

This note exists so whoever picks PvP up starts from these facts rather than rediscovering them. PvP is several releases away; nothing here is a recommendation to act now.
