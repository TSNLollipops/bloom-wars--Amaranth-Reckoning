# THE BLOOM WARS — Chat Keyword Categories: Delivery v1 (Categories 1–5)

**Status: content + spec drafted 27 Aug 2026 — wired into the real code and live-verified in Maxime's own running game, 1 September 2026.** Executes `claude/Bloom_Wars_Chat_Keyword_Categories_Plan_v1.md`'s recommended build order (Greeting/Worry first, then Farewell/Advice/Banter as a batch) — categories 1 through 5. Categories 6 (agreement/disagreement) and 7 (rudeness toward a specific NPC) were deliberately **not** attempted here — the plan doc itself flagged both as real design questions (\"does each catalyst have an opinion about being agreed with,\" a tone call on rudeness) that wanted a short conversation before content got written, not a build to guess through. **Update, 2 Sep 2026: Category 7 has since had that conversation and shipped** — see \"What's still open\" below.

**Wiring update, 1 Sep 2026 — the access note below is now historical.** This doc was written without a connected device; that gap is closed. `src/data/chatIntent.ts` gained a real `detectSmallTalk()` function (not the `matchesAny`-in-`interpretPlayerChat` shape sketched below, since the real file's own architecture — separate `detect*` functions checked in `submitChat()`, one per category, not one big dispatcher inside `interpretPlayerChat` — turned out to be the better fit once the actual file was read), `src/data/smallTalk.ts` (new) holds the content banks below transcribed verbatim, and `src/scenes/Hub.ts`'s `submitChat()` routes a detected kind to the nearest single-target NPC. Full account of what shipped, the real ordering decision that resolved the "match order" question flagged below, and the live-verification results: `claude/Bloom_Wars_Master_Index.md`'s "Chat small-talk wiring" section. The Crew Greeting/Farewell and Crew Advice/Banter line banks used for the real content (rather than the one-line-per-catalyst Advice/Banter sketches below) are their own later, richer docs — see "What's still open" at the bottom of this file.

**Access note, historical — read before pasting anything below into the repo:** this session originally had no connected device/folder, so none of this was checked against the actual current `chatIntent.ts` or `Hub.ts` at the time it was written. The shape below follows the pattern already documented in the project's own build logs (word-boundary `\b`-anchored regex matching, `interpretPlayerChat(text) -> HubMessage | null`, per-catalyst `Record<Catalyst, string[]>` content banks) — but "follows the documented pattern" isn't the same as "verified against the file," and this project's own standing rule is to check the real file before trusting a claim about it. That check has since happened (see the wiring update above) and the real shape differs in the ways noted there.

---

## Categories 1 & 2 — Greeting and Mission-Worry — recognizer only, no new content

Both reuse existing infrastructure entirely, per the plan doc's own note — the job here is recognition and routing, not writing lines.

```ts
const GREETING_KEYWORDS = [
  "hey", "hi", "hello", "how are you", "how's it going", "you good", "sup", "morning", "evening"
];

const WORRY_CHECKIN_KEYWORDS = [
  "you okay about the mission", "worried about them", "how's it going out there",
  "any word from the mission", "worried", "anxious about the mission", "any news"
];
```

**Routing:**
- `GREETING_KEYWORDS` match → `{ kind: 'greeting' }`, handled identically to the existing E-key Talk interaction: `pickAmbientLine(npc.ambient)`, reading the NPC's real current state exactly as it does today.
- `WORRY_CHECKIN_KEYWORDS` match → `{ kind: 'worry_checkin' }`. If `npc.ambient.worried` is true, prefer the fear-pool bucket specifically (same content already live, just a more targeted pull) rather than the NPC's default echo weighting; otherwise fall back to the same general ambient pick as a greeting.

**Ordering note — resolved, 1 Sep 2026: see the Master Index's "Chat small-talk wiring" section.** These two buckets are checked in the same precedence slot as the existing History/Highlights detectors — before the coarser muster/emotion pass — which closes the two real keyword collisions this note originally worried about ("how are you"/"any word from the mission" false-matching an emotion or muster keyword).

## Category 3 — Farewell / sign-off — new content, 3 lines × 9 catalysts

```ts
const FAREWELL_KEYWORDS = ["bye", "see you", "later", "gotta go", "take care", "dismissed"];

const FAREWELL_LINES: Record<Catalyst, string[]> = {
  wolf:   ["Go on — I'll keep count of who's still here when you get back.",
           "Stay where I can find you later.",
           "See you at muster. Try not to make me worry."],
  dog:    ["Don't you dare not come back and tell me about it.",
           "I'll save you a seat. Don't be late.",
           "Later. And I mean that — I'll be checking."],
  cat:    ["Try not to die, it's bad for morale and worse for my paperwork.",
           "Catch you later. Try to be useful in the meantime.",
           "I've got places to be. So do you, apparently."],
  crow:   ["Go on, go be interesting somewhere else for a while.",
           "Later — I've got a theory to get back to anyway.",
           "See you. Try to bring back a good story this time."],
  raven:  ["Before you go — remember what I said about the angle. Actually, you'll remember. Go.",
           "Take care out there. I mean that more than the manual would.",
           "See you. Ask if you need anything, I mean it."],
  bear:   ["I'll be here. I'm always here.",
           "Go on. I've got the corner covered.",
           "See you when I see you."],
  fox:    ["Don't get caught doing anything I wouldn't do. Actually, do — just don't get caught.",
           "Later. Try to leave me something good to razz you about.",
           "See you. Try not to be boring while you're gone."],
  rabbit: ["Take care of yourself out there, please. I mean it.",
           "Come back in one piece. I'll be worrying regardless, but still.",
           "See you soon. Stay safe. Please."],
  shark:  ["Go make it count.",
           "See you when there's something worth coming back for.",
           "Later. Don't come back with a story about how you held back."],
};
```

**Superseded, 1 Sep 2026 — the shipped content isn't this sketch.** `claude/Bloom_Wars_Crew_Greeting_Farewell_Line_Bank_v1.md`, written the same day the wiring happened, is a richer 4-line-per-catalyst Greeting+Farewell bank, and that's the content actually in `src/data/smallTalk.ts` today. This section's 3-line sketch is left here for the historical record of the original estimate, not as the shipped text.

## Category 4 — Advice request — new content, one line × 9 catalysts

Plan doc's own note: "at minimum for raven, ideally for all nine." Went with all nine — matches how every other content bank in this project is structured, and each catalyst's take on "giving advice" is a real, cheap character beat on its own.

```ts
const ADVICE_KEYWORDS = ["what do i do", "what should i do", "any advice", "what would you do"];

const ADVICE_LINES: Record<Catalyst, string> = {
  wolf:   "Whatever it is — you don't have to carry it alone. That's my whole advice, honestly.",
  dog:    "Trust the people who've already proven they've got you. Everyone else, take slower.",
  cat:    "Figure out what it actually costs you to do nothing. Usually more than people think.",
  crow:   "Step back and look for the pattern. There's almost always a pattern. Even when there isn't, looking helps.",
  raven:  "Whatever it is, somebody's gotten it wrong before you and survived it. Learn from them instead of from scratch.",
  bear:   "Watch a while before you act. Most things look different once you've actually seen the whole board.",
  fox:    "Do the thing nobody expects. Works more often than the safe play does — just not always, so don't blame me.",
  rabbit: "Ask for help before you need it, not after. I'll always say yes either way, but ask earlier.",
  shark:  "Pick the harder option. If you're asking, some part of you already knows the easy one isn't enough.",
};
```

**Superseded, 1 Sep 2026 — same as Farewell above.** `claude/Bloom_Wars_Crew_Advice_Banter_Line_Bank_v1.md` is the richer 4-line-per-catalyst bank actually shipped, plus the CO's own separate Stress-gated Advice bank from `Bloom_Wars_CO_Bespoke_Dialogue_Bank_v1.md`. This section's one-line-per-catalyst sketch is historical only.

## Category 5 — Banter / joke request — new content, one line × 9 catalysts

Plan doc flags crow as the strongest thematic fit (their fear-content is literally about needing distraction). Wrote all nine anyway, same reasoning as Category 4 — but crow's is the one I'd actually expect to fire most in practice if routing ever weights toward thematic fit over strict per-NPC catalyst.

```ts
const BANTER_KEYWORDS = ["tell me a joke", "make me laugh", "say something funny", "lighten the mood"];

const BANTER_LINES: Record<Catalyst, string> = {
  wolf:   "Why'd the Munti bring a whole crate of parts to the fight? Because everyone kept 'borrowing' pieces of their last one.",
  dog:    "I trust exactly three people with my back and one of them's a stray I fed once. Rest of you are on probation.",
  cat:    "I'd tell you a joke about teamwork but you'd all take credit for the punchline.",
  crow:   "Okay hear me out — what if the reason drills always land on laundry day isn't a coincidence—",
  raven:  "Two pilots walk into a briefing. Only one reads it. I'll let you guess which one's telling this joke.",
  bear:   "I've got a great one. I'm not telling it. That's the bit.",
  fox:    "Ask me sometime why the Quartermaster still checks his own boots before putting them on. It's a whole story.",
  rabbit: "Why don't skeletons fight each other? They don't have the guts. ...Sorry. Nerves. That's genuinely the best I've got right now.",
  shark:  "Funniest thing I've seen all week was the Bloom actually trying to dodge me. Didn't work, but A for effort.",
};
```

**Superseded, 1 Sep 2026 — same as Farewell/Advice above.** The real shipped content is `claude/Bloom_Wars_Crew_Advice_Banter_Line_Bank_v1.md`'s 4-line-per-catalyst Banter bank.

## Implementation shape, illustrative only

```ts
// inside interpretPlayerChat(text), checked in this order — see the
// ordering note under Categories 1/2 above before trusting this order
if (matchesAny(text, GREETING_KEYWORDS))      return { kind: 'greeting' };
if (matchesAny(text, WORRY_CHECKIN_KEYWORDS)) return { kind: 'worry_checkin' };
if (matchesAny(text, FAREWELL_KEYWORDS))      return { kind: 'farewell' };
if (matchesAny(text, ADVICE_KEYWORDS))        return { kind: 'advice' };
if (matchesAny(text, BANTER_KEYWORDS))        return { kind: 'banter' };
// ...existing muster / verb / emotion checks follow
```

`matchesAny` assumed to be the same `\b`-anchored `escapeRegExp` helper the hardening pass already built for the emotion buckets — reuse it, don't reimplement.

**Superseded, 1 Sep 2026 — the real shape is a standalone `detectSmallTalk()` in `chatIntent.ts`, checked directly in `Hub.ts`'s `submitChat()`, not a branch inside `interpretPlayerChat`.** See the Master Index's "Chat small-talk wiring" section for the actual routing logic, including the CO-specific branch (his own bespoke Greeting/Farewell/Advice content, keyed off `pilotId === CO_PILOT_ID`) that this illustrative sketch didn't anticipate.

## What's still open

- **Category 6 (agreement/disagreement)** — not built, per the plan doc's own flag. Happy to take a first pass once you want that design conversation rather than a guess.
- **Category 7 (rudeness toward a specific NPC) — built, 2 September 2026.** That design conversation happened (`claude/Bloom_Wars_Praise_Insult_Apology_System_Proposal_v1.md`) and the resulting Praise/Insult/Apology/Gift/Congratulate/Send-Off system shipped, including named per-NPC targeting and a full escalation ladder for repeated insults. Full account: `claude/Bloom_Wars_Build_Log_Addendum_CrewInteractionsBrainstorm_02Sep2026.md`.
- **Live-feel validation — Greeting/Farewell done via automation, 1 Sep 2026; CO confirmed separately by Maxime the same day.** Typing "hey"/"bye" to a real crew NPC in Maxime's own running game produced her exact Wolf-bank greeting/farewell lines, verbatim. Advice, Banter, and Worry-checkin content weren't reachable in that same automated pass (the NPC had wandered out of single-target range) — the correctly-behaving fallback fired instead of a crash, which is itself a good sign, but the actual line content for those two categories is still owed a direct check from Maxime's own play. The CO specifically has since been checked by Maxime directly in the grotto and confirmed working ("the guy in the grotto is okay") — that gap is closed.
- **Exact match order and any existing keyword collisions — resolved.** See the Master Index's own account of the real precedence slot chosen.
- Whether Advice/Banter should ever vary by *which* NPC answers versus always using the responding NPC's own catalyst — shipped as "whichever NPC answers uses their own line," the simpler of the two, matching what this doc originally assumed. The CO is the one deliberate exception: he uses his own bespoke bank instead of a catalyst pool when he's the one being talked to.
