# THE BLOOM WARS — Rourke "Unflappable" Line Bank v1

Content-only, no engineering required to fold into the existing `LINE_BANK` shape — same status as `Bloom_Wars_Munti_Respect_Line_Bank_v1.md`. Written from an in-chat brainstorm (28 Aug 2026): Maxime asked for NPC banter about the MC's apparent unflappability — "doesn't he ever panic?" — and a project search turned up a real, already-locked answer sitting in `Bloom_Wars_Independent_Campaign_The_Amaranth_Reckoning.md` §6b (Command Fatigue): Maxime's own words, *"the only thing the MC is exempt [from] is death itself... i think she should feel loss and panic too."* Rourke is not actually unflappable — she's exempt from permadeath, not from Stress/Morale, and her fragility is designed to show up as *pace* (a future deploy gate) rather than a visible on-screen break. That tension — crew sees ice, canon says it's not really ice — is the whole bit this bank is built around.

**Corrected mid-brainstorm, and this is the load-bearing design constraint for the whole bank: nothing here is pinned to a named pilot.** The first draft leaned on Bosk ("her mentor, saw her crack once") as a witness — Maxime's own reminder killed that approach: NPCs die fast under this campaign's real permadeath rule and get recycled (generated Lance recruits, emergency Munti replacements, Character Editor pilots), so a line that depends on one specific named pilot still being alive to have said it is a bug waiting to happen the moment that pilot goes down. Every line below is tagged by **catalyst** (the existing 9-entry Reaction Engine set) and **Stage** (Green/Blooded/Command, already derived live off pilot gear tier via `stageFromTier()`) instead — the same two axes the real `LINE_BANK` already partitions on, so whoever's actually alive and holding that catalyst/Stage combination can say it, original cast or someone's third replacement.

## The framework

Each catalyst reads the same underlying fact (she doesn't flinch) through its own lens — Wolf frames it as what holds the squad together, Cat frames it as personal insurance, Fox suspects a mask, Rabbit worries about the person under it, and so on. Stage adds a second axis on top of that: **Green** pilots are still mythologizing her from outside, having not tested the claim themselves; **Blooded** pilots have watched her operate under real fire and speak from firsthand memory; **Command**-stage pilots have started carrying command weight themselves and read her from the inside, at the cost of some of their own certainty. The combination is meant to feel like the same question asked at three different depths, not three unrelated jokes.

2 lines per catalyst × Stage cell, 9 catalysts × 3 stages = **54 lines total**, all NEW content.

## Wolf (teamwork)

**Green**
- "They told us before we even shipped out — follow her, she doesn't break. I'm still finding out if that's true or just what green pilots get told."
- "I don't know her. I know the squad doesn't scatter when she's on comms. That's enough for me right now."

**Blooded**
- "Whatever's actually going on under there, it holds the formation together. I've built three tactics around just trusting that it will."
- "You want to know if she panics, watch the squad instead. We don't. That's her, not us."

**Command**
- "I run my own lance the way she runs hers — like the center holding is the whole job. Doesn't leave a lot of room to ask if it's costing her something."
- "Command is a shape everyone else takes from. I learned that watching her. I don't know what shape she takes it from."

## Dog (loyalty)

**Green**
- "I don't need to know if she panics. I need to know she's where she says she'll be. So far, always."
- "First time I heard her voice on comms mid-fight I stopped being scared. Didn't ask myself why. Still haven't."

**Blooded**
- "I've followed her into worse than this without checking twice. That's not blind, that's earned. I earned it watching, not guessing."
- "Doesn't matter to me what's happening behind her eyes. Matters that she's never once told me something that turned out to be a lie to keep me calm."

**Command**
- "Loyalty like mine gets called naive by people who've never had a commander worth it. I've had one. I know the difference."
- "I'd follow her into the kind of fight where nobody comes home talking. I have. She was right there in front, same as always."

## Cat (selfishness)

**Green**
- "Don't care if she panics. Care that she's good enough nobody dies finding out. So far, fine by me."
- "Everyone's got a theory about Rourke. Mine's simple — as long as her calm keeps me breathing, I don't need it to be real."

**Blooded**
- "I've stopped asking if the ice is genuine. It's kept me alive four missions running. That's the only audit I care about."
- "Somebody else can worry about what it costs her to look like that. I've got my own hide to keep whole."

**Command**
- "You get to my rank, you learn everyone's calm is partly performance, hers included. Doesn't bother me. Performance that keeps the unit alive is a service, not a lie."
- "I don't need her to be unbreakable. I need her to keep being useful to me right up until she isn't. Cold, I know. I'm still here because of it."

## Crow (indulgence)

**Green**
- "Somebody start a pool. First time Rourke actually flinches, I want to have called it."
- "I want to see it just once. The crack. Purely for the story I'd get to tell after."

**Blooded**
- "Ran a whole book on it for a while — dead serious, actual odds. Nobody's collected. I'm starting to think that's the real punchline."
- "I've teased her about it to her face. Got a look that ended the bit fast. Worth it, honestly."

**Command**
- "Used to want to see her crack for the gossip. Now I mostly hope I never do. Funny how rank changes what you find entertaining."
- "Still the best story nobody's got. I've stopped chasing it. Some jokes aren't actually jokes once you're close enough to the punchline."

## Raven (instruction)

**Green**
- "I've started taking notes. Whatever she's doing with her breathing before a call, I want to be able to do it too someday."
- "They should teach whatever she's got as a class. I'd sit front row."

**Blooded**
- "Best I can tell, it's not that she doesn't feel it. It's that she's decided the feeling doesn't get a vote. I'm trying to learn the same trick."
- "Watched her give an order with her whole squad in the red. Voice didn't move an inch. I've replayed that a dozen times trying to reverse-engineer it."

**Command**
- "I teach new lance leads now. First thing I tell them: it's not that command doesn't shake. It's deciding the shake doesn't get to talk. Learned it watching her, though she never said a word about it."
- "Whatever she's built, it's not natural talent. Nobody's born that steady. I've spent a career trying to build my own version of it."

## Bear (isolation)

**Green**
- "Don't know her well enough to say. Don't know anyone well enough to say, honestly. Just noticed she's steady. That's all I've got."
- "She's not close to anyone I can tell. Neither am I. Maybe that's just what it looks like from out here."

**Blooded**
- "Nobody really gets close enough to know if it's real. I don't get close to anyone either. Might be why I don't find it strange."
- "I don't need her warm. I need her consistent. She's been that every time I've had eyes on her."

**Command**
- "Command is lonely at every rank, hers worse than mine. If she's not panicking, it's probably because there's nobody left to panic in front of. I'd know."
- "I've stopped expecting anyone to let me see the real version. Wouldn't surprise me if she's stopped expecting it too."

## Fox (trickery)

**Green**
- "Nobody's that calm for free. I just haven't worked out what she's trading for it yet."
- "Watching for the tell. Everybody's got one. Haven't found hers. Yet."

**Blooded**
- "I've caught plenty of people running a bluff under fire. Hers doesn't read like a bluff. That almost bothers me more."
- "If it's an act, it's the best one I've ever seen run this long without slipping once. At some point I stopped trying to catch it and started respecting it instead."

**Command**
- "Spent years assuming there was a seam somewhere. Command taught me some masks are just the face, worn in until there's no difference left. Might be looking at one."
- "I still clock people for a living. Clocked her a hundred times. Come up empty every time. I've started to think empty is the actual answer."

## Rabbit (nurturing)

**Green**
- "Somebody should check on her. Not because anything's wrong — just because nobody ever seems to."
- "I worry about her a little. She looks out for all of us. Wondered who looks out for her."

**Blooded**
- "I've started leaving her the good rations without saying why. Small thing. Felt wrong not to do something."
- "She never asks anyone to hold her up. I think that's exactly why somebody should, whether she asks or not."

**Command**
- "I've watched command eat people who never let anyone catch them first. I don't know if she's the exception or just further along the same road."
- "Told her once she doesn't have to be fine in front of me specifically. She said thank you and changed the subject. I'm still leaving the door open anyway."

## Shark (ambition)

**Green**
- "That's the bar. Unshakeable, whatever it costs. I intend to clear it someday, whatever it costs me."
- "I want to be the pilot people say never panics. She's proof it's possible. That's all the invitation I need."

**Blooded**
- "I used to want her calm. Now I want my own version of it — better, if I can manage it. Competitive, I know. Keeps me sharp."
- "Every fight I don't flinch is a fight I've closed the gap on her by a little. She'd probably say that's not the point. I don't fully believe her."

**Command**
- "I chased her calm for years thinking it was the finish line. Command's taught me it's just the entry fee. I'm still paying it."
- "I outrank half this ship now and I still measure myself against her. Some benchmarks you don't retire just because you've technically arrived."

## Honestly still open

- **Echo bucket unassigned.** The real `LINE_BANK` is `Record<Catalyst, Record<Echo, Record<Stage, string[]>>>` — these 54 lines are catalyst + Stage only, no Echo (Hangar / After Action / Off Duty / Under Pressure / Close Call) tag yet. Most of these read as Off Duty or Hangar banter rather than in-mission lines; a pass to assign Echo per line (or a decision to bucket the whole set under one Echo) is a real remaining step before this can fold into `ambientLines.ts` as-is.
- **No engineering attempted.** Same status as the Munti Respect bank at delivery — pure content, not wired into any file, no `combat_sim.py`-equivalent check needed since nothing here is a balance number.
- **The payoff line is still speculative.** Several Command-stage lines lean on the idea that *nobody* has actually seen her crack — that's consistent with Command Fatigue (§6b) being design-intent only, not a shipped mechanic. Once Stress/Morale actually exists and gates deploys, there may be room for a rarer, higher-tier line that reacts to her actually being in a "breaking" state for the first time — not attempted here, since that state doesn't exist in the live engine yet.
- **Naming lock checked.** No reserved terms appear anywhere in this bank — clean.

## Update 1 (28 Aug 2026) — sub-catalyst lines, a plan, not built

Maxime asked for a plan for sub-catalyst lines "for when we shipped" — read as: don't write the content now, scope the approach so it's ready to pick up whenever this bank actually gets integrated. Nothing in this section is built.

**What "sub-catalyst" means here.** A created pilot can carry a primary catalyst plus an optional secondary — "a Fox with a Dog's loyalty underneath" (`Bloom_Wars_Character_Editor_v1.md` §2). The already-shipped bleed mechanic (`pickAmbientLineWithBleed`, Social Sim Roadmap #2) already handles the cheap version of this for free: ~30% of the time, a pilot with a secondary draws an ordinary line from *that* catalyst's own bucket instead of their primary's. Since all 9 catalyst buckets in this bank are already written, **a Fox/Dog pilot can already occasionally deliver a pure Dog "unflappable" line today, zero new work needed.** What that mechanic doesn't do is anything that actually acknowledges the combination — it reads as "sometimes Fox, sometimes Dog," never "Fox with Dog underneath." Whether that gap is worth closing, and how, is the actual question this plan is scoping.

**The real problem: the combinatorics don't fit a hand-written pass.** Primary × secondary is 9 × 8 = 72 ordered pairs (ordered because "Fox with Dog underneath" reads differently than "Dog with Fox underneath"), × 3 Stages = 216 cells. Even at 1 line each that's four times the size of the bank above. Writing all of it blind, before anyone's confirmed which pairs actually occur in the live game, is the kind of scope growth worth flagging rather than just doing — so, three ways to cut it down, not a decision made here:

- **Option A — do nothing new.** The bleed mechanic already delivers sub-catalyst flavor for free, today, from content that already exists. Cheapest by a wide margin. Never actually characterizes the *pairing* itself, only alternates between two single readings.
- **Option B — a small template-slotted "tension" set, not pair-specific.** Maybe 9-12 catalyst-agnostic lines built on `{PRIMARY}`/`{SECONDARY}` slots ("I don't know if that's the {PRIMARY} talking or the {SECONDARY} underneath — maybe both"), reusing the exact infrastructure Crew Banter §11's template-slot resolver (`crewBanterSlots.ts`) already proved out for `{SQUADMATE}`/`{MISSION}`/`{CLASS}`/`{LOADOUT}`. Covers all 72 pairs automatically through slot-filling instead of hand-authoring each one. The tradeoff is genericness — a slotted line can't be tuned to a specific pairing's actual voice the way a hand-written one could.
- **Option C — hand-authored, but scoped to pairs that actually exist in the live game**, not all 72 mathematically possible ones. Blocked on two things that aren't settled yet: named pilots' own catalyst reads are still "a proposal, not locked" per Crew Banter §10, and the Character Editor's animal-preset table (which pairs get generated for player-made pilots, and how often) is still an open item per that doc's own §4. Best fit, but not buildable until those two land.

**Recommendation, not a decision:** B is the practical middle path if this gets picked up before C's blockers clear — it reuses proven infrastructure and scales to the full pairing space without a 216-cell writing job. A costs nothing and is already live either way. Maxime's call on whether this is worth doing at all before Early Access or held for after, same bucket as the rest of the Social Sim Roadmap's "ongoing, no end date" items.
