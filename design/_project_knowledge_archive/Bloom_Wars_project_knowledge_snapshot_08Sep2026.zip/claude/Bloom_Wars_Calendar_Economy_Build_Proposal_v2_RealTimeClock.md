# THE BLOOM WARS — Calendar Economy: Build Proposal v2 (real-time clock)

**Supersedes v1's core model.** Written 2 September 2026. v1 (`claude/Bloom_Wars_Calendar_Economy_Build_Proposal_v1.md`, same day, a few minutes earlier) proposed a discrete per-action pricing model, following the locked docs. Maxime rejected that model directly and replaced it with his own, verbatim and worth keeping visible rather than paraphrased into something tidier:

> "time spent in the hub and time spent on mission run on the same ckock. depend on time player spend in each. like a inevitable day night cycle in wow. the calandar run when you play. no matter what you do. some event take some times some less. your call on it. byt this is my vision."

v1 is left in the project unedited as the record of the model that got rejected and why the replacement is better — it isn't wrong about the plumbing (§2's data model, §7's scope list, §5's epoch all survive intact), only about what drives the clock.

## 1. The model, restated

The calendar is **a clock that runs while you play**, not a bill charged per action. Real time spent in the Hub and real time spent in a mission both feed the same counter, at the same rate. Standing in the Rec Room doing nothing advances the calendar exactly as fast as flying a sortie does, because both are real time spent in the world — this is the WoW day/night-cycle comparison Maxime reached for, and it's the right one: an inevitable ambient clock, not a resource meter.

Discrete per-event costs still exist ("some event take some times some less") but they are **demoted from the primary mechanism to an accent layer** on top of the running clock. This is the single biggest structural difference from v1.

## 2. Doc drift this creates — flagged per the project's own rule

Two locked docs now say something the game won't do. Per "don't let the docs quietly drift from what we actually decided," both need updating, and neither should be silently left to rot:

- **`claude/Bloom_Wars_Calendar_System_v1.md`** specifies that the calendar advances "via a fixed cost per mission on completion, **independent of real play speed**." That is now exactly backwards — real play speed is the primary driver. This doc needs a real correction pass, not a footnote.
- **`claude/Bloom_Wars_Walkable_Hub_Build_Plan_v1.md` §4**'s itemized-pricing lock ("itemized, not a flat tax", with the CO < Rec Room < Berths ordering) is **partially** superseded. Itemized costs still exist and the ordering is still honored — but as small accents on a real-time base, not as the mechanism that moves the calendar. Worth a clarifying line rather than a rewrite; the ordering it locked is still doing real work below.
- `src/data/verbs.ts`'s own header comment ("Every verb is free until the calendar itself exists to spend against") stays accurate as written and needs no change.

## 3. The base rate

**1 calendar day = 6 real minutes of active play.** (`MS_PER_CALENDAR_DAY = 360_000`.)

Reasoning, so this is a tunable decision and not a magic number: that's ~10 days per real hour. A 30-hour campaign lands near Day 300, which puts `Bloom_Wars_Calendar_System_v1.md`'s own example landmark — "Day 212 — The Reckoning" — in late-campaign territory, exactly where a name like that reads like it belongs. The whole rate is one constant in one file; if it feels fast or slow in real play it is a one-line change, and it is expected to move at least once after playtesting.

## 4. Where the clock ticks

**Hub and Battle only** — the two contexts Maxime named explicitly ("time spent in the hub and time spent on mission"). Deliberately NOT ticking in MapSelect, Debrief, the shop panel, or any menu overlay: that's UI time, not world time, and burning in-fiction days while a player reads a shop list would be charging them for deliberation rather than for living in the world.

Tab-away is handled for free — Phaser pauses its own update loop when the page loses visibility, so the clock stops when the player alt-tabs without any special handling.

**Known corner, flagged now rather than discovered later:** a player who idles with the tab focused burns days doing nothing. This is harmless while the calendar is cosmetic-only (which is still locked, see §7). If mechanical teeth are ever added on top of this, that idle case is the first thing that needs rethinking — a real-time clock with real consequences punishes going to make a coffee.

## 5. The accent layer — per-event costs

Maxime's answer on tier spread was explicitly **"narrow the gap"** — the calendar should barely be felt per-action, with the background clock doing the real work. Final numbers:

| Verb | Accent | Why |
| --- | --- | --- |
| `talk`, `gift`, `praise`, `insult`, `apology`, `congratulate`, `sendOff` | **0** | Conversation. The running clock already covers the minute it took to say it. |
| `shareADrink`, `pegBoard`, `fletchers` | **+0.25 day** (6h) | A real, short sit-down activity. |
| `poker`, `askOut` | **+0.5 day** (12h) | The longer end — a full Hold'em session, or a real date-tier ask. Preserves §4's locked Rec Room < romance ordering. |
| `angerBlowup`, `breakdown`, `spar` | **0** | System-triggered, never a player choice. Confirmed directly by Maxime. |

**Being honest about what these accents are.** A poker session already ticks ~1.7 days of real clock while the player actually plays it. The +0.5 on top is not a duration model — it's a deliberate thumb on the scale marking "that was a real activity, not just standing in the room." Stating that plainly here so nobody later reads the table as an attempt to simulate how long darts takes.

## 6. Mission completion

**+2 days flat**, applied once in `Debrief.ts`, **on top of** whatever real time the Battle scene already ticked. This represents the transit, prep and return that never get played out on screen.

A 20-minute mission therefore lands around 5-6 total days — close to v1's flat 5-day guess, but arrived at honestly and now scaling with how long the player actually takes, which is the entire point of the model change.

## 7. What carries over from v1 unchanged

- **Data model** — one new `CampaignState.calendarDay: number`, a float (the fractional accumulation is the whole mechanism now, so truncating early would break it outright rather than merely lose signal). Backfill for pre-calendar saves: `if (state.calendarDay === undefined) state.calendarDay = 1;`.
- **Epoch** — Day 1 is campaign start, first Hub load on a new save.
- **Cosmetic only, no fail state**, this pass. Still locked, unchanged, and now doubly important given §4's idle corner.
- **UI** — a third corner-text line in the Hub following the existing `(16, 20)` / `(16, 80)` anchor convention; a "Day 47 → Day 52" stamp on Debrief; final day count at the finale as a shareable stat, no leaderboard (there's no backend, it's a pure-`localStorage` game).
- **Named landmarks** ("Day 47 — Muster") remain a separate, later content task — deciding which day numbers earn a name is a writing decision, not this build's.

## 8. New plumbing this model needs that v1 didn't

- **`src/engine/calendarClock.ts`** — a new small module owning the rate constant and a single `tickCalendar(state, deltaMs)`, plus `applyVerbCost` / `applyMissionCost` for the accent layer. One home for every calendar number, so tuning never means hunting through scenes.
- **Tick wiring** in `Hub.ts`'s and `Battle.ts`'s update loops — the actual real-time accumulation.
- **Persistence timing** — the accumulated fraction has to survive a scene transition. Existing `saveCampaignState` call sites on scene exit should cover it; if Hub doesn't already save on the way out, that's a small addition to make deliberately rather than by accident.

## 9. Naming-lock safety check

No proper nouns invented. Nothing here approaches the reserved book-series terms.
