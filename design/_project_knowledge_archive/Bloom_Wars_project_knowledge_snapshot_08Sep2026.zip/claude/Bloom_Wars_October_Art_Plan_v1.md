# Bloom Wars — the October art plan (v1)

*Written 26 August 2026, for spending in October. You said $100 loose, and asked for something you can just follow instructions on when you get there — that's what this is. It assumes you're starting from zero on this: no account set up yet, no prompts written yet.*

**Update, same evening — done, all fifteen, before October even started.** Turned out there was no reason to wait: the existing Gemini Pro subscription (§0/§1's free path) covered the whole thing at no extra cost. All fifteen named pilots across all three lances — Rourke, Bosk, Lask, Iyari, Anand (Lance A); Okafor, Solheim, Tarrant, Vashti, Reyes (Second Lance); Kova, Ness, Onwuka, Delgado, Yeun (Third Lance) — are generated and saved in `assets/portraits/` as `<surname>_portrait.png`. The shot list, prompt template, and mek-track tell key below are kept as-built documentation, not a still-pending to-do — useful if any portrait needs regenerating later, or as the pattern to follow for future recruits. The $100 is genuinely free for something else now; see the chat thread for the honest misses worth knowing about (Hiopi reading female-presenting didn't take, the rune-tech glow is generic AI invention not your actual script) — both real placeholder gaps for whenever there's a real artist, not bugs to keep chasing with prompts.

**One caveat up front, honestly stated:** the prices below are current as of today. AI pricing moves fast — before you actually spend anything in October, spend thirty seconds confirming the per-image rate hasn't changed (aistudio.google.com's pricing page). Everything else in this plan holds regardless of small price drift.

## 0. Updated call: you already have Gemini Pro until 6 October — use that first, don't wait for the $100

You told me you're already subscribed through the 6th. That's a subscription that already includes image generation in the consumer **Gemini app** (gemini.google.com) — a different door than the pay-as-you-go API path this doc originally assumed, and one you've already paid for. That changes the order of operations:

- **Do the shot list now, before the 6th, in the Gemini app, at no extra cost.** Fifteen portraits (or even forty-five, if the template takes a few tries to lock) is nowhere near enough volume to worry about a quota — Google doesn't publish an exact image-generation cap for the Pro tier, but it's a "compute budget refreshing every few hours" model, not a hard per-image ceiling, and this shot list is small. If you do hit a soft wall, just space the rest across a day or two.
- **The $100 stays untouched for now.** Once the shot list is done inside your existing subscription window, the $100 is free to become a real, separate decision in October: renew the subscription another month if you want ongoing access (for battle sprites later, Hub backgrounds, whatever), or bank it, or spend it on something else in the project entirely. Not deciding that for you — just flagging that "the $100 plan" and "the portrait plan" have come apart, which is good news, not a complication.
- **Everything from §2 onward — the shot list, the prompt template, the sequencing — is unchanged.** Only the account-setup step below changes.

## 1. Account setup — the free path (do this before the 6th)

1. Go to **gemini.google.com**, signed in with the Google account that's on the Pro plan.
2. Ask it directly for an image, using the template in §3 — no API key, no billing page, no coding. If the response text describes an image instead of generating one, or gives you a noticeably weaker model, that's a sign the image-gen entry point in the app has moved since this was written; look for whatever the app currently calls its image/creation mode and use that instead.
3. Nothing to configure here — this is the "just follow instructions" version. If it stalls or the results are visibly worse than expected, that's the trigger to fall back to §1b below, not a sign something's broken.

### 1b. Fallback — pay-as-you-go via Google AI Studio (use this only if the free path above doesn't get you through the shot list, or once the 6th has passed)

1. Go to **aistudio.google.com**, sign in with your Google account. No coding involved — it's a prompt box in a browser, type a description, get an image back, download it.
2. Free access here is separately throttled and "can change without notice." To move past that, attach billing: follow the "Get API key" / upgrade-to-paid flow, which asks for a credit card and creates a Google Cloud billing project behind the scenes. Normal, not a dark pattern — it's how every pay-per-use API works. Current rate is roughly **$0.134 per image at 1K/2K resolution** (plenty sharp for a portrait), so the $100 covers about 740 images if it ever comes to that.
3. Once billing's attached, set a budget alert: Google Cloud Console → Billing → Budgets & alerts → new budget, $100, alert at 50%/90%/100%. Honest caveat: this **notifies** you, it doesn't automatically cut off spending — but per the math in §5, you won't get anywhere near $100 doing what this plan actually asks for.
4. Confirm which model name is current when you get there — "Nano Banana Pro" is what people call Gemini's image model right now, but Google renames these. Whatever AI Studio's top-line image model is at the time is the one to use.

## 2. The shot list — in priority order

Fifteen named pilots exist across the campaign's three lances. That's the actual list — don't try to hand-craft portraits for procedurally generated recruits later; reuse a small set of generic portraits per class/species for those instead, or that scope never ends.

**Lance A — Warden Company (do these first, they carry the whole campaign):**
1. 2nd Lt. Dessa Rourke "Lark" — human, Meeps. The protagonist. Do her first if only to test the style.
2. M.Sgt. Halvard Bosk "Anvil" — human, Tank. Scripted death at Mission 12 — his portrait will get used at the moment it matters most, worth getting right early rather than rushing it last.
3. Spec. Corin Lask "Patch" — human, Munti.
4. Pvt. Tegan Iyari "Foxfire" — Hiopi, centauroid, Meeps.
5. Cpl. Priya Anand "Farsight" — Osnian, vibrissal, Reeps.

Notice 1–3 are human and 4–5 aren't. Do the three humans first — zero extra research needed. Before generating Iyari or Anand, pull the actual visual description of Hiopi and Osnian from the GDD/Canon Pass (or ask me to pull it for you) rather than guessing alien anatomy from the word "centauroid" alone — I didn't bake invented alien features into the template below on purpose, since getting that wrong is worse than just checking first.

**Second Lance (forms at Mission 13) — five more, names in `campaignAmaranth.ts` if you want them ahead of time.**

**Third Lance (forms at Mission 25):**
6. Sgt. Mireille Kova "Bastion" — vibrissal, Tank.
7. Cpl. Aurelio Ness "Rampart" — centauroid, Tank.
8. Pvt. Sable Onwuka "Whiplash" — vibrissal, Meeps.
9. Spec. Rasha Delgado "Longshot" — bipedal, Reeps.
10. Cpl. Faro Yeun "Splint" — centauroid, Munti.

Fifteen total. If October only has energy for Lance A, that's a genuinely complete, satisfying stopping point — those five are the ones a player actually bonds with first.

## 3. The locked prompt template

The one real weakness in this pipeline is that separate generations drift from each other — proportions shift, style wanders. The fix is a template you don't touch except for the bracketed pilot-specific facts, so all fifteen read as one roster instead of fifteen different artists' work.

```
A painterly military sci-fi character portrait, head-and-shoulders, three-quarter
view, of [NAME] ("[CALLSIGN]"), a [SPECIES] mech pilot wearing a worn combat
flight uniform appropriate to a [CLASS] pilot ([Tank: heavier, armored,
utilitarian] / [Meeps: leaner, mobile, minimal bulk] / [Reeps: has visible
targeting/optics gear] / [Munti: has visible medic or field-repair gear]).
Muted, desaturated palette — steel blue-grey, rust, faded olive, no bright
saturated colors. Serious, weathered expression. Tone is WW1/WW2 trench war,
not glamorous or heroic-poster. Plain soft gradient background, dark slate
grey, nothing else in frame. No text, no logos, no watermark. Square format.
```

Fill the class-specific bracket with just the one relevant clause, delete the others. Generate Rourke first. Look at it before doing anyone else — if the style's off, adjust the *style* language (palette, tone, tightness of the description), not the per-pilot facts, and regenerate until it feels right. Then lock that exact template and don't touch the style block again for the rest of the roster. That consistency discipline is doing more work than any single prompt tweak would.

One deliberate simplification, worth knowing why it's there: no transparency, no cutout, no chroma-key. A flat gradient background dropped straight into a dialogue panel avoids the single hardest, most failure-prone part of AI-generated game art entirely (Gemini can't produce real alpha channels — getting a clean transparent cutout is its own separate, fiddly pipeline). Portraits don't need it. Save that problem for if and when you ever tackle battle-unit sprites, which is a Stage 4 problem, not an October problem.

## 4. What to actually do, step by step

1. Set up AI Studio, billing, and the budget alert (§1).
2. Generate Rourke. Judge it. Adjust the template's style language if needed, regenerate, until it's locked.
3. Run the same locked template for Bosk, Lask (both human, no extra research).
4. Pull Hiopi and Osnian visual references, then run Iyari and Anand.
5. Download each as it's generated, named consistently — `rourke_portrait.png`, `bosk_portrait.png`, etc. — into one folder so nothing gets lost.
6. Stop. Five portraits, Lance A complete, is a real finish line — not a "phase 1 of something bigger you have to keep pushing through."
7. If there's budget and appetite left, repeat for the Third Lance (names above) and the Second Lance (pull those names from `campaignAmaranth.ts` first).

## 5. The budget math, if you end up on the fallback path

If the free subscription path in §1 covers the whole shot list, this section doesn't matter — skip it. If you're on §1b instead: $100 at $0.134/image ≈ 740 generations. Fifteen pilots, even at a generous three attempts each while you're dialing in the template, is 45 generations — about $6. You will not be anywhere close to spending the full $100 doing exactly what this plan asks for. That's not an accident — it means there's real room left over afterward to try a couple of Hub background establishing shots (the Rec Room, the Hangar Deck) if you want scenery too, without needing a second $100 event to do it.

## 6. What this plan deliberately doesn't cover

Battle-unit sprites — still Stage 4 in the master plan, still not urgent, still a genuinely harder problem (transparency, multi-tier consistency across dozens of variants) that doesn't need solving in October. The rights/copyright caveat from our chat still applies exactly as stated there — nothing new to add here, just don't forget it exists before anything ships commercially.
