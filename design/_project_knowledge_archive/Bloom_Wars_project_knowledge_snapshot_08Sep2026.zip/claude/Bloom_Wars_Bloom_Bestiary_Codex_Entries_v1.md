# The Bloom Wars — Bloom Bestiary: Codex Entries v1

*Written 2 Sep 2026, right after the Coalition World entry closed out — Maxime's own stated priority order. This is the second real content pass for the Codex's eventual lore/bestiary tabs (`Bloom_Wars_Codex_Design_v1.md` §11's order: content first, screen later). Same `_v1` status as everything else here — a full pass for reaction, not locked until you weigh in. Checked against `Bloom_Wars_Data_Pack_v0.1.docx` §8 (stats/on-hit rules), `Bloom_Wars_Independent_Campaign_The_Amaranth_Reckoning.md` (the three named Amaranth threats), `Bloom_Wars_Canon_Pass_v1.md` §E (color/lineage), the Enemy Variety Reuse note and individual mission build logs (debut missions), before writing a word of new prose.*

## 0. What this covers, and what it deliberately doesn't

**Nine live entries** — every Bloom archetype the player can actually encounter across the shipped 36-mission campaign, in the order they're first met: Crawlmass (Mission 1), Splitfang (Mission 2), Undertow (Mission 4), Sporethrower (Mission 7), the Choir (Mission 8), Gallcyst (Mission 9), Sirenmaw (Mission 12), the Wellroot (Mission 21), the Unnamed (Mission 35). Three of these (Crawlmass, Undertow, the Wellroot) already shipped as sample entries in `Codex_Design_v1.md` §6 and are carried forward unchanged below for a complete, one-doc reference — not rewritten, just not re-litigated either.

**One archetype deliberately left out: the Heartwood.** It's one of the original seven pre-rolled archetypes (Data Pack §8) and it's real, shipped data — but grep-confirmed (per the Master Index's on-hit-effects section) it isn't spawned by any live mission in either campaign today, only the archived Team One vertical slice. An unlock-gated codex entry for something the live game never actually shows the player is dead weight — it would sit locked forever. Noted here rather than silently dropped; easy to add back the moment it's ever placed in a real mission again.

**Two things this bestiary will never cover, on purpose, not an oversight:** the Mission 1a ambush mechs (`hostile_mech_01`–`04`) — the Build Brief is explicit these are never explained anywhere in game text, ever, and a bestiary entry would be exactly the kind of screen that quietly breaks that rule; and House Amaranth's own mechs (Marrow's forces) — those are a human faction, not Bloom, and belong under Personnel/World whenever that content gets written, not here.

**House Amaranth's "the Bramble"** (proposed Act III signature threat for that campaign, `Bloom_Wars_House_Amaranth_Mission_Plan_v1.md`) isn't included — it's a name and a pitch, no lineage, no stat block, nothing built. Add it here once it's real.

## 1. A voice call, made rather than left implicit — flag if it's not what you want

The three already-shipped entries (Crawlmass, Undertow, Wellroot) are written in a soldier's-eye, non-clinical register — description that carries a reaction in it rather than a separate quoted aside. Design doc §10 floated a fancier version of this (an explicit "field notes" line, Rourke's own voice quoted apart from the entry) as an unprompted idea, marked not decided. I matched the register the three shipped entries already use rather than bolting on a separately-attributed quote — it reads as one voice throughout rather than description-plus-commentary, and it's the version that's already live. If you want the more literal Rourke's-log framing instead, that's a real, cheap rewrite, not a redo — say so and I'll pass over these again.

## 2. The entries, in the order the player actually meets them

> **codex_bloom_crawlmass** *(unlocks on first encounter — Mission 1)* — *already shipped, `Codex_Design_v1.md` §6*
> **Crawlmass**
> The first thing most soldiers ever see of the Bloom, and the least dangerous — alone. A Crawlmass folds almost the instant it's hit. The danger was never any single one of them; it's that they never show up alone, and every one you're fighting is a turn you're not spending on something worse.

> **codex_bloom_splitfang** *(unlocks on first encounter — Mission 2)*
> **Splitfang**
> A Crawlmass drift with something coordinating it. Nothing changes about how any one of them looks or moves — until one spots you, and the rest turn like they heard it happen. They don't share a mind. They share a target, the instant one of them finds it, and three or four of them converging on the same mech in the same turn is the fastest way anyone's squad has folded on open ground. Kill the one that saw you first, if you can tell which it was. Otherwise, kill fast, and don't be standing wherever they all decided to look.

*(Carries Crawlmass's own "the danger is the swarm, not the unit" idea one step further — coordinated focus fire rather than just numbers, matching the pack-AI target-sharing rule directly without naming it mechanically.)*

> **codex_bloom_undertow** *(unlocks on first encounter — Mission 4)* — *already shipped, `Codex_Design_v1.md` §6*
> **Undertow**
> You will not see this thing until it wants you to, or until something with a sharper sensor does. It waits under the ground, motionless, right up until it surfaces to strike — and the strike lands harder for the wait. After that, it's just a target like anything else. The wait is the entire fight.

> **codex_bloom_sporethrower** *(unlocks on first encounter — Mission 7)*
> **Sporethrower**
> Slow, low to the ground, and it never has to be anywhere near you to hurt you. It plants itself at range and spits, and nothing you do at melee reach touches it back — no counter, no retaliation, just the shot landing and the next one already loading. It's not fast and it's not smart. It doesn't have to be either, from that far away. Close the distance or go around it. Standing where it can already see you is the one thing that doesn't work.

*(This is the game's first Reeps lesson delivered by an enemy rather than a teammate — matches the Data Pack's own note, "it is a Reeps, and it teaches the player what a Reeps does to them," without naming the class triangle directly.)*

> **codex_bloom_choir** *(unlocks on first encounter — Mission 8)*
> **The Choir**
> Whatever the flying ones usually are, this isn't one of them alone — it's several, and they don't hunt like several. They call and answer, mid-fight, in real time, closing from different angles on the same signal like it was planned before the fight started. Maybe it was. Nobody's found anything that looks like a leader among them, which is its own kind of unsettling — coordination this clean, and apparently nobody in charge of it. Whatever's screaming, it's screaming together.

*(Deliberately never says "Sirenmaw" or implies a relationship to it — the player meets the Choir four missions before they meet a lone Sirenmaw, so this entry has to stand on its own, per the design doc's own "an entry has to know only what's been shown by this point" rule. Stays soldier-level: describes the coordination, not the lineage or the palette-derivation reasoning that's real in the docs but invisible in-fiction.)*

> **codex_bloom_gallcyst** *(unlocks on first encounter — Mission 9)*
> **Gallcyst**
> It doesn't move, doesn't need to — plant it somewhere with a line of sight and it holds that ground better than almost anything else the Bloom fields. Whatever's actually alive inside that shell is small. Getting through to it is the entire fight, and for most of that fight it does not look like it's working. Then it does, all at once, and whatever's left underneath goes just as fast as it looked slow a moment ago. The acid it spits in the meantime doesn't wash off clean, and neither does the ground it lands on.

*(The first sessile the player meets, and the entry leans into the shell-versus-what's-underneath asymmetry — 140 Endurance, 20 Vitality — without stating either number, which is exactly the Collapse rule's own showcase moment per the Data Pack's "reads as tanky, then suddenly not." "Doesn't wash off clean" nods at the acid DoT and the bloom_mat tile conversion without describing either mechanically, matching the same restraint the Wellroot entry already uses for its own acid identity.)*

> **codex_bloom_sirenmaw** *(unlocks on first encounter — Mission 12)*
> **Sirenmaw**
> The first thing that flies. Ground, rubble, open water — none of it slows this thing down or gets in its way, and nothing on the field can wall it out. It doesn't hit hardest of anything you'll fight. What it does is scream, close enough and loud enough that everyone near the mech it's screaming at fights a little worse for a while — not just the one it caught. Take it down first if you can reach it, or plan the fight assuming your own aim is a little off for as long as it's still in the air.

*(A player reading this after Mission 8 gets to connect the dots themselves — "the flying ones" callback to the Choir's own opening line — without the entry spelling out the relationship. "Everyone near the mech it's screaming at" is the −20% attack debuff's own 2-tile spread, described rather than stated.)*

> **codex_bloom_wellroot** *(unlocks on first encounter — Mission 21)* — *already shipped, `Codex_Design_v1.md` §6*
> **The Wellroot**
> Solheim found the root structure two weeks before anyone found what's actually growing out of it — "too regular to be natural," she called it, and she wasn't wrong. It doesn't move, doesn't have to: it's already dug in past anywhere you'd want to reach it, and it calls up burrowers of its own the longer the fight runs. The wound it leaves isn't the kind that closes clean. Whatever's feeding it, it isn't hungry — it's patient.
>
> *(Stays soldier-level on purpose — it alludes to something deliberate behind the growth without naming House Amaranth or the bargain, matching what a pilot at Mission 21 has actually been told in-fiction by that point. The full truth is Mission 23's reveal, not this entry's.)*

> **codex_bloom_unnamed** *(unlocks on first encounter — Mission 35)*
> **The Unnamed**
> Nobody who's fought this thing has ever called it anything else, and nobody's tried very hard to fix that. It's not that no name fits — it's that naming it feels like agreeing it's one thing, singular, when everything about how it fights says otherwise. It doesn't move because it's already everywhere it needs to be. It doesn't panic when the shell finally gives, because nothing about what's underneath was ever waiting to be found — it was already there the whole time, under everything you thought you were fighting instead. Whatever it is you actually beat, if you beat it, you won't get a name for that either. You'll get to still be standing, and Meridian still standing under you. Some fights, that's the whole prize.

*(Written with real caution, worth stating plainly rather than just doing it quietly: this entry sits closer to the Build Brief's actual spoiler term than anything else in this doc, precisely because "no name given" is already the game's own real device for the same reason the book withholds one. The entry reinforces the absence as meaningful in itself — a refusal to call it "one thing, singular" — rather than framing it as a mystery waiting to be solved or a name nobody's found yet. Nothing here gestures toward a hidden true name existing to be discovered; that's the whole point of writing it this way. Flagging this so it gets a specific, careful read from you before it ships, not just the ordinary naming-lock pass every entry gets.)*

## 3. Naming-lock safety check

No Coalition terms, no "Synker," and — checked with the most care of anything in this doc — nothing here gestures at, rhymes with, or gets close to the Build Brief's actual spoiler term. "The Unnamed" entry specifically avoids implying a real name exists to be found; see its own note above.

## 4. Status

Nine entries, one deliberate omission (Heartwood, archived — see §0), two deliberate exclusions (Mission 1a's ambush mechs, House Amaranth's mechs — see §0). The voice call in §1 is a real decision, not a placeholder — flag it if you want Rourke's-log framing instead. Next natural pass, once you've reacted to these: Personnel (the roster bios, with the live-status problem `Codex_Design_v1.md` §4 already flagged), or Systems (lowest spoiler risk, already has three sample entries drafted and ready to extend) — your call which.
