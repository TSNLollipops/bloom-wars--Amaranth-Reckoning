# THE BLOOM WARS — The Catalyst Gauntlet, v2: House Amaranth's Third Lance, their Meks, Verinis, and the recruit generator

**Design pass — zero code. Sandbox dossiers updated; the engine change (§5) waits on "go."**

*Written 7 Sep 2026. Maxime, on the codex plan's note that the House's Third Lance had no backgrounds: "any playable pilot, mek and npc run the catalyst gauntlet." The gauntlet is the formula locked 1 Sep — `Background_Zones_v1` §6 (Sector → Zone; Academy × Birthplace Texture → Pressure; Zone × Pressure → Planet-12) and `NPC_Catalyst_Formula_Closing_And_Roster_Assignments_v1` §2 (Planet-12 → catalyst, a bijection). This document runs it for everyone the 1 Sep pass missed or that arrived after it, keeps that pass's own audit rules (§7 there: the same Academy × Texture pair always yields the same Pressure; no two entries share an identical full background), and finishes the one thing the formula needs before a generator can run it: the full Academy × Texture → Pressure table.*

## 0. Who was outside the gauntlet on 7 Sep — verified against `npcSeed.ts`, not memory

`BACKGROUND_CATALYST_ASSIGNMENTS` (48 entries) plus the two hand-seeded lists cover every named pilot and Mek from the 1 Sep pass. Outside it:

| Who | Catalyst today | How |
| --- | --- | --- |
| `pilot_thorne`, `pilot_kastan`, `pilot_osei`, `pilot_dunmore`, `pilot_amsel` — the House's Third Lance, added 6 Sep | whatever the djb2 hash of the id lands on | `catalystForPilot`'s fallback; nothing chose it |
| `mek_thorne`, `mek_kastan`, `mek_osei`, `mek_dunmore`, `mek_amsel` | same hash fallback | same |
| Brig. Verinis Amaranth (`facilityHouseAmaranth.ts` `co.catalyst`) | **shark — a placeholder, mine, flagged in the file** | hand-set 6 Sep, never derived. NB: his nine voice banks were written 7 Sep and are locked content — see §4.3's correction |
| Every generated recruit (`pilot_recruit_N`, `mek_recruit_N`) | hash fallback | `generatePilot` mints name/class/chassis only; no background exists to derive from |
| Rourke, Marrow | hand-picked (Marrow: dog; Rourke: **none** — `npcSeed.ts` flags it as a gap) | excluded from the 1 Sep pass by Maxime's own instruction; see §6 |

## 1. A structural fact the formula produces, stated before the table so nobody thinks it's a mistake

Planet-12 → catalyst is a bijection on nine cells, and the Frontier row holds exactly three of them: Mercury → Fox, Venus → Crow, Spider → Cat. **A Frontier-born pilot who never left the Frontier can only be Fox, Crow, or Cat.** Wolf, Dog, Raven, Rabbit, Bear, and Shark are Core and Mid-Rim results. This is not new — Iyari (Crow), Tarrant (Fox), Reyes (Cat), Vashti (Crow), Marrin (Crow), Reyken (Cat) already show it — but the Third Lance is the first group where it bites visibly, because two of the five are from the House's own ground and both come out Crow. Read it as the terraces' own texture rather than a coincidence: the formula is saying that people who stayed and kept planting under the drift for thirty years share a read. If that ever feels too narrow, the lever is the Zone × Pressure table, not the pairs below — and that table is locked.

## 2. The Amaranth Reach becomes the sixth sector — RESOLVED 7 Sep 2026

Every named pilot so far comes from one of Background Zones' five sectors, even the House's own regulars (Vondra: Glasswater; Meir: Cistgate). That was fine while the House's roster was officers and career soldiers who came to the Reach. The Third Lance addendum's own through-line is the opposite: "the people this war ran out of anyone else to send" — Thorne an ex-terrace foreman, Amsel a Ward-Crop Technician thirteen months ago. They are from the terraces. There is no sector to put them in.

**Maxime, 7 Sep 2026: "Yes 6th, terrace world called Aerius."** Locked. Zone: **Frontier** ("where the war is fought" — it is, literally, this game's war). Temperament: Hearth-Bloc-adjacent by blood (a charter dynasty) with a loyalist governor-general's office layered on top — the one sector in the list where the political tension is the campaign. Two planets, per the layer's own two-per-sector rule:

- **Meridian** — already canon: the capital, shipyards, the elevator, the governor-general's seat. Docksides, arcology stacks (the rings), garrison quarters.
- **Aerius** — the terrace world. **Maxime's name, 7 Sep 2026.** The ward-crop terraces, the Greathouse, the Fallow Line at their edge, the growth zones, every diversion relay: all of it is Aerius. This resolves a real ambiguity nobody had noticed — the Independent Campaign doc calls Meridian "the Reach's capital world" and the terraces "the sector's richest agricultural terraces," Warden's Act I holds the Fallow Line at the terraces' edge, and Act III "falls back to Meridian" ring by ring. Two worlds was the only reading that made the geography work, and no doc had ever said so. Now one does.

**What this settles beyond the two pilots:** House Amaranth's campaign is set on Aerius from Mission 1 to 36; Warden's Act I and II are on Aerius and its border, and the fall back to Meridian in Act III is an actual interplanetary withdrawal rather than a vague retreat inward. Worth a line in the Independent Campaign doc.

**Naming-lock check on "Aerius."** Grepped the whole `src/` tree and searched every project doc: zero hits, no collision with any of the 20 Background Zones proper nouns, the 72 mission names across both campaigns, any named pilot, Mek, Bloom archetype, room, or ability. It is not a Qiraki proper noun (it appears nowhere in the canon bridge material this project has been given), so it carries no porting risk. Neither reserved term is echoed or abbreviated by it. The real `lint-spoiler` run still happens on Maxime's machine at build time, as always.

## 3. The Academy × Texture → Pressure table, completed

Background Zones §6 defines Pressure as "a function of Academy × Birthplace Texture" and never writes the function down; the 1 Sep pass derived thirty-one of the forty-eight pairs implicitly and audited them for consistency. A generator needs all forty-eight. **Bold** cells are locked by an existing entry (changing one would change a shipped catalyst); plain cells are this document's proposal, chosen by the doc's own three definitions — Sheltered: stakes arrived late, filtered through family or institution; Tested: real, survivable hardship; Forged: early and direct, before the pilot had any say.

| Academy ↓ / Texture → | Dockside | Terrace Farmstead | Arcology Stack | Garrison Quarter | Drift Colony | Company Housing | Preserve-Adjacent | Academy Ward |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tallowmere Fitting Yards | **T** | **S** | T | **F** | **F** | **S** | **T** | **S** |
| Cutbank Muster School | T | **T** | T | F | T | **S** | F | **S** |
| Glasswater Conservatory | **T** | **F** | T | **T** | **T** | **S** | **F** | **F** |
| Cistgate Ledgerworks | **T** | **F** | T | **F** | **F** | **S** | **F** | **S** |
| Greywatch Muster | T | **T** | T | **T** | **T** | S | **T** | **S** |
| Line-trained | T | T | T | **F** | T | T | **F** | S |

Reading the proposals: Arcology Stack is Tested everywhere (vertical class geography is hardship, not catastrophe — and no entry had used the texture at all until this pass). Line-trained is never Sheltered except for an Academy Ward — a staff kid who grew up on a campus and never enrolled is the one line-trained upbringing an institution still filtered. Company Housing under a line-trained pilot is Tested, not Forged: a labour family's stakes arrive with the job, which is early but survivable; what happened to a specific technician on a specific terrace is *their* story and Pressure is not allowed to know it (the audit rule is the whole point). Cutbank Muster × Garrison Quarter is Forged because the doc's own sample cross ("knew the muster horn's cadence before they knew their own house's address") is a childhood inside the militia, not beside it.

Two locked cells look odd and stay: Conservatory × Academy Ward = Forged (Yeun) and Conservatory × Terrace Farmstead = Forged (mek_yeun). Both were reverse-fits protecting a Rabbit; the 1 Sep audit kept them and so does this.

Rarity check, 48 cells: 11 Sheltered, 24 Tested, 13 Forged. Frontier × Sheltered (Mercury) is reachable only through Company Housing or Academy Ward on a Frontier sector — "a governor's kid, a charter officer's family posted out there," exactly the outlier §6 wanted.

## 4. The gauntlet, run

Format follows the 1 Sep tables. Every full background below was checked against all 49 existing entries for an identical Sector + Planet + Texture + Academy; none collide. Every pair used matches §3.

### 4.1 House Amaranth — Third Lance (5)

| Pilot | Sector | Planet | Texture | Academy | Zone | Pressure | Planet-12 | Catalyst | Why this fits them |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `pilot_thorne` "Harrow" (Pvt., Tank/human, Armorer — ex-terrace foreman) | **Amaranth Reach** | Aerius | Terrace Farmstead | Line-trained | Frontier | Tested | Venus | **Crow** | Thirty years of drift at the edge of the field and he kept the harvest line running anyway — the deliberate, earned brightness Venus names, in a man who has never had a uniform and does not much want this one. Holds ground the way he held a line of pickers: by being the one who does not go home first. |
| `pilot_amsel` "Rootbind" (Pvt., Meeps/human, Armorer — Ward-Crop Technician 13 months ago) | **Amaranth Reach** | Aerius | Company Housing | Line-trained | Frontier | Tested | Venus | **Crow** | A House labour family, the money at one remove, the job in the growth zones from the day he could carry a rig. He kept replanting the line the drift crossed every season; that is a Crow's whole stance, chosen, not naive. The second Reach-born Crow — see §1. |
| `pilot_kastan` "Scarecrow" (Pvt., Meeps/Hiopi-centauroid, Runemaster) | The Understrand | Cistgate | **Arcology Stack** | Line-trained | Mid-Rim | Tested | Mars | **Shark** | Eleven levels down, "up" a direction other people took for granted; no academy would have her and the House's levy would. Advancement through conflict is the least indirect pairing on the table and she is its least indirect case: she is in a mech to get out of the stack for good. The first Arcology Stack entry in either roster. |
| `pilot_osei` "Silo" (Pvt., Reeps/Osnian-vibrissal, Quartermaster) | Emberfall Drift | Greywatch | Academy Ward | Line-trained | Frontier | Sheltered | Mercury | **Fox** | A Greywatch Muster staff kid — raised in the stores, never enrolled, learned every shelf in the quartermaster's cage before he learned to shoot. The rare Frontier-sheltered case: quick, improvising, "always one more shot stashed," and not yet actually tested. Fox is the scrounger's catalyst and the formula got there on its own. |
| `pilot_dunmore` "Chaffwind" (Pvt., Munti/Hiopi-centauroid, Fieldwright) | The Understrand | Loomvale | Company Housing | Line-trained | Mid-Rim | Tested | Mars | **Shark** | A registry-colony labour family, the charter house's paper handled by her parents and never theirs; no pipeline, the levy instead. A Munti who advances by being indispensable — the second Shark in the lance, and the two of them will know it. |

*A note on the two Sharks:* Kastan and Dunmore land on the same cell by honest derivation (Mid-Rim × Tested is the project's own "default soldier" read, and two Understrand line-trained kids with no institution to shelter them is exactly who fills a levy). Left as derived rather than nudged: the 1 Sep pass has three Jupiter/Bear Warden Meks and did not flinch. If a fifth distinct catalyst is wanted, Dunmore moves to Cordage Belt / Skeinreach / Drift Colony / Line-trained (Tested → Mars → still Shark) or to Long Marches / Harrow's Table / Garrison Quarter / Line-trained (Forged → Spider → Cat); the second is the only real alternative and it makes her a colder healer than "Chaffwind" suggests.

### 4.2 House Amaranth — Third Lance Meks (5), contrast with their own pilot

| Mek | Sector | Planet | Texture | Academy | Zone | Pressure | Planet-12 | Catalyst | Contrast |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `mek_thorne` | Cordage Belt | Tallowmere | Academy Ward | Tallowmere Fitting Yards | Mid-Rim | Sheltered | Saturn | **Wolf** | Raised on the Yards' own floor, steady and dutiful — the formation-minded constant under a foreman-turned-Tank who is still learning that a lance is not a picking crew. |
| `mek_amsel` | Glasswater Reach | Pale Cistern | Terrace Farmstead | Glasswater Conservatory | Core | Forged | Neptune | **Rabbit** | A cultivated plot on the leisure colony, real shelter, a real early loss the Conservatory could not prevent — fiercely protective of a pilot who has already lost one crew to the zones. |
| `mek_kastan` | Glasswater Reach | Pale Cistern | Garrison Quarter | Glasswater Conservatory | Core | Tested | Uranus | **Raven** | Close enough to Glasswater's comfort to see the gap, structured into instruction — the one voice that slows a Shark down long enough to aim. |
| `mek_osei` | The Understrand | Cistgate | Arcology Stack | Cistgate Ledgerworks | Mid-Rim | Tested | Mars | **Shark** | A stack kid who tested into the Ledgerworks and never looked down again — ambition beside a Fox's trickery; between them, nothing in the cage is ever unaccounted for. |
| `mek_dunmore` | Emberfall Drift | Emberfall | Terrace Farmstead | Greywatch Muster | Frontier | Tested | Venus | **Crow** | A farming pocket on the refinery world, hardship met with chosen lightness — the joke in the cradle beside a Munti who advances by never needing one. |

### 4.3 Brig. Verinis Amaranth — the House's own CO (1)

| Character | Sector | Planet | Texture | Academy | Zone | Pressure | Planet-12 | Catalyst | Why |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Verinis (`facilityHouseAmaranth.ts` `co`, `stage: "command"`) | **Amaranth Reach** | Aerius | Terrace Farmstead | Glasswater Conservatory | Frontier | **Forged** (locked: Conservatory × Terrace Farmstead) | Spider | **Cat** | Blood of a generational terrace dynasty — the texture's own definition, from the top of it rather than the bottom — sent to the Coalition's finishing school and back to command what is left. The Bloom has been at the edge of his family's ground his whole life; the Seal is on Osnius; he is what the House has at the front. Spider is "the interior nobody has fully mapped, maybe not even them," and Cat is self-preservation as the only stance left standing. |

#### The shark question, answered properly — 7 Sep 2026

Maxime, on being offered "keep shark" as an option: *"Why would keeping shark make it an exception?"* Fair, and the option text was sloppy. It would not be, and here is the actual accounting.

**Reverse-fitting is not an exception to the gauntlet. It is the gauntlet's own second procedure.** The 1 Sep pass ran 22 entries that way (§3 there): take the catalyst that is already locked, find the one Planet-12 cell that produces it, then pick a Sector/Planet/Texture/Academy that lands on that cell. The background comes out real and internally consistent; it was just derived backwards. Bosk, Iyari, Anand, Vondra, Meir, Bray and Orin all have their origins by exactly that route, and nobody calls them exceptions.

**So keeping shark is only an exception if he keeps it the way he has it now — hand-set, with nothing behind it.** That is the one thing "any playable pilot, mek and npc run the gauntlet" actually rules out. Give him a background that derives to shark and he has run the gauntlet as legitimately as Bosk did.

**But shark costs him the terraces, and that is the real fork.** Shark is Mars, and Mars is **Mid-Rim × Tested**. The Reach is Frontier. There is no background on Aerius, or anywhere in the Reach, that produces shark — the formula will not do it. A shark Verinis has to be from the Cordage Belt or the Understrand, which means a House scion who grew up off the terraces entirely: raised at the family's other interests, schooled in the Understrand's procedural culture, and posted back to the front as a career step. That is a coherent, honest reading of a charter-house blood relative. It is also a different man:

| | **Cat** (Aerius, Terrace Farmstead, Conservatory → Frontier × Forged → Spider) | **Shark** (Understrand, Cistgate, Company Housing, Ledgerworks → Mid-Rim × Tested → Mars) |
| --- | --- | --- |
| Where he's from | The terraces. The Bloom has been at the edge of his family's ground his whole life. | Off-world. The Reach is a posting, not a homecoming. |
| Why he's an asshole | Self-preservation is what is left after thirty years of watching the ground go. Guarded, unmapped, gives nothing away. | Ambition. The front is standing to be won, and Marrow is in the way of the winning. |
| Why Article Nine galls him | He is *from here* and may not command the defence of his own dirt. | It caps what this posting can be converted into. |
| Clashes with (`CATALYST_CLASH_PAIRS`) | wolf (Meir) and **dog (Marrow)** | wolf (Meir) and rabbit (Orin) |
| What that does at the table | Grates on the MC herself: loyalty against self-preservation, which is the Seal and the Sword in the one dial the ambient system has, and the axis Mission 28 turns on. | Grates on two of her lance. An abrasive CO the crew resents, with Marrow between him and them. |

#### Correction, same day — his lines DO exist, and they change the argument

**This section first claimed Verinis had no shipped dialogue, so nothing was at risk either way. That was wrong, and Maxime caught it: *"verinis line were made earlier today. they should exist."*** He is right. The claim came from `Bloom_Wars_House_Amaranth_Hub_Build_Plan_v1.md` §2 and the 6 Sep Hub addendum §4, both of which say his lines are still to be written — **both are stale as of today.** `Bloom_Wars_Now_And_Next.md` records the actual current state: *"Verinis's lines — content pass complete, 7 Sep 2026, all nine slots."* Greeting (5), Farewell (5), Advice, Confide (5), Callout (5), Build-approval (5), Brief (5), and the two check-in lines, all through the 4 Sep workflow — Maxime's first batch, a matching batch after. This is exactly the failure the project's own carried-over rule warns about: verify against the current file, not an older plan. I checked the plan and not the state doc.

**So the reverse-fit rule does apply after all.** There is now a locked voice to protect, which puts Verinis in the same class as Bosk and Iyari rather than in a class of his own. Keeping shark would be an ordinary reverse-fit; taking cat has to be consistent with what he already sounds like.

**And the voice argues for cat, independently of the geography.** Now_And_Next records the locked register as *mocking, sarcastic, icy-formal, flatly impatient, resource-not-person framing, deliberately-rote-as-the-joke, a running paperwork/logistics motif* — plus the samples on record ("Report to me before you deploy again, Colonel," "Did you forget something, Colonel?", "You're here for your next mission, Colonel? Here it is," and *caporal* as a deliberately-wrong-rank insult). Read against `catalystProfile.ts`'s own trait words:

- **cat** — alone, myself, independent, exit plan, self-preservation, solo, **distance**, not my problem
- **shark** — ambition, drive, win, push, relentless, stakes, ground, fuel, outwork

Icy-formality is distance. Hiding behind rote procedure is insulation. A running paperwork motif is a man putting forms between himself and people. Calling his own colonel the wrong rank on purpose is keeping her beneath notice, not competing with her. **Nothing in the register is hungry** — and hunger is the whole of shark. A shark CO would be claiming credit, pushing for more, racing Marrow; this one is managing a losing position from behind a desk and making sure nobody mistakes him for invested.

**The honest counter-read, stated so it is not buried:** "resource-not-person framing" can be read as shark's instrumentalism — people as fuel, which is literally one of shark's trait words. The tiebreaker is whether he *wants* something or is *protecting* something. The Facility Plan's own summary of him ("an asshole, plain and simple") plus the one thing the archive says in his favour — that he is the reason the estate still has power, walls and a roster — reads as a man holding a position, not climbing one.

**Caveat on my own evidence:** I have read the register summary and the sample lines recorded in Now_And_Next, not all nine banks verbatim. Now_And_Next says the content pass happened *in chat*, and I can find no doc holding the lines themselves. If the full banks contradict this read, the full banks win.

**Which raises a real flag, unrelated to the catalyst:** nine slots of locked, hand-authored voice content appear to exist only in a chat transcript. That is one context window away from gone, and it is the single most expensive kind of content in this project to reproduce (Maxime writes the first batch himself, by design). **Recommend a `Bloom_Wars_Verinis_Voice_Bank_v1.md` in the project holding all nine banks verbatim, before the plumbing pass.** Cheap now; unrecoverable later.

**My read:** cat — now on two independent grounds. The derivation lands there from the geography, and the voice he already has reads there too. The price stays the same: cat means Verinis is terrace-born.

**Open, pending his answer.** The sandbox shows cat; `facilityHouseAmaranth.ts` still says shark and stays that way until he calls it.

**Not stated on the page either way:** none of this reaches a player-facing string. His dossier in the codex carries "CATALYST — Cat" (or Shark) the way the Warden CO's carries Wolf, and nothing more.

## 5. The recruit generator — "any playable pilot" means the ones the shop makes, too

Today `generatePilot` (`campaignState.ts`) mints a rank, a name, a class, a chassis, and a Mek with a class-default track; `catalystForPilot` then hashes the id. A recruit has no origin, and the codex's intake dossier says so honestly. The gauntlet makes the intake line real. Engine shape, for the "go":

1. **`PilotRecord.background?: PilotBackground`** — `{ sector, planet, texture, academy }`, four string unions in `data/types.ts` (the twenty proper nouns from Background Zones §8 plus the Amaranth Reach, Meridian and Aerius). Optional: every existing save and every authored record reads as "no background," no migration.
2. **`data/background.ts`** — pure: `ZONE_BY_SECTOR`, `PRESSURE_TABLE` (§3, as data), `CATALYST_BY_CELL` (the §2 bijection), `deriveCatalyst(background)`, and `rollBackground(rng, opts)` with the two weightings Background Zones §7 asks for — the sector's own academy favoured, Line-trained common on the Frontier, textures not flat-uniform. Tests: every locked cell in §3 pinned; every one of the 49 + 11 authored backgrounds re-derives to its recorded catalyst (the audit, as a test, forever).
3. **`generatePilot`** rolls a background for the pilot and a second, contrasting one for the Mek (a different sector, at least), stores both (`mek.background` on the `MekArchetype` too — Meks run the gauntlet by Maxime's own words).
4. **`catalystForPilot`** gains one step between `BACKGROUND_CATALYST_ASSIGNMENTS` and the hash: if the record carries a background, derive. The hash fallback survives only for ids nobody has ever given an origin — after this, that is nobody.
5. **The codex intake line** reads the background: "Intake: the Understrand, Cistgate. Arcology stack. Line-trained." — four words the archive can say about a stranger without inventing a life.

Scope, plainly: a new persisted field on the pilot record and a new pure data module. Roughly 150 lines with tests; touches `types.ts`, `campaignState.ts` (one function), `npcSeed.ts` (one branch), and the codex's `buildDossier`. Nothing about the tactical loop. Folds into the codex build if Maxime says so; ships separately if not.

## 6. Rourke and Marrow — still outside, still Maxime's call

The 1 Sep pass excluded both protagonists on his explicit instruction. "Any playable pilot" could be read either way and I am not going to read it for him. What running them would mean: Marrow's dog is hand-picked and load-bearing (the Longhouse's clash math and the Verinis reading above both use it), so hers would be a reverse-fit — a Core × Sheltered background (Glasswater or Pale Cistern, Company Housing or Academy Ward) that a common-born career officer can carry, and the Independent Campaign doc's "common-born" makes Glasswater / Company Housing / Conservatory (Sheltered → Earth → Dog) almost write itself: the money one remove away, the finishing school on a scholarship, loyalty as the default setting of someone who was given a chance and never forgot who gave it. Rourke has *no* catalyst at all today — a gap the code flags — so hers would be a fresh derivation and would land wherever a Glasswater dockside kid who tested into the Conservatory lands (Tested → Uranus → Raven, the mentor's read, which is her Act III arc thirty missions early). Both are one row each once he says yes; neither is written into any table here.

## 6a. Decisions — Maxime, 7 Sep 2026

- **The Amaranth Reach is the sixth sector; the terrace world is Aerius.** §2, locked.
- **The duplicate catalysts stay.** Two Crows (Thorne, Amsel) and two Sharks (Kastan, Dunmore) in one lance, derived and left alone. His call, and the right one: a formula you override when you dislike the output is not a formula. The 1 Sep pass held the same line with three Jupiter/Bear Meks.
- **The recruit generator is folded into the codex build.** §5 ships with it — background as a real persisted field, the 48-cell Pressure table as data, `rollBackground` in the shop path. After that, "any playable pilot, mek and npc" is true without an asterisk: the djb2 hash survives only for ids that predate the field.
- **Verinis: open.** See §4.3's own subsection. The question was mine to answer, not his to guess at, and it is answered there.

## 7. Docs this touches

- `Bloom_Wars_Background_Zones_Birthplace_Academy_Planet_Sector_v1.md` — §2 gains a sixth sector if §2 above is approved; §6 should point at §3 above as the written-down Pressure function; §8's naming-lock list gains **Aerius**.
- `Bloom_Wars_NPC_Catalyst_Formula_Closing_And_Roster_Assignments_v1.md` — §4 gains 4.7 (Third Lance), 4.8 (their Meks), and a Verinis row beside the Warden CO in 4.3; §6's "Rourke and Marrow still have no background" stays true until §6 above is answered.
- `src/data/npcSeed.ts` `BACKGROUND_CATALYST_ASSIGNMENTS` — ten new rows (§4.1–4.2) at build time.
- `src/engine/facilityHouseAmaranth.ts` `co.catalyst` — `"shark"` → `"cat"`, and the placeholder comment replaced with a pointer here.
- **Stale as of 7 Sep, both saying Verinis's lines don't exist yet:** `Bloom_Wars_House_Amaranth_Hub_Build_Plan_v1.md` §2 step 4 and §4, and `Bloom_Wars_Build_Log_Addendum_HouseAmaranthHub_06Sep2026.md` §4. `Bloom_Wars_Now_And_Next.md` has the correct state; these two need a dated pointer to it.
- **Recommended new doc:** `Bloom_Wars_Verinis_Voice_Bank_v1.md` — all nine banks verbatim. They appear to live only in chat today (§4.3's correction).
- `Bloom_Wars_Codex_Rework_Plan_v1.md` §4 item 7 — the Third Lance is no longer "intake stubs"; §3a's intake line becomes the background line once §5 ships.
- The sandbox — updated in the same pass (v1.9): the five Privates' dossiers rewritten from these backgrounds, their Meks added, Verinis's catalyst line.
