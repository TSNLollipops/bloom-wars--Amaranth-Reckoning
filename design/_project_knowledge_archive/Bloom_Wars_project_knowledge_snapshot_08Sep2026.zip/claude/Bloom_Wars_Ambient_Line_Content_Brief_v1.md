# THE BLOOM WARS — Ambient & Named-Pilot Line Content: Handoff Brief v1

## STATUS — EXECUTED 26 AUG 2026, WITH ONE CORRECTION TO §1

**The job this brief scoped is done.** Delivery: `claude/Bloom_Wars_Ambient_Line_Bank_Delivery_v1.md` — all 297 generic Crew Banter lines re-sorted into echoes (Phase A), 81 new lines filling the thin buckets (Phase B, anger turned out to be the real desert, not fear/sadness), 36 slot variants (Phase C), everything tagged with both echo and stage as instructed. Scope was confirmed with Maxime before writing: **generic bank only** — "the names" meant pilot name generation, which is handled by game data; Phase E (named-pilot depth) is not wanted.

**Correction, verified against the actual file:** §1's second bullet claims `claude/pilot_creator.html`'s `LINE_BANK` is the same flat 180 lines with no stage axis. **That does not match the file in the project**, which was last touched 25 Aug — before this brief was written. Its `LINE_BANK` is keyed catalyst → echo → stage and holds the full **324-line staged bank** (2 Green + 5 Blooded + 2 Command per bucket), with the stage picker and Promote button wired around it. So §1's third bullet has it backwards: the Crew Banter STATUS UPDATE and the NPC-needs addendum were describing something that **does** exist, and their claims should not be treated as stale. §1's *first* bullet — `src/data/ambientLines.ts` being a flat 180 — could not be checked from the writing session (no repo access) and is still assumed true; its 5-per-bucket shape exactly matches the sandbox's Blooded tier, consistent with a port that happened before the sandbox grew its Green/Command wings. Worth a 10-second repo check.

**Still open, unchanged:** the Phase A stage question (the delivery recommends **keep the axis**, with reasons in its §13 — but that's Maxime's call) and all of Phase D (template resolver, `stage` field in `AmbientPilotState`), which stays engineering-side.

*Original brief below, unchanged.*

---

**Purpose of this doc:** a self-contained brief for a separate writing-focused conversation to pick up and execute, with no access to the engineering thread that produced it. Everything it needs to know is here or cited by path. Written 26 Aug 2026, in response to Maxime testing the Hub chat live and flagging it as too thin/repetitive.

---

## 0. The one hard rule, restated for whoever writes this

One reserved term from the book side of this project must never appear in any line, filename, or comment written for the game — enforced by a build-failing lint rule (`tools/lint-spoiler.mjs`), not just a convention. The term itself is deliberately not restated in game-side docs, this one included. If a word feels like it might be it, ask Maxime rather than guessing.

---

## 1. What's actually true right now — verified directly against the files, 26 Aug 2026, not from memory or an older doc

- **The real, shipped `LINE_BANK`** (`src/data/ambientLines.ts`) — what the live game actually draws from — is 180 lines total: 9 catalysts (wolf/dog/cat/crow/raven/bear/fox/rabbit/shark) × 4 echoes (love/fear/anger/sadness) × 5 lines each. Flat. No stage/rank axis.
- **`claude/pilot_creator.html`'s own `LINE_BANK`** (the sandbox the real one was ported from) — checked directly, line 2921 in the current file — is the *same* 180 lines, same flat catalyst × echo shape. No stage axis exists in it. **[SEE STATUS AT TOP — this bullet is wrong against the actual file.]**
- **Correction to two other project docs, so nobody chases something that isn't there:** `Bloom_Wars_Crew_Banter_Phrase_Bank_v1.md`'s own STATUS UPDATE and `Bloom_Wars_Spitball_Ideas_Addendum_NPCNeeds_26Aug2026.md` both describe a second, separately-authored 324-line bank (9 catalysts × 4 echoes × 3 stages) supposedly already live in `pilot_creator.html`. That bank does not exist in the file as it stands today — this was checked by reading the actual `LINE_BANK` object in full, not by searching for the word "stage." Treat those two docs' claims about it as stale/outdated, not as a shortcut sitting there ready to port. **[SEE STATUS AT TOP — reversed: those two docs were right; the bank exists in the project file.]**
- **The real, usable resource that DOES exist:** `claude/Bloom_Wars_Crew_Banter_Phrase_Bank_v1.md` — **319 real, already-written, in-voice lines**: 297 generic (9 catalysts × 3 stages [Green/Blooded/Command] × ~11 lines spread across 5 contexts [Hangar/After Action/Off Duty/Under Pressure/Close Call]), plus 22 named-pilot demonstration lines. Also includes a fully-specified §11 template/slot-fill system that can turn a subset of those lines into roughly 1,200-3,000+ unique deliverable strings at runtime, using roster/mission/room data the engine already tracks. This is real, already-good voice work — the job below is adapting and extending it, not starting from a blank page.

---

## 2. The actual problem this solves

Maxime, live-testing the Hub today: the chat feels thin and repeats fast — 5 lines per catalyst × echo bucket runs dry quickly in a session with a lot of Talk / minigame / muster interactions. The fix is real writing volume, not a code trick. (A same-day code addition — the catalyst-dictionary/sub-animal system, see `Bloom_Wars_Build_Log_Addendum_HubPolish_26Aug2026.md` §32 — already helps a little by sometimes routing a reply through a *different* catalyst's existing voice, but it doesn't add a single new line to the pool. Content is still the actual gap.)

---

## 3. The job, broken into phases

### Phase A — Re-sort the existing 319 lines into the real shape (do this first — highest leverage, no new writing needed yet)

The 297 generic lines in the Crew Banter doc are organized catalyst × stage × context. The real engine's axis is catalyst × echo. These don't map 1:1 — each line needs an actual read to judge which of love / fear / anger / sadness it expresses. (The Crew Banter doc's own STATUS UPDATE already flagged this as open work: "real remaining work, not a mechanical find-replace.")

Concretely: for each of the 297 generic lines, tag it with the echo it actually reads as. Expect an uneven split, and that's fine — Under Pressure lines will skew fear, Close Call and After Action are mixed, Off Duty skews love/neutral. Don't force an even distribution.

**One open design question this surfaces — not fable's to decide alone, flag it back rather than guessing:** does the real game keep a `stage` axis at all (a green/blooded/command voice shift, tied to a pilot's rank and gear tier), or does everything flatten into one voice per catalyst regardless of rank? `AmbientPilotState` in the real engine doesn't track stage/rank today — adding it would be a small real code change, not just content. To keep this decision cheap either way, tag output with **both** echo and stage — that way the decision can be made after the writing's done without redoing any of it.

### Phase B — Fill the gaps

After Phase A's re-sort, some catalyst × echo (or catalyst × echo × stage) cells will be thin or empty, since the source material wasn't written against this axis. Write new lines in the voice already established per catalyst — each catalyst's arc across the three stages is described in the Crew Banter doc's own section headers (§1-9) and is genuinely specific character direction, not just a trait label; read the relevant one before writing for that catalyst. Suggested floor: 8-10 lines per bucket (up from today's flat 5) — more for fear and sadness specifically, since Stress and mission-worry trigger those echoes often in play.

### Phase C — Tag template-slot candidates (optional, high value if there's time)

Crew Banter §11 already specs 7 slot types the real engine already has data for: `{SQUADMATE}`, `{CLASS}`, `{LOADOUT}`, `{ENEMY}`, `{MISSION}`, `{ROOM}`, `{SHIP}`. For lines that naturally gesture at "someone," "the fight," "the mission," write a slotted variant alongside the flat one — e.g. "Talk to me like I'm one of the team having a bad day, not like I'm about to break" → "...same as you would for {SQUADMATE}." Don't force a slot where one doesn't fit; the doc's own estimate is roughly a third of a bank this size takes one naturally. This phase is content only — wiring the actual runtime slot-fill logic is Phase D, not part of this job.

### Phase D — NOT part of this job, flagged so no one wastes time on it

Wiring the template resolver into the real engine, and — if Phase A's stage question comes back "yes, keep it" — adding a `stage` field to `AmbientPilotState`/`HubNpc` and threading a pilot's actual rank/gear tier into it. Both are real TypeScript changes, handled on the engineering side, not by whoever writes this content.

### Phase E — separate, smaller track: only relevant if "the names" meant named-pilot depth specifically

Crew Banter §10 already has a first pass at every named pilot on record — 5 Warden Company leads, 5 Team One, 6 Team Two/bench, 16 total — a catalyst assignment plus 2-3 adapted lines each, explicitly framed there as "a demonstration, not a separate 300." If the actual ask is to deepen *that* — give named pilots more of their own distinct voice beyond the shared catalyst bank — that's a different, smaller, more character-specific pass: same per-pilot bios already on record (Canon Pass, `Bloom_Wars_Amaranth_Act1_Build_Log_v1.md` and related mission docs) as source material, output being more named-pilot-specific lines rather than more generic catalyst content. Worth confirming which one is actually wanted before spending time here — see the open note below.

---

## 4. Deliverable format needed back

A plain structured list is enough — a markdown table or one-entry-per-line, doesn't need to be code. Columns: **catalyst, echo, stage (if kept), context (optional, for reference), line text, slotted variant (if any, from Phase C), source** (new, or adapted from Crew Banter §_). That's everything needed to fold it into `ambientLines.ts` without re-deriving anything.

---

## 5. What this brief deliberately doesn't decide

- Whether `stage` survives as a real tracked axis (Phase A's open question) — pick a lane after seeing how the re-sort actually looks, don't block Phase A on deciding it up front.
- Exact minimum-lines-per-bucket target — 8-10 is a suggestion, not a lock.
- Whether Phase E happens at all, and how large — only relevant if "write up the names" meant named-pilot depth specifically rather than the generic bank. **Flagging honestly: this brief was written from a chat message ("I'll have another convo write up the names") where "the names" wasn't fully unambiguous — it could mean this generic-bank expansion, or it could mean Phase E specifically. This doc covers the generic-bank work (Phases A-D) as the primary job since that's what directly continues the "chatbot doesn't have enough lines" conversation, with Phase E included as the other real candidate. Worth Maxime confirming which one (or both) before handoff.** *(Resolved 26 Aug — see STATUS at top: generic bank; Phase E not wanted.)*
