# THE BLOOM WARS — Master Index

**This is a router, not a document.** It was a 233KB single file until 4 September 2026; it is now three levels plus an archive. Read the one you need.

| Read this | When |
| --- | --- |
| **`Bloom_Wars_Foundation.md`** | **Start here if you're picking the project up cold.** The rules that don't change: the naming lock, locked design decisions, the balance philosophy, the trust ordering when two sources disagree, the repo layout and verification gate, and the process disciplines this project earned the hard way. Short, and meant to be read whole. |
| **`Bloom_Wars_Now_And_Next.md`** | **What's happening right now.** Where the game stands, what's waiting on Maxime's decision, what's blocked on him specifically, what he's said he wants next, what's on the table to build, and what needs verifying. Rewritten as things move. |
| **`Bloom_Wars_History.md`** | What's been built, September 2026 onward, oldest first. New build entries append here — short, pointing at the build's own addendum. |
| **`Bloom_Wars_History_Aug2026.md`** | Frozen archive, 26–29 August 2026, with the resolved-issue log as its appendix. Not appended to. |

**Foundation plus Now & Next is enough to start working.** History is reference.

---

## Where the real authority lives

This index and the three files it points at are *synthesized*. When they disagree with something more primary, they lose:

1. **The code** — `src/data/campaignAmaranth.ts` and friends. Ground truth; nothing can contradict it.
2. **`claude/build_log/README.md`** — the per-mission and per-engine-system build history.
3. **The specific dated addendum** — `claude/Bloom_Wars_Build_Log_Addendum_*.md` is the authority for the build it covers.
4. **These four files.**

## The naming lock

Two terms from the book series are reserved and must never appear in the game's code, comments, filenames, or UI strings — one of them enforced by a build-failing lint rule, not by convention. A shortened or informal form of a reserved term is still the reserved term; that exact reasoning produced a real slip once. The terms themselves are deliberately not written in any of these docs. Full rule: `Bloom_Wars_Foundation.md`.

## The other project in this workspace

**Qiraki**, a book series, is indexed separately under `Qiraki_Master_Index.md` and carries its own style guide and craft rules that are deliberately *not* meant to agree with the game's. Don't cross-apply them. The naming lock above is the only genuinely shared rule; the cross-project borrowing policy in Foundation is the one deliberate bridge.

---

## Why this was split, 4 September 2026

Maxime's call, and the evidence was already in the file. The old master index had grown to 233KB — one document carrying the rules, the entire build history, and the current state all interleaved, with a 24KB single paragraph of dated updates at the top duplicating every section below it.

The failure mode that caused was mechanical, not aesthetic: **the Projects tool has no partial edit**, so appending one line meant rewriting all 233KB. By 2 September sessions had stopped editing it at all and started writing standalone sync notes instead (`Bloom_Wars_Master_Index_Sync_Note_1/2/3Sep2026.md`), and roughly thirty builds landed with no index entry. A doc nobody can afford to edit stops being a source of truth and becomes a fossil.

The split fixes it at the seam that actually matters — **how often a thing changes**. Foundation almost never changes. Now & Next changes constantly and is small. History appends and is capped by archiving each month. Nothing was deleted in the split; the top dated-update paragraph was collapsed because every entry in it already had a full section below, and the 2–4 Sep gap was reconstructed from the sync notes and the morning report rather than left blank.
