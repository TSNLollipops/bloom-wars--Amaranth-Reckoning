# Bloom Wars — notes for whoever eventually does the real art (v1)

*26 August 2026. Not a spec, not a commission brief — a running note of what got worked out (and what didn't) while generating placeholder pilot portraits with AI this evening. Point an artist at this before they start, so they're not reverse-engineering fifteen images to figure out what the "rules" were. Update this doc whenever the AI-art pass teaches something new, rather than letting it go stale like other docs have.*

## What this covers

Fifteen head-and-shoulders pilot portraits exist now — the full named roster, Lance A through the Third Lance — generated in Gemini this evening, saved in `assets/portraits/` as `<surname>_portrait.png`. They're good enough to sit in a Hub dialogue panel today. They are not final art, and some of what they got right, they got right by accident. This doc is what to keep, what to fix, and what a real artist would need to know that isn't obvious just from looking at the images.

## The house style that emerged (worth keeping, whoever draws these next)

- **Composition:** head-and-shoulders, three-quarter view, plain soft gradient background (dark slate grey), nothing else in frame. No scene, no props beyond the pilot's own gear.
- **Palette:** muted and desaturated — steel blue-grey, rust, faded olive. One warm accent color (amber-gold) reserved specifically for Runemaster-track tech, so it reads as meaningful when it shows up rather than decorative.
- **Tone:** WW1/WW2 trench-war grounded, colliding with worn-out future tech — lived-in, patched, scratched. Deliberately not glamorous, not chrome, not a heroic-poster look. Serious, weathered expressions throughout.
- **Universal tell:** every pilot has a visible neural-interface jack at the temple, with cabling running down into the collar. This is the one detail that says "mech pilot" across every species and class — worth keeping in any future pass.
- **An unplanned but consistent detail:** Hiopi pilots kept getting a braided/woven cable for that neural jack; humans and Osnians kept getting a plain tube cable. Nobody asked for this split, it just happened four times in a row. Worth a deliberate decision — keep it as a real species-material distinction, or flatten it, but it's there now across the existing set.

## Mek-track visual key (ties directly to the game's real MekTrack system — not decoration)

Each pilot's collar carries one small tech detail keyed to their actual mek track, so the portrait means something mechanically, not just visually:

| Track | Tell used |
| --- | --- |
| Armorer | A riveted plating patch, scuffed metal |
| Runemaster | A glowing amber-gold conduit with etched rune-line patterns *(see the honest gap below — these are not your actual runic script)* |
| Fieldwright | A repair-clamp or multi-tool clipped at the collar |
| Fabricator | A scavenged spare-parts pouch, mismatched scrap — visibly salvaged, not issued |
| Quartermaster | A stamped ledger or tally chit, dog-tag style |

Every stitched fabric tab also carries faint etched lettering — deliberately illegible, treated as texture rather than a caption. A couple came back legible-ish by accident (Solheim's, Kova's), which is worth noting as a nice-to-have, not something to chase.

## Species physical facts actually used (pulled from Qiraki canon, not invented for this)

- **Human:** baseline, nothing special.
- **Hiopi:** quadruped, centaur-built, frog/lizard hybrid. Dense build, faintly ridged hide, digitigrade legs. No fixed secondary sex characteristics as individuals — but the species' own mating structure (one male per "city") means the population skews heavily female, so most individual Hiopi encountered should read female. Ritual scarring worn openly, a mark of pride, not hidden.
- **Osnian (Osnius in the source material):** bear-adjacent, explicitly **not** human-passing — this was corrected once already in the book canon after an earlier draft got it wrong, worth not re-making that mistake here. One fixed, universal marker: a faint natural luminosity at the inner corner of each eye, subtle in bright light, unmistakable in shadow. Individual coat color varies freely (black through brown, grey, tawny), no social meaning attached to which. Natural whisker-like vibrissae at the muzzle.

## Honest gaps — real placeholder limits, not bugs to keep prompting around

- **Hiopi reading female:** despite the note above being in every Hiopi prompt, none of the five generated this evening (Iyari, Tarrant, Reyes, Ness, Yeun) actually read as female-presenting — they all landed androgynous-to-neutral. The model has no established visual vocabulary for sex dimorphism on a species that doesn't exist anywhere in its training data, so there's nothing to translate the instruction into. An artist will need to actually design what that looks like — this can't be prompted into existence without a reference.
- **The Runemaster glow is fake runes.** It's Gemini improvising a consistent-looking glyph set per image, not your actual runic script from the Qiraki side. It'll hold up fine as a placeholder but needs the real glyphs substituted whenever there's either a real artist or at least a reference sheet of the actual script to feed a tool.
- **No transparency/cutout.** All fifteen are flat-background bust portraits — fine for a dialogue panel, useless as-is for anything needing a real cutout sprite. That's a deliberately separate, harder problem (see the October Art Plan doc), not attempted here.
- **Cross-image consistency is "close enough," not locked.** The prompt template kept proportions and style close across generations, but nothing here is a true style-locked pipeline — a real art pass would want an actual style guide / model sheet, not fifteen independently-generated images that happen to resemble each other.

## The current roster, for reference

Lance A: Rourke "Lark" (human, Meeps), Bosk "Anvil" (human, Tank), Lask "Patch" (human, Munti), Iyari "Foxfire" (Hiopi, Meeps), Anand "Farsight" (Osnian, Reeps).

Second Lance: Okafor "Ledger" (human, Tank), Solheim "Static" (human, Reeps), Tarrant "Kestrel" (Hiopi, Meeps), Vashti "Driftwood" (Osnian, Munti), Reyes "Hardpan" (Hiopi, Reeps).

Third Lance: Kova "Bastion" (Osnian, Tank), Ness "Rampart" (Hiopi, Tank), Onwuka "Whiplash" (Osnian, Meeps), Delgado "Longshot" (human, Reeps), Yeun "Splint" (Hiopi, Munti).

The fifteen saved files themselves are the other half of this brief — loose visual reference for "here's what's already been established," even though none of them are final.
