# THE BLOOM WARS — Brig. Verinis Amaranth: Voice Bank v1

**Status: CONTENT COMPLETE across eight of nine slots. Not wired — see §11.**

*Filed 7 Sep 2026 from Maxime's own compiled `Verinis_Voice_Bank.docx` (which dates itself 8 Sep; recorded as-is). This file was created hours earlier as an empty capture skeleton, after a pass found that nine slots of hand-authored CO voice existed only in a chat transcript. Maxime found the conversation and compiled it. This is now the canonical record.*

## 0. Provenance — what survived, and the one thing that didn't

**Every line Maxime wrote is intact.** All 30 of his authored lines across the six authored slots, plus the 5 locked Brief lines and 2 locked Check-in lines.

**Three of the six matching batches were lost and rewritten.** His own compiled file flags it in the same words each time: *"the original 6–7 Sep matching batch for this slot did not survive a context-compaction gap; this is a fresh pass in the same locked register, not a recovery of the original wording."* That applies to **Greeting (f–i), Farewell (f–i), and Advice (e–g)**. Confide, Callout and Build-approval carry no such note, so those matching batches are the 6–7 Sep originals.

Worth stating plainly because it is the whole argument for this file existing: the half that was expensive — the half only Maxime can write — came through untouched. The half that was lost is the half that is cheap to redo.

**Line count: 63.** Maxime 30 · locked (Brief + Check-in) 7 · matching batches 26.

## 1. The character

Human, blood of House Amaranth, Brigadier, field commander of the Greathouse. *"An asshole, plain and simple."*

**Full ADCON authority over the estate** — builds, resources, berths. **Zero OPCON/TACON over Marrow once she is deployed** (Article Nine) — the Seal-and-Sword command split. Not the Seal-holder; that person is on Osnius. **Romanceable** (human, uncapped by `ROMANCE_CAPPED_SPECIES`, unlike Arangement).

## 2. Locked register

Mocking, sarcastic, icy-formal, flatly impatient, resource-not-person framing, deliberately-rote-as-the-joke, a running paperwork/logistics motif.

## 3. Standing content rules

- **Rank token.** Rank references that mean Marrow's *actual* rank use a live token reading her real rank, never a hardcoded "colonel" — matters once a promotion system exists.
- **"Caporal" is fixed.** Used as an insult, never tokenised. The joke is that it is wrong on purpose.
- **"Holoband"** (Brief b) is cleared — the 7 Sep crossover decision puts Bloom Wars 30 years before Qiraki's own story start inside the same 60-year war, so species/tech/setting vocabulary crosses freely. Reveal-adjacent material stays locked exactly as before.
- **"Synker" — RESOLVED 7 Sep 2026, and it is not what this file first said.** Maxime: *"synker is the canon name for pilots. they synchronized with their machine."* It is not Verinis's idiolect. It is the correct term, from `Qiraki_Concept_v4.md`'s own lock — *"Mech pilots ('mechwarrior' being trademarked/unusable, resolved to **Synker**)"* — and the etymology is live in Bloom Wars already: the drafted codex describes "a frame, **a pilot wired into it**," which is the sync the word names.
  - **Naming lock, precisely.** The reserved item is the book's own military-arc *title* built on this noun. It is deliberately not written out anywhere in this file or in the sandbox any more — see §12d. The common noun is setting vocabulary of exactly the kind the 7 Sep crossover decision cleared to cross freely, alongside Holoband, Longsight, sprout, Heirloom-grade and the species names. The 7 Sep lint pass ran with both Callout drafts live in the repo and did not trip. **The word is cleared; the title stays locked.**
  - **What it changes about his lines:** Callout c and d stop reading as a quirk and start reading as an officer using the formal service term about his own personnel — which lands *with* the paperwork motif ("red notice," "filed a complaint," "my roster") rather than beside it. Strictly better than the idiolect reading.
  - **Open, and larger than this file:** whether Bloom Wars adopts "synker" game-wide. See §12a.
- **Check-in stays a one-time gate**, not a per-mission ritual. Maxime, 7 Sep: *"no extra steps for the player."* A recurring version was raised and parked once already on 28 Aug for the same reason.

## 4. Greeting — 5 + 4

`data/smallTalk.ts` → `pickCoGreetingLine`

**Maxime's**
- a. "Greetings, Caporal. Still alive I see."
- b. "Good day. Had a good vacation?"
- c. "Bloom-clear skies today. Nice, isn't it." — *sarcastic; House Amaranth's own biotech suppresses the Bloom at estate scale, so the clear skies are their doing, not luck*
- d. "Greetings, Colonel."
- e. "What do you need, Colonel."

**Matching batch** *(rewritten 8 Sep — not the original wording)*
- f. "You're here. That's already better than I expected."
- g. "Try not to lose anyone new today, Colonel."
- h. "You made it back in one piece. Don't get used to it."
- i. "Standing there like you're waiting for a compliment. You'll be waiting a while."

## 5. Farewell — 5 + 4

`data/smallTalk.ts` → `pickCoFarewellLine`

**Maxime's**
- a. "Thank you, Colonel."
- b. "..." — *literally three dots; the joke is the non-committal silence*
- c. "See you next time." — *deliberately flat and rote, confirmed on purpose*
- d. "Farewell." — *deliberately flat and rote, confirmed on purpose*
- e. "Really?" — *deliberately ambiguous: surprise, sarcasm, or a genuine question, and staying unresolved is the point*

**Matching batch** *(rewritten 8 Sep — not the original wording)*
- f. "Go on, then."
- g. "Try to come back in the same number of pieces."
- h. "Don't let the door catch your ego on the way out."
- i. "Dismissed."

## 6. Advice — 4 + 3

`data/smallTalk.ts` → `pickCoAdviceLine`

**Open:** Arangement's shipped Advice bank splits calm vs. elevated on `STRESS_PANIC_THRESHOLD` (70). Whether Verinis's set carries the same split is undecided.

**Maxime's**
- a. "We're not allowed to spar, or I'd offer to punch you."
- b. "If you need help — that's supposed to be my job."
- c. "I've been sober for a century. You could be told to be too." — *reads as ambiguous hyperbole either way; per the crossover decision, a charter house affording Sovereign/Heirloom-grade longevity makes it literally true. Ships as a line regardless. See §12.*
- d. "Go ask out your mek. It looks like you need it."

**Matching batch** *(rewritten 8 Sep — not the original wording)*
- e. "Complaining to me won't fix it. Complaining to someone who can will."
- f. "Whatever's eating at you, it's still there tomorrow whether you talk about it or not. Your call which version of tomorrow you'd rather have."
- g. "I've buried better officers than you for less complaining. Back to work."

## 7. Confide — 5 (one a tier pair) + 5

`data/socialActions.ts` → `pickCoConfideLine` · mechanically **−15 `mcStress`**

**b is a duty-tier / high-favorability-tier pair on purpose** — the first real appearance of the proposed 30/60/75 gradient, though nothing in the engine gates dialogue tone by favorability yet. **Which one ships before that gate exists is an open build question** (§11).

**Maxime's**
- a. "Did you have to say all that?"
- b *(duty tier)*. "I'm only listening because it's my job."
- b *(high-favorability tier)*. "I'm only listening because it's you."
- c. "That's good to know."
- d. "I sympathize."
- e. "Listening to you makes me learn all sorts of things about OPCON."

**Matching batch** *(6–7 Sep original)*
- f. "Try to keep it logistics-relevant. Try."
- g. "You didn't need my permission to talk. You have it anyway."
- h. "Noted. Filed under things I can't do anything about."
- i. "This stays between us. I've got enough reports to write as it is."
- j. "Feel better. That's an order, not a sentiment."

## 8. Callout — 5 + 5

`data/socialActions.ts` → `pickCoCalloutLine` (the Insult Tier-3 standoff callout)

**c and d use "synker"** — see §3.

**Maxime's**
- a. "You broke my roster, got anything to say about that?"
- b. "Human ego is fragile, manage them better."
- c. "One of my synker is refusing to work with you. Either fix it or ask me to discharge him."
- d. "What happened, Caporal, one of the synker gave me a red notice."
- e. "Someone filed a complaint, Caporal."

**Matching batch** *(6–7 Sep original)*
- f. "Explain yourself. Briefly. I have other problems today."
- g. "I don't care whose fault it was. I care that it's fixed."
- h. "Second time this month. There won't be a third conversation about it."
- i. "You're costing me manpower I didn't budget for."
- j. "Fix it, or I will — and you won't like my version."

## 9. Build-approval — 5 + 5

`scenes/Hub.ts` → `handleBuildRequest` (hard-written today, not yet a data bank)

**All ten are approvals**, varying in how grudging. The refusal line ("needs power first, Commander — get the Generator built before that one") is Arangement's and is still shared. **Verinis has no denial-on-bad-standing path** — that is the separate post-EA idea filed in `Now_And_Next.md`. `"..."` marks the room-name slot; it needs a real token format when this moves to a data bank.

**Maxime's**
- a. "\"...\" is approved."
- b. "Since you think it's needed. Approved."
- c. "I have no objection."
- d. "Logged the build order on \"...\"."
- e. "Don't waste it. Approved."

**Matching batch** *(6–7 Sep original)*
- f. "Approved. Try not to need another one next week."
- g. "Fine. It's your budget to justify, not mine."
- h. "\"...\" — approved, filed, forgotten. Next."
- i. "You'll have it built before you're back from your next sortie."
- j. "Approved. Don't make me regret saying yes twice in one week."

## 10. Brief — 5, locked · Check-in — 2, locked · Debrief — empty

**Brief.** `scenes/Hub.ts`, the brief bubble ahead of the full `MissionBriefingPanel`. Brief became a full narrative panel on 4 Sep with real per-mission text for all 36 House Amaranth missions; **these five are the short spoken line that fires before/alongside that panel**, not the panel's content.

- a. "Here's the sitrep, Colonel."
- b. "Sending you the brief on your Holoband."
- c. "You're here for your next mission, Colonel? Here it is."
- D. "Here for a mission, Caporal?" — *mocking, wrong rank on purpose; stays fixed, not tokenised*
- E. "Next mission is \"...\"." — *needs House Amaranth's own mission-order lookup before it can name a mission. Not built.*

**Check-in.** `scenes/Hub.ts` nudge/block. Fires **once per campaign**, on the very first debrief, satisfied by any Talk/chat that reaches him. Voiced as Verinis speaking, replacing the narrator/UI text shipped 1 Sep.

- Nudge. "Report to me before you deploy again, Colonel."
- Block. "Did you forget something, Colonel?"

**Debrief / Campaign Shop callouts.** `scenes/Debrief.ts`. The House Amaranth side now has a real console to point at (the Motor Court's). **No lines exist for this slot yet. Open — the one remaining content gap.**

## 11. What's left — plumbing, not content

None of it needs Maxime's voice again.

1. Key the CO banks by a **`coVoice` id** on the facility profile (`"arangement"` / `"verinis"`), each `pickCo*` reading its own bank and falling back to Arangement's for any slot Verinis lacks.
2. Move `Hub.ts`'s hard-written CO sentences (build-request, brief bubble, check-in nudge/block) out of literals and into the bank.
3. Replace the hardcoded **"Rourke"** ("Every mission on the board's flown, Rourke.") with the MC's short name read from the profile.
4. Confirm the **Holoband** clearance in the lint pass. (**"Synker" is resolved** — canon, cleared, see §3 — but the game-wide vocabulary question in §12a is open and may add strings this pass would want to catch.)
5. Build **Brief E's** mission-name lookup for House Amaranth (mirrors Warden's existing `nextWardenMission`).

**Three build questions this file surfaces that the plumbing list does not cover:**

- **Confide b.** Two variants, no favorability gate in the engine. Ship the duty-tier line until the 30/60/75 gradient exists, or build the gradient as part of this pass? The former is honest and cheap; the latter is a new axis.
- **Advice split.** Does Verinis's bank carry Arangement's calm/elevated split on `STRESS_PANIC_THRESHOLD`? Seven lines is enough to split; four is not.
- **Room-name token.** Build-approval a/d/h embed `"..."` as the room name. It needs a real substitution format the moment those leave `Hub.ts` literals.

## 12. What the lines settle about the character

**They land the catalyst question.** `Catalyst_Gauntlet_v2` §4.3 argued cat over the placeholder shark from the register summary alone. The lines themselves are far more conclusive: **across all 37 authored and locked lines there is not one about advancement.** No credit-claiming, no competing with Marrow, no interest in what the posting could become. Shark's entire identity is wanting, and nothing here wants anything. What is there instead is withholding — "...", "I have no objection," "That's good to know," "Really?", and above all *"I'm only listening because it's my job."* That is distance as a default setting, which is cat. The high-favorability variant, *"I'm only listening because it's you,"* is exactly what a crack in that stance looks like.

### 12a. The vocabulary question "synker" opens — flagged, not decided

If "synker" is the canon word for a mech pilot, then the game currently uses the wrong one nearly everywhere, and Verinis's two lines are the only place it is right.

**Measured, not guessed:** ~300 player-facing `"pilot"` strings in `src/` (excluding `pilot_*` ids, `PilotRecord`, `pilotId` — internal identifiers would not change), and 117 more in the codex sandbox drafts. A game-wide swap is a real content migration touching the Codex, the roster panel, the shop, the Hangar, briefings and the ambient banks. **That is scope growth and it gets flagged before anyone starts, per the project's own rule.**

**Three options, honestly weighted:**

1. **Leave it.** "Pilot" everywhere; Verinis's two lines are simply him being formal. Zero cost. Cost is that the setting keeps a generic mech-game word when it owns a better one.
2. **Swap game-wide.** Every player-facing "pilot" becomes "synker." Most faithful, most expensive, and it makes the first hour of the game teach a word before it teaches a mechanic.
3. **Register split — recommended.** Both words, deliberately. "Pilot" stays the plain descriptive term the UI and the manual use, because a player must understand it instantly. "Synker" is what the *service* calls them — officers, official paper, the Coalition's own documents, the Codex's Record- and Reference-kind entries. Real militaries work exactly this way; "soldier," "infantryman" and "grunt" all coexist and the choice tells you who is speaking. Cost is one Glossary entry and a light pass over the in-fiction documents, not 417 strings. It also makes the Codex's provenance system do real work: a Fleet Registry extract says *synker*, a field note says *pilot*, and the reader learns the difference without being told.

### 12b. DECIDED 7 Sep — the register split, and what "synker" does grammatically

**Maxime: "register split yes."** Option 3 above is the call. "Pilot" stays the plain descriptive word the UI, the manual and ordinary speech use. "Synker" is the service's own term: officers, official paper, Coalition and House documents, and the Codex's Record- and Reference-kind entries from official sources. Nothing is renamed wholesale; the ~300 `src/` strings and 117 codex uses are not swapped, only the in-fiction official ones.

**The grammar, resolved — with a correction to the reasoning that got there.** Maxime's argument was *"its the synker wars not the synkers wars."* That reasoning does not hold on its own: English puts a noun in the singular when it modifies another noun regardless of its plural — the *Boer* Wars (Boers), the *Zulu* Wars (Zulus), *car* park, *dog* show. Attributive position forces the singular, so the title cannot be evidence about the plural.

**Full invariance would also fight the language.** English `-er` agent nouns are near-exceptionlessly regular (worker, runner, driver, welder); there is essentially no invariant `-er` noun. "Two synker" reads as a typo every time, and the style guide's read-aloud rule would trip on it.

**But his own lines point at something better than invariance.** Both read *"one of my synker"* / *"one of the synker"* — partitives of a **collective**, which is standard military English: *one of my personnel*, *one of my infantry*, *a hundred horse*. So:

- **Collective in service register** — "my synker," "one of my synker," "the synker on this estate." Officers, manning tables, official paper.
- **Regular count plural elsewhere** — "two synkers," "the synkers in Lance B."

This is not a separate rule from the register split; it is the same rule showing up in the grammar. Verinis says *"one of my synker"* for the same reason he says *red notice* and *filed a complaint*. **His two Callout lines need no edit.**

**Scope of the editorial pass this implies** — not started, sized here so it can be timed: the Codex's official-source entries (Fleet Registry extracts both sides, the Standing Service primer, Coalition Staff doctrine, the Charter and the House's Article Nine text, the Ledger and Academy Board circulars, the Cultivar Works' own papers) take *synker*; field notes, briefs and anything a line unit wrote keep *pilot*; the Field Manual and Glossary keep *pilot*, because they teach. Roughly a dozen entries, not 117 uses.

**A real canon implication, flagged rather than assumed.** Advice c — *"I've been sober for a century"* — is literally true under the crossover decision, and it rhymes precisely with the drafted `tech_grades` codex entry: *"A charter house rich enough to field Heirloom-grade arms is rich enough to have a patriarch who remembers the war starting."* If Verinis is Sovereign-grade-extended, he comfortably predates a 30-year war, which changes what "the Bloom has been at the edge of his family's ground his whole life" means — his whole life is longer than the war. It does not break the Aerius / Terrace Farmstead / Conservatory derivation (Frontier × Forged → Spider → Cat holds either way), but it is a genuinely different man. **Maxime's call whether the line is hyperbole or fact.**

### 12c. DECIDED 7 Sep — Ranks & Command converts, and the Gladiator Days canon call

**Maxime: yes.** The `RANKS` shelf converts. It is the only *shipped* codex text the register split touches, and it converts because a rank table is the service's own paperwork — the most official document on the shelf. Everything else shipped stays as it is.

**Exact strings the codex build must change in `src/data/codex.ts` `RANKS` (four, in two entries):**

| Entry | Was | Becomes |
|---|---|---|
| `rank_personal` ¶1 | "Every **pilot** climbs the same ladder" | "Every **synker** climbs the same ladder" |
| `rank_personal` ¶1 | "what an enlisted **pilot** can reach" | "what an enlisted **synker** can reach" |
| `rank_personal` ¶2 | "**Munti pilots** often carry" | "**Munti synkers** often carry" |
| `rank_command` ¶1 | "one **five-pilot** lance day to day" | "one **five-synker** lance day to day" |

`rank_command` ¶2 (the Rourke paragraph) contains no instance and does not change. "Munti synkers" and "five-synker" are both count usages, so the collective rule in §12b does not apply — it governs the partitive service register ("one of my synker"), not attributive or counted forms.

**The cost, stated rather than glossed.** Ranks & Command is *instructional* — it is where a new player learns the ladder they are climbing. Converting it means the entry that teaches ranks uses a noun no HUD string, roster panel or tooltip uses. That is the one place the split costs comprehension instead of adding texture. Accepted because `gloss_synker` is ungated and always browsable and `tech_everyday` teaches the word explicitly, so a player is never stranded. **No explanatory clause was added inside the rank entries on purpose** — a rank table that stops to define its own noun is exactly the stated-thesis failure the style guide bans.

**The Gladiator Days canon question — a recommendation, needing yes or no.** The question was whether pre-war arena pilots synced, which decides whether `hist_gladiator` says pilot or synker.

*Recommended: the interface predates the war; the word does not.*

The argument is inside the entry already. It says the arena squads "were the only people alive who knew how to fight in a mech," and that the Coalition "took them whole." That only holds if their skill transferred directly. A control interface that arrived with the war would have made arena veterans beginners again at the one thing that mattered, and there would have been no reason to take squads intact rather than break them up as instructors. So arena mechs synced.

"Synker" is nonetheless the *service's* coinage, from when the Coalition turned a sport into a military. This is what gives the primer's line its teeth — *"a first-year who says pilot will be corrected exactly once"* is a correction about **belonging**, not about accuracy. If synker were the ancient word it would be pedantry; because it is the service's own, it is initiation.

Two consequences:

1. The rest of `hist_gladiator` keeps saying *pilot* deliberately — it is describing the arena era in the arena's own word — and the new closing line is what licenses that rather than making it look like an oversight. Added to the entry, ¶4: *"One thing did not carry. The arena had pilots — a name on a gate, a driver in a machine, a purse at the end of the season. The paperwork the Coalition put them on says synker."*
2. **Verinis is old enough to have been alive for the change.** Under the §12b longevity reading he predates the war comfortably. A man who remembers when *synker* was new paperwork is free character texture that costs nothing and is currently unused. Candidate for one dry aside in a future Confide line; not written.

### 12d. CORRECTED 7 Sep evening — "it has been synkers for milenia," and a naming-lock slip I put there myself

**Maxime: *"it has been synkers for milenia."*** That kills the second half of §12c. My reading was: interface old, word wartime. Wrong. Both are old. The arena had synkers; there was never a time inside recorded history when the word was new.

**What survives, and what it costs.** The register split survives intact — the *output* is unchanged, only the reason under it moves:

| | My §12c reading (dead) | Canon (Maxime) |
|---|---|---|
| Why official paper says *synker* | it is the service's own coinage | it is simply **correct**, and always was |
| Why the line says *pilot* | the older, plainer word | a **borrowed** word — a vehicle word put on mechs |
| What "corrected exactly once" means | initiation, a marker of belonging | plain correction; the wrong word marks a civilian |

**The better version this opens, and it is genuinely better than what I had.** If *synker* is ancient and correct, *pilot* needs a source, and the arena is sitting right there. A promoter needs a noun civilians already own; nobody sells tickets to watch synchronisation. So the sloppy word is a fossil of the sport's own advertising — which is not a new claim but `hist_gladiator` ¶3 extended, since that paragraph is already about the sport's grammar surviving into the service. The split stops being formal-vs-informal register and becomes **correct-vs-borrowed**, which is a sharper joke and a better teaching device.

**Edits made in sandbox v1.13:**

- `hist_gladiator` ¶1 "the pilots on the floor" → "the synkers on the floor"; ¶2 "the five-pilot lance" → "the five-synker lance". The entry is a published institute history and the arena had synkers, so it converts throughout.
- `hist_gladiator` ¶4 — yesterday's paragraph deleted, replaced with: *"One piece of the language runs the other way. Synkers were synkers for a very long time before anyone built an arena to put them in — the word is the interface, and the interface is old. What the sport added was the other word. A gate needs a name people already own, and nobody was ever going to sell tickets to watch synchronisation."*
- `gloss_synker` ¶1 rewritten. "The service's own word" was the wrong etymology and is gone. ¶2 (the collective/count grammar) is untouched — §12b's grammar finding does not depend on the etymology.
- `tech_everyday`'s teaching sentence is unchanged and reads better under the correction, not worse.
- **Dead:** the Verinis texture idea in §12c item 2 (a man who remembers when *synker* was new paperwork). There is no such time. Cut it, do not write it.

**A standing implication I am flagging rather than assuming.** If synkers are millennia old, the **mech** is millennia old. That makes the Gladiator arena a late, decadent chapter of an ancient technology rather than its origin — which costs nothing, needs no book material, and makes "the last of those hulls" land considerably harder. But it is a real widening of the game's own timeline, well past "thirty years of war," and it is a design call, not a copy-edit. **Your yes or no.**

**Separately — a naming-lock slip, mine, now fixed.** In writing up the split I wrote the reserved book title out verbatim in three places: this file's §2 note, `Bloom_Wars_Codex_Rework_Plan_v1.md` §5, and — worst of the three — a dev note inside the sandbox artifact itself. The lock covers code, **docs**, filenames and UI strings, and I put it in two docs and a mockup while writing the paragraph that explains the lock. All three are scrubbed; the sandbox greps clean. The common noun is cleared and stays; the title is not written down anywhere in this workspace any more. Worth naming because it is the failure mode the project's carried-over rule warns about — the edit was correct and it broke its own neighbour.

## 13. Cross-references

- `Bloom_Wars_Now_And_Next.md` — the record that the content pass completed, and the plumbing list.
- `Bloom_Wars_House_Amaranth_Hub_Facility_Plan_v1.md` §5 — the character lock and the 30/60/75 gradient.
- `Bloom_Wars_Antfarm_Carrier_Hub_v1.md` §11.3 — Arangement's parallel bank, still unwritten, and how his gradient differs (warm-to-close, not cold-to-grudging).
- `Bloom_Wars_Build_Log_Addendum_MekTrackClobberRestored_06Sep2026.md` — the plumbing spec, written before the content existed.
- `Bloom_Wars_Catalyst_Gauntlet_v2_ThirdLance_Verinis_Recruits.md` §4.3 — the catalyst question these lines settle.
- `Bloom_Wars_Qiraki_Crossover_Decision_v1.md` — the Holoband clearance and the longevity implication in §12.
- **Stale, both say his lines are still to be written:** `Bloom_Wars_House_Amaranth_Hub_Build_Plan_v1.md` §2 step 4 / §4, and `Bloom_Wars_Build_Log_Addendum_HouseAmaranthHub_06Sep2026.md` §4.
