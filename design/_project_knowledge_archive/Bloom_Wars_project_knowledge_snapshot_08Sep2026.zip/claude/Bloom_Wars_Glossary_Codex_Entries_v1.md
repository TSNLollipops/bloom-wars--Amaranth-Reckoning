# The Bloom Wars — Glossary Codex Entries v1

*Written 2 Sep 2026, the fastest remaining category per the design doc's own note — short-form lookups for jargon the HUD already uses from Mission 1, not full prose entries. Checked against `Bloom_Wars_GDD_v0.2.docx` §§3.1/5/8, `Bloom_Wars_Data_Pack_v0.1.docx` §§8/11.5/12.1, and the already-shipped Systems entries (`Bloom_Wars_Systems_Codex_Entries_v1.md`) before writing, so nothing here contradicts the fuller explanations those entries already give the same systems — this category is meant to be the short lookup you'd want mid-fight, not a replacement for the Systems tab's own longer version.*

## 0. Resolved, 2 Sep 2026 — the naming question this section originally raised

Original flag, for the record: the GDD's own §8 heading is "The Heirloom: Severance," and this session couldn't confirm whether "Severance" or "Requiem" (Bosk's own personal instance, per the Independent Campaign doc) was the name a player would actually see on the ability button.

**Maxime's answer settles it, and changes the shape of the naming, not just which word wins:** *"i think heirloom should simply have special heirloom name. like peregrine is called the celestial magi. in code term, its the requiem system."* Two distinct levels, not one word replacing another —

- **The system itself** (what the GDD called "Severance," what the code still calls `SEVERANCE`/`abil_severance` internally) is now **the Requiem system** — the mechanic's own name, code-level and generic, covering every instance of it across every pilot who ever holds one.
- **Each specific pilot's own weapon gets its own special title** on top of that.

**Both halves are now closed.** Bosk's own weapon — the one that passes to Rourke — is **Gjallar**: Old Norse, "the resounding," Heimdall's horn, sounded once at the end and heard by everyone. It keeps the thing the old "Requiem" title got right, a sound made for the dead at the exact moment the weapon changes hands, rather than trading that away for the rename. The other nine Heirlooms were given the same treatment the same day. Full table and reasoning: `Bloom_Wars_Heirloom_Naming_Update_2Sep2026.md` §3.

The glossary entry below gives the system-level name, since that's what a player meets first. Individual Heirloom titles aren't Glossary-tier terms — they belong in the Independent Campaign doc's own §9 table and in `src/data/heirlooms.ts`, both of which now carry them.

## 1. The entries

> **Meeps** — Fast, fragile combat path. Six tiles of movement, one-tile reach. Beats Tank, loses to Reeps.
>
> **Reeps** — Ranged combat path. Fights from two to four tiles out, never in melee. Beats Tank at range, loses badly if a Meeps ever closes the distance.
>
> **Tank** — Defensive combat path. Short movement, high defense, an overshield that protects nearby allies. Beats Meeps, loses to Reeps.
>
> **Munti** — Support path. Outside the triangle entirely — doesn't fight to win, keeps everyone else alive. Every mission is quietly a mission to protect it.
>
> **Endurance** — A Bloom creature's outer health value. Depletes first; a hit that overflows past zero doesn't carry through to Vitality underneath.
>
> **Vitality** — What's actually alive underneath a Bloom creature's Endurance. Once Endurance hits zero, any hit at least this large kills outright.
>
> **Collapse** — The state a Bloom creature enters the instant its Endurance hits zero. Fights back at full strength while in it — not weaker.
>
> **Restock** — A downed pilot returns to the field at full strength next mission, rather than being lost for good — provided a Munti was alive on the field at the moment they went down. No Munti on the field, no restock.
>
> **Mek** — A pilot's personal support partner. Never deployed, never a target, never lost to anything that happens in a fight.
>
> **Bloom-mat** — Ground the Bloom leaves behind. Deals acid damage over time to anything standing on it.
>
> **Spare part** — What a Fabricator Mek spends to put a downed pilot back on the field mid-mission, at half strength, instead of losing them for the rest of that fight.
>
> **Lance** — A five-pilot squad; the basic organizational unit Warden Company is built from.
>
> **Gear tier** — A pilot's own equipment ladder, G up through A, climbed with points rather than time served. An Heirloom pilot sits above it entirely, at S — a rung nothing can be bought up to.
>
> **The Requiem system** — Warden Company's own company-wide Heirloom mechanic. One charge, shared by the whole unit, spent by whoever's holding it: a line of damage eight tiles long that doesn't check sides, and doesn't stop for a full shell of Endurance either. The specific weapon wielded under it — Bosk's, then Rourke's — is called **Gjallar**.

## 2. Naming-lock safety check

Nothing here touches either reserved book term. "Requiem" and "Gjallar" are both Bloom Wars' own native vocabulary — one invented for the system, one drawn from Old Norse, neither borrowed from the book side.

**One honest caveat on that check:** it was made by reading, not by running the lint. `tools/lint-spoiler.mjs` skips itself when `BW_RESERVED_TERM` is unset, and that variable's `.env.local` does not currently exist in the repo — so no machine check of any recent naming work has actually run. See the 2 Sep aristocrat-minting build-log addendum's own "Findings" section.

*(See `Bloom_Wars_Heirloom_Naming_Update_2Sep2026.md` for the full reasoning behind the system/weapon split and every one of the ten names.)*

## 3. Status

Fourteen terms, matching what the HUD would realistically show a player from Mission 1 onward. Deliberately kept to one or two sentences each, per the design doc's own "short-form lookup" spec — anything that needed more room already has a fuller Systems entry, cross-referenced rather than duplicated. §0's naming question is fully resolved as of 2 Sep 2026, at both the system and the weapon level.
