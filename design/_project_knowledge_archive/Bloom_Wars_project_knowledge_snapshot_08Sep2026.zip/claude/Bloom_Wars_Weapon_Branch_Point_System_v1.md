# Bloom Wars — Weapon Branch Point System, v1

*Started 27 Aug 2026, decided the same day. A plan, not a build — every open call in it is now resolved, but nothing here is in the engine yet, and nothing should get built off this doc without a separate go-ahead. Direct answer to Maxime, verbatim: "plan the point system for the economy. branches upgrade like would of tank. but better attuned."*

## 0. What this is answering, and what it's built on

This is the currency/structure half of `Bloom_Wars_Mek_Workshop_And_Weapon_Progression_v1.md` (26 Aug), formalized into an actual point-system spec. That doc already did the hard creative work — per-class weapon branch ideas for Meeps, Tank, Reeps, Munti, a modules list, the "not a second currency" principle. This doc doesn't re-invent any of that. It answers the part that doc left open: how do you actually *buy* a branch, from which pool, gated behind what, and how does that plug into the two-pool economy that's already live in `campaignEconomy.ts`.

## 1. The reframe worth seeing first: you already half-built this

World of Tanks' progression has two currencies, not one:

- **Per-vehicle XP** — earned by playing that specific tank, only spendable on that tank's own research (its next module, its next tier).
- **Free XP** — earned slowly (or converted), spendable on *anything* in your garage.

Bloom Wars already has exactly this split, just under different names, built 22 Aug:

- **PERSONAL points** (`CampaignPilotEntry.personalPoints`) — earned by that pilot's own kills/assists/survival, spendable only on that pilot's own gear tier and mek secondary. This *is* per-vehicle XP.
- **COMPANY points** (`CampaignState.points`) — earned by the squad's mission performance as a whole, spendable on recruits and spare parts, shared. This *is* free XP.

And the G→A gear tier ladder (60/90/140/210/320/500, flat ~1.5×/step, locked in the Data Pack) already plays the role of WoT's tech-tree spine: a linear sequence you climb one step at a time, each step gated behind having bought the last one.

What's actually missing, the one real gap: **WoT trees fork. Bloom Wars' tier ladder doesn't — it's a single line, not a tree.** Everything else already rhymes. This plan is about adding the one missing piece, not building a parallel system next to the one that's already working.

## 2. "Better attuned" — what NOT to import from WoT

Naming this explicitly so it doesn't quietly creep in later:

- **No premium currency, no real-money anything.** Not relevant to this game, don't build toward it.
- **No sprawling garage.** WoT has hundreds of vehicles because it's about collecting a fleet. Bloom Wars has 15 fixed, named pilots for the whole campaign — the tree per class needs to stay small (4 branch options per class across the board, as of §4 below — small and symmetric, not sprawling).
- **No grind wall.** WoT deliberately prices higher tiers so they cost more than an average game earns, to pressure premium spend. Bloom Wars has no monetization anywhere — the economy should stay reward-forward, not adversarial. §6's cost sanity-check is there specifically to catch this failure mode.
- **No separate crew-skill grind.** WoT crews level independently of the vehicle. Personal points already cover "this pilot is growing" — adding a third meter on top of tier + branches would dilute both instead of adding depth.
- **No regression.** WoT resets a vehicle to stock if you sell it. Nothing in Bloom Wars' economy ever takes points or progress away from a pilot once spent — a branch, once bought, is owned forever, same as a tier step or a mek secondary.

What *does* carry over, and is worth deliberately keeping: the psychological pull of "one more branch to unlock," a tier gate creating real anticipation instead of an instant unlock, and a fork that's a genuine identity choice rather than a stat-only pick.

## 3. The mechanic: Weapon Branch as a fourth purchasable category

GDD §6.4, quoted exactly, is currently: "Points buy exactly three things, deliberately few" — gear tier, spare mek part, mek secondary specialization. **This plan proposes a fourth: Weapon Branch** (and, per §4 below, its Munti-side counterpart, Support Branch — same mechanic, different content). Flagging that explicitly because it's a direct change to a LOCKED section — see §9 for what needs updating if this goes ahead.

**Pool: PERSONAL, not company.** A weapon branch is an investment in *that pilot's* identity and combat style, same category as their gear tier and their mek's secondary — not squad-wide logistics like a spare part or a recruit. Same pool, same "personal points only ever buy that pilot's own growth" rule `campaignEconomy.ts` already states as its own organizing principle for that pool.

**Tier-gated**, same shape the Mek Workshop doc already proposed for Tank's Maser Lance (D-tier minimum, so Tank reads as "the wall" before it reads as "also hits hard") — generalized here to every class's later branches, not just Tank's:

- 1st branch (first non-default weapon): unlockable from **D-tier**
- 2nd branch: unlockable from **C-tier**
- 3rd branch: unlockable from **B-tier**
- 4th branch: unlockable from **A-tier**, i.e. only once a pilot is already maxed on the tier ladder. This is deliberately the single most expensive, most "completionist" purchase in the game.

**Multiple branches, owned permanently, one equipped at a time.** This is the actual design fork worth flagging as Maxime's own call, not something I'm quietly deciding:

- **Option A — single permanent fork.** Same shape as mek secondary exactly: buy once, locked forever, done. Simple, cheap to build, but a pilot's weapon choice is "solved" the moment it's made and there's nothing left to buy after.
- **Option B — collect them over time, swap for free.** A pilot can eventually own 2, 3, or all 4 branches (money and tier-gating permitting), but only one is *equipped* going into a given mission — swapping which owned branch is active is a free pre-mission choice, not a repurchase.

**Decided 27 Aug: Option B.** Maxime, on swapping: "as long as its before a mission swaping is fine" — which only makes sense if there's more than one owned branch to swap between, so this settles Option A vs. B in B's favor too, not just the swap-cost question on its own. Equipping which owned branch goes into the next mission is free, and only available pre-mission (Transporter Pad, alongside the composition picker — see §9), never mid-mission. This gives personal points somewhere to go after a pilot hits A-tier and has a mek secondary — previously a dead end — and adds a real tactical layer for free: "swap Rourke to Impact Lance, this mission's got three Tank-path units" reuses content already paid for instead of asking for more of it.

## 4. Munti gets its own track — Support Branch, decided 27 Aug

The Mek Workshop doc's own §3 gives Munti one dual-use weapon (Reclaimer Beam, the Repair beam run in reverse), not a branch menu, because its identity is support, not weapon variety — and giving it three more guns would blur an identity that's already working. That was the right call to keep. But it left Munti with nothing to spend late-campaign personal points on, once its tier and mek secondary are both maxed, while every other class would have three more branches to chase.

**Decided: Munti gets a fourth branch option too — just aimed at its support kit instead of its weapon.** Reclaimer Beam stays singular, exactly as designed. What branches is *how the pilot heals*, using the same tiered, personal-pool, permanent-once-bought shape as Weapon Branch (§3) — same cost curve, same tier gates, same Option B collect-and-swap logic once that's settled:

- **Combat Medic** — Repair also applies a small heal-over-time tick for a turn or two after use. More value per repair, not more repairs.
- **Field Doctor** — Repair costs less, or gets an extra charge per mission. More repairs, not stronger ones — the inverse tradeoff from Combat Medic.
- **Aegis Ward** — the passive AoE regen aura's radius increases. Buffs the passive identity, not the active ability — the one branch that rewards just standing near people rather than spending an action.
- **Rapid Response** — heal range extends (2→3), or Munti can move and still heal the same turn if it can't already. Positioning flexibility instead of raw healing power.

This isn't a new system bolted onto the plan — it's the exact same Weapon Branch mechanic in §3, just with Munti's four options being support variants instead of guns. Worth naming the side effect plainly: this also fixes an asymmetry I'd flagged as a real gap without a real fix — Meeps/Tank/Reeps each had 4 branch options, Munti had 1. Now every class has 4. One mechanic, four classes, four choices each, no special case anywhere in the rules.

## 5. The conversion valve — personal points that would otherwise sit idle, decided 27 Aug

**Decided: personal points can convert to company points, at a deliberately bad rate, for any pilot — not just a maxed-out one.** This is a universal release valve, not a Munti-specific fix, and it's worth two separate justifications, both real:

1. **The dead-end problem.** Even with Support/Weapon Branch giving every class a fourth thing to buy, a pilot who's bought everything (tier maxed, mek secondary, all four branches) still has nowhere for new personal points to go. The valve means those points are never just stranded.
2. **The permadeath problem, which is the more interesting one.** `campaignEconomy.ts`'s own `applyMissionEarnings` already zeroes a permanently-lost pilot's banked personal points on death (it's how `applyPermadeathCheck` treats a lost pilot's balance). Right now, a pilot who dies with 400 unspent personal points just loses all 400 — nothing recoverable. A conversion valve gives a player a real, deliberate way to hedge that: bank a pilot's points into the shared company pool before a mission you're worried they might not survive, rather than watching them evaporate if the worst happens.

**Worth being honest about the tension this creates.** A valve that's too generous invites converting every pilot's points before every risky mission as routine hedging — which cuts against permadeath's whole emotional point, that loss should actually cost something. The lossy rate is the thing doing the work here: pick a rate bad enough that converting is a real sacrifice, not a free insurance policy, and it only makes sense either when points are genuinely idle (nothing left to buy) or when the risk is real enough to be worth the loss — not as a reflexive habit.

**Placeholder rate: 2 personal points → 1 company point.** One-directional only — company points never convert back to personal. That asymmetry matches how the two pools already behave: personal is scarce and pilot-specific, company is the shared, more fungible pool; a one-way valve keeps that relationship intact instead of turning the two pools into one pool with extra steps.

**Confirmed 27 Aug: the rate stays a placeholder on purpose.** Maxime: "conversion would be adjust in testing" — right instinct, and it matches §7's own discipline for every other number in this doc. Ship the mechanism, tune the number once there's a real harness to test it against, not before.

## 6. Where modules fit, and a rule worth keeping for future purchasables too

The Mek Workshop doc's modules list (Combat Stims, Reinforced Plating, Grapple Line, Smoke Charge, Signal Booster) is equipment, not identity — closer in kind to a spare mek part than to a branch choice. **Confirmed 27 Aug: COMPANY pool.** Maxime's own framing nails it: "i see it like XCOM. company pool." That closes a loop back to the Mek Workshop doc's own opening ask — style the Workshop room "like XCOM's Engineering bay" — since XCOM's own resources (Elerium, alloys, weapon fragments) belong to the base, not the soldier, which is exactly the "campaign-wide logistics resource, not a per-pilot investment" framing `campaignEconomy.ts` already uses for spare parts. Modules sit on the same shelf.

That gives a clean rule, worth stating plainly since it'll keep paying off for any *future* purchasable category too, not just these two:

> **PERSONAL pool = pilot identity/skill** (gear tier, mek secondary, weapon/support branch). **COMPANY pool = squad logistics/equipment** (spare parts, modules, recruits).

**Cutting Emergency Foam** — Maxime had no strong pull either way ("i dunno. forgot about it."), so going with the original recommendation rather than leaving it stranded: it's a self-stabilize charge that reads as a second way to buy what the Fabricator track's spare parts already sell narratively, and the GDD's own stated philosophy for this economy is "deliberately few." Five modules, not six. Cheapest possible reversal if it turns out to be missed — it's one list entry, not a system.

**Confirmed 27 Aug, second half: bought individually, not unlocked once.** Maxime: "you gotta buy each individual module to have multiple of each." That changes the shape from what I first drafted — not a permanent per-pilot unlock like mek secondary, but a consumable stockpile: each purchase adds one usable charge, a mission spends it, and carrying three Combat Stims into a future mission means having bought three. Closer to how spare mek parts already work (`purchaseSpareParts` — buy one, add one to a count) than to `purchaseMekSecondary`'s one-and-done shape, which is what the module pricing below should have been modeled on from the start.

**One inference worth flagging rather than assuming silently: is the stockpile per-pilot, or one shared company armory?** "I see it like XCOM" points toward shared — XCOM's own consumables (grenades, medkits) live in one armory and get equipped per-soldier per-mission, not owned by a soldier permanently. Reading it that way: `CampaignState` gets a company-wide stock count per module type (`moduleStock: Record<ModuleId, number>`), buying a Combat Stims charge adds to that shared pool, and equipping one onto a specific pilot for the next mission (same Transporter-Pad-adjacent moment as the branch equip-swap in §3) draws it down by one — consumed on use, not tied to that pilot afterward. Flagging this as my own read of "like XCOM," not something confirmed word-for-word — say if you actually meant per-pilot stockpiles instead.

Two consequences worth naming: the per-unit price should come down from what I first proposed, since you're buying one use now, not permanent access — something like **20-40 company points per charge** is a more honest starting band than the old 60-100 one-time figure, still placeholder, still sim-tested before it's real. And this raises a genuinely new open question: is there a cap on how many of one module type the armory can hold at once (mirroring Fabricator's own 2-primary/1-secondary ceiling), or can you stockpile as many as you can afford? Not answered here — see §11.

## 7. Every number below is a placeholder — same discipline as the Mek Workshop doc's own §2

Nothing here is tuned. This project's own standing rule for combat numbers ("a number only counts once it's run through the sim and passed") doesn't have an equivalent harness for economy numbers yet — there's no `combat_sim.py`-style tool that plays out a whole campaign's earn/spend loop. Worth building one before any of this ships, the same way the deploy-cap change got a real before/after sim pass rather than shipping on feel. Until then, treat every cost below as "here's roughly the shape," not a number to code against.

**Proposed branch costs (Weapon Branch and Support Branch both — same curve, deliberately, so no class's track is cheaper or more expensive than another's):** 150 / 220 / 300 / 400 for 1st through 4th branch. These sit in the same order of magnitude as the existing tier costs (140-320 for the D→C→B range) rather than dwarfing or trivializing them.

**A rough earn-rate sanity check, worth doing before proposing any number:** `KILL_BONUS`/`SURVIVAL_BONUS` are both 5, `OBJECTIVE_BONUS` is 10. A pilot having a good mission (a kill or two, survives, mission won) nets roughly 20-30 personal points. With the new full-roster deploy caps (10 in Act II, 15 in Act III — 26 Aug change), every active pilot deploys on effectively every mission now, so across a ~24-mission Act II/III campaign a consistently-performing pilot might bank somewhere in the 400-700 range over the whole run. That's enough for maybe 2-3 tier steps, or a mix of tier steps plus a branch or two plus the mek secondary — not enough to max tier *and* own all four branches *and* a secondary on the same pilot in one campaign (tier alone costs 1,320 total G→A; add all four branches and you're past 2,300). That's the right shape: owning everything is a real stretch goal, not a given — you specialize, you don't max out. The conversion valve (§5) doesn't really change this math, on purpose: a 2:1 loss rate means converting is never a more efficient path to value than just buying something outright.

## 8. What this doc deliberately does NOT cover

Per the Mek Workshop doc's own §5: new status effects (stun for Shock Claws, an attack-debuff for Suppression Autocannon, any future slow/root) are real engine work, not data. This doc is about the *currency and purchase structure* — whether a branch can be bought, from where, gated how. It is not about what any individual weapon or support branch actually does in combat. Keep those as two separate approval decisions: this structure could be greenlit and built against branches that are numbers-only (bigger attack, different range, a heal-over-time tick, a cheaper action cost) well before anyone touches a status-effect system. Every branch named in §3 and §4 above is numbers-only in this sense, worth noting — none of them need new engine plumbing beyond the purchase/equip system itself.

**One tuning principle worth locking in now, even though the actual damage numbers stay out of scope per above:** whatever attack bonus a branch eventually carries should scale *with* the G→A tier climb, not compete with it or flatten it out — the same additive pattern a mek's own track bonus already uses. Worth stating plainly since gear tier already does real work here: `data/combatTables.ts`'s live `TIERS` table climbs attack G→A as 100/106/112/118/125/132/140 across six steps — a real, additive, gently-accelerating curve already, not something waiting to be built. (Note for the record: an earlier draft of this section briefly proposed a *military*-rank damage bonus for Rourke specifically — Maxime's actual point was about gear tier, "im talking about g-a rank not military rank," so that's been pulled. The formula reasoning wasn't wrong, it was just answering a question nobody asked.)

## 9. If this goes ahead, what actually needs to change

**Docs**, per the project's own standing rule about decisions in chat drifting away from what's written down:

- **GDD §6.4** — "exactly three things" becomes four. Needs a real edit, not a footnote, since that line is quoted almost verbatim in this very doc's §3.
- **Data Pack §12** — needs the new branch-cost rows, the module-charge cost, and the conversion rate (once decided) added once numbers are sim-verified, same table that already holds the tier/secondary/spare-part costs.

**Code**, concretely, since I read both files fresh for this doc rather than guessing at their shape:

- `campaignEconomy.ts` needs one generic branch-purchase function, not two — Weapon Branch and Support Branch are mechanically identical (tier-gated, personal-pool, permanent, same cost curve), just pointed at a different content list per class. Building `purchaseWeaponBranch()` and a near-duplicate `purchaseSupportBranch()` would be exactly the kind of drifting-duplicate the build log already flags as a repeated failure mode on this project (the `pilotRegistry.ts`/`ALL_HOSTILE_MECHS` precedent `ShopPanel.ts`'s own header cites) — one `purchaseBranch(state, pilotId, branchId)` keyed off a per-class branch table is the right shape, same "fails cleanly" ok/reason result object the existing `purchaseMekSecondary()` already uses.
- A second new function, `convertPersonalToCompany(state, pilotId, amount)` — same result-object pattern, fails cleanly on an unknown/non-active pilot or insufficient personal balance, otherwise moves `amount` off that pilot's personal balance and `Math.floor(amount / 2)` onto `state.points` at the placeholder 2:1 rate.
- `ShopPanel.ts`'s `ShopEntry` union needs a new variant (`{ type: "branch"; pilotId: string }` or similar — one variant serving both Weapon and Support Branch, matching the one-function decision above). Recommending it render as a *third* button row inside the existing per-pilot card in `drawPilotRow()` — right under where tier-upgrade and mek-secondary already sit — rather than a whole new section. `ROW_H.pilot` (currently 96) will need to grow to fit a third button row — a small, contained number change, not a redesign. The conversion valve is a natural fourth control on that same card (a small "convert N personal → company" button), rather than its own section.
- **Equip/swap** (choosing which owned branch is active for the next mission, per Option B in §3) is a separate UI touch point from the purchase itself, and doesn't obviously belong in the shop at all — lives on `TransporterPad.ts` alongside the composition picker, confirmed pre-mission-only, never mid-mission, not a between-mission investment.
- **Modules need a third new piece, distinct from both of the above:** a company-wide stock table (`CampaignState.moduleStock: Record<ModuleId, number>`) rather than anything keyed to a pilot or mek, a `purchaseModuleCharge(state, moduleId)` function (company pool, adds one to stock, same result-object pattern), and an equip-from-armory step alongside the branch equip-swap on `TransporterPad.ts` — three separate systems now share that pre-mission screen (composition picker, branch equip, module equip), worth designing that screen's layout with all three in mind rather than bolting them on one at a time.

## 10. Ideas worth floating while I'm in here, not required for this to work

- **A small visual branch-tree** — even just 4 icons and connecting lines per class, not a real interactive tree — would give the "look, my pilot's build" payoff some visual home beyond a shop button list. Codex already exists as a doc/UI concept (`Bloom_Wars_Codex_Design_v1.md`) and might be the cheapest place to hang this rather than building new screen real estate for it.
- **A one-line ambient quip when a branch gets equipped** — reuses the ambient-line-bank pipeline that's already built and populated for other systems this project, rather than needing new UI or new writing infrastructure. Basically free if the pipeline's already there.
- **Longer shot, not this pass:** a pilot's equipped branch reskinning their sprite or portrait (even just a weapon-silhouette swap) would make the choice visible without a menu at all. Flagging it because it's a genuinely good idea, not because it's in scope here — this is Art Plan territory and shouldn't be assumed.

## 11. Status — one new open question, one inference to confirm, everything else decided

Since the last pass: modules are confirmed bought per-charge, not unlocked once (§6) — that part's settled. Two things from that same decision still need your eyes:

- **Shared company armory, or per-pilot stockpiles?** §6 reads "I see it like XCOM" as shared armory and explains why — confirm that's the right read, or correct it if you actually meant each pilot builds their own stock.
- **Is there a cap on how many charges of one module the armory can hold**, mirroring Fabricator's own ceiling, or unlimited if you can afford it?

Everything else is settled: Option B for branch ownership (§3), free pre-mission-only equip-swap, Emergency Foam cut (§6), modules from company pool (§6), and the conversion valve's rate deliberately left for testing (§5). The G→A tier ladder already scaling damage the way it should — see the tuning principle added to §8 — needed confirming, not building; nothing new there.

What's still true and unchanged: this is a design decided, not a feature built. §9's list of doc/code changes is real work, and per the project's own standing rule on scope, none of it starts without a separate go-ahead.

---

Sources: `Bloom_Wars_Mek_Workshop_And_Weapon_Progression_v1.md` (26 Aug, all weapon/module content this plan builds on), `engine/campaignEconomy.ts` (read in full, live code — every existing cost/pool/function cited above is transcribed from it, not recalled), `scenes/shop/ShopPanel.ts` (read in full, live code — the UI shape §9 proposes extending), GDD §6.4 and Data Pack §12 (the locked economy this plan proposes amending).
