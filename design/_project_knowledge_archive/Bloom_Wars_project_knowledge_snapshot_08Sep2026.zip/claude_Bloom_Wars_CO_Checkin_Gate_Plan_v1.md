# THE BLOOM WARS — CO Check-In Gate Plan v1

**Written 28 Aug 2026, in chat with Maxime. Status: plan only, not yet built.**

**Update, 1 Sep 2026: built, verified, and committed.** Implemented exactly as designed below, with one deliberate simplification found while wiring it — see the new "Built, 1 Sep 2026" section right after §5 for what shipped, how it was verified (real typecheck/lint/1194-test-suite/build pass in a cloud sandbox — this device has no `device_bash`, so verification ran the same way this project's other device-bash-less passes have), and the one open loose end (Maxime's own live playtest of the actual block/nudge screens hasn't happened yet).

Grew directly out of the Hub NPC-discoverability gap flagged against `Bloom_Wars_Onboarding_Tutorial_Plan_v1.md` §0: a third "tutorial," distinct from that doc's Mission 1 combat hints and from `Bloom_Wars_Antfarm_Grid_v1.md` §3e's still-open room-placement tutorial. This one teaches a new player that Hub NPCs, specifically the CO (Arangement of Content, Carabil, seated in the grotto), are real, talkable, and worth finding.

## 0. How this got locked, in order

Worth keeping the reasoning on record, not just the conclusion:

- **Started as a Hub-entry nudge:** a first-time-only passive line on walking into the Antfarm. Considered, not what shipped as the plan.
- **Relocated to Debrief.** Maxime's own call: *"Maybe fold it as mission debrief. Talk to the co before anything get done nudge."* A stronger fit than the Hub-entry version: debrief-to-CO is a real military beat, not an arbitrary popup, and it reuses the exact pattern `Debrief.ts`'s existing `lastMissionEcho` flag already proves out (Debrief sets state, Hub reads it on next entry).
- **Frequency: once only.** Maxime: *"only once heavy nudge."* Not a per-mission ritual. The recurring version was raised and explicitly parked in the prior conversation, gated on the CO actually having real content to say every time. Not built here.
- **Enforcement: a real gate, not a passive line.** Maxime: *"cant start a new mission if you havent debrief[ed with the CO]. after [the debrief]."* The next mission's BEAM DOWN is blocked until the CO has been talked to once.

## 1. The mechanism

**New state: `CampaignState.hasCheckedInWithCo` (boolean, default false).**

Lives in `CampaignState`, not the localStorage flag the Mission 1 combat tutorial uses. That precedent is deliberately different: the tutorial hint is a meta flag ("has this browser already learned this UI"), built on purpose to survive New Game. This one is a narrative beat tied to this specific playthrough's Rourke and CO relationship, so a fresh campaign should have to earn it again. Lives in the save, resets with it.

**Trigger: the first debrief this `CampaignState` has ever produced**, not a hardcoded `mission_amaranth_1` check. Functionally identical today (Mission 1 is always first), but keeps the gate reusable for The Other Side or any future campaign without a second copy of it, same campaign-agnostic discipline the talk-down system already holds to. Concretely: `Debrief.ts` checks whether this is the first debrief of the save and whether `hasCheckedInWithCo` is still false; if both, it shows the debrief-side nudge text (§1 below).

**Satisfying condition:** the player enters Talk range of Arangement of Content specifically. Reuses the exact proximity check `Hub.ts`'s `submitChat()` already added for the CO build-request handler ("is the player standing next to the CO, not just any NPC"). The first Talk or chat interaction that reaches him while `hasCheckedInWithCo` is false sets it permanently true. No new detection logic, same check, new consumer.

**The gate itself:** `canLaunchMission()` (`campaignState.ts`) gains one more condition alongside the existing Munti-guarantee check. `TransporterPad.ts`'s BEAM DOWN blocks exactly the way it already does for that check: same UI convention, second reason.

**Directional messaging, two places.** A hard block with no direction reads as a bug, not a nudge:
1. Debrief shows a line the first time through, something like: *"Report to the CO in the grotto before your next deployment."*
2. If the player skips past that and tries BEAM DOWN anyway, the block message repeats the direction: something like *"The CO hasn't signed off yet, find him in the grotto."*

## 2. Open questions, need your call

- **Exact block/debrief copy.** Placeholder text above; real wording is a texture call, flagging that it needs a pass, not asking you to write it now. **Resolved by shipping the placeholder text as-is** — see the Built section below; both lines above went in verbatim rather than waiting on a separate copy pass, since nothing about them was placeholder-quality-bad, just unreviewed. Easy to swap later.
- **Does this first CO interaction deserve a bespoke line, or is the generic ambient pool fine for it?** He still has zero unique content. A once-ever gate riding on a generic line is a much smaller risk than the parked per-mission ritual would've been, but "the one moment the game hard-stops you to go talk to this guy" landing on a random line is worth a beat of thought. Doesn't block building the gate; can ship on the generic pool and get a real line whenever his content work happens. **Now moot in practice** — the CO's own bespoke Greeting/Farewell/Advice bank shipped the same day as this gate (see `Bloom_Wars_CO_Bespoke_Dialogue_Bank_v1.md`), so whatever line actually satisfies the gate is very likely one of his real bespoke lines already, not a generic-pool placeholder.
- **Non-issue worth flagging anyway:** if a player wanders into the grotto and talks to him before ever trying to deploy again, the flag's already true and the gate never visibly fires. Correct behavior, just worth knowing so a playtest that never sees the block isn't mistaken for a bug.

## 3. What this doesn't touch

No change to Debrief's other behavior (scoring, gear/mek purchases, the RECRUIT button): this adds one read and one conditional line, not a rework. No change to any other NPC's Talk or chat handling. No change to the combat tutorial's own localStorage flag: separate system, separate precedent, deliberately not reused here (see §1). Doesn't touch the still-open Hub room-placement tutorial (`Antfarm_Grid_v1.md` §3e) at all.

## 4. Doc update flagged

`Bloom_Wars_GDD_v0_2.docx` §3, "Core gameplay loop," lists the mission loop beat by beat, ending on "Debrief: points awarded, then the between-mission layer... (§6.4)." This gate adds a real step to that loop for the very first debrief specifically, worth a line there once it ships. Same standing blocker as every other GDD edit right now: this project only has the GDD's extracted text, not the real `.docx` bytes, so this needs your own hand or a session with real file access, not something I can apply from here. Flagged now so it doesn't get lost, not asking you to do it yet. **Still open as of 1 Sep 2026** — the gate has shipped in code, this doc update has not.

## 5. Sizing

Small-to-medium, and every piece of it reuses an existing pattern: the gate shape (Munti-guarantee precedent), the CO-proximity check (build-request precedent), the Debrief-to-Hub flag-passing shape (`lastMissionEcho` precedent). One new `CampaignState` field, one new condition on an existing gate function, one new conditional line on Debrief, no new UI component, no new detection logic. Doesn't cross into new-system territory the way the parked per-mission ritual version would have.

## 6. Built, 1 Sep 2026 — what actually shipped, and the one real design call made along the way

**Matches the design above almost exactly, with one substitution worth flagging: the "first debrief" trigger reuses `CampaignState.lastMissionEcho` instead of adding a second new field.** `lastMissionEcho` (Social Sim Roadmap #9, already in the save) is undefined until `Debrief.ts`'s `create()` sets it for the first time, ever — so "is this the first debrief" and "has this save ever finished a mission" turn out to be the exact same question, answerable from state that already exists. This matters for more than just tidiness: without gating the block on "a debrief has actually happened," `hasCheckedInWithCo`'s own default-false would incorrectly block a brand-new campaign's Mission 1 before there's any CO interaction to have happened yet — exactly the "after the debrief" framing Maxime's own instruction already called for. `canLaunchMission()`'s new condition reads `state.lastMissionEcho !== undefined && !state.hasCheckedInWithCo`.

**hasCheckedInWithCo is satisfied by three interaction paths, not just the build-request one originally scoped** — because two of them (small talk, chat-driven Greeting/Farewell/Advice) didn't exist yet on 28 Aug when this plan was written, and only started existing the same day this gate did (`Bloom_Wars_Crew_Greeting_Farewell_Line_Bank_v1.md` / `Crew_Advice_Banter_Line_Bank_v1.md` / `CO_Bespoke_Dialogue_Bank_v1.md`'s own wiring). `Hub.ts` gained a single `markCoCheckedIn()` helper (idempotent, saves once) called from: ordinary Talk (`speak()`, the E-key/click interaction, regardless of which line actually fires), a chat build request to the CO, and small talk with the CO. Broader coverage than the original single-path design, same permanent-once-set behavior.

**Debrief's nudge is a new callout panel** (`drawCoCheckinNudge`, blue/informational — `#4a7a9a` border, matching the chat box's own established color), inserted into the same draw sequence as the Munti/bonus/lance callouts, reading exactly the placeholder text from §1 above: "Report to the CO in the grotto before your next deployment." **TransporterPad needed no new code at all** — `canLaunchMission`'s `reason` string was already wired straight into the BEAM DOWN block text, so the second placeholder line ("The CO hasn't signed off yet — find him in the grotto.") just had to be the gate's own `reason`, not a second implementation.

**Verified, not assumed — full account since this device has no `device_bash`:** staged every `src/` file, `package.json`/`package-lock.json`, `tsconfig.json`, `eslint.config.js`, `tools/lint-spoiler.mjs`, `index.html`, and the two `public/` assets into a cloud sandbox, ran `npm install` there, then `npx tsc --noEmit` (clean), `npx eslint .` (clean), `npx vitest run` (**1194/1194 passing, zero regressions** — specifically checked `campaignState.test.ts`'s existing `canLaunchMission` suite by hand first: every existing test case uses a freshly-created campaign state, which always has `lastMissionEcho === undefined`, so the new gate condition is provably a no-op against all of them), and `npm run build` (clean production build). Edited files (`engine/campaignState.ts`, `scenes/Debrief.ts`, `scenes/Hub.ts`) committed back to the connected folder with an mtime-drift guard, no conflicts.

**Genuinely still open:** nobody has actually seen the nudge panel or the block message render on screen yet — this was verified by code inspection, a byte-for-byte-provable non-regression argument against the existing test suite, and a clean typecheck/lint/test/build pass, not by playing through a full mission-to-debrief-to-second-mission loop in the browser (this session has no way to drive player movement in-game, a standing limitation noted elsewhere). Worth Maxime's own eyes the next time he finishes a mission and tries to launch a second one without having talked to the CO first — that specific sequence hasn't been watched happen live.
