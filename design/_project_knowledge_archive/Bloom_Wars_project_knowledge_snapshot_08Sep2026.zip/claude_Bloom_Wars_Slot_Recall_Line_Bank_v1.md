# Slot Recall Line Bank v1 — CLASS, STAGE_MOMENT, RIVAL, LOST, and two-fact

Writing lines per `claude_Bloom_Wars_Slot_Recall_Content_Brief_v1.md`'s own recommended order (CLASS/STAGE_MOMENT first, RIVAL next, LOST last and carefully, two-fact once single-slot content exists). 40 new lines total. Each is a full `SLOTTED_LINES` entry, same shape as the existing 39: `{ catalyst, echo, stage, slotType, flat, slotted }`, plus `slotType2` on the two-fact set.

**ROOM excluded, still blocked.** Its only spec predates the walkable Hub and doesn't obviously match `Hub.ts`'s real room set. Not writing against an unverified vocabulary.

**One honest correction to my own brief.** I'd framed CLASS/ROOM as "pick an existing flat line, write its slotted sibling." I only have the full live `LINE_BANK` text for Wolf in front of me (`Ambient_Line_Bank_Delivery_v1.md`'s own table), not the other eight catalysts' full 700+ lines. Retrofitting a "flat" line I can't verify word-for-word against the real bank risks claiming a match that isn't there, exactly the kind of thing this project checks for before shipping. So everything below is new flat + slotted content, same as the Munti Respect Bank's own approach, not a resort. Flagged plainly rather than quietly assumed.

## CLASS — 9 lines, love, Stage B

Each substitutes the speaker's own path (Meeps/Tank/Reeps/Munti) for an abstract stand-in ("my job," "my role") in an identity-flavored line.

| Catalyst | Flat | Slotted |
|---|---|---|
| Wolf | I don't care what my job title says on paper. Out there, my job is making sure nobody's standing alone. | I don't care what {CLASS} says on paper. Out there, my job is making sure nobody's standing alone. |
| Dog | Say what you want about the assignment. I already decided who I'm loyal to, and it isn't a job description. | Say what you want about {CLASS}. I already decided who I'm loyal to, and it isn't a job description. |
| Cat | My role's whatever keeps me useful enough that command doesn't reassign me somewhere worse. | {CLASS}'s whatever keeps me useful enough that command doesn't reassign me somewhere worse. |
| Crow | Everybody's got a theory about what my role's actually for. I've got three. None of them match the manual. | Everybody's got a theory about what {CLASS}'s actually for. I've got three. None of them match the manual. |
| Raven | I teach my own role the hard way, then I teach it to anyone green enough to still ask questions. | I teach {CLASS} the hard way, then I teach it to anyone green enough to still ask questions. |
| Bear | Don't need my role explained to me twice. Told me once, I did it my way ever since. | Don't need {CLASS} explained to me twice. Told me once, I did it my way ever since. |
| Fox | What my role says I did and what actually won that fight aren't always the same story. | What {CLASS} says I did and what actually won that fight aren't always the same story. |
| Rabbit | Doesn't matter what my role's called. If somebody on this crew needs looking after, that's the actual job. | Doesn't matter what {CLASS}'s called. If somebody on this crew needs looking after, that's the actual job. |
| Shark | My role's the floor, not the ceiling. I'm not staying inside it just because it's what's written down. | {CLASS}'s the floor, not the ceiling. I'm not staying inside it just because it's what's written down. |

## STAGE_MOMENT — 9 lines, love, Stage C

Gated correctly by the resolver, only fires for a pilot with a real recorded Command promotion. Reflective, pride-toned.

| Catalyst | Flat | Slotted |
|---|---|---|
| Wolf | Since I made rank, I stopped needing to be the loudest voice in the room to lead it. | Since I made {STAGE_MOMENT}, I stopped needing to be the loudest voice in the room to lead it. |
| Dog | Since I made rank, loyalty stopped being instinct. Now it's a decision I make on purpose, every day. | Since I made {STAGE_MOMENT}, loyalty stopped being instinct. Now it's a decision I make on purpose, every day. |
| Cat | Since I made rank, I still keep score. Just stopped pretending the squad isn't part of my own math anymore. | Since I made {STAGE_MOMENT}, I still keep score. Just stopped pretending the squad isn't part of my own math anymore. |
| Crow | Since I made rank, people actually sit through my theories instead of walking off halfway. Rank's good for something. | Since I made {STAGE_MOMENT}, people actually sit through my theories instead of walking off halfway. Rank's good for something. |
| Raven | Since I made rank, my lessons stopped being suggestions. Wish that had happened before some of what taught me, not after. | Since I made {STAGE_MOMENT}, my lessons stopped being suggestions. Wish that had happened before some of what taught me, not after. |
| Bear | Since I made rank, I still keep my distance. Just further out now, so I can see more of what's coming. | Since I made {STAGE_MOMENT}, I still keep my distance. Just further out now, so I can see more of what's coming. |
| Fox | Since I made rank, half my old tricks stopped working. Command expects them now. Had to get better ones. | Since I made {STAGE_MOMENT}, half my old tricks stopped working. Command expects them now. Had to get better ones. |
| Rabbit | Since I made rank, I still worry about every one of them. Just get listened to now when I say something's wrong. | Since I made {STAGE_MOMENT}, I still worry about every one of them. Just get listened to now when I say something's wrong. |
| Shark | Since I made rank, ambition stopped being a solo project. Turns out it's a lot more useful pointed at a whole squad. | Since I made {STAGE_MOMENT}, ambition stopped being a solo project. Turns out it's a lot more useful pointed at a whole squad. |

## RIVAL — 9 lines, anger, Stage B

One real named rival per catalyst, gated on `RIVAL_THRESHOLD`, each catalyst's anger flavor pulled straight from its own established voice (protective for Wolf, personal for Dog, and so on).

| Catalyst | Flat | Slotted |
|---|---|---|
| Wolf | I've got a real problem with one pilot on this roster. Not personal. They break formation and somebody else pays for it. | My problem with {RIVAL} was never personal. They break formation and somebody else pays for it. |
| Dog | There's exactly one person on this ship I can't be in a room with for long. That's not a secret. Ask anyone. | {RIVAL} is exactly the one person on this ship I can't be in a room with for long. That's not a secret. Ask anyone. |
| Cat | I've done the math on one particular pilot more times than I'd like to admit. The math never comes out in their favor. | I've done the math on {RIVAL} more times than I'd like to admit. The math never comes out in their favor. |
| Crow | I've got a whole running theory about why one pilot on this crew rubs me wrong. Nobody wants to hear it. I keep updating it anyway. | I've got a whole running theory about why {RIVAL} rubs me wrong. Nobody wants to hear it. I keep updating it anyway. |
| Raven | There's one pilot I've stopped correcting. Not because they got better. Because they stopped listening, and that's a choice, not a mistake. | I've stopped correcting {RIVAL}. Not because they got better. Because they stopped listening, and that's a choice, not a mistake. |
| Bear | One pilot on this crew and I don't talk. Not a grudge. Just the truth of it, and I've made my peace with that truth. | {RIVAL} and I don't talk. Not a grudge. Just the truth of it, and I've made my peace with that truth. |
| Fox | There's one pilot whose approval I stopped chasing and started outmaneuvering instead. Works better. Feels better too, if I'm honest. | I stopped chasing {RIVAL}'s approval and started outmaneuvering them instead. Works better. Feels better too, if I'm honest. |
| Rabbit | One pilot on this crew makes me nervous in a way that isn't about the mission. I still watch their back anyway. Doesn't mean I like it. | {RIVAL} makes me nervous in a way that isn't about the mission. I still watch their back anyway. Doesn't mean I like it. |
| Shark | There's exactly one pilot on this roster I measure myself against, and it isn't friendly. Keeps me sharp. I'll take it. | {RIVAL} is exactly who I measure myself against, and it isn't friendly. Keeps me sharp. I'll take it. |

## LOST — 9 lines, sadness, Stage B

`{LOST}` only resolves off a real fallen Munti, so every line here is specifically about losing a Munti, not a generic squadmate. Kept quiet and grounded rather than reaching for drama, matching each catalyst's own established grief register.

| Catalyst | Flat | Slotted |
|---|---|---|
| Wolf | We lost our Munti once. I still count heads wrong some mornings, like they're still supposed to be one of them. | We lost {LOST}. I still count heads wrong some mornings, like they're still supposed to be one of them. |
| Dog | Nobody had to tell me to grieve harder over our Munti than anyone else. Losing them broke something specific, not something general. | Losing {LOST} broke something specific in me, not something general. Nobody had to tell me why. |
| Cat | I've run the numbers on what losing our Munti actually cost this crew. The math still doesn't close. I don't think it's supposed to. | I've run the numbers on what losing {LOST} actually cost this crew. The math still doesn't close. I don't think it's supposed to. |
| Crow | I had three theories about what would happen if we ever lost our Munti. None of them prepared me for what actually did. | I had three theories about what would happen if we ever lost our Munti. Losing {LOST} matched none of them. |
| Raven | I've replayed the approach where we lost our Munti more times than I'll admit out loud, looking for the lesson. Some losses don't have one. | I've replayed the approach where we lost {LOST} more times than I'll admit out loud, looking for the lesson. Some losses don't have one. |
| Bear | I was watching the whole field the day we lost our Munti. Saw everything except the one second that mattered. | I was watching the whole field the day we lost {LOST}. Saw everything except the one second that mattered. |
| Fox | I've got a trick for every bad moment except one. Losing our Munti isn't something I've figured out how to misdirect around yet. | I've got a trick for every bad moment except one. Losing {LOST} isn't something I've figured out how to misdirect around yet. |
| Rabbit | I check on everyone twice as much since we lost our Munti. Doesn't bring them back. Makes the rest of it feel less like it's for nothing. | I check on everyone twice as much since we lost {LOST}. Doesn't bring them back. Makes the rest of it feel less like it's for nothing. |
| Shark | Losing our Munti is the one loss I never turned into fuel. Tried. Couldn't make that one useful. Just let it be what it is. | Losing {LOST} is the one loss I never turned into fuel. Tried. Couldn't make that one useful. Just let it be what it is. |

## Two-fact — 4 lines across 2 pairs

RIVAL+LOST (anger, grief hardened into resolve) and SQUADMATE+STAGE_MOMENT (love, a witness to the promotion). Two catalysts each, not all nine, first slice only.

| Catalyst | Slot 1 | Slot 2 | Echo | Stage | Flat | Slotted |
|---|---|---|---|---|---|---|
| Dog | RIVAL | LOST | anger | B | My rival still gets under my skin. Doesn't come close to what losing our Munti did. I know the difference now. Didn't used to. | {RIVAL} still gets under my skin. Doesn't come close to what losing {LOST} did. I know the difference now. Didn't used to. |
| Shark | RIVAL | LOST | anger | C | My rival pushes me to be better. Losing our Munti taught me why that actually matters, past just winning. | {RIVAL} pushes me to be better. Losing {LOST} taught me why that actually matters, past just winning. |
| Wolf | SQUADMATE | STAGE_MOMENT | love | C | Someone was there the day I made rank. Didn't say much. Didn't need to. | {SQUADMATE} was there the day I made {STAGE_MOMENT}. Didn't say much. Didn't need to. |
| Rabbit | SQUADMATE | STAGE_MOMENT | love | C | Someone was the one who told me I'd earned my rank, before I believed it myself. | {SQUADMATE} was the one who told me I'd earned {STAGE_MOMENT}, before I believed it myself. |

## Naming lock check

No new proper nouns anywhere above, no book-side terminology. Same as every prior delivery, `tools/lint-spoiler.mjs` has final say at build time.

## Ready to hand off

All 40 entries drop straight into `crewBanterSlots.ts`'s `SLOTTED_LINES` array in the existing `{ catalyst, echo, stage, slotType, flat, slotted }` shape, `slotType2` added on the four two-fact entries. No resolver changes needed, per `Recall_Item3_Delivery_v1.md`'s own note. Whoever wires this in (Claude Code, live repo access) should run the same content-sanity check Roadmap #17 used: every `flat` string gets its own real check for accidental duplication against the live bank before merge, since these are new text, not transcribed from an existing source this time.
