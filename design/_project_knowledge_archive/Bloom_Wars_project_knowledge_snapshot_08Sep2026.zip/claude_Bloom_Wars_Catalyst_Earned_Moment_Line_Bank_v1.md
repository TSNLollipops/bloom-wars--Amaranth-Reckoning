# THE BLOOM WARS — Catalyst-Flavored Earned Moments: Line Bank v1

Written 28 Aug 2026. Scoped in chat off Maxime's ask for "story based voiceline, for each animal" — landed on per-catalyst arcs (not path-flavor, see Social Sim Roadmap #18, which stays untouched by this doc) and trigger-based content, earned by a real tracked pilot moment rather than a mood/context roll. Content only, zero code shipped here — same standing rule as everything else on the social/hub side of this project.

## 0. Why these three events, and what already exists

Rather than inventing new triggers, this reuses events already tracked on the pilot record (`Bloom_Wars_Antfarm_Carrier_Hub_v1.md`'s tally system) that don't yet have a catalyst-aware reaction:

- **Legend** (`isLegend()`, heroicTallyCount >= 5, saves + kill assists + rescues combined) — currently just a roster tag, no line fires at all.
- **Rescue** — fires a line already (`pickRescueLine`), but it's flat, no catalyst check.
- **Save-log milestone** — flagged in `Bloom_Wars_Munti_Respect_Line_Bank_v1.md`'s roadmap entry (#13) as "not built," and originally scoped Shark/Crow only. This generalizes it to all nine.

**Not included:** Kill assist. No flavor-text slot exists for it yet (missions don't render custom text there per Roadmap #13's own note), so it needs new UI plumbing before content has anywhere to attach. Parked, not written.

Stage promotion and the rank greeting already have catalyst-flavored banks live (Roadmap #4/#39). Not touched here.

**One reading called, worth flagging.** The original Munti Respect roadmap entry framed the save-log idea as *squadmates* (Shark/Crow) reacting to a Munti's growing count. This bank instead has the Munti react to their own count, in their own catalyst voice, same structure as Legend and Rescue. Simpler, one hook shape for all three triggers. If you actually wanted the squadmate-reaction version, flag it and I'll redo that section.

**Flat, no Stage or Echo split.** Same shape as the Munti Respect bank, not a new axis on `LINE_BANK`. One line set per catalyst per trigger.

## 1. LEGEND — fires once, first time a pilot crosses the threshold

| Catalyst | Line |
| --- | --- |
| Wolf | Five for the squad now. Wasn't chasing a number, just doing right by you all. |
| Dog | Didn't count until someone else did. Guess I just keep showing up. |
| Cat | Five times the math worked out in the squad's favor. I'm allowed to be a little proud of that. |
| Crow | Five! That's a party. Somebody's buying, and it's not going to be me. |
| Raven | Five good calls, five good outcomes. Write it down somewhere, so the next green pilot's got something to aim for. |
| Bear | Didn't need anyone to notice. Wish they hadn't. |
| Fox | Five clean plays, five times it worked. Not luck. Don't tell anyone I said that. |
| Rabbit | Five people who got to go home because I was there. That's the only number I'm keeping. |
| Shark | Five. On record, on the log, not up for debate. Who's next to beat it. |

## 2. RESCUE — fires each time, catalyst-flavored, two per catalyst for variety

| Catalyst | Lines |
| --- | --- |
| Wolf | "Not leaving anyone out there. That's not heroics, that's just how this squad runs." / "Got them back. That's the job, that's always been the job." |
| Dog | "Didn't think twice. Wasn't going to leave them out there, full stop." / "Somebody's out there hurt, I go. Doesn't matter whose name's on the roster." |
| Cat | "Left them out there, I'm down a body next mission. Simple math, really." / "Don't make this a thing. I did the practical play, that's all." |
| Crow | "Pulled them out just in time for a good story. I'm telling it tonight." / "Rescue complete. Somebody owes me a drink for that one." |
| Raven | "Textbook pickup. Take notes, that's how it's done." / "Got them out clean. Worth walking through how, later, for whoever's green." |
| Bear | "They're back. Don't need a parade about it." / "Handled it. Wasn't going to make it anyone else's problem." |
| Fox | "Slipped in, got them, slipped out. Nobody even saw me do it." / "Called the gap before anyone else did. Worked exactly like I figured." |
| Rabbit | "They're safe. That's all that matters to me right now." / "Got to them in time. I'll actually breathe again in a minute." |
| Shark | "That's another one on the board. Keeping count, same as always." / "Pulled them out. Put a mark next to my name for it." |

## 3. SAVE-LOG MILESTONE — Munti only, fires when their own save count crosses a threshold

Threshold number not decided here (Munti Respect's own grief threshold used 3 as its illustrative number; this doesn't need to match it). `{COUNT}` stands in for the actual number at the crossing.

| Catalyst | Line |
| --- | --- |
| Wolf | {COUNT} of you back on your feet because the squad needed you there. That's the only reason that number matters to me. |
| Dog | {COUNT} times now. I'm not stopping at whatever number you're expecting. |
| Cat | {COUNT} saves. Do the math on what this squad loses if I ever stop showing up. |
| Crow | {COUNT}! Somebody get the good stuff, we're celebrating this one properly. |
| Raven | {COUNT} on the log. Every one of them's a lesson for the next pilot who goes down. |
| Bear | {COUNT}. Wasn't counting. Somebody else clearly was. |
| Fox | {COUNT} pulls, {COUNT} clean escapes. Nobody's caught me short yet. |
| Rabbit | {COUNT} people who got to walk away. I remember every one of their faces. |
| Shark | {COUNT} on the board. Ask me again after the next mission, it'll be higher. |

## 4. Integration notes, for whenever this gets wired

Three separate hook points, each a small touch, not a new system:

- **Legend** needs a one-time-fired flag on the pilot record (same shape as `stagePromotedAt`), since `isLegend()` today is a derived boolean with no memory of whether the crossing was already announced.
- **Rescue** needs `pickRescueLine` to take the rescuer's catalyst and index into this bank instead of the flat `RESCUE_LINES` pool. Existing `{r}`/`{w}` name-substitution pattern can carry over if wanted, though these lines don't currently use it.
- **Save-log milestone** needs an actual threshold decided, plus a check on `recordSave()` for whether the new length crosses it, same shape as the existing `GRIEF_THRESHOLD` check on `recordMuntiLost()`.

## 5. What this doesn't decide

- Kill assist flavor text (parked, needs a text slot built first).
- The exact save-log milestone number.
- Whether Legend, once it has a real line, should also update the roster-card tag interaction or stay a chat-only reveal.
- Whether the squadmate-reaction reading of save-log milestones (see §0) is wanted instead of or alongside this version.
